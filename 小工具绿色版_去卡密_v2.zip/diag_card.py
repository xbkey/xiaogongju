# -*- coding: utf-8 -*-
"""卡密连不上时自查：检测本机服务端、配置文件指向、与官方对比。"""
import json
import os
import socket
import sys

PORT = int(sys.argv[1]) if len(sys.argv) > 1 else 8765


def probe(host, port, timeout=3):
    s = socket.socket()
    s.settimeout(timeout)
    try:
        s.connect((host, port))
        return True
    except Exception as ex:
        return False
    finally:
        s.close()


def main():
    print("==== 卡密连接诊断 ====")
    here = os.path.dirname(os.path.abspath(__file__))
    print("[1] 本机卡密服务端 127.0.0.1:%d" % PORT,
          "在线" if probe("127.0.0.1", PORT) else "未监听")
    print("    若未监听：请先运行 一键启动.bat 或 point_local_card.py，")
    print("    或在解压目录运行 python cardserver/card_server.py")

    print("[2] 配置文件指向（本机加密，逐目录尝试读回）")
    appdata = os.environ.get("LOCALAPPDATA") or ""
    dirs = []
    if appdata:
        dirs.append(os.path.join(appdata, "XiaoGongJu", "data", "小工具源码"))
        dirs.append(os.path.join(appdata, "XiaoGongJu", "app", "小工具源码"))
    dirs.append(os.path.join(here, "小工具源码"))
    for d in dirs:
        p = os.path.join(d, "card_config.json")
        if not os.path.isfile(p):
            continue
        sys.path.insert(0, d)
        try:
            import zsf_gift_grabber as Z
            cfg = Z._card_cfg_load() or {}
            enc = cfg.get("server_enc") or ""
            addr = Z._dec_addr(enc) if enc else "(空)"
            print("    %s" % p)
            print("        -> 卡密服务端地址 = %s" % addr)
        except Exception as ex:
            print("    %s 读取失败：%s" % (p, ex))

    print("[3] 内置默认地址（源码版已改本机；原版 exe 取决于上面配置）")
    try:
        import zsf_gift_grabber as Z2
        print("    DEFAULT_CARD_SERVER = %s" % Z2.DEFAULT_CARD_SERVER)
    except Exception:
        pass

    print("[4] 解析卡密服务端域名（确认 DNS/外网）")
    print("    官方 1.92.106.89:8765 在线" if probe("1.92.106.89", 8765) else
          "    官方 1.92.106.89:8765 不可达（与本地版无关）")

    print("==== 结论 ====")
    if not probe("127.0.0.1", PORT):
        print("★ 本机卡密服务端没起来 —— 这是「无法连接」的直接原因。")
        print("  先确保 一键启动.bat / point_local_card.py 跑过，")
        print("  或在解压目录开一个黑窗口跑：python cardserver/card_server.py")
    else:
        print("★ 本机服务端在线，仍连不上请检查配置地址是否也是 127.0.0.1:%d" % PORT)


if __name__ == "__main__":
    main()
