# -*- coding: utf-8 -*-
"""路 B：把原版「小工具.exe」的卡密服务端指到本机，并拉起本机服务端。

不改 exe 任何字节。原理见下，但比旧版多了一步：写完后**本进程直接把卡密
服务端拉起来**（后台，独立进程），省得用户再开一个窗口。

  原版 exe 启动器把源码释放到 %LOCALAPPDATA%\XiaoGongJu\app，数据放在
  %LOCALAPPDATA%\XiaoGongJu\data\小工具源码，base_dir() 指的就是后者。
  card_config.json 在 _entry.py:USER_SETTINGS 名单里 —— 打包时「只补缺、
  绝不覆盖」，所以我们预先放进去的这份会一直留着。

  CardGate.__init__ 读服务端地址优先级：
      本机加密配置 card_config.json 的 server_enc  >  内置默认地址
  → 官方卡密端被本机端顶掉。

  ★ 配置文件必须用客户端自己的 _boot_key() 加密（绑定机器码）；所以这个脚本
    必须在本机运行，拷到别的机器上是解不开的。

用法： python point_local_card.py [端口]
"""
import base64
import hashlib
import os
import subprocess
import sys
import time

PORT = int(sys.argv[1]) if len(sys.argv) > 1 else 8765
ADDR = sys.argv[2] if len(sys.argv) > 2 else "http://127.0.0.1:8765"

here = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(here, "小工具源码"))
sys.path.insert(0, os.path.join(here, "web"))

import zsf_gift_grabber as Z            # noqa: E402

try:
    srv = Z._enc_addr(ADDR)
except Exception as ex:
    raise SystemExit("地址加密失败：%s" % ex)

cfg = {}
try:
    cfg = Z._card_cfg_load() or {}
except Exception:
    cfg = {}
cfg["server_enc"] = srv
cfg["card"] = "LOCAL-OFFLINE"
cfg["grace_hours"] = 0

targets = []
appdata = os.environ.get("LOCALAPPDATA") or ""
if appdata:
    root = os.path.join(appdata, "XiaoGongJu")
    targets += [
        os.path.join(root, "data", "小工具源码"),   # 单文件 exe 实际数据目录
        os.path.join(root, "app", "小工具源码"),
    ]
targets.append(os.path.join(here, "小工具源码"))     # 源码版（本目录）

n = 0
for d in targets:
    if not os.path.isdir(d):
        try:
            os.makedirs(d, exist_ok=True)
        except OSError:
            continue
    path = os.path.join(d, "card_config.json")
    try:
        Z._safe_save_json(path, cfg, indent=1, key=Z._boot_key())
        back = (Z._safe_load_json(path, Z._boot_key())[0] or {})
        good = back.get("server_enc") == srv
        print("  %s %s" % ("OK  " if good else "FAIL", path))
        n += 1 if good else 0
    except Exception as ex:
        print("  FAIL %s（%s）" % (path, ex))

print("%d 处配置已写入，地址 = %s" % (n, ADDR))

# ---- 拉起本机卡密服务端（独立后台进程）
srv_py = os.path.join(here, "cardserver", "card_server.py")
if os.path.isfile(srv_py):
    try:
        subprocess.Popen([sys.executable, srv_py, "--host", "127.0.0.1",
                          "--port", str(PORT)], creationflags=0x08000000)
        print("已拉起本机卡密服务端（127.0.0.1:%d），请保持本窗口/程序运行。" % PORT)
    except Exception as ex:
        print("卡密服务端启动失败：%s（请改用一键启动.bat 或手动启动）" % ex)
else:
    print("未找到 cardserver/card_server.py，请确认本目录完整。")

print("现在可以直接启动 小工具.exe 了；卡密框随便填就能通过。")
if n == 0:
    sys.exit(1)
