@echo off
chcp 65001 >nul
cd /d "%~dp0"
title 小工具 · 去卡密版

echo ============================================================
echo   小工具 去卡密版  一键启动
echo ============================================================
echo.

where python >nul 2>nul
if errorlevel 1 (
    echo [!] 没检测到 Python，请先安装 Python 3.8 以上
    echo     https://www.python.org/downloads/
    pause
    exit /b 1
)

echo [1/2] 把卡密服务端指向本机并写入配置...
python "%~dp0point_local_card.py"
if errorlevel 1 (
    echo [!] 配置写入失败
    pause
    exit /b 1
)

echo [2/2] 启动网页版（会自动拉起本机卡密服务端）...
echo.
echo ============================================================
echo   网页版地址： http://127.0.0.1:8000
echo   卡密随便填（哪怕是 1），都会通过。
echo   本机卡密服务端必须保持运行，关了工具会掉线。
echo ============================================================
echo.

python "%~dp0run_web.py"
pause
