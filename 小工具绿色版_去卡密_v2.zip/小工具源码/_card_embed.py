# 自动生成（build.bat 打包前调用 _gen_card_embed.py）—— 勿手改
CARD_SERVER_ENC = 'EgcSM1tdS3JeXhdKXVZtUEhcdFpc'   # 已改为本机自建服务端
