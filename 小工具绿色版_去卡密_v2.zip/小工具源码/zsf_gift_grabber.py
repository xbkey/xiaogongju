# -*- coding: utf-8 -*-
"""
小工具（多账号隔离版）
=================================
站点：www.zsf.com（实际跳转 www.321kf.com），微信扫码登录后领取「50元真充」礼包。

三个页面：
  1. 礼包领取 —— 多账号隔离抢礼包（v1.1.2 起支持「只领选中账号」，单独抢一个号）
  2. 论坛签到 —— Discuz 论坛（苍月/萝卜/奇速/八二）Cookie 模式签到
  3. QQ群签到 —— 通过 OneBot 11 WebSocket 客户端（NapCat / LLOneBot /
     Lagrange / go-cqhttp 等）拉取群列表、给勾选的群发自定义签到消息、
     给指定 QQ 号点赞（v1.1.0 起不再支持「给全部好友点赞」）

核心特性：
  1. 自动检测本机浏览器（Chrome / Edge / 360 / 2345 / QQ ...）
  2. 多账号互相隔离：每个账号独立的浏览器 profile 目录 + 独立调试端口，
     cookie / 登录态 / localStorage 完全隔离，互不串号
  3. CDP 直连控制浏览器，不依赖 chromedriver，不受浏览器版本升级影响

数据目录（EXE 同目录）：
  LOCALAPPDATA%/zsf_gift_browser_data/browser_data_<账号>/ 浏览器隔离数据(纯ASCII路径)
  accounts.json      账号列表
  records.json       领取记录
  config.json        程序配置
  forum_accounts.json  论坛登录 Cookie + 签到设置
  qq_signin.json       QQ 群签到设置（WS 地址、群勾选、消息、点赞）
"""
import os
import re
import io
import sys
import json
import time
import socket
import random
import threading
import collections
import html
try:
    import ctypes
except Exception:                 # 非 Windows 上没有 windll
    ctypes = None
import subprocess
import tempfile
import struct
import shutil
import zipfile
import hashlib
import hmac
# ★ v1.0.3 非对称加密：客户端-服务端通信从 PSK 对称 HMAC 升级为 ECDH 密钥协商。
#   客户端只存服务端公钥，不存私钥 → 被逆向也不能冒充服务端；
#   每次请求临时 ECC 密钥对 → 前向保密，抓包不能解密历史流量。
# ★ v1.0.6 加固：打包运行时（便携 Python）**没有 cryptography** —— 光靠上面的
#   try/except 会让 _HAS_ECC 恒为 False，非对称"名存实亡"（实际降级回 PSK）。
#   所以这里再挂一层**内置纯 Python P-256**（_ecc_pure.py，零依赖、离线可用）。
#   两条路径产出的会话密钥 K 逐字节一致（见 02/_test_ecc_pure.py 交叉验证）。
_ECC_BACKEND = "none"
try:
    from cryptography.hazmat.primitives.asymmetric import ec
    from cryptography.hazmat.primitives import hashes, serialization
    from cryptography.hazmat.primitives.kdf.hkdf import HKDF
    _HAS_ECC = True
    _ECC_BACKEND = "cryptography"
except Exception:
    try:
        import _ecc_pure as _EP
        ec = hashes = HKDF = None
        serialization = None
        _HAS_ECC = True
        _ECC_BACKEND = "pure"
    except Exception:
        _EP = None
        _HAS_ECC = False
# ★ v1.1.10 内置浏览器包改用 LZMA 压缩（体积 134MB→87MB）。
#   zipfile 里 lzma 是**延迟导入**的，PyInstaller 静态分析靠不住，
#   这里显式导入一次，保证打包后 zipfile 能解 LZMA 条目（否则释放浏览器会失败）。
import lzma                      # noqa: F401
import urllib.request
import urllib.parse
import webbrowser
from datetime import datetime, timedelta

import tkinter as tk
from tkinter import ttk, messagebox, filedialog, simpledialog

# ============================================================ 全局静默（★ v1.1.8）
# 本程序用 --noconsole 打包，自身没有控制台。此时只要拉起任何「控制台子进程」
# （powershell.exe / cmd.exe / tasklist.exe ...），Windows 就会给它**新建一个
# 控制台窗口并弹到前台** —— 就是用户看到的那个黑框。
# 这里统一给所有 subprocess 子进程注入 CREATE_NO_WINDOW，从根上不再弹窗。
# 对 GUI 子进程（chrome.exe）该标志被系统忽略，浏览器窗口不受任何影响。
CREATE_NO_WINDOW = 0x08000000

if os.name == "nt":
    _orig_popen_init = subprocess.Popen.__init__

    def _silent_popen_init(self, *args, **kwargs):
        """给每个子进程强制带上 CREATE_NO_WINDOW（与其他标志按位或，幂等）。"""
        try:
            kwargs["creationflags"] = (
                int(kwargs.get("creationflags") or 0) | CREATE_NO_WINDOW)
        except Exception:
            pass
        return _orig_popen_init(self, *args, **kwargs)

    subprocess.Popen.__init__ = _silent_popen_init
    # subprocess.run / call / check_output / check_call 内部都走 Popen，
    # 所以这一处改写即可覆盖全程序（含第三方库）的所有子进程调用。

# ============================================================ 常量
APP_NAME = "小工具"          # 对外显示名（窗口标题 / 顶栏）
SITE_URL = "https://www.zsf.com"
VERSION = "v1.1.29"          # 启动日志 + EXE 文件名（顶栏不再显示版本号）

# 账号输入框的占位提示（只做视觉，不写进 acc_var，避免被当成账号名添加）
ACC_PLACEHOLDER = "输入账号 ID"


def _vis_len(s):
    """粗略可视宽度：中文/全角按 2 个宽度算，用于判断文本会不会撑破面板。"""
    return sum(2 if ord(c) > 0x2E80 else 1 for c in str(s))


def _fit_vis(s, maxw):
    """把文本裁到指定可视宽度内，超出加省略号。"""
    s = str(s)
    if _vis_len(s) <= maxw:
        return s
    out, w = "", 0
    for c in s:
        cw = 2 if ord(c) > 0x2E80 else 1
        if w + cw > maxw - 1:
            break
        out += c
        w += cw
    return out + "…"


def _fmt_uid(uid):
    """把「站内身份」压成能塞进 190px 面板的短文本。

    抓取失败时源码会写入 '__ERR__[WinError 10053] 你的主机中的软件中止了…'
    这种超长错误串，直接显示会把详情行撑爆，这里压成 '失败(10053)'。
    """
    u = str(uid or "")
    if not u:
        return ""
    if u.startswith("__ERR__"):
        m = re.search(r"WinError\s*(\d+)", u)
        return "失败(%s)" % m.group(1) if m else "获取失败"
    return u


def _last_run_key(dt):
    """把执行时间统一成 'YYYY-MM-DD HH:MM'，用于定时去重比较。"""
    return dt.strftime("%Y-%m-%d %H:%M")


def _last_run_normalize(s):
    """兼容旧版配置：
    - 新版 'YYYY-MM-DD HH:MM' 精确到分钟，已执行过的时间点不再重复触发。
    - 旧版 'YYYY-MM-DD' 只记录日期，视为当天 00:00（当天改时间后仍会触发）。
    这样当天修改定时时间后，到新时间点会再次执行，不会隔天。
    """
    s = str(s or "").strip()
    if re.match(r"^\d{4}-\d{2}-\d{2}$", s):
        return s + " 00:00"
    if re.match(r"^\d{4}-\d{2}-\d{2} \d{2}:\d{2}$", s):
        return s
    return ""


try:
    import winreg
except ImportError:
    winreg = None

# 浏览器候选（名称, 内核, 候选路径）
BROWSER_CANDIDATES = [
    ("Chrome", "chromium", [
        r"C:\Program Files\Google\Chrome\Application\chrome.exe",
        r"C:\Program Files (x86)\Google\Chrome\Application\chrome.exe",
        r"%LOCALAPPDATA%\Google\Chrome\Application\chrome.exe",
    ]),
    ("Edge", "chromium", [
        r"C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe",
        r"C:\Program Files\Microsoft\Edge\Application\msedge.exe",
        r"%LOCALAPPDATA%\Microsoft\Edge\Application\msedge.exe",
    ]),
    ("Chromium", "chromium", [
        r"%LOCALAPPDATA%\Chromium\Application\chrome.exe",
        r"C:\Program Files\Chromium\Application\chrome.exe",
    ]),
    ("360极速浏览器", "chromium", [
        r"%LOCALAPPDATA%\360Chrome\Chrome\Application\360chrome.exe",
        r"C:\Program Files (x86)\360\360Chrome\Chrome\Application\360chrome.exe",
    ]),
    ("360安全浏览器", "chromium", [
        r"%APPDATA%\360se6\Application\360se.exe",
    ]),
    ("QQ浏览器", "chromium", [
        r"C:\Program Files (x86)\Tencent\QQBrowser\QQBrowser.exe",
        r"%LOCALAPPDATA%\Tencent\QQBrowser\QQBrowser.exe",
    ]),
    ("搜狗高速浏览器", "chromium", [
        r"%LOCALAPPDATA%\SogouExplorer\SogouExplorer.exe",
    ]),
    ("2345加速浏览器", "chromium", [
        r"C:\Program Files (x86)\2345Soft\2345Explorer\2345Explorer.exe",
    ]),
    ("Firefox", "gecko", [
        r"C:\Program Files\Mozilla Firefox\firefox.exe",
        r"C:\Program Files (x86)\Mozilla Firefox\firefox.exe",
    ]),
]

REG_EXES = ["chrome.exe", "msedge.exe", "firefox.exe", "360chrome.exe", "360se.exe",
            "QQBrowser.exe", "SogouExplorer.exe", "2345Explorer.exe"]


# ============================================================ 通用
def base_dir():
    # ★ 2026-10-14：加固单文件版下 sys.executable 是原生壳在 %TEMP% 的临时镜像，
    #   老写法会把 base_dir() 指到 %TEMP%（随时被清理）→ 用户设置每次启动全丢。
    #   启动器下发的 ZSF_DATA_ROOT 指向持久目录（与 _bootstrap_portable 的 live 同处）。
    _root = (os.environ.get("ZSF_DATA_ROOT") or "").strip().strip('"').strip("'")
    if _root:
        return os.path.join(_root, "data", "小工具源码")
    if getattr(sys, "frozen", False):
        return os.path.dirname(os.path.abspath(sys.executable))
    return os.path.dirname(os.path.abspath(__file__))


def _browser_data_root():
    """★ 移植 v10 隔离方法 ①（关键）：浏览器数据目录必须放在
    【纯 ASCII、无空格、无括号、无中文】的路径下。

    旧版放在 EXE 同目录（桌面"新建文件夹 (2)"，中文+空格+括号），
    Chrome 对 --user-data-dir 的解析在部分版本会出问题——表现为
    "浏览器开了但站点不导航 / 会话不稳定"。
    """
    base = os.environ.get("LOCALAPPDATA") or tempfile.gettempdir()
    path = os.path.join(base, "zsf_gift_browser_data")
    try:
        os.makedirs(path, exist_ok=True)
    except Exception:
        path = tempfile.gettempdir()
    return path


# 旧版 profile 位置（v3.0 及之前在 EXE 目录下，含中文/空格/括号路径）
OLD_DATA_DIR = os.path.join(base_dir(), "profiles")
# 新版：ASCII 干净路径（v10 同款方案）
DATA_DIR = _browser_data_root()
# ★ v1.1.1 cookie 备份目录：**必须放在 profile 外面**。
#   以前备份写在 profile 里（cookies_backup.json），一旦 profile 被清理软件
#   清空 / Chrome 重置，备份跟着一起没，只能重新扫码。
#   现在同时写两处：LOCALAPPDATA 一份 + 程序目录一份，恢复时取最新的那个。
COOKIE_BACKUP_DIRS = [os.path.join(DATA_DIR, "cookie_backup"),
                      os.path.join(base_dir(), "cookie_backup")]
ACCOUNTS_FILE = os.path.join(base_dir(), "accounts.json")
RECORDS_FILE = os.path.join(base_dir(), "records.json")
CONFIG_FILE = os.path.join(base_dir(), "config.json")
LOCK_FILE = os.path.join(base_dir(), "app.lock")


# ==================== ★ v1.0.3 非对称加密（ECDH）+ 本地数据落地加密 ====================
# 1) 客户端-服务端通信：ECDH 密钥协商（P-256）
#    - 服务端持有长期私钥 sk_s，公钥 pk_s 内嵌客户端
#    - 客户端每次请求临时生成 ECC 密钥对 (ek_c/dk_c)
#    - 双方用 ECDH 协商出会话密钥 K = HKDF(ECDH_shared)
#    - 用 K 替代原来的 PSK 做 HMAC 挑战应答
#    优势：客户端不存私钥 → 被逆向不能冒充服务端；每次 K 不同 → 前向保密
# 2) 本地数据落地加密仍用 PSK（同 v1.1.31），因为本地数据只在本机读写
# 3) 降级：如果 cryptography 包不可用（极端情况），回退到旧 PSK 模式
_DATA_MAGIC = b"ZSFENC01"
_PSK_ENC = "AAAABgITFidBGUoRXlRzU0RJewpaWEsQ"    # 本地数据加密用（见 _psk()）
_PSK_CACHE = None

# ★ 服务端 ECC 公钥（P-256，DER 格式，X9.62 uncompressed）—— 构建期由 _build.py 注入
#   如果为空（旧版/降级），走旧 PSK 模式
_SRV_PK_DER = b'0Y0\x13\x06\x07*\x86H\xce=\x02\x01\x06\x08*\x86H\xce=\x03\x01\x07\x03B\x00\x040qV\xee\xfdb\xe9l\xa2n{\x18XD\xb3\xa6%we\xff\x879\xab\xdf\xf5\x83\xf1;D\xc4mx\x9c\x9fX\xaa\xbfS\x95\x16?T\x84\x91J\x91|G\xe0\t}/\xa8\x86\xd1\xa2O\xf83\xda\x90\x81L\xce'


def _psk():
    """本地数据加密密钥（仅用于本地文件加密，不再用于网络通信）。"""
    global _PSK_CACHE
    if _PSK_CACHE is None:
        _PSK_CACHE = _dec_addr(_PSK_ENC) or "zsf-fallback-psk"
    return _PSK_CACHE


def _norm_machine(m):
    """机器码归一化 —— 必须与服务端 Store.norm_machine 完全一致。"""
    return re.sub(r"[^0-9A-Za-z]", "", str(m or "")).upper()


# ==================== ★ v1.3.0 K_data 命门（客户端侧） ====================
# 背景（2026-10-13 逆向复盘实测）：
#   本地账号/cookie 池原先用
#       _data_key() = SHA256("zsf-local-data|" + 源码里的 _PSK_ENC) 派生
#   —— 密钥完全在客户端、常量写在源码里。只要拿到 EXE，用这一条式子就能
#   把 qq_signin.json / config.json / forum_accounts.json 解成明文（已复现）。
#   于是「patch 掉卡密校验分支 + 打上自己的账号」即可长期白嫖。
#
# 现在改为：
#   账号池 / cookie 池 / 本地配置一律用**服务端下发的 K_data** 加密。
#   K_data 只存内存、不落盘，来源是 /api/verify 成功后的响应字段。
#   → patch 掉卡密校验 = 拿不到 K_data = 账号池 HMAC 不过 = 工具「能开但没账号」。
#   → 「把卡密改成永久」不再等于「可以一直用」，只是拿到一个空壳。
#
# ★ v1.4.2：原先这里有一个 `KDATA_REQUIRED = True` 过渡开关，被用在
#       if not KDATA_REQUIRED: return _legacy_data_key()
#   —— 等于给破解者留了一条现成后门：翻一个布尔量，就退回「本地常量派生」的
#   旧密钥（那条链能从二进制算出来）。**现已整条删除**：
#   「必须持有效卡密取到业务密钥」不再是一个可切换的开关，而是唯一行为。
_KDATA = {"key": None, "key_prev": None, "sig": "", "epoch": -1, "ts": 0.0}


def _kdata_install(r, card, machine):
    """把 /api/verify 或 /api/heartbeat 响应里的 K_data 装进内存。

    ★ 为什么客户端不做 HMAC 验证：验签密钥（命门根 secret）只在服务端，
      这也是命门的根本。伪造 K_data 的人只能伪造出**他自己的**钥匙 ——
      那把钥匙解不开服务端下发的数据，等于自己把自己锁在外面。
    """
    try:
        b64 = str(r.get("k_data") or "")
        if not b64:
            return False
        kd = base64.b64decode(b64)
        if len(kd) != 32 or kd == b"\x00" * 32:
            return False
        prev = None
        pb = str(r.get("k_data_prev") or "")
        if pb:
            try:
                p = base64.b64decode(pb)
                if len(p) == 32:
                    prev = p
            except Exception:
                prev = None
        old = _KDATA.get("key")
        _KDATA.update({"key": kd, "key_prev": prev or old,
                       "sig": str(r.get("k_sig") or ""),
                       "epoch": int(r.get("k_epoch") or -1),
                       "rotate_secs": int(r.get("k_rotate_secs") or 0),
                       "keep": int(r.get("k_keep") or 0),
                       "ts": time.time()})
        return True
    except Exception:
        return False


def _kdata_ready():
    return _KDATA.get("key") is not None


def _kdata_valid():
    """K_data 是否仍在租约内。

    ★ v1.3.0 自锁：验证/心跳成功会不断刷新 ts（在线每 60s 一次）。
      若客户端被 patch 成「跳过心跳」（为躲服务端封号），ts 不再刷新，
      超过 keep×rotate（默认 2×6h=12h）→ K_data 视为过期 →
      账号池自我锁死（读不出、也写不进）。于是「patch 掉心跳」不是长久之计：
      要么放心跳（被服务端看见），要么 12 小时后变空壳。
      服务端未下发租约参数（旧服务端）→ 不作过期判断（兼容）。
    """
    if not _kdata_ready():
        return False
    rot = int(_KDATA.get("rotate_secs") or 0)
    keep = int(_KDATA.get("keep") or 0)
    if rot <= 0 or keep <= 0:
        return True
    return (time.time() - float(_KDATA.get("ts") or 0.0)) <= rot * keep


def _data_key():
    """本地数据加密密钥 = 服务端下发的 K_data（内存态、且在租约内）。

    ★ 2026-10-13：不再本地派生。没有 K_data（未验证 / 校验被 patch 掉 /
    服务端不可达 / 租约过期）→ 返回一把**与真实密钥无关的死密钥**：
      读旧数据 HMAC 不过 → 视为「无账号」；写新数据谁也解不开。
    这样「把卡密校验改成永久」拿到的是一个**打不开账号池的空壳**。

    ★ v1.4.2：已删除原先的 `KDATA_REQUIRED` 过渡开关
      （`if not KDATA_REQUIRED: return _legacy_data_key()`）—— 那是一道
      「翻个布尔量就退回本地可算密钥」的现成后门。本函数现在**只有两条出口**：
      ① 有效 K_data；② 死密钥。**没有任何分支可被翻。**
    """
    kd = _KDATA.get("key")
    if kd and _kdata_valid():
        return kd
    try:
        seed = "zsf-nokey|%s|%s" % (get_machine_code(), VERSION)
    except Exception:
        seed = "zsf-nokey|unknown"
    return hashlib.sha256(seed.encode("utf-8")).digest()


def _data_keyring():
    """当前片 + 上一片（用于跨租约迁移读取）；无有效租约 → 只给死钥匙（自锁）。"""
    if not _kdata_valid():
        return [_data_key()]
    out = []
    for k in (_KDATA.get("key"), _KDATA.get("key_prev")):
        if k and k not in out:
            out.append(k)
    if not out:
        out.append(_data_key())
    return out


def _boot_key():
    """卡密配置专用「引导密钥」—— 必须**验证前**可读，所以不能依赖 K_data。

    ★ 为什么单独一把：card_config.json 里存的是「卡密 + 服务端地址」，
      而 CardGate.__init__ 在读它的时候还没验证、必然没有 K_data。
      若也套 K_data，则每次重启都会读不出卡密（功能性回归）。
    因此这把钥匙退回「本机派生」——但绑定机器码 + 构建常量，
      拷到别的机器解不开；且它只护「卡密槽」，不护账号池（账号池走 K_data）。
    """
    try:
        mc = get_machine_code()
    except Exception:
        mc = "unknown"
    return hashlib.sha256(
        ("zsf-boot|%s|%s" % (mc, _PSK_ENC)).encode("utf-8")).digest()


def _legacy_data_key():
    """★ v1.3.0 之前的旧密钥（= 本地常量派生，**能从二进制算出来**）。

    ⚠ **只允许用于「读 / 升级迁移」**，唯一调用点是 _reseal_all_pools()
      （把旧密钥封的池就地重封到当前 K_data）。**严禁出现在任何写路径**：
      v1.4.2 起 ① _data_key() 不再回退到它；② _safe_save_json() 显式拒收它。
    它存在的唯一理由：让 v1.3.0 之前版本封的旧池还能被迁移上来。
    """
    return hashlib.sha256(
        ("zsf-local-data|" + _psk()).encode("utf-8")).digest()


def _reseal_all_pools():
    """把所有已知数据池重新封到**当前 K_data** 下（幂等、滚动）。

    触发点：① 首次装填 K_data（升级迁移）；② 每次租约轮换（epoch 变）。
    尝试集合 = {上一片密钥, 旧常量密钥}，命中即用当前片重写：
      - 升级场景：老盘用旧常量密钥封的池 → 迁到 K_data（否则会被判「无账号」）。
      - 轮换场景：上一片密钥封的池 → 收口到当前片，让泄漏的旧片快速作废。
    """
    cur = _KDATA.get("key")
    if not cur:
        return
    cand = []
    for k in (_KDATA.get("key_prev"), _legacy_data_key()):
        if k and k != cur and k not in cand:
            cand.append(k)
    if not cand:
        return
    for path in (ACCOUNTS_FILE, CONFIG_FILE, RECORDS_FILE,
                 FORUM_CFG_FILE, FORUM_RECORDS_FILE, QQ_CFG_FILE):
        try:
            if not os.path.exists(path):
                continue
            with open(path, "rb") as f:
                blob = f.read()
            for k in cand:
                dec = _file_decrypt_with(blob, k)
                if dec is None:
                    continue
                tmp = path + ".reseal"
                with open(tmp, "wb") as f:
                    f.write(_file_encrypt(dec, cur))
                os.replace(tmp, path)
                break
        except Exception:
            pass


# ==================== ★ v1.4.0 服务端托管「作业配方」（客户端侧） ====================
# 背景（2026-10-13 复盘）：K_data 命门只保护「账号池的**数据**」——
#   patch 掉校验 → 拿不到 K_data → 账号池读不出/写不进。但**「怎么抢」这件事
#   本身还写在本地二进制里**（点哪个按钮、调哪个接口、表单带什么字段）。
#   于是破解者「自带账号 + 自改本地密钥」照样能把抢包跑起来。
#
# 现在把「怎么抢」也搬出客户端：
#   ① 每次作业前向卡密端领一张一次性、短时效的作业票据；
#   ② 服务端用 K_job = HMAC(K_data, "job|"+job) 加密下发作业配方；
#   ③ 本地**不再保留任何 JS / 接口路径常量** —— 没有配方就点不了、发不出。
#   没卡 = 没有 K_data = 解不开配方 = 手里只剩一个「不知道要干嘛」的浏览器。
JOB_REQUIRED = True                 # 出厂 True：必须持有效卡密换取作业许可
_JOB = {"kind": "", "job": "", "sig": "", "exp": 0.0, "got": 0.0,
        "ver": 0, "recipe": None}
_JOB_REFRESH_AHEAD = 20.0           # 到期前 20s 提前换票（避免卡在最后一秒）


class _JobError(Exception):
    """没有有效作业票据/配方 —— 抢包动作**不发车**。

    ★ 必须与「网络错误」严格区分：这是**授权缺失**。
      绝不允许静默回落成「用本地常量继续跑」——那等于把命门又拆掉。
    """


def _job_key(kd, job):
    """K_job = HMAC(K_data, "job|"+job)。必须与服务端 _job_key 逐字节一致。"""
    return hmac.new(kd, ("job|" + str(job)).encode("utf-8"),
                    hashlib.sha256).digest()


def _job_valid(kind="gift"):
    """当前内存里有没有未过期的、对应 kind 的作业配方。"""
    if not _JOB.get("recipe"):
        return False
    if _JOB.get("kind") != kind:
        return False
    return time.time() < float(_JOB.get("exp") or 0.0)


def _job_fetch(gate, kind="gift", timeout=12, force=False):
    """向卡密端领一张作业票据，解开配方并缓存。返回 (True, "") / (False, 原因)。

    ★ 密钥不走网络：K_data 本来就在内存里（验证/心跳下发的），
      本地算一遍 K_job 就够了，少一个泄漏面。
    """
    if not JOB_REQUIRED:
        return True, ""
    if (not force) and _job_valid(kind) and \
            time.time() < float(_JOB.get("exp") or 0.0) - _JOB_REFRESH_AHEAD:
        return True, ""
    kd = _KDATA.get("key")
    if not kd or not _kdata_valid():
        return False, "未取得业务密钥（K_data），无法领取作业许可"
    try:
        r = _card_post(gate.server, "/api/job",
                       {"token": str(getattr(gate, "token", "") or ""),
                        "card": gate.card, "machine": gate.machine,
                        "kind": kind, "version": VERSION},
                       timeout=timeout)
    except Exception as ex:
        return False, "领取作业许可失败：%s" % ex
    if not r.get("ok"):
        return False, str(r.get("msg") or "服务端拒绝签发作业许可")
    job = str(r.get("job") or "")
    try:
        ttl = int(r.get("ttl") or 0)
    except Exception:
        ttl = 0
    try:
        blob = base64.b64decode(str(r.get("recipe_ct") or ""))
    except Exception:
        return False, "作业配方解码失败"
    dec = _file_decrypt_with(blob, _job_key(kd, job))
    if dec is None:
        return False, "作业配方校验失败（票据与配方不匹配）"
    try:
        pack = json.loads(dec.decode("utf-8"))
    except Exception:
        return False, "作业配方解析失败"
    if str(pack.get("job") or "") != job:
        return False, "作业票据不一致"
    _JOB.update({"kind": kind, "job": job, "sig": str(r.get("sig") or ""),
                 "exp": time.time() + max(1, ttl), "got": time.time(),
                 "recipe": pack.get("recipe") or {},
                 "ver": int(r.get("recipe_ver") or 0)})
    return True, ""


def _recipe(kind="gift"):
    """取当前作业配方；没有则抛 _JobError（**绝不**回落到本地常量）。"""
    if not _job_valid(kind):
        raise _JobError("未取得作业许可（%s）——抢包已停止。"
                        "请确认卡密有效、且能连上卡密服务端。" % kind)
    out = (_JOB.get("recipe") or {}).get(kind)
    if not isinstance(out, dict) or not out.get("js_receive"):
        raise _JobError("服务端下发的作业配方不完整（%s）" % kind)
    return out


def _job_info():
    """给界面/日志看的作业状态（不含密钥）。"""
    return {"ok": _job_valid(), "kind": _JOB.get("kind") or "",
            "ver": int(_JOB.get("ver") or 0),
            "left": max(0, int(float(_JOB.get("exp") or 0.0) - time.time())),
            "job": str(_JOB.get("job") or "")[:8]}


# ==================== ★ v1.0.3 ECDH 非对称密钥协商 ====================
def _ecdh_session(srv_pk_der=None):
    """客户端临时 ECDH 密钥协商：返回 (临时公钥 DER, 会话密钥 K)。

    流程：
      1) 加载服务端公钥 pk_s（从 _SRV_PK_DER 或参数）
      2) 生成客户端临时 ECC 密钥对 (dk_c, ek_c)
      3) ECDH: shared = dk_c.exchange(ECDH, pk_s)
      4) K = HKDF-SHA256(shared, length=32, info="zsf-ecdh-v1")
      5) 返回 (ek_c 的 DER, K) —— ek_c DER 随请求发给服务端

    服务端收到 ek_c DER 后：用 sk_s + ek_c 做同样 ECDH → 得到相同的 K。
    """
    if not _HAS_ECC:
        return None, None
    try:
        der = srv_pk_der or _SRV_PK_DER
        if not der:
            return None, None
        # ★ v1.0.6 纯 Python 分支（打包运行时无 cryptography 时走这里）
        if _ECC_BACKEND == "pure":
            q_s = _EP.pub_from_der(der)
            d_c, q_c = _EP.keygen()
            shared_x = _EP.ecdh(d_c, q_s)
            K = _EP.hkdf_sha256(shared_x.to_bytes(32, "big"), None,
                                b"zsf-ecdh-v1", 32)
            return _EP.pub_to_der(q_c), K
        # 加载服务端公钥
        srv_pk = serialization.load_der_public_key(der)
        # 生成客户端临时密钥对
        dk_c = ec.generate_private_key(ec.SECP256R1())
        ek_c = dk_c.public_key()
        # ECDH 密钥协商
        shared = dk_c.exchange(ec.ECDH(), srv_pk)
        # HKDF 派生会话密钥
        K = HKDF(
            algorithm=hashes.SHA256(),
            length=32,
            salt=None,
            info=b"zsf-ecdh-v1",
        ).derive(shared)
        # 临时公钥序列化为 DER（发给服务端）
        ek_der = ek_c.public_bytes(
            encoding=serialization.Encoding.DER,
            format=serialization.PublicFormat.SubjectPublicKeyInfo,
        )
        return ek_der, K
    except Exception:
        return None, None


def _xor_stream(key, nonce, data):
    """SHA256 计数器流：加/解密是同一个函数（XOR 自反）。"""
    out = bytearray(len(data))
    ctr = off = 0
    while off < len(data):
        ks = hashlib.sha256(key + nonce + struct.pack(">I", ctr)).digest()
        chunk = min(32, len(data) - off)
        for i in range(chunk):
            out[off + i] = data[off + i] ^ ks[i]
        off += 32
        ctr += 1
    return bytes(out)


def _file_encrypt(b, key=None):
    """明文 → 密文。key 缺省用当前片的 K_data。"""
    key = key or _data_key()
    nonce = os.urandom(16)
    ct = _xor_stream(key, nonce, b)
    tag = hmac.new(key, nonce + ct, hashlib.sha256).digest()[:16]
    return _DATA_MAGIC + nonce + tag + ct


def _file_decrypt_with(blob, key):
    """用**指定**密钥解一次：成功返回明文，不是密文 / 校验不过 → None。"""
    if not blob or not blob.startswith(_DATA_MAGIC) or len(blob) < 40:
        return None
    nonce, tag, ct = blob[8:24], blob[24:40], blob[40:]
    want = hmac.new(key, nonce + ct, hashlib.sha256).digest()[:16]
    if hmac.compare_digest(tag, want):
        return _xor_stream(key, nonce, ct)
    return None


def _file_decrypt_ex(blob):
    """密文 → (明文, 命中的密钥)；不是密文 / 都解不开 → (None, None)。

    ★ v1.3.0：依次尝试「当前片 + 上一片」—— 跨租约时用上一片的密钥
      仍能读出旧数据，读完立刻用当前片重写（见 _read_data_bytes）。
    """
    if not blob or not blob.startswith(_DATA_MAGIC) or len(blob) < 40:
        return None, None
    for key in _data_keyring():
        dec = _file_decrypt_with(blob, key)
        if dec is not None:
            return dec, key
    return None, None


def _file_decrypt(blob):
    """密文 → 明文；不是密文（旧明文文件）或校验不过 → None。"""
    return _file_decrypt_ex(blob)[0]


class _LockedError(Exception):
    """数据文件是密文、但当前无有效密钥（未验证 / 卡密被 patch / 租约过期）。

    ★ 必须与「文件损坏」严格区分：损坏才备份留底，**锁着绝不能动文件** ——
      否则每次「未验证就启动」（如 --daemon、卡密窗口里的隐藏后台）都会把
      用户的账号池改名成 .bad-时间戳，那才是真的丢数据。
    """


def _read_data_bytes(path, key=None):
    """读数据文件原始字节：密文自动解密（含跨租约自动迁移），明文原样返回。

    key 显式传入（如卡密配置用 _boot_key）→ 单密钥解密、不做跨租约迁移。
    密文但当前解不开 → 抛 _LockedError（调用方按「锁着」处理，不动文件）。
    """
    with open(path, "rb") as f:
        blob = f.read()
    if not (blob.startswith(_DATA_MAGIC) and len(blob) >= 40):
        return blob                      # 明文（旧文件）原样返回
    if key is not None:
        dec = _file_decrypt_with(blob, key)
        if dec is None:
            raise _LockedError(path)
        return dec
    dec, used = _file_decrypt_ex(blob)
    if dec is None:
        raise _LockedError(path)         # 密文但没钥匙 → 锁着，别动它
    cur = _KDATA.get("key")
    if cur and used != cur:
        # 是用上一片密钥解出来的 → 立刻用当前片重新落盘（无缝迁移）
        try:
            tmp = path + ".reseal"
            with open(tmp, "wb") as f:
                f.write(_file_encrypt(dec, cur))
            os.replace(tmp, path)
        except Exception:
            pass
    return dec


def _safe_save_json(path, obj, indent=2, key=None):
    """原子写 + 落地加密（先 .tmp 再 replace）。返回 True/False。

    ★ v1.3.0 命门护栏：没有 K_data 时**拒绝写入** —— 否则会用「死密钥」
      把用户已有的账号池覆盖掉，那才是真的丢数据。宁可这一轮存不下。
      （显式传 key 的引导文件——如卡密配置——不受此限。）

    ★ v1.4.2：显式**拒收旧「常量密钥」**（_legacy_data_key）。那把钥匙能从
      二进制算出来，只配用于「读 / 升级迁移」（见 _reseal_all_pools），
      一旦允许它写，等于把本地可算的密钥重新变成可写。
    """
    try:
        if key is None and not _kdata_valid():
            return False          # 无有效 K_data（未验证/过期）→ 不写，防死密钥覆盖
        if key is not None and key == _legacy_data_key():
            return False          # 旧常量密钥禁止写（只读/迁移专用）
        d = os.path.dirname(path)
        if d:
            os.makedirs(d, exist_ok=True)
        raw = json.dumps(obj, ensure_ascii=False, indent=indent).encode("utf-8")
        tmp = path + ".tmp"
        with open(tmp, "wb") as f:
            f.write(_file_encrypt(raw, key))
        os.replace(tmp, path)
        return True
    except Exception:
        return False


# ==================== 账号登录态（★ v1.1.11 掉线检测） ====================
#   ok  = 已登录：核对过，站点还认这份登录态
#   off = 掉线：以前登录过，但凭证已失效 / 丢失，必须重新扫码
#   no  = 未登录：从没登录过（或本地压根没有登录记录）
# (列表显示文本, Treeview tag, 文字颜色)
ACC_STATUS = {
    "ok":  ("● 已登录", "ok",  "#1a8f4a"),
    "off": ("⚠ 掉线",   "off", "#c9741a"),
    "no":  ("○ 未登录", "no",  "#9b978f"),
}


def account_profiles(acc_id):
    """该账号可能放登录数据的 profile 目录。

    新版隔离目录优先，末尾带上旧版（EXE 目录 profiles/<账号>）——
    老用户升级上来的登录数据还在旧目录里，漏了就会被误判成「未登录」。
    """
    return [os.path.join(DATA_DIR, "browser_data_" + safe_name(acc_id)),
            os.path.join(OLD_DATA_DIR, safe_name(acc_id))]


def account_profile(acc_id):
    """账号专属浏览器 profile 目录（与领取流程用的是同一个目录）。"""
    return account_profiles(acc_id)[0]


def cookie_backup_paths(profile):
    """cookie 备份候选路径：外部目录优先，profile 内的旧版文件放最后兜底。

    放到模块级是为了让「引擎写备份」和「掉线检测读备份」共用同一份口径 ——
    两边各写一套路径规则，迟早会漂移。
    """
    prof = profile or ""
    key = os.path.basename(prof.rstrip("\\/")) or "default"
    paths = [os.path.join(d, key + ".json") for d in COOKIE_BACKUP_DIRS]
    if prof:
        paths.append(os.path.join(prof, "cookies_backup.json"))
    return paths


def _read_backup_cookies(path):
    """读一个 cookie 备份文件里的 cookie 列表（坏文件/旧格式一律当空）。"""
    try:
        with open(path, "r", encoding="utf-8") as fp:
            data = json.load(fp)
    except Exception:
        return []
    cookies = data.get("cookies") if isinstance(data, dict) else data
    return cookies if isinstance(cookies, list) else []


def local_login_hint(acc_id):
    """只看磁盘、不开浏览器，先判这个账号还剩没剩登录凭证。

    "ok"  有可用 cookie（或 profile 里有 Chrome 的 cookie 库）→ 值得开浏览器复核
    "off" 备份还在，但 cookie 已全部过期 → 磁盘上就能判死是掉线
    "no"  压根没登录过 → 没必要为它开浏览器（省一次启动开销）

    备份是本工具自己用 CDP 写出来的明文 JSON，所以过期时间能精确读出来；
    Chrome 自己的 Cookies 是加密库，读不出内容，只当「有凭证」的证据。
    """
    best_total, best_alive = 0, 0
    for prof in account_profiles(acc_id):
        for f in cookie_backup_paths(prof):
            cookies = _read_backup_cookies(f)
            if not cookies:
                continue
            now = time.time()
            total = alive = 0
            for c in cookies:
                if not isinstance(c, dict):
                    continue
                total += 1
                exp = c.get("expires")
                if exp in (None, -1, 0):
                    alive += 1                  # 会话 cookie：备份后仍可注入使用
                else:
                    try:
                        alive += 1 if float(exp) > now else 0
                    except Exception:
                        alive += 1
            if total > best_total or alive > best_alive:
                best_total, best_alive = total, alive
    if best_total:
        return "ok" if best_alive else "off"
    for prof in account_profiles(acc_id):
        for rel in (("Default", "Network", "Cookies"), ("Default", "Cookies")):
            if os.path.exists(os.path.join(prof, *rel)):
                return "ok"
    return "no"


def acc_status(acc):
    """账号当前登录态。显式 status 优先，旧数据（只有 first_login）自动回退。"""
    s = str(acc.get("status") or "")
    if s in ACC_STATUS:
        return s
    return "ok" if acc.get("logined") else "no"


def acc_set_status(acc, s):
    """写登录态：status 是唯一真源，logined 只是它的布尔投影（兼容旧字段）。"""
    acc["status"] = s
    acc["logined"] = (s == "ok")


def _status_from_record(a):
    """从 accounts.json / 导入文件里的一条记录取登录态（新字段优先）。"""
    s = str(a.get("login_status") or "").strip()
    if s in ACC_STATUS:
        return s
    return "ok" if a.get("first_login") else "no"


# ==================== 论坛签到 ====================
FORUMS = [
    ("苍月引擎论坛", "https://bbs.cym2.com/"),
    ("萝卜论坛", "https://bbs.0lb.com/"),
    ("奇速论坛", "https://bbs.73su.com/"),
    ("八二单机论坛", "https://82pc.com/"),
]
FORUM_CFG_FILE = os.path.join(base_dir(), "forum_accounts.json")
# ★ v1.1.0 签到记录（时间/论坛/结果/详情），关软件再开仍可查
FORUM_RECORDS_FILE = os.path.join(base_dir(), "forum_records.json")
FORUM_UA = ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
            "(KHTML, like Gecko) Chrome/109.0.0.0 Safari/537.36")
FORUM_TODAYSAY = ["每日签到", "签到打卡", "日常签到", "坚持签到", "打卡"]
# 首页没有签到入口时，按顺序探测这些常见签到插件（装了哪个用哪个）
# ★ v1.1.23 越攒越多 —— 新论坛/新插件优先在这里补一行
FORUM_COMMON_ENTRIES = [
    ("paulsign", "plugin.php?id=dsu_paulsign:sign"),   # 每日签到 dsu_paulsign
    ("paulsign", "dsu_paulsign-sign.html"),            # 同上（伪静态）
    ("kmisign", "plugin.php?id=k_misign:sign"),        # 萝卜签到 k_misign
    ("kmisign", "k_misign-sign.html"),                 # 同上（伪静态）
    ("lwdz", "plugin.php?id=lwdz_signin:index"),      # 奇速/八二 同款 Ajax 打卡
    ("erling_qd", "plugin.php?id=erling_qd:sign_in"),  # 恩山论坛 erling_qd 签到
    ("generic", "plugin.php?id=wq_sign"),              # 微签 wq_sign
    ("generic", "plugin.php?id=nkes_sign"),            # 恩克斯签到
    ("generic", "plugin.php?id=dc_sign"),              # DC签到
    ("generic", "plugin.php?id=dsc_sign"),             # DSC签到
    ("generic", "plugin.php?id=xm_sign:sign"),         # XM 签到
    ("generic", "plugin.php?id=bkas_sign"),            # bkas 签到
    ("task", "home.php?mod=task"),                     # Discuz 自带每日签到任务
]
# 手动登录用的持久化 profile（每次登录复用，免重复登录）
FORUM_LOGIN_DIR = os.path.join(DATA_DIR, "forum_login")

# ★ v1.1.29 所有日志/记录只保留 5 天，到期自动删除 —— 防止服务器上
#   长期挂机把磁盘写满（records.json / forum_records.json /
#   forum_sign.log / qq_sign.log 四处都会随时间累积）。卡密服务端不涉及。
LOG_KEEP_DAYS = 5


def _prune_records_by_time(records, days=LOG_KEEP_DAYS):
    """按记录的 time 字段清掉超过 days 天的旧记录，返回保留列表。

    记录时间格式是 "MM-DD HH:MM:SS"（没有年份）：先按当前年解析，
    若解析出的时间比现在超前 36 小时以上，视为上一年的跨年记录；
    解析不了的时间保守保留（宁可多留也不误删）。
    """
    if not isinstance(records, list):
        return records
    now = datetime.now()
    cutoff = now - timedelta(days=days)
    keep = []
    for r in records:
        t = None
        try:
            s = str((r or {}).get("time", "")).strip()
            t = datetime.strptime(s, "%m-%d %H:%M:%S").replace(year=now.year)
            if (t - now).total_seconds() > 36 * 3600:
                t = t.replace(year=now.year - 1)
        except Exception:
            t = None
        if t is None or t >= cutoff:
            keep.append(r)
    return keep


def _prune_log_file(path, days=LOG_KEEP_DAYS):
    """删掉文本日志里超过 days 天的行（行首 [YYYY-MM-DD HH:MM:SS] 时间戳）。

    forum_sign.log / qq_sign.log 都是带完整年份的行前缀，直接按行过滤；
    认不出时间戳的行（如多行消息的续行）保留。文件无变化时不重写。
    """
    try:
        if not os.path.exists(path):
            return
        with open(path, "r", encoding="utf-8", errors="replace") as f:
            lines = f.read().splitlines()
        cutoff = datetime.now() - timedelta(days=days)
        keep, changed = [], False
        for ln in lines:
            t = None
            m = re.match(r"[\[(]?(\d{4})-(\d{2})-(\d{2})[ T]"
                         r"(\d{2}):(\d{2}):(\d{2})", ln)
            if m:
                try:
                    t = datetime(*(int(x) for x in m.groups()))
                except Exception:
                    t = None
            if t is not None and t < cutoff:
                changed = True          # 该行过期：丢弃
                continue
            keep.append(ln)
        if changed:
            with open(path, "w", encoding="utf-8") as f:
                f.write("\n".join(keep) + ("\n" if keep else ""))
    except Exception:
        pass


# ==================== QQ 群签到（OneBot WS 客户端） ====================
# 通过 WebSocket 连接 QQ 机器人框架（NapCatQQ / LLOneBot / Lagrange / go-cqhttp
# 等 OneBot 11 实现）暴露的 WS 服务，实现：
#   · 拉取群列表并在界面里展示
#   · 对勾选的群发送自定义签到消息
#   · 给指定 QQ 号点赞（v1.1.0 起「全部好友点赞」已移除）
# ★ 2026-10-09 支持两种连接方向（OneBot 11 的「正向 WS」与「反向 WS」）：
#   · 正向 WS：框架开服务端，我们连过去 —— OneBotWS.connect()（拨号）。
#   · 反向 WS：**小工具端开服务端**，框架连进来 —— OneBotWS.attach() 接管
#     别人送上门的、已握手的 socket（见 web/wsclient.py 的 WSListener/
#     accept_websocket）。两条路径连上之后协议完全相同。
QQ_CFG_FILE = os.path.join(base_dir(), "qq_signin.json")
QQ_DEFAULT_MSG = "签到"
# 一键切换的常用签到语（下拉框）
QQ_MSG_PRESETS = ["签到", "打卡", "每日签到", "签到打卡", "打卡签到", "冒泡", "来了"]
QQ_LOG_FILE = os.path.join(base_dir(), "qq_sign.log")


def cdp_all_cookies(port, host_filter="", timeout=20):
    """通过浏览器级 CDP 读取全部 Cookie（含 HttpOnly），返回 Cookie 头字符串。

    host_filter 形如 "cym2.com"，只保留该域及其子域的 Cookie。
    """
    import websocket
    op = urllib.request.build_opener(urllib.request.ProxyHandler({}))
    info = json.loads(op.open("http://127.0.0.1:%d/json/version" % port,
                              timeout=8).read().decode("utf-8", "replace"))
    ws_url = info.get("webSocketDebuggerUrl")
    if not ws_url:
        return ""
    ws = websocket.create_connection(ws_url, timeout=timeout)
    try:
        ws.send(json.dumps({"id": 1, "method": "Storage.getCookies",
                            "params": {}}))
        end = time.time() + timeout
        while time.time() < end:
            msg = json.loads(ws.recv())
            if msg.get("id") == 1:
                cookies = (msg.get("result") or {}).get("cookies") or []
                pairs = []
                for c in cookies:
                    dom = (c.get("domain") or "").lstrip(".")
                    if host_filter and host_filter not in dom:
                        continue
                    pairs.append("%s=%s" % (c.get("name"), c.get("value")))
                return "; ".join(pairs)
    except Exception:
        return ""
    finally:
        try:
            ws.close()
        except Exception:
            pass
    return ""


def cdp_browser_ua(port, timeout=8):
    """读取登录浏览器的真实 User-Agent（CDP /json/version 自带）。

    ★ v1.1.24 Cookie 模式签到必须用「抓 Cookie 时那个浏览器」的 UA：
    Cloudflare / 雷池 / 加速乐 / 宝塔 WAF 把防护 Cookie 绑定在 UA 上，
    UA 不一致时 forum.php 可能放行，但签到插件页会直接 403。
    """
    try:
        op = urllib.request.build_opener(urllib.request.ProxyHandler({}))
        info = json.loads(op.open(
            "http://127.0.0.1:%d/json/version" % port,
            timeout=timeout).read().decode("utf-8", "replace"))
        return (info.get("User-Agent") or "").strip()
    except Exception:
        return ""


class DiscuzForumSigner(object):
    """Discuz 论坛签到器（Cookie 模式）。

    用户在内置浏览器里手动登录，程序自动抓取并保存 Cookie；
    签到全部基于该 Cookie 用 HTTP 提交，无需账号密码。
    签到自动识别：dsu_paulsign 插件 / lwdz_signin 插件 / 通用表单兜底。
    """

    def __init__(self, base, cookie="", log=None, ua=""):
        self.base = base if base.endswith("/") else base + "/"
        self.cookie = cookie.strip() if cookie else ""
        self.log = log or (lambda m: None)
        # ★ v1.1.24 优先用抓 Cookie 时浏览器的 UA（WAF 防护 Cookie 绑 UA）；
        #   老配置没存 ua 才退回内置 UA（重登一次即可补上）
        self.ua = (ua or "").strip() or FORUM_UA
        import urllib.request as _ur
        import http.cookiejar as _cj
        import ssl as _ssl
        self._ur = _ur
        ctx = _ssl.create_default_context()
        ctx.check_hostname = False
        ctx.verify_mode = _ssl.CERT_NONE
        self.jar = _cj.CookieJar()
        self.op = _ur.build_opener(
            _ur.ProxyHandler({}),
            _ur.HTTPCookieProcessor(self.jar),
            _ur.HTTPSHandler(context=ctx))
        self.op.addheaders = [
            ("User-Agent", self.ua),
            ("Referer", self.base),
            ("Accept", "text/html,application/xhtml+xml,application/xml;"
                       "q=0.9,image/avif,image/webp,*/*;q=0.8"),
            ("Accept-Language", "zh-CN,zh;q=0.9"),
            ("Upgrade-Insecure-Requests", "1"),
        ]
        # ★ v1.1.23 防封顶配：请求间隔 + 403 退避重试（见 _req）
        self._last_req = 0.0

    # ---- HTTP 基础
    # ★ Discuz 站点有 GBK / UTF8SC / BIG5 多种编码（ruciwan 实测 charset=gbk）。
    #   以前一律按 utf-8 解码，GBK 站点的中文全成乱码，于是所有靠中文文案判断的
    #   分支（已签到 / 未登录 / 签到成功）静默失效，最后只剩「响应无成功标志」。
    _CHARSET_RE = re.compile(rb'charset\s*=\s*["\']?\s*([\w\-]+)', re.I)
    _CS_ALIAS = {"gb2312": "gbk", "gbk": "gbk", "gb18030": "gbk",
                 "utf-8": "utf-8", "utf8": "utf-8", "big5": "big5"}

    @classmethod
    def _decode(cls, raw, ctype=""):
        """按页面自己声明的编码解码。

        候选顺序：HTTP 头 charset → HTML <meta charset> → utf-8 → gbk；
        哪个能解码成功就用哪个，全失败才走 replace 兜底。
        """
        cands = []
        for blob in (ctype[:300].encode("latin-1", "ignore"), raw[:4096]):
            for m in cls._CHARSET_RE.finditer(blob):
                try:
                    cs = m.group(1).decode("latin-1").strip().lower()
                except Exception:
                    continue
                if cs in cls._CS_ALIAS:
                    cands.append(cls._CS_ALIAS[cs])
        cands += ["utf-8", "gbk"]
        seen = set()
        for cs in cands:
            if cs in seen:
                continue
            seen.add(cs)
            try:
                return raw.decode(cs)
            except Exception:
                continue
        return raw.decode("utf-8", "replace")

    def _req(self, url, data=None, referer=None, extra_cookie=True,
             extra_headers=None):
        # ★ v1.1.23 防 WAF 403 三件套：
        #   1) 更像浏览器的请求头（Accept 等，见 __init__ addheaders）
        #   2) 请求间隔 ≥0.8~1.5s（连续请求太快会被防火墙当 CC 攻击拦截）
        #   3) 403/429/503 自动退避重试 2 次（很多站点偶尔抽风，重试就过）
        # ★ v1.0.4：extra_headers 允许调用方补 X-Requested-With / Origin 等
        #   —— 恩山论坛 erling_qd 的 Ajax 签到接口必须带 X-Requested-With，
        #   否则被站点 WAF 当机器人拦（503 request_tainting）。
        headers = {}
        if extra_headers:
            headers.update(extra_headers)
        if referer:
            headers["Referer"] = referer
        if extra_cookie and self.cookie:
            headers["Cookie"] = self.cookie
        gap = time.time() - self._last_req
        wait = (0.8 + random.random() * 0.7) - gap
        if wait > 0:
            time.sleep(wait)
        body = None
        if data is not None:
            body = urllib.parse.urlencode(data).encode("utf-8")
        for attempt in range(3):
            try:
                req = self._ur.Request(url, data=body, headers=headers)
                resp = self.op.open(req, timeout=20)
                raw = resp.read()
                self._last_req = time.time()
                return self._decode(raw, resp.headers.get("Content-Type", ""))
            except self._ur.HTTPError as ex:
                if ex.code in (403, 429, 503) and attempt < 2:
                    d = 1.5 * (attempt + 1) + random.random() * 1.5
                    self.log("  ⚠ HTTP %s（疑似拦截/过快），%.1f 秒后重试…"
                             % (ex.code, d))
                    time.sleep(d)
                    continue
                # ★ v1.1.24 认不出防火墙就翻一下 403 页面，给用户可执行的提示
                try:
                    blob = ex.read(4096).decode("utf-8", "replace").lower()
                except Exception:
                    blob = ""
                hint = ""
                if ("just a moment" in blob) or ("cf-ray" in blob) \
                        or ("cloudflare" in blob):
                    hint = "站点开了 Cloudflare 防护，防护 Cookie 与本程序不匹配"
                elif ("safeline" in blob) or ("雷池" in blob):
                    hint = "站点开了雷池 WAF，拦截了本程序的请求"
                elif ("yunsuo" in blob) or ("加速乐" in blob) \
                        or ("jiasule" in blob):
                    hint = "站点开了加速乐防护，拦截了本程序的请求"
                elif ("waf" in blob) or ("防火墙" in blob) or ("拦截" in blob):
                    hint = "站点防火墙拦截了本程序的请求"
                if not hint:
                    hint = ("站点持续拦截本程序的请求；请重新点『登录』抓取"
                            "一次 Cookie（防火墙可能要求 Cookie 与浏览器"
                            "配对），再不行就是站点临时封了该网络")
                try:
                    ex.hint = hint        # sign() 里取去拼人话
                except Exception:
                    pass
                raise
            except OSError as ex:
                # ★ v1.1.28 网络瞬断（远程强制断开 WinError 10054 / 超时 /
                #   连接被拒）退避重试 —— 凌晨整点线路/站点偶发抖动，
                #   重试一两次往往就过；HTTP 403 类拦截仍走上面分支。
                if attempt < 2:
                    d = 2.0 * (attempt + 1) + random.random() * 1.5
                    self.log("  ⚠ 网络瞬断（%s），%.1f 秒后重试…"
                             % (str(ex)[:70], d))
                    time.sleep(d)
                    continue
                try:
                    ex.hint = ("网络连续 3 次连接失败（远程强制断开/超时）。"
                               "多为凌晨整点线路或站点瞬时抖动，稍后再试；"
                               "持续如此请检查本机网络或换个网络。")
                except Exception:
                    pass
                raise
        raise self._ur.HTTPError(url, 403, "retry exhausted", None, None)

    def _url(self, path):
        if path.startswith("http"):
            return path
        return self.base + path.lstrip("/")

    @staticmethod
    def _txt(html):
        return re.sub(r"<[^>]+>", " ", html)

    @staticmethod
    def _ajax_text(resp):
        """★ Discuz 的 ajax 回执常被包成
        `<?xml version="1.0" encoding="gbk"?><root><![CDATA[今日已签]]></root>`。
        直接 _txt() 会把 CDATA 里的正文连尖括号一起当标签吃掉，判定结果变成空串
        ——ruciwan 实测就是这样：明明已经签到了，却因为读不出文字而报「无成功标志」。
        这里先把 CDATA 正文取出来，再走正常的标签清理。
        """
        parts = [m.group(1) for m in
                 re.finditer(r"<!\[CDATA\[(.*?)\]\]>", resp, re.S)]
        return DiscuzForumSigner._txt(" ".join(parts) if parts else resp)

    @staticmethod
    def _formhash(html):
        m = re.search(r'name="formhash"[^>]*value="([a-f0-9]+)"', html)
        if not m:
            m = re.search(r'formhash=([a-f0-9]+)', html)
        return m.group(1) if m else ""

    # ---- ★ v1.0.3 Discuz seccheck 滑块验证检测与处理 ----
    @staticmethod
    def _seccheck_info(html):
        """从页面/响应 HTML 中提取 seccheck 验证码信息。

        Discuz seccheck 机制：当服务端判定需要验证码时（风控 IP、频繁操作等），
        签到页/响应里会出现：
          - 隐藏字段 <input type="hidden" name="seccodehash" value="S{随机}">
          - 验证码输入框 <input type="text" name="seccodeverify">
          - 验证码图片 <img src="misc.php?mod=seccode&update=...&idhash=S{随机}">
          - 或 JS 弹窗提示「请输入验证码后继续操作」

        返回 (需要验证码:bool, seccodehash:str, idhash:str)
        """
        # 检测 seccodehash 字段
        m = re.search(r'name="seccodehash"[^>]*value="([^"]+)"', html)
        if not m:
            m = re.search(r'seccodehash=([^&"\']+)', html)
        seccodehash = m.group(1) if m else ""
        # idhash 通常和 seccodehash 相同（Discuz 用 S{uid} 格式）
        idhash = seccodehash
        # 也检测 seccodeverify 字段（有它就说明需要验证码）
        has_verify = bool(re.search(r'name="seccodeverify"', html))
        # 检测文字提示
        has_prompt = ("验证码" in html and ("请输入" in html or "请完成" in html
                      or "seccode" in html.lower()))
        need = bool(seccodehash) or has_verify or has_prompt
        return need, seccodehash, idhash

    def _seccheck_image(self, idhash):
        """获取 seccheck 验证码图片（bytes），失败返回 None。

        验证码图片地址：misc.php?mod=seccode&update={random}&idhash={idhash}
        必须带同源 Referer，否则被 WAF 拦截。
        """
        if not idhash:
            return None
        try:
            url = self._url("misc.php?mod=seccode&update=%d&idhash=%s"
                            % (random.randint(10000, 99999), idhash))
            raw = self._req(url, referer=self.base)
            # raw 可能是 HTML 文本（被拦截），真正的图片应该是二进制
            # _req 返回 str，这里需要直接拿 bytes
            return None  # 纯 HTTP 模式无法可靠获取二进制验证码图片
        except Exception:
            return None

    def _try_seccheck_bypass(self, html, entry, formhash):
        """★ v1.0.3 尝试绕过 seccheck 验证码完成签到。

        恩山论坛（right.com.cn）等站点在签到时会触发 seccheck 滑块验证。
        纯 HTTP Cookie 模式无法自动完成滑块，但可以：
          1) 检测到需要验证码 → 给出明确提示
          2) 尝试不带验证码提交（部分站点验证码是可选的）
          3) 如果必须验证码 → 返回需要浏览器操作的提示

        返回 (状态, 说明) 或 None（没有 seccheck 或无法处理）
        """
        need, seccodehash, idhash = self._seccheck_info(html)
        if not need:
            return None
        self.log("  ⚠ 签到需要验证码（seccheck），尝试处理…")
        # 策略 1：尝试不带验证码直接提交（某些站点验证码是前端限制，后端不强制）
        if seccodehash and formhash:
            try:
                # 带空 seccodeverify 提交
                url = self._url(entry) if entry else self._url("forum.php")
                data = {"formhash": formhash, "seccodehash": seccodehash,
                        "seccodeverify": "", "seccodemodid": "member::logging"}
                resp = self._req(url, data=data, referer=self._url(entry))
                j = self._json_status(resp)
                if j is not None:
                    if j["status"] == "success":
                        return "ok", "签到成功（已跳过验证码）"
                    if j["status"] == "checked":
                        return "already", "今日已签到，无需重复"
                t = self._txt(resp)
                if ("签到成功" in t) or ("打卡成功" in t):
                    return "ok", "签到成功（已跳过验证码）"
                if self._already(t):
                    return "already", "今日已签到，无需重复"
                # 验证码不通过
                if "验证码" in t or "seccode" in t.lower():
                    self.log("  验证码未通过，空提交被拒绝")
            except Exception as ex:
                self.log("  跳过验证码提交失败: %s" % str(ex)[:60])
        # 策略 2：验证码无法自动处理，给用户明确指引
        return ("fail",
                "签到需要滑块验证码，纯Cookie模式无法自动完成。"
                "请在工具的内置浏览器里手动打开签到页完成验证："
                "点「登录」→ 打开浏览器 → 访问签到页 → 拖滑块 → 签到")

    # ---- 登录
    @staticmethod
    def _is_logged_in(html):
        """★ 游客页面也有 formhash，必须用『退出』链接判断登录态。"""
        return ("action=logout" in html) or ("action%3Dlogout" in html) or \
               ("mod=logging&amp;action=logout" in html)

    def login(self):
        """校验 Cookie 是否有效。有效返回 (True, formhash)，否则 (False, 原因)。"""
        if not self.cookie:
            return False, "未登录（请先点『登录并获取Cookie』）"
        try:
            html = self._req(self._url("forum.php"))
            if self._is_logged_in(html):
                return True, self._formhash(html)
            return False, "Cookie 已失效（请重新点『登录并获取Cookie』）"
        except self._ur.HTTPError as ex:
            return False, "Cookie 校验被服务器拦截(HTTP %s)" % ex.code
        except Exception as ex:
            return False, "Cookie 校验失败: %s" % ex

    # ---- 签到
    def _find_entry(self, html):
        """从首页 HTML 找签到入口，返回 (类型, 相对地址)。"""
        m = re.search(r'href="([^"]*dsu_paulsign-sign\.html[^"]*)"', html)
        if m:
            return "paulsign", m.group(1).replace("&amp;", "&")
        m = re.search(r'href="([^"]*plugin\.php\?id=lwdz_signin[^"]*)"', html)
        if m:
            return "lwdz", m.group(1).replace("&amp;", "&")
        m = re.search(r'href="([^"]*plugin\.php\?id=k_misign[^"]*)"', html)
        if m:
            return "kmisign", m.group(1).replace("&amp;", "&")
        # ★ 伪静态入口（ruciwan 实测）：首页只有 k_misign-sign.html，
        #   并不出现 plugin.php?id=k_misign，漏掉它会掉进下面的通用兜底，
        #   而通用兜底会把页面里的搜索表单当签到表单提交。
        m = re.search(r'href="([^"]*k_misign-sign[^"]*)"', html)
        if m:
            return "kmisign", m.group(1).replace("&amp;", "&")
        # ★ v1.0.4 恩山论坛 erling_qd 签到：伪静态入口 erling_qd-sign_in.html 会
        #   被站点 WAF（阿里云 ESA）拦成滑块验证页，必须改回插件原始地址
        #   plugin.php?id=erling_qd:sign_in（该地址 WAF 放行）。
        if "erling_qd-sign_in" in html or "id=erling_qd" in html:
            return "erling_qd", "plugin.php?id=erling_qd:sign_in"
        m = re.search(
            r'href="([^"]*plugin\.php\?id=[\w:]*?(?:sign|qiandao|qd|checkin)[\w:]*[^"]*)"',
            html, re.I)
        if m:
            return "generic", m.group(1).replace("&amp;", "&")
        m = re.search(r'href="([^"]*(?:sign|qiandao|checkin)[^"]*)"', html, re.I)
        if m and "logging" not in m.group(1) and "search" not in m.group(1):
            return "generic", m.group(1).replace("&amp;", "&")
        # 文案入口：<a href="...">签到</a> / <a href="...">打卡</a>（有的论坛只认文字）
        for m in re.finditer(
                r'href="([^"]+)"[^>]*>[^<]{0,12}(?:签到|打卡|簽到)[^<]{0,12}<',
                html):
            u = m.group(1).replace("&amp;", "&")
            # ★ 排除「打卡签到记录帖」这类帖子/版块链接，它们不是签到入口
            bad = ("logging", "search", "forum.php", "tid=", "thread-",
                   "redirect", "home.php")
            if any(b in u for b in bad):
                continue
            return "generic", u
        return None, ""

    def _probe_entry(self):
        """首页看不到签到入口时（有的论坛登录后才显示），逐个探测常见插件页。
        装了但需登录 → 页面正常返回；未安装 → 页面含『插件不存在』。"""
        for kind, path in FORUM_COMMON_ENTRIES:
            try:
                page = self._req(self._url(path), referer=self._url("forum.php"))
            except self._ur.HTTPError:
                continue
            except Exception:
                continue
            if ("插件不存在" in page) or ("插件已关闭" in page):
                continue
            t = self._txt(page)
            if ("签到" in t) or ("打卡" in t):
                return kind, path
        return None, ""

    @staticmethod
    def _parse_form(html):
        """取页面第一个 <form>：返回 (action, {name:value})。"""
        fm = re.search(r'<form[^>]*>(.*?)</form>', html, re.S | re.I)
        if not fm:
            return "", {}
        block = fm.group(1)
        am = re.search(r'action="([^"]*)"', fm.group(0))
        action = am.group(1).replace("&amp;", "&") if am else ""
        fields = {}
        for m in re.finditer(
                r'<input[^>]*name=["\']([^"\']+)["\'][^>]*>', block):
            tag = m.group(0)
            vm = re.search(r'value=["\']([^"\']*)["\']', tag)
            fields[m.group(1)] = vm.group(1) if vm else ""
        return action, fields

    @staticmethod
    def _parse_forms_all(html):
        """解析页面全部 <form>：返回 [(action, {name:value}), ...]。

        ★ cym2 实测（v4.8.2）：签到页上第一个表单可能是登录表单
        （member.php?mod=logging&action=login，字段 username/password），
        也有论坛第一个表单是搜索框。盲目提交第一个表单会签不上，
        所以签到前要在所有表单里挑出真正的签到表单。
        """
        out = []
        for fm in re.finditer(r'<form[^>]*>(.*?)</form>', html, re.S | re.I):
            block = fm.group(1)
            am = re.search(r'action="([^"]*)"', fm.group(0))
            action = am.group(1).replace("&amp;", "&") if am else ""
            fields = {}
            for m in re.finditer(
                    r'<input[^>]*name=["\']([^"\']+)["\'][^>]*>', block):
                tag = m.group(0)
                vm = re.search(r'value=["\']([^"\']*)["\']', tag)
                fields[m.group(1)] = vm.group(1) if vm else ""
            out.append((action, fields))
        return out

    def _pick_sign_form(self, page):
        """从签到页的全部表单里挑出真正的签到表单，返回 (action, fields)。

        排除：登录表单（action 含 logging/login）、搜索表单（action 含 search，
        字段含 srchtxt/srchfilter）。优先：action 含 dsu_paulsign/qiandao/sign，
        其次：字段含 qdxq/todaysay（dsu_paulsign 特征字段）。
        找不到就退回第一个非登录非搜索表单，再找不到返回 ("", {})。
        """
        forms = self._parse_forms_all(page)

        def is_bad(action, fields):
            low = (action or "").lower()
            if "logging" in low or ("login" in low and "member.php" in low):
                return True
            if "search" in low or "srchtxt" in fields or "srchfilter" in fields:
                return True
            return False

        good = [(a, f) for a, f in forms if not is_bad(a, f)]
        # 优先级 1：action 明确是签到插件
        for a, f in good:
            low = (a or "").lower()
            if "dsu_paulsign" in low or "qiandao" in low or "signin" in low:
                return a, f
        # 优先级 2：action 含 sign
        for a, f in good:
            if "sign" in (a or "").lower():
                return a, f
        # 优先级 3：字段带 dsu_paulsign 特征（qdxq/todaysay）
        for a, f in good:
            if "qdxq" in f or "todaysay" in f:
                return a, f
        # 兜底：第一个非登录非搜索表单
        if good:
            return good[0]
        return "", {}

    def _already(self, txt):
        # ★ 必须排除 "未签到" 弹窗提示（cym2 等 dsu_paulsign 站点未签到时
        #   会出现"今日未签到会员将自动跳转..."），否则会被 "已签" 误判
        if "未签到" in txt:
            return False
        return ("已签到" in txt or "今天已经签到" in txt
                or "您今日已签到" in txt or "已签" in txt
                or "已打卡" in txt or "今天已经打卡" in txt
                or "今日已打卡" in txt or "已经打过卡" in txt)

    # ---------------- ★ v1.1.23 签到方式注册表 ----------------
    # 现在支持的签到方式（kind → 处理方法）。以后要支持新论坛/新插件：
    #   ① 在 _find_entry / FORUM_COMMON_ENTRIES 里加上该插件的入口特征；
    #   ② 写一个 _sign_xxx(entry) 方法（返回 ("ok"/"already"/"fail", 说明)，
    #      判定口径复用 _json_status / _already / _ajax_text，别自造）；
    #   ③ 在下面注册表里加一行即可，其余流程（登录校验→找入口→提交→判定）
    #      全部自动复用。
    SIGN_METHODS = {
        "paulsign": "_sign_paulsign",   # dsu_paulsign（DPS 每日签到，最常见）
        "lwdz": "_sign_lwdz",           # lwdz_signin（纯 Ajax 打卡）
        "kmisign": "_sign_kmisign",     # k_misign（萝卜签到）
        "erling_qd": "_sign_erling_qd",  # erling_qd（恩山论坛签到）
        "task": "_sign_task",           # Discuz 自带「每日签到」任务
        "generic": "_sign_generic",     # 通用兜底（页面表单 + Ajax 接口）
    }

    def sign(self):
        """执行签到。返回 (状态, 说明)，状态：ok / already / fail。"""
        try:
            ok, fh = self.login()
            if not ok:
                return "fail", fh
            html = self._req(self._url("forum.php"))
            if not self._is_logged_in(html):
                return "fail", "登录态校验失败（账号或 Cookie 未生效）"
            kind, entry = self._find_entry(html)
            if not kind:
                self.log("  首页未找到签到入口，正在探测常用插件…")
                kind, entry = self._probe_entry()
            if not kind:
                # ★ v1.1.23 兜底：不装插件的论坛常把签到挂在「任务中心」
                r = self._sign_task("")
                if r[0] != "fail":
                    return r
                return "fail", "未找到签到入口（该论坛可能没有签到功能）"
            self.log("  签到入口: %s（方式 %s）" % (entry, kind))
            handler = getattr(self, self.SIGN_METHODS.get(
                kind, "_sign_generic"))
            r = handler(entry)
            # ★ v1.1.23 首次尝试失败且不是登录问题 → 再试任务签到兜底
            if (r[0] == "fail" and kind != "task"
                    and ("登录" not in r[1])):
                self.log("  %s 方式未成功，改试任务中心签到…" % kind)
                r2 = self._sign_task(entry)
                if r2[0] != "fail":
                    return r2
            return r
        except self._ur.HTTPError as ex:
            # ★ v1.1.23：到达这里说明退避重试 2 次后仍被拦截
            # ★ v1.1.24：带上 _req 从 403 页面认出的防火墙提示
            hint = getattr(ex, "hint", "")
            return "fail", ("HTTP %s（已自动重试仍被拦截。%s）"
                            % (ex.code, hint))
        except Exception as ex:
            # ★ v1.1.28：网络瞬断重试 3 次仍失败 → 带上可执行的提示
            hint = getattr(ex, "hint", "")
            return "fail", ("异常：%s%s" % (ex, ("（%s）" % hint) if hint else ""))

    def _sign_task(self, entry):
        """★ v1.1.23 Discuz 自带「每日签到」任务（home.php?mod=task）。

        很多论坛不装签到插件，只在任务中心挂一个每日任务 —— 入口是
        home.php?mod=task&do=apply&id=N，完成后 do=draw 领奖励。
        判定从严：只认「恭喜 / 任务完成 / 已领取」这类明确文案，
        认不出就老实报 fail，绝不把没签上说成成功。"""
        taskpage = self._url("home.php?mod=task")
        try:
            page = self._req(taskpage, referer=self._url("forum.php"))
        except Exception as ex:
            return "fail", "任务中心打不开: %s" % ex
        txt = self._txt(page)
        if ("未登录" in txt) or ("请先登录" in txt):
            return "fail", "登录已失效（请重新点『登录』获取 Cookie）"
        if ("任务" not in txt):
            return "fail", "该论坛没有任务中心"
        # ① 优先找带「签到/打卡」字样的任务链接
        ids = []
        for m in re.finditer(
                r'href="([^"]*mod=task&[^"]*do=apply[^"]*id=(\d+)[^"]*)"'
                r'[^>]*>\s*([^<]{0,30})', page):
            label = m.group(3) or ""
            if ("签到" in label) or ("打卡" in label):
                if m.group(2) not in ids:
                    ids.append(m.group(2))
        # ② 链接文字不在 href 旁边（图片按钮/嵌套结构）→ 收集全部任务逐个试
        if not ids:
            for m in re.finditer(
                    r'mod=task&(?:amp;)?do=apply&(?:amp;)?id=(\d+)', page):
                if m.group(1) not in ids:
                    ids.append(m.group(1))
                if len(ids) >= 5:
                    break
        if not ids:
            return "fail", "任务中心没有找到可申请的任务"
        last = ""
        for tid in ids:
            url = "home.php?mod=task&do=apply&id=%s" % tid
            try:
                r1 = self._req(self._url(url), referer=taskpage)
            except Exception as ex:
                last = str(ex)[:40]
                continue
            t1 = self._txt(r1)
            if ("已经完成过" in t1) or ("您已领取" in t1) or self._already(t1):
                return "already", "今日已签到（任务已完成），无需重复"
            if ("恭喜" in t1) or ("任务完成" in t1) \
                    or ("签到成功" in t1) or ("打卡成功" in t1):
                return "ok", "签到成功（每日签到任务）"
            # 申请成功后常停在「进行中」→ 去领奖页确认
            try:
                r2 = self._req(self._url(
                    "home.php?mod=task&do=draw&id=%s" % tid), referer=taskpage)
                t2 = self._txt(r2)
                if ("恭喜" in t2) or ("领取成功" in t2) \
                        or ("奖励" in t2 and "发放" in t2):
                    return "ok", "签到成功（每日签到任务）"
                if ("已经完成过" in t2) or ("您已领取" in t2) or self._already(t2):
                    return "already", "今日已签到（任务已完成），无需重复"
                if ("任务" in t2 and "完成" in t2):
                    return "ok", "签到成功（每日签到任务）"
                last = t2[:36]
            except Exception as ex:
                last = str(ex)[:40]
        return "fail", "签到任务未确认（%s）" % last

    def _judge_paulsign(self, resp):
        """判定 dsu_paulsign 的签到响应：成功/已签到返回结果，否则 None。

        实测各站版本不同，响应有两类：
          · HTML：含 `签到成功`（可带『已连续签到N天』）
          · JSON：`{"status":1,"data":{"days":..,"mdays":..,"reward":..}}`
        """
        j = self._json_status(resp)
        if j is not None:
            info = j.get("info") or {}
            raw = (j.get("objs") or [{}])[0]
            if str(raw.get("status")) == "1" or j.get("status") == "success":
                bits = []
                if info.get("days"):
                    bits.append("连续%s天" % info["days"])
                if info.get("reward"):
                    bits.append("奖励%s" % info["reward"])
                return "ok", "签到成功" + ("，" + "，".join(bits) if bits else "")
            msg = str(info.get("msg") or info.get("message") or "")
            if msg:
                if "登录" in msg:
                    return "fail", "登录已失效（请重新点『登录』获取 Cookie）"
                if "签到" in msg:
                    if "已" in msg:
                        return "already", "今日已签到，无需重复"
                    return "fail", "签到未确认：%s" % msg
        txt = self._txt(resp)
        if "签到成功" in txt:
            day = re.search(r'已连续签到(\d+)天', txt)
            return "ok", "签到成功%s" % ("，" + day.group(0) if day else "")
        if self._already(txt):
            return "already", "今日已签到，无需重复"
        # ★ cym2 实测（v4.8.2）：未登录时 POST 返回
        #   succeedhandle_('member.php?mod=logging&action=login', '您需要先登录才能继续本操作')
        if ("未登录" in resp) or ("请先登录" in resp) or ("先登录才能" in resp) \
                or re.search(r"succeedhandle_\(['\"][^'\"]*mod=logging", resp):
            return "fail", "登录已失效（请重新点『登录』获取 Cookie）"
        # ★ v1.0.3 检测签到响应中的 seccheck 验证码要求
        need_sec, sec_hash, _ = self._seccheck_info(resp)
        if need_sec:
            return "fail", ("签到需要滑块验证码，纯Cookie模式无法自动完成。"
                            "请用内置浏览器手动签到：点「登录」→ 打开签到页 → 拖滑块")
        return None

    def _sign_paulsign(self, entry):
        """dsu_paulsign 签到。

        ★ 关键：提交地址是 `plugin.php?id=dsu_paulsign:sign&operation=qiandao
          &infloat=1&inajax=1`，参数 formhash/qdxq/qdmode/todaysay/fastreply；
          网上不少教程写的 `operate=withqdxq` 是错的（动词都不对）。
        不同站版本有差异，所以**优先把签到页上的表单原样提交**，再用标准参数兜底。
        """
        page = self._req(self._url(entry), referer=self._url("forum.php"))
        txt = self._txt(page)
        if self._already(txt):
            return "already", "今日已签到，无需重复"
        # ★ v1.0.3 检测 seccheck 滑块验证码
        sec_r = self._try_seccheck_bypass(page, entry, self._formhash(page))
        if sec_r is not None:
            return sec_r
        if ("请先登录" in page) or ("您需要登录" in page) \
                or ("先登录才能" in page):
            return "fail", "登录已失效（请重新点『登录』获取 Cookie）"
        fh = self._formhash(page)
        if not fh:
            return "fail", "签到页未获取到 formhash（可能未登录或被拦截）"

        # ① 优先：签到页自带表单 → 原样提交（最贴合该站版本）
        # ★ v4.8.2：不能盲取第一个表单——cym2 实测签到页第一个表单是
        #   登录表单（member.php?mod=logging&action=login），提交它永远
        #   签不上。改为在全部表单里挑真正的签到表单（跳过登录/搜索表单）。
        action, fields = self._pick_sign_form(page)
        low = (action or "").lower()
        if fields and ("formhash" in fields or "qdxq" in fields
                       or "qiandao" in low or "sign" in low):
            fields.setdefault("formhash", fh)
            # 给空字段补默认值：cym2 弹窗里心情/今日感言可能是空值，
            # 不填无法提交成功。
            if "qdxq" in fields and not fields["qdxq"]:
                fields["qdxq"] = "kx"
            if "todaysay" in fields and not fields["todaysay"]:
                fields["todaysay"] = random.choice(FORUM_TODAYSAY)
            try:
                resp = self._req(self._url(action or entry), data=fields,
                                 referer=self._url(entry))
                r = self._judge_paulsign(resp)
                if r:
                    return r
            except self._ur.HTTPError as ex:
                self.log("  表单提交被拦截(HTTP %s)，改用标准参数重试" % ex.code)

        # ② 兜底：标准提交参数
        qm = re.search(r'name="qdxq"[^>]*value="([^"]+)"', page)
        qdxq = qm.group(1) if qm else "kx"
        say = random.choice(FORUM_TODAYSAY)
        resp = self._req(
            self._url("plugin.php?id=dsu_paulsign:sign&operation=qiandao"
                      "&infloat=1&inajax=1"),
            data={"formhash": fh, "qdxq": qdxq, "qdmode": "2",
                  "todaysay": say, "fastreply": "1", "submit": "1"},
            referer=self._url(entry))
        r = self._judge_paulsign(resp)
        if r:
            return r
        # ③ 再兜底：不带 inajax 再试一次
        resp = self._req(
            self._url("plugin.php?id=dsu_paulsign:sign&operation=qiandao"),
            data={"formhash": fh, "qdxq": qdxq, "todaysay": say,
                  "fastreply": "0", "submit": "1"},
            referer=self._url(entry))
        r = self._judge_paulsign(resp)
        if r:
            return r
        m = re.search(r'(?:showError|alert)\([\'"]([^\'"]{4,40})', resp)
        return "fail", "签到未确认：%s" % (m.group(1) if m else "响应无成功标志")

    # lwdz_signin 是「纯 Ajax 打卡」插件：页面无签到表单，
    # 点按钮时执行 POST /plugin.php?id=lwdz_signin:signin
    #   参数 uid / username / formhash（都写在页面 JS 里）→ 返回 JSON
    AJAX_POST_RE = re.compile(
        r'xhr\.open\(\s*["\']POST["\']\s*,\s*["\']([^"\']+)["\']', re.I)

    @staticmethod
    def _jsvar(page, name, quoted=False):
        if quoted:
            m = re.search(r'var\s+%s\s*=\s*["\']([^"\']*)["\']' % re.escape(name), page)
        else:
            m = re.search(r'var\s+%s\s*=\s*[\'"]?([\w\-]+)' % re.escape(name), page)
        return m.group(1) if m else ""

    @staticmethod
    def _json_status(resp):
        """解析插件响应，返回统一结果字典；解析不出返回 None。

        ★ 坑：lwdz_signin 重复签到时会把**多个 JSON 串接**返回，例如
          {"status":"checked"}{"status":"success","normalReward":0}
        直接用 json.loads 会失败，落到文本兜底就会误判成「签到成功」。
        这里用 raw_decode 逐个解析，并让 checked 优先于 success。
        """
        objs = []
        i, dec = 0, json.JSONDecoder()
        while i < len(resp):
            k = resp.find("{", i)
            if k < 0:
                break
            try:
                obj, end = dec.raw_decode(resp, k)
                if isinstance(obj, dict):
                    objs.append(obj)
                i = max(end, k + 1)
            except Exception:
                i = k + 1
        if not objs:
            return None
        sts = [str(o.get("status") or o.get("code") or "").lower() for o in objs]
        if any(s in ("checked", "already", "signed") for s in sts):
            st = "checked"
        elif any(s in ("success", "ok", "1", "y", "true") for s in sts):
            st = "success"
        else:
            st = next((s for s in sts if s), "")
        info = {}
        for o in objs:
            ih = o.get("infoHanding")
            if isinstance(ih, dict) and ih:
                info = ih
            dd = o.get("data")          # 有的插件把数据放在 data 里
            if isinstance(dd, dict) and dd:
                for k, v in dd.items():
                    info.setdefault(k, v)
            for key in ("thisReward", "normalReward", "rank", "message", "msg",
                        "info"):
                if o.get(key) and key not in info:
                    info[key] = o[key]
        return {"status": st, "info": info, "objs": objs}

    def _sign_lwdz(self, entry):
        page = self._req(self._url(entry), referer=self._url("forum.php"))
        # ★ v1.0.3 检测 seccheck 滑块验证码
        sec_r = self._try_seccheck_bypass(page, entry, self._formhash(page))
        if sec_r is not None:
            return sec_r
        uid = self._jsvar(page, "uid")
        uname = self._jsvar(page, "username", quoted=True)
        fh = self._jsvar(page, "formhash", quoted=True) or self._formhash(page)
        sign_name = self._jsvar(page, "signName", quoted=True) or "签到"
        reward = self._jsvar(page, "rewardTitle", quoted=True)

        # 页面已明示「今天已打卡」→ 直接返回，省一次请求也避免误判
        today = datetime.now().strftime("%Y-%m-%d")
        if ("已%s" % sign_name) in page and today in page:
            return "already", "今日已%s，无需重复" % sign_name

        # ★ uid=0 / username 为空 = 游客态（页面 JS 里仍会输出占位值，
        #   实测 73su/82pc 游客态就是 uid='0' username=''，不能当成已登录）
        if (not uid) or uid == "0" or (not uname) or (not fh):
            if self._already(self._txt(page)):
                return "already", "今日已签到，无需重复"
            if ("未登录" in page) or ("请先登录" in page):
                return "fail", "登录已失效（请重新点『登录』获取 Cookie）"
            # 页面结构不符（插件升级）→ 退回通用方式
            return self._sign_generic(entry)

        resp = self._req(
            self._url("plugin.php?id=lwdz_signin:signin"),
            data={"uid": uid, "username": uname, "formhash": fh},
            referer=self._url(entry))
        j = self._json_status(resp)
        if j is not None:
            st = j.get("status")
            info = j.get("info") or {}
            if st == "checked":
                return "already", "今日已%s，无需重复" % sign_name
            if st == "success":
                bits = []
                days = info.get("continuousDays")
                if days and str(days) != "1":
                    bits.append("连续%s天" % days)
                rew = info.get("thisReward") or info.get("normalReward")
                if rew:
                    bits.append("%s+%s" % (reward or "奖励", rew))
                return "ok", "%s成功%s" % (sign_name,
                                           "，" + "，".join(bits) if bits else "")
            msg = info.get("message") or info.get("msg") or info.get("info") or ""
            if "登录" in str(msg):
                return "fail", "登录已失效（请重新点『登录』获取 Cookie）"
            return "fail", "%s未成功：%s" % (sign_name, msg or ("status=%s" % st))
        # 非 JSON 响应 → 文本兜底（严格，不看裸 success 字样，避免误判）
        txt = self._txt(resp)
        if ("签到成功" in txt) or ("打卡成功" in txt) or ("成功" in txt and "已" not in txt):
            return "ok", "签到成功"
        if self._already(txt):
            return "already", "今日已签到，无需重复"
        if ("未登录" in resp) or ("请先登录" in resp):
            return "fail", "登录已失效（请重新点『登录』获取 Cookie）"
        return "fail", "签到未确认（插件返回内容无法识别）"

    @staticmethod
    def _km_done(page):
        """k_misign 页面是否已显示今日已签到。

        实测（0lb）已签到态特征：
          <span class="btn btnvisted"></span>  +  『您的签到排名：299』
          <img id="fx_checkin_b" alt="今日已签">
        未签到态：<a id="JD_sign" class="btn J_chkitot"> + 『您今天还没有签到』
        """
        return ("btnvisted" in page or "您的签到排名" in page
                or "今日已签" in page or "您今天已签到" in page
                or "今日已签到" in page or "已经签到" in page
                or "您已签到" in page or "已打卡" in page)

    def _sign_kmisign(self, entry):
        """k_misign（萝卜签到）插件。

        签到按钮 <a id="JD_sign" class="btn J_chkitot">：
          - 游客态它的 href 指向登录页
          - 登录态 href 一般是带参数的签到地址（或由页面 JS 触发）
        页面文案『您今天还没有签到 / 您今天已签到』可直接判断状态，
        所以提交后再复核一次页面，最稳。
        """
        url = self._url(entry)
        try:
            page = self._req(url, referer=self._url("forum.php"))
        except self._ur.HTTPError as ex:
            # ★ v1.1.24 伪静态 k_misign-sign.html 被防火墙单独拦截时，
            #   换回插件原始地址 plugin.php?id=k_misign:sign 再试一次
            if ex.code == 403 and "k_misign" in entry:
                url = self._url("plugin.php?id=k_misign:sign")
                self.log("  %s 被 403 拦截，改试插件原始地址…" % entry)
                page = self._req(url, referer=self._url("forum.php"))
            else:
                raise
        if self._km_done(page):
            return "already", "今日已签到，无需重复"
        # ★ v1.0.3 检测 seccheck 滑块验证码（恩山等站点签到时触发）
        sec_r = self._try_seccheck_bypass(page, entry, self._formhash(page))
        if sec_r is not None:
            return sec_r
        fh = self._formhash(page)
        cands = []
        for pat in (r'<a[^>]*id="JD_sign"[^>]*href="([^"]*)"',
                    r'<a[^>]*href="([^"]*)"[^>]*id="JD_sign"',
                    r'<a[^>]*class="[^"]*J_chkitot[^"]*"[^>]*href="([^"]*)"',
                    r'<a[^>]*href="([^"]*)"[^>]*class="[^"]*J_chkitot[^"]*"'):
            m = re.search(pat, page)
            if m:
                href = m.group(1).replace("&amp;", "&")
                # 游客态按钮指向登录页、或按钮只是个 javascript: 占位符 → 跳过。
                # ★ ruciwan 的 <a id="JD_sign" href="javascript:;"> 就是后者，
                #   拿它当提交地址只会白发一个无意义请求。
                if (href and "logging" not in href
                        and not href.lower().startswith(("javascript:", "#"))
                        and href not in cands):
                    cands.append(href)
                break
        if fh:
            cands.append(
                "plugin.php?id=k_misign:sign&operation=qiandao&formhash=" + fh)
            # ★ 官方前端脚本同款参数（format=empty&inajax=1&ajaxtarget=JD_sign），
            #   部分站点版本只认这一套；前一个候选没命中时再试它。
            cands.append(
                "plugin.php?id=k_misign:sign&operation=qiandao&formhash=%s"
                "&format=empty&inajax=1&ajaxtarget=JD_sign" % fh)
        if not cands:
            # 文案口径与 _sign_paulsign 保持一致，否则掉登录态时会误报成
            # 「未找到可提交的签到地址」，用户不知道该重新登录。
            if ("未登录" in page) or ("请先登录" in page) \
                    or ("先登录才能" in page) or ("需要先登录" in page) \
                    or ("需要登录" in page):
                return "fail", "登录已失效（请重新点『登录』获取 Cookie）"
            return "fail", "签到页未找到可提交的签到地址"
        last = ""
        for c in cands:
            try:
                resp = self._req(self._url(c), referer=url)
            except self._ur.HTTPError as ex:
                last = "HTTP %s" % ex.code
                continue
            except Exception as ex:
                last = str(ex)[:40]
                continue
            j = self._json_status(resp)
            if j is not None:
                if j["status"] == "success":
                    return "ok", "签到成功"
                if j["status"] == "checked":
                    return "already", "今日已签到，无需重复"
                last = j["status"] or "响应无状态字段"
            t = self._ajax_text(resp)
            if ("签到成功" in t) or ("打卡成功" in t):
                return "ok", "签到成功"
            # ★ 回执直接就是「今日已签」这类文案（ruciwan 的 CDATA 回执），
            #   那表示今天早就签过了，不能落到下面的兜底记成「签到成功」。
            if self._already(t):
                return "already", "今日已签到，无需重复"
            if self._km_done(resp) or self._km_done(t):
                return "ok", "签到成功"
            # 复核：重新打开签到页看状态是否已变为「已签到」
            try:
                if self._km_done(self._req(url, referer=url)):
                    return "ok", "签到成功"
            except Exception:
                pass
            last = last or "响应无成功标志"
        return "fail", "签到未确认（%s）" % last

    # ---- ★ v1.0.4 恩山论坛 erling_qd 签到插件 ----
    @staticmethod
    def _is_waf_page(html):
        """识别 WAF 滑块/挑战页（阿里云 ESA / Cloudflare 等）。

        恩山论坛对伪静态地址 erling_qd-sign_in.html 会返回阿里云 ESA 的滑块
        验证页（含 AliyunCaptcha.js / CF_APP_WAF），纯 Cookie 模式解不开，
        必须换用 plugin.php 原始地址（WAF 放行）。
        """
        if not html:
            return False
        low = html.lower()
        if ("aliyuncaptcha" in low) or ("cf_app_waf" in low) \
                or ("cf_wsui" in low) or ("cf-ray" in low) \
                or ("just a moment" in low):
            return True
        if ("请完成以下操作" in html) and ("验证" in html) and len(html) < 40000:
            return True
        return False

    # ---- ★ v1.0.5 erling_qd 精准判定（治「假成功」）----
    @staticmethod
    def _erling_page_state(html_or_txt):
        """判定 erling_qd 签到面板里**当前用户**的签到状态。

        返回 "signed" / "unsigned" / "unknown"。

        ★★ 血泪教训（v1.0.4 假成功 bug 根因）★★
        签到页上有一句**全站计数**：「今日已签到：3737 人」——
        里面就含「已签到」三个字。旧代码直接套用通用 _already() 判断，
        于是「今天根本没签」被误报成「今日已签到，无需重复」，
        用户看到的就是「显示签到了、实际没签到」。
        所以这里**必须先剔除该计数**，再按按钮文案判定：
          · 面板有「立即签到」按钮        → 未签到（unsigned）
          · 无「立即签到」但有签到痕迹    → 已签到（signed）
          · 都不是                        → unknown（交给接口 JSON 判定）
        """
        if not html_or_txt:
            return "unknown"
        if "<" in html_or_txt:          # 传进来的是 HTML，先去标签
            html_or_txt = DiscuzForumSigner._txt(html_or_txt)
        t = html_or_txt
        # 剔除全站计数：今日已签到：3737 人 / 今日已签到 3737 人
        t = re.sub(r"今日已签到\s*[：:]\s*\d+\s*人?", "", t)
        t = re.sub(r"今日已签到\s*\d+\s*人", "", t)
        if "立即签到" in t:
            return "unsigned"
        if ("连续签到" in t) or ("今日已签到" in t) or ("已经签到" in t) \
                or ("明天再来" in t) or ("签到成功" in t):
            return "signed"
        return "unknown"

    @staticmethod
    def _erling_json(resp):
        """把 erling_qd 接口返回解析成 dict。

        接口回的是 {"success":true|false,"message":"..."}，其中 message
        是 **\\uXXXX 转义**的中文（例：\\u8bf7\\u5148\\u767b\\u5f55 =
        「请先登录」）。所以在原始字符串上做中文子串匹配一定失败，
        必须 json.loads 解回中文。
        """
        if not resp:
            return None
        m = re.search(r"\{.*\}", resp, re.S)
        if not m:
            return None
        try:
            obj = json.loads(m.group(0))
        except Exception:
            return None
        return obj if isinstance(obj, dict) else None

    def _erling_confirm(self):
        """签到后再读一次签到页，确认状态真的变了。

        返回 "signed" / "unsigned" / "unknown"。
        这是**防假成功的最后一道闸**：接口回 success 但页面仍显示
        「立即签到」时，判定为未生效（报 fail），绝不报成功。
        """
        for path in ("plugin.php?id=erling_qd:sign_in",
                     "erling_qd-sign_in.html"):
            try:
                p = self._req(self._url(path), referer=self._url("forum.php"))
            except Exception:
                continue
            if self._is_waf_page(p):
                continue
            return self._erling_page_state(p)
        return "unknown"

    @staticmethod
    def _erling_formhash(page):
        """从 erling_qd 签到页里取 formhash（v1.0.6）。

        恩山论坛签到页里有一行 `var FORMHASH = 'a3385cae';`，浏览器端
        的真实签到就是把这个值 POST 给接口：
            $.ajax({url:'plugin.php?id=erling_qd:action&action=sign',
                    type:'POST', dataType:'json',
                    data:{ formhash: FORMHASH }});
        插件服务端走 Discuz 的 submitcheck()，**必须**读到 $_POST['formhash']
        且与会话 formhash 一致，否则回「请求来源验证失败」。

        兼容三种写法：
          · JS:   var FORMHASH = 'a3385cae';
          · JS:   FORMHASH : 'a3385cae'  /  formhash: "a3385cae"
          · HTML: <input type="hidden" name="formhash" value="a3385cae">
        """
        if not page:
            return ""
        m = re.search(r"FORMHASH\s*=\s*['\"]([0-9a-zA-Z]{6,})['\"]", page)
        if m:
            return m.group(1)
        m = re.search(r"formhash\s*[:=]\s*['\"]([0-9a-zA-Z]{6,})['\"]",
                      page, re.I)
        if m:
            return m.group(1)
        return DiscuzForumSigner._formhash(page)

    def _sign_erling_qd(self, entry):
        """恩山论坛（right.com.cn）erling_qd 签到插件。

        ★★ 实测要点（v1.0.6，登录态下本机抓包 + 复现验证）★★
          1) 伪静态入口 erling_qd-sign_in.html 被站点 CDN/WAF（阿里云 ESA +
             CF_APP_WAF）拦成**滑块验证页**（含 AliyunCaptcha、「滑动」）——
             用户必须先拖滑块，签到按钮才出现。纯 Cookie（HTTP）模式过不了
             滑块，所以**一律改用 plugin.php?id=erling_qd:sign_in**：
             同一插件页、同一登录态，但**不经 WAF、无滑块**。
          2) 真正的签到是 JSON 接口（不是表单 POST）：
               POST plugin.php?id=erling_qd:action&action=sign
               返回 {"success":true|false,"message":"..."}
                 未登录 → {"success":false,"message":"请先登录"}
             （message 是 \\uXXXX 转义，必须 json.loads 解中文再判断）
          3) ★ 必须带 **formhash**（浏览器同款配方，v1.0.6 修正）：
                 页面里有 var FORMHASH = 'a3385cae';  取出来
                 POST data={formhash:<FORMHASH>}
                 + X-Requested-With: XMLHttpRequest
                 + Referer: plugin.php?id=erling_qd:sign_in
                 + Origin: https://www.right.com.cn
             插件服务端走 Discuz submitcheck()，缺/错 formhash 就回
             「请求来源验证失败」。
             ⚠ 旧版「绝对不要带 formhash」是**错的**：那只是**未登录 /
             缺 WAF 校验 Cookie（acw_tc、cdn_sec_tc）**时，本站 WAF 对
             字面量 formhash 的误拦假象。带着有效登录会话时，POST formhash
             会被 WAF 放行、插件才认。实测：POST {formhash:'a3385cae'} →
             {"success":true,"message":"签到成功"}，页面「立即签到」消失、
             变为「连续签到 1 天」。
          4) ⚠ 判定只认接口 JSON，页面文案仅用于①排除已登录失效 ②二次确认。
             页面那句「今日已签到：N 人」是**全站计数**，含「已签到」子串，
             用通用 _already() 会误判成「你今天已签到」——即 v1.0.4 的
             「显示签到了、实际没签到」假成功 bug（见 _erling_page_state）。
          5) 接口回 success 后**必须二次确认**：再读一次签到页，若仍显示
             「立即签到」则判未生效（报 fail），绝不报成功。
        """
        # ① 取签到页（只用 plugin.php，绕开伪静态的 WAF 滑块）
        page, last_err = None, ""
        for path in ("plugin.php?id=erling_qd:sign_in",
                     entry or "plugin.php?id=erling_qd:sign_in"):
            try:
                cand = self._req(self._url(path),
                                 referer=self._url("forum.php"))
            except Exception as ex:
                last_err = str(ex)[:60]
                continue
            if self._is_waf_page(cand):
                last_err = "被 WAF 滑块拦截"
                continue
            page = cand
            break
        if page is None:
            return "fail", ("签到页被站点人机验证（WAF 滑块）拦截。纯 Cookie "
                            "模式过不了滑块：请在『登录/内置浏览器』里打开签到页"
                            "拖一次滑块后再试（%s）" % (last_err or "未知"))
        txt = self._txt(page)
        if ("请先登录" in txt) or ("您需要登录" in txt) or ("未登录" in txt):
            return "fail", "登录已失效（请重新点『登录』获取 Cookie）"
        # ② 页面状态：只做「已签到」的正向判断（已剔除全站计数）
        if self._erling_page_state(txt) == "signed":
            return "already", "今日已签到，无需重复"
        # ③ 取 formhash（插件 submitcheck() 必需；浏览器端就是 POST 它）
        fh = self._erling_formhash(page)
        # ④ 按浏览器真实 Ajax 配方调签到接口（主路径 POST formhash）
        _om = re.match(r"(https?://[^/]+)", self.base or "")
        origin = _om.group(1) if _om else ""
        sign_page = self._url("plugin.php?id=erling_qd:sign_in")
        hdr = {"X-Requested-With": "XMLHttpRequest",
               "Accept": "application/json, text/javascript, */*; q=0.01"}
        if origin:
            hdr["Origin"] = origin
        api = self._url("plugin.php?id=erling_qd:action&action=sign")
        attempts = []
        if fh:
            attempts.append(("post-formhash", {"formhash": fh}))
        attempts.append(("post-min", {}))          # 兜底：不带 formhash
        attempts.append(("get", None))             # 兜底：GET
        errs = []
        for mode, d in attempts:
            try:
                if mode == "get":
                    r = self._req(api, referer=sign_page, extra_headers=hdr)
                else:
                    r = self._req(api, data=d, referer=sign_page,
                                  extra_headers=hdr)
            except Exception as ex:
                errs.append("%s:%s" % (mode, str(ex)[:32]))
                continue
            if (not r) or self._is_waf_page(r) or ("System Error" in r):
                errs.append("%s:被拦截" % mode)
                continue
            obj = self._erling_json(r)
            if obj is None:
                errs.append("%s:非JSON" % mode)
                continue
            succ = obj.get("success")
            msg = str(obj.get("message") or obj.get("msg") or "")
            if str(succ).lower() in ("true", "1", "yes"):
                # ★ 二次确认：页面必须真的变成「已签到」才算数
                conf = self._erling_confirm()
                if conf == "unsigned":
                    return "fail", ("接口返回成功，但签到页仍显示『立即签到』"
                                    "——本次可能未真正生效，请在内置浏览器确认")
                return "ok", "签到成功%s" % ("（%s）" % msg if msg else "")
            if ("已签到" in msg) or ("已经签到" in msg) or ("已打卡" in msg) \
                    or ("明天再来" in msg):
                return "already", "今日已签到，无需重复"
            if ("请先登录" in msg) or ("未登录" in msg):
                return "fail", "登录已失效（请重新点『登录』获取 Cookie）"
            if msg:
                errs.append(msg)
        detail = "；".join([e for e in errs if e][:3]) or "无有效响应"
        return "fail", ("签到未成功（%s）。若站点提示需要验证/滑块，请在"
                        "『登录/内置浏览器』里打开签到页手动签到" % detail[:90])

    def _sign_generic(self, entry):
        """通用签到：优先找真签到表单，其次尝试页面 JS 里的 Ajax 接口。"""
        page = self._req(self._url(entry), referer=self._url("forum.php"))
        txt = self._txt(page)
        if self._already(txt):
            return "already", "今日已签到，无需重复"
        # ★ v1.0.3 检测 seccheck 滑块验证码
        sec_r = self._try_seccheck_bypass(page, entry, self._formhash(page))
        if sec_r is not None:
            return sec_r
        if ("未登录" in txt) or ("请先登录" in txt):
            return "fail", "登录已失效（请重新点『登录』获取 Cookie）"

        # ① 表单方式：必须像签到表单（含 formhash 或提交地址带 sign/qd/打卡）
        # ★ v1.0.4：改用 _pick_sign_form（跳过登录/搜索表单）——直接取页面
        #   第一个表单会把顶部登录表单/搜索框当签到表单提交，永远签不上。
        action, fields = self._pick_sign_form(page)
        low = (action or "").lower()
        looks_sign = bool(fields) and (
            "formhash" in fields or "sign" in low or "qiandao" in low
            or "qd" in low or "checkin" in low)
        if looks_sign:
            resp = self._req(self._url(action or entry), data=fields,
                             referer=self._url(entry))
            j = self._json_status(resp)
            if j is not None:
                if j["status"] == "success":
                    return "ok", "签到成功"
                if j["status"] == "checked":
                    return "already", "今日已签到，无需重复"
            t = self._txt(resp)
            if ("签到成功" in t) or ("打卡成功" in t):
                return "ok", "签到成功"
            if self._already(t):
                return "already", "今日已签到，无需重复"
            return "fail", "签到未确认（表单已提交但无成功标志）"

        # ② Ajax 方式：从页面 JS 找 POST 地址，按 lwdz 同款参数尝试
        m = self.AJAX_POST_RE.search(page)
        if m:
            api = m.group(1).replace("&amp;", "&")
            data = {"formhash": self._formhash(page)}
            uid = self._jsvar(page, "uid")
            uname = self._jsvar(page, "username")
            if uid and uid != "0":          # uid=0 是游客态占位值
                data["uid"] = uid
            if uname:
                data["username"] = uname.strip().strip("'\"")
            resp = self._req(self._url(api), data=data, referer=self._url(entry))
            j = self._json_status(resp)
            if j is not None:
                st = str(j.get("status") or j.get("code") or "").lower()
                if st in ("success", "ok", "1", "y", "true"):
                    return "ok", "签到成功"
                if st in ("checked", "already", "signed"):
                    return "already", "今日已签到，无需重复"
                msg = j.get("message") or j.get("msg") or ""
                if "登录" in str(msg):
                    return "fail", "登录已失效（请重新点『登录』获取 Cookie）"
                return "fail", "签到未确认：%s" % (msg or ("status=%s" % st))
            t = self._txt(resp)
            if "成功" in t:
                return "ok", "签到成功"
            if self._already(t):
                return "already", "今日已签到，无需重复"
            return "fail", "签到未确认（Ajax 已提交但无成功标志）"

        # ③ ★ v1.1.23 最后兜底：直接 POST formhash 到插件页本身。
        #    一批简单签到插件（wq_sign/dc_sign 等）就认这个姿势；
        #    提交错也无害（站点只是回个无效请求页面）。
        fh = self._formhash(page)
        if fh and entry:
            try:
                resp = self._req(self._url(entry), data={"formhash": fh},
                                 referer=self._url(entry))
                j = self._json_status(resp)
                if j is not None:
                    st = str(j.get("status") or j.get("code") or "").lower()
                    if st in ("success", "ok", "1", "y", "true"):
                        return "ok", "签到成功"
                    if st in ("checked", "already", "signed"):
                        return "already", "今日已签到，无需重复"
                t = self._txt(resp)
                if ("签到成功" in t) or ("打卡成功" in t):
                    return "ok", "签到成功"
                if self._already(t):
                    return "already", "今日已签到，无需重复"
            except Exception:
                pass

        return "fail", "该论坛未找到可用的签到接口（可能是非标准插件）"


class _no_proxy_env(object):
    """临时把目标主机加进 no_proxy 环境变量。

    为什么需要：websocket-client 在未显式指定 http_proxy_host 时，会自己去读
    环境变量 / 系统代理（get_proxy_info）。此时传 http_no_proxy 参数是无效的
    （proxy_info 只在 proxy_host 非空时才读它）。本机装了代理软件时，
    连 127.0.0.1 的 ws 请求也会被丢给代理，表现为
    "failed CONNECT via proxy status: 502" 或者连接极慢。所以直接改环境变量，
    用完立刻还原，不污染其它模块（论坛签到等仍按原样走系统代理）。
    """

    KEYS = ("no_proxy", "NO_PROXY")

    def __init__(self, hosts):
        self.hosts = [h for h in (hosts or []) if h]
        self.old = {}

    def __enter__(self):
        for k in self.KEYS:
            self.old[k] = os.environ.get(k)
            cur = [x for x in (self.old.get(k) or "").replace(" ", "").split(",")
                   if x]
            for h in self.hosts:
                if h not in cur:
                    cur.append(h)
            try:
                os.environ[k] = ",".join(cur)
            except Exception:
                pass
        return self

    def __exit__(self, *exc):
        for k, v in self.old.items():
            try:
                if v is None:
                    os.environ.pop(k, None)
                else:
                    os.environ[k] = v
            except Exception:
                pass
        return False


_WS_HDR_KW = None


def _ws_header_kw():
    """探测本机 websocket-client 设置「附加请求头」的参数名。

    官方版（≥1.0）是 additional_headers，部分变体 / 老版是 header。
    用错名字会被 create_connection 的 **options 静默吞掉——不报错，
    但 Token 头根本没发出去，服务端会直接拒连。所以必须探测。
    """
    global _WS_HDR_KW
    if _WS_HDR_KW:
        return _WS_HDR_KW
    name = "header"
    try:
        import websocket
        root = os.path.dirname(getattr(websocket, "__file__", "") or "")
        for dirpath, dirs, files in os.walk(root):
            dirs[:] = [d for d in dirs if d != "__pycache__"]
            for fn in files:
                if not fn.endswith(".py"):
                    continue
                try:
                    with open(os.path.join(dirpath, fn), "r",
                              encoding="utf-8", errors="replace") as f:
                        if "additional_headers" in f.read():
                            name = "additional_headers"
                            break
                except Exception:
                    continue
            if name != "header":
                break
    except Exception:
        pass
    _WS_HDR_KW = name
    return name


class OneBotWS(object):
    """OneBot 11 协议 WebSocket 客户端（正向 WS）。

    连接 NapCatQQ / LLOneBot / Lagrange / go-cqhttp 等 QQ 机器人框架暴露的
    ws 服务，实现「拉群列表 / 发群签到消息 / 点赞」。

    协议：每个请求形如 {"action": "...", "params": {...}, "echo": "<id>"}，
    服务端回包带上同一个 echo。这里采用同步请求-响应模型（加锁串行化），
    忽略中间夹杂的事件帧（心跳、群消息等），直到拿到匹配 echo 的回包。
    相比后台 recv 线程，这种模型不会因 socket 超时导致半包错位，更稳。
    """

    def __init__(self, url, token="", log=None):
        self.url = (url or "").strip()
        self.token = (token or "").strip()
        self.log = log or (lambda m: None)
        self.ws = None
        self.self_id = ""
        self.nickname = ""
        self._io = threading.Lock()      # 串行化：同一时刻只允许一个请求在途
        self._seq = 0
        # ⭐ 心跳保活（v1.0.2）：业务层 get_status 心跳 + 断线自动重连（同 v10）
        self.ka_interval = 30            # 心跳间隔（秒）
        self._ka_stop = threading.Event()
        self._ka_thread = None
        self._hb_seq = 0
        self._hb_fails = 0
        # ⭐ v1.1.13 事件回调：群消息/通知这类**推送帧**会交给它处理
        #   （红包监测靠它收群消息）。签名 cb(event_dict) -> None。
        #   ⚠ 回调是在「持有 _io 锁」时被调用的，里面**不能**同步再发
        #     OneBot 请求（会自锁死），要发请求请另起线程。
        self._on_event = None
        # ⭐ 2026-10-09 反向 WS（OneBot 11 反向 WebSocket）：
        #   reverse=True 表示这条连接是**机器人框架主动连进来**的（我们不拨号），
        #   由 attach() 接管已建立的 socket。此时心跳线程不再自动重拨 ——
        #   断开后由 service 的反向监听线程负责重新 attach。
        self.reverse = False
        # 反向连接掉线时的回调 cb() -> None（service 用它更新连接状态）
        self._on_gone = None

    # ---------------- 连接
    def connect(self, timeout=8):
        import websocket
        if self.ws is not None:
            return True
        if not self.url:
            raise RuntimeError("未填写 WS 地址")
        if not re.match(r"^wss?://", self.url, re.I):
            self.url = "ws://" + self.url
        headers = []
        if self.token:
            headers.append("Authorization: Bearer %s" % self.token)
        self.log("连接 %s ..." % self.url)
        # 关键：本机 / 局域网 WS 绝不能走系统代理。
        # 本机装了代理软件时，websocket-client 会把 127.0.0.1 的 ws 请求也发给
        # 代理（表现为 "failed CONNECT via proxy status: 502" 或极慢），必须绕开。
        try:
            host = urllib.parse.urlparse(self.url).hostname or ""
        except Exception:
            host = ""
        no_proxy = ["127.0.0.1", "localhost", "::1"]
        if host and host not in no_proxy:
            no_proxy.append(host)
        kw = {"timeout": timeout, "http_no_proxy": no_proxy}
        if headers:
            kw[_ws_header_kw()] = headers
        with _no_proxy_env(no_proxy):
            self.ws = websocket.create_connection(self.url, **kw)
        try:
            info = self.get_login_info(timeout=timeout) or {}
        except Exception as ex:
            # 连上却拿不到登录信息：若 socket 已断，多半是 Token 不对被服务端拒绝
            if self.ws is None:
                raise RuntimeError("连接被服务端拒绝（Token 可能不正确）：%s" % ex)
            info = {}
            self.log("（未获取到登录信息，忽略：%s）" % ex)
        self.self_id = str(info.get("user_id", "") or "")
        self.nickname = str(info.get("nickname", "") or "")
        self._start_keepalive()
        return True

    def attach(self, ws, self_id="", nickname="", timeout=8):
        """★ 2026-10-09 反向 WS：接管一个**已建立**的 WebSocket（框架主动连进来的）。

        与 connect() 的唯一区别：connect() 主动拨号，attach() 用的是别人送上门、
        已经握好手的 socket。连上之后的协议完全一样，所以这里只做三件事：
          1) 记住 ws 并标 reverse=True；
          2) 拉一次登录信息（拿 QQ 号 / 昵称，拿不到也不算失败）；
          3) 起心跳线程。
        """
        if self.ws is not None:
            return True
        self.reverse = True
        self.ws = ws
        try:
            info = self.get_login_info(timeout=timeout) or {}
        except Exception as ex:
            # 连上却问不到登录信息：多半是框架刚连上还没就绪，不算致命
            info = {}
            self.log("（未获取到登录信息，忽略：%s）" % ex)
        self.self_id = str(self_id or info.get("user_id", "") or "")
        self.nickname = str(nickname or info.get("nickname", "") or "")
        self._start_keepalive()
        return True

    def _fire_gone(self):
        """反向连接掉线：通知回调（供心跳线程在退出前调用，不抛异常）。"""
        cb = self._on_gone
        if cb is None:
            return
        try:
            cb()
        except Exception:
            pass

    # ---------------- 心跳保活（v1.0.2：v10 式业务层心跳 + 断线自动重连）
    def _start_keepalive(self):
        """启动心跳线程：定时发 OneBot 业务层 get_status 心跳，断线自动重连。

        机制与 C# 版小工具（v10）一致，比协议层 ping 帧更可靠：
          1) 每 ka_interval 秒（30s）发 {"action":"get_status","echo":"hb_<seq>"}，
             同步等服务端回包最多 10 秒——回包要走完 NapCat 完整业务链路，
             能真正确认服务端活着，而不只是 TCP 层有数据流动；
          2) 连续 2 次无响应/异常（约 60 秒）→ 判定连接死亡 → 自动重连；
          3) 未连接时也会在每个周期尝试自动重连（手动断开除外）；
          4) 重连失败不放弃，随下个心跳周期再试（天然 30 秒限速，不会风暴）。
        """
        t = self._ka_thread
        if t is not None and t.is_alive():
            self._ka_stop.clear()        # 复用现有线程（close 后重连的场景）
            return
        self._ka_stop.clear()
        self._hb_seq = 0
        self._hb_fails = 0               # 连续无响应次数

        def loop():
            while not self._ka_stop.wait(self.ka_interval):
                if self.ws is None:
                    if self.reverse:
                        # ★ 反向 WS：**不主动拨号** —— 断开后等框架重新连进来，
                        #   由 service 的反向监听线程重新 attach。心跳线程就此收工。
                        self.log("反向 WS 已断开，等待机器人框架重新连入…")
                        self._fire_gone()
                        return
                    # 未连接：尝试自动重连（手动断开时 _ka_stop 已 set，循环会退出）
                    try:
                        self.log("⏳ WS 未连接，尝试自动重连…")
                        self._hb_reconnect()
                    except Exception as ex:
                        self.log("[心跳] 自动重连失败：%s（%d 秒后再试）"
                                 % (ex, self.ka_interval))
                    continue
                self._hb_seq += 1
                try:
                    self._call("get_status", {}, timeout=10,
                               echo="hb_%d" % self._hb_seq)   # v10 同款 hb_ 前缀
                    self._hb_fails = 0            # 心跳正常，清零
                except Exception as ex:
                    self._hb_fails += 1
                    if self._hb_fails < 2:
                        self.log("⚠ 心跳无响应（%d/2）：%s" % (self._hb_fails, ex))
                        continue                  # 单次抖动，下个周期再确认
                    if self.reverse:
                        # ★ 反向 WS：不回拨，交给监听线程重新 attach
                        self.log("反向 WS 连接已断开，等待机器人框架重新连入…")
                        self.ws = None
                        self._fire_gone()
                        return
                    self.log("[心跳] 连接已断开，尝试重连…")
                    try:
                        self._hb_reconnect()
                        self._hb_fails = 0
                        self.log("[心跳] 自动重连成功")
                    except Exception as ex2:
                        self.log("[心跳] 自动重连失败：%s（%d 秒后再试）"
                                 % (ex2, self.ka_interval))

        self._ka_thread = threading.Thread(
            target=loop, daemon=True, name="ws-keepalive")
        self._ka_thread.start()

    def _hb_reconnect(self):
        """心跳线程内部的重连：关掉旧连接 → connect() 重新拨号。"""
        self.close(keepalive_stop=False)     # 只关 socket，别停掉心跳线程自己
        if self._ka_stop.is_set():
            return                           # 用户刚好点了断开，别再连回去
        self.connect()

    def close(self, keepalive_stop=True):
        if keepalive_stop:
            self._ka_stop.set()              # 停掉心跳线程（重连时 connect 会再拉起）
        ws, self.ws = self.ws, None
        if ws is None:
            return
        try:
            ws.settimeout(2)
            ws.close()
        except Exception:
            pass

    def is_alive(self):
        return self.ws is not None

    # ---------------- 通用调用
    def call(self, action, params=None, timeout=10):
        """发送一个 OneBot 动作并同步等待回包，返回 data 字段。

        call 本身不做重连重试（单次请求语义干净）；断线恢复由心跳线程负责：
        _start_keepalive 每秒级周期发 get_status 业务心跳，连续 2 次无响应
        自动重连（v1.0.2，机制同 C# 版 v10）。
        """
        return self._call(action, params, timeout)

    def _call(self, action, params=None, timeout=10, echo=None):
        """单次请求-响应，无任何重连重试。echo 可自定义（心跳用 hb_ 前缀）。"""
        import websocket
        if self.ws is None:
            raise RuntimeError("尚未连接 WS 服务")
        with self._io:
            self._seq += 1
            if echo is None:
                echo = "zsf-%d-%d" % (int(time.time() * 1000) % 1000000,
                                      self._seq)
            payload = json.dumps({"action": action, "params": params or {},
                                  "echo": echo}, ensure_ascii=False)
            try:
                self.ws.send(payload)
            except Exception as ex:
                self.ws = None
                raise RuntimeError("发送失败，连接已断开：%s" % ex)
            deadline = time.time() + timeout
            while True:
                remain = deadline - time.time()
                if remain <= 0:
                    raise TimeoutError("%s 响应超时（%ss）" % (action, timeout))
                self.ws.settimeout(max(0.3, min(remain, 2.0)))
                try:
                    raw = self.ws.recv()
                except websocket.WebSocketTimeoutException:
                    continue
                except Exception as ex:
                    self.ws = None
                    raise RuntimeError("连接已断开：%s" % ex)
                if not raw:
                    continue
                try:
                    msg = json.loads(raw)
                except Exception:
                    continue
                if str(msg.get("echo")) != echo:
                    # 事件帧（群消息 / 通知 / 请求…）→ 交回调；其余回包直接跳过
                    if isinstance(msg, dict) and msg.get("post_type"):
                        self._dispatch_event(msg)
                    continue                      # 事件帧 / 其它回包，跳过
                ret = msg.get("retcode", 0)
                if ret not in (0, None) or \
                        str(msg.get("status", "ok")).lower() == "failed":
                    raise RuntimeError("%s 失败：retcode=%s %s"
                                       % (action, ret,
                                          msg.get("wording") or msg.get("message")
                                          or msg.get("msg") or ""))
                return msg.get("data")

    # ---------------- 事件分发（v1.1.13）
    def _dispatch_event(self, msg):
        """把推送事件交给回调。

        ⚠ 本方法在**持有 _io 锁**时被调用（_call 的收包循环里、poll_events 里），
        回调中若再同步调用 call()/send_*() 会自锁死 —— 需要发请求请另起线程。
        """
        cb = self._on_event
        if cb is None:
            return
        try:
            cb(msg)
        except Exception:
            pass

    def poll_events(self, timeout=1.0):
        """空闲时主动取一帧推送事件并分发，实现「不等心跳也能及时收到群消息」。

        与 _call 共用同一把 _io 锁，且用**非阻塞**方式抢锁：
        有请求在途（签到/点赞/心跳）时立刻返回 —— 那时事件会由那次请求的
        收包循环顺带分发。绝不并发读同一个 socket，否则回包会串。
        """
        import websocket
        ws = self.ws
        if ws is None:
            return False
        if not self._io.acquire(blocking=False):
            return False              # 有请求在跑，事件交给它的 recv 循环
        try:
            try:
                ws.settimeout(max(0.05, float(timeout)))
            except Exception:
                return False
            try:
                raw = ws.recv()
            except websocket.WebSocketTimeoutException:
                return False          # 这段时间没有事件，正常
            if not raw:
                return False
            try:
                msg = json.loads(raw)
            except Exception:
                return False
            if isinstance(msg, dict) and msg.get("post_type"):
                self._dispatch_event(msg)
                return True
            return False
        except Exception:
            self.ws = None            # 连接坏了，交给心跳线程重连
            raise
        finally:
            self._io.release()

    # ---------------- 业务封装
    def get_login_info(self, timeout=8):
        return self.call("get_login_info", {}, timeout=timeout) or {}

    def get_group_list(self, timeout=20):
        data = self.call("get_group_list", {}, timeout=timeout) or []
        out = []
        for g in data:
            try:
                out.append({"id": int(g.get("group_id")),
                            "name": str(g.get("group_name") or "").strip(),
                            "count": int(g.get("member_count") or 0),
                            "max": int(g.get("max_member_count") or 0)})
            except Exception:
                continue
        out.sort(key=lambda x: (-x["count"], x["id"]))
        return out

    def get_friend_list(self, timeout=20):
        data = self.call("get_friend_list", {}, timeout=timeout) or []
        out = []
        for f in data:
            try:
                out.append({"id": int(f.get("user_id")),
                            "name": str(f.get("nickname") or f.get("remark")
                                        or "").strip()})
            except Exception:
                continue
        return out

    def send_group_msg(self, group_id, message):
        data = self.call("send_group_msg",
                         {"group_id": int(group_id), "message": str(message)},
                         timeout=15)
        return data or {}

    def send_private_msg(self, user_id, message):
        """私聊某人（红包监测的通知通道）。"""
        data = self.call("send_private_msg",
                         {"user_id": int(user_id), "message": str(message)},
                         timeout=15)
        return data or {}

    def send_like(self, user_id, times=1):
        try:
            times = max(1, min(10, int(times)))    # QQ 同一好友每天上限约 10 次
        except Exception:
            times = 1
        return self.call("send_like", {"user_id": int(user_id), "times": times},
                         timeout=15)

    def get_status(self, timeout=8):
        return self.call("get_status", {}, timeout=timeout) or {}


def parse_qq_list(text):
    """把 "10001, 10002 10003；10004" 解析成去重的 QQ 号列表。"""
    out, seen = [], set()
    for tok in re.split(r"[,，;；\s/|]+", str(text or "")):
        tok = tok.strip()
        if tok.isdigit() and 5 <= len(tok) <= 12 and tok not in seen:
            seen.add(tok)
            out.append(int(tok))
    return out


# ============================================================ 通用小工具
# ★ 2026-09-26 红包监测功能已整体删除（用户要求）。这两个工具函数被
#   「关键字监测」和论坛登录日志用到，所以从原「红包识别」区块里搬出来保留。
def _short(s, n=80):
    """截断 + 去掉换行，日志里一行显示得下。"""
    t = str(s if s is not None else "")
    t = t.replace("\r", " ").replace("\n", " ")
    return t if len(t) <= n else (t[:n] + "…")



def _seg_types(message):
    """把消息段列表压成 "text,at,json" 这样的短串（排障日志用）。"""
    if isinstance(message, list):
        out = []
        for s in message:
            out.append(str(s.get("type")) if isinstance(s, dict)
                       else type(s).__name__)
        return ",".join(out) or "-"
    if isinstance(message, str):
        return "str"
    return "-"



# ============================================================ 关键字监测（v1.1.15）
# 与红包监测并列的第二类通知：只看「被勾选参与关键字的群」里，群消息文本
# 是否命中用户配置的任一关键字（逗号/空格/分号分隔，可配多条）。
def parse_keywords(text):
    """把 "上架, 开服 内测；更新" 解析成去重（按小写去重、保留原样）的关键字表。"""
    out, seen = [], set()
    for tok in re.split(r"[,，;；、\s/|]+", str(text or "")):
        tok = tok.strip()
        if not tok:
            continue
        low = tok.lower()
        if low in seen:
            continue
        seen.add(low)
        out.append(tok)
    return out


def _msg_search_text(ev):
    """关键字匹配用的正文：优先拼所有 text 段；没有 text 段才退回 raw_message。

    不直接用 raw_message —— 它含 [CQ:at,qq=...] 这类 CQ 码，会把「号码里恰好
    含关键字」这种噪声也算命中。
    """
    if not isinstance(ev, dict):
        return ""
    msg = ev.get("message")
    parts = []
    if isinstance(msg, list):
        for seg in msg:
            if not isinstance(seg, dict):
                continue
            if str(seg.get("type")) != "text":
                continue
            d = seg.get("data")
            t = d.get("text") if isinstance(d, dict) else d
            if t:
                parts.append(str(t))
    elif isinstance(msg, str):
        parts.append(msg)
    if not parts:
        raw = ev.get("raw_message")
        if raw:
            parts.append(str(raw))
    txt = "\n".join(parts)
    if "&" in txt:                       # 协议端会把 [ ] , 转义成 HTML 实体
        try:
            txt = html.unescape(txt)
        except Exception:
            pass
    return txt


def _find_keyword(ev, keywords):
    """消息是否命中任一关键字；命中返回该关键字（原样），否则 None。"""
    if not keywords:
        return None
    txt = _msg_search_text(ev)
    if not txt:
        return None
    low = txt.lower()
    for k in keywords:
        if k and k.lower() in low:
            return k
    return None


def kw_notify_text(group_id, group_name="", sender_name="", sender_id="",
                   keyword="", snippet=""):
    """拼关键字通知正文：群号 + 群名 + 命中词 + 发送者 + 内容摘要。"""
    title = (("群「%s」(%s)" % (group_name, group_id)) if group_name
             else ("群 %s" % group_id))
    who = ("%s（%s）" % (sender_name or "未知", sender_id)
           if sender_id else (sender_name or "未知"))
    body = "【关键字监测】%s 命中关键词「%s」\n发送者：%s" % (title, keyword, who)
    if snippet:
        body += "\n内容：%s" % snippet
    return body


def qq_headless_sign(log=None):
    """无头模式下的 QQ 群签到：按保存的配置连 WS → 给启用的群发消息。

    在 QQ 页勾选『每天定时自动签到』后，由 --sign / --daemon 自动执行。
    任何异常都只记日志，不影响论坛签到。
    """
    log = log or (lambda m: None)
    try:
        cfg = {}
        if os.path.exists(QQ_CFG_FILE):
            with open(QQ_CFG_FILE, "r", encoding="utf-8") as f:
                cfg = json.load(f) or {}
    except Exception:
        cfg = {}
    st = cfg.get("_settings", {}) or {}
    groups = cfg.get("groups", {}) or {}
    # ★ 2026-09-26 红包监测已删（此处原为「命令行模式不启动红包监测」的说明）。
    # 命令行（--sign / --daemon）签到完就断开，这里明确提示一下。
    # ★ 红包监测已删：不再有「命令行模式不启动红包监测」的判断。
    if st.get("kw_on"):
        log("QQ关键字通知：需在图形界面常驻连接，命令行模式不启动")
    targets = [(gid, g) for gid, g in groups.items()
               if isinstance(g, dict) and g.get("enabled")]
    if not targets:
        log("QQ群签到：没有启用的群，跳过")
        return 0
    url = str(st.get("url", "") or "").strip()
    if not url:
        log("QQ群签到：未配置 WS 地址，跳过")
        return 0
    default_msg = (str(st.get("default_msg", "") or "").strip()
                   or QQ_DEFAULT_MSG)
    conn = OneBotWS(url, st.get("token", ""), log=log)
    done = 0
    try:
        conn.connect()
        for gid, g in targets:
            msg = str(g.get("msg") or "").strip() or default_msg
            name = g.get("name") or gid
            try:
                conn.send_group_msg(int(gid), msg)
                done += 1
                log("QQ群签到：✅ %s 已发送「%s」" % (name, msg))
            except Exception as ex:
                log("QQ群签到：✗ %s %s" % (name, ex))
            time.sleep(1.0)
    except Exception as ex:
        log("QQ群签到：连接失败 %s" % ex)
    finally:
        conn.close()
    return done


def _is_terminal(msg):
    """判断服务器响应是否为终态业务错误（不值得重试）：
    格式错误 / 验证出错 / 已经领取 / 库存不足 / 不合法 / 不存在 / 抢光 / 次数/上限 等"""
    s = str(msg or "")
    if not s:
        return False
    keys = ("格式错误", "验证出错", "验证码", "已经领取", "已领取",
            "已领过", "领取过", "库存不足", "不合法", "不存在",
            "抢光", "已抢光", "次数", "上限", "未到时间", "账号异常",
            "请登录", "登录失效")
    return any(k in s for k in keys)


def _safe_load_json(path, key=None):
    """★ v4.7.0 配置保护：读 JSON，文件存在但损坏时**自动备份**而不是静默丢弃。

    返回 (dict/list 或空, 错误信息或 None)。之前的行为是 except 后直接返回
    空配置，界面一保存就把用户原配置覆盖成默认值（账号/群列表全没）。
    现在损坏的文件会改名留底成 <原名>.bad-时间戳，且错误会被记进界面日志。
    utf-8-sig 兼容被外部工具加过 BOM 的文件。
    key 显式传入（如卡密配置用 _boot_key）→ 用指定密钥解。
    """
    if not os.path.exists(path):
        return {}, None
    try:
        # ★ v1.1.31 数据文件落地加密：密文自动解密，旧明文文件原样读
        raw = _read_data_bytes(path, key)
        return (json.loads(raw.decode("utf-8-sig")) or {}), None
    except _LockedError:
        # ★ v1.3.0 锁着（未验证 / 租约过期）：本次用空值，但**保留原文件**，
        #   等拿到 K_data 后还能读回来。绝不能走下面的「损坏备份」分支。
        return {}, None
    except Exception as ex:
        bak = "%s.bad-%s" % (path, datetime.now().strftime("%Y%m%d-%H%M%S"))
        try:
            os.replace(path, bak)      # 留底（被锁住时 replace 会失败，原文件还在）
            msg = ("%s 读取失败（%s），原文件已备份为 %s，本次用默认值。"
                   "如反复出现，多半是杀毒/清理软件在锁文件。"
                   % (os.path.basename(path), ex, os.path.basename(bak)))
        except Exception:
            msg = ("%s 读取失败（%s）。本次用默认值；文件被占用暂无法备份，"
                   "内容还在原处。" % (os.path.basename(path), ex))
        return {}, msg


def safe_name(s):
    """账号名转成安全的目录名"""
    s = re.sub(r'[\\/:*?"<>|\s]+', "_", str(s).strip())
    return s or "default"


def free_port(start=9600):
    for _ in range(60):
        p = random.randint(start, start + 900)
        s = socket.socket()
        try:
            s.bind(("127.0.0.1", p))
            return p
        except Exception:
            continue
        finally:
            s.close()
    return random.randint(20000, 40000)


_NO_PROXY = urllib.request.build_opener(urllib.request.ProxyHandler({}))


# ============================================================ 浏览器检测
EMBED_MAGIC = b"ZSFEMB01"          # 8 字节 magic，尾部固定 16 字节
EMBED_DIR = os.path.join(os.environ.get("LOCALAPPDATA", tempfile.gettempdir()),
                         "zsf_gift_embedded_browser")


def _read_embedded_zip(exe_path):
    """读取附加在 EXE 尾部的浏览器压缩包。

    尾部布局: [zip 数据][8字节长度 LE][8字节 magic]，共 16 字节；
    没有附加浏览器的小体积 EXE 会因大小/校验不符直接返回 None。
    """
    try:
        size = os.path.getsize(exe_path)
        if size < 100 * 1024 * 1024:        # <100MB 说明没附加浏览器
            return None
        with open(exe_path, "rb") as f:
            f.seek(-16, 2)                  # io.SEEK_END
            tail = f.read(16)
            if len(tail) != 16 or tail[8:] != EMBED_MAGIC:
                return None
            zlen = struct.unpack("<Q", tail[:8])[0]
            if not (1024 * 1024 < zlen < size - 16):
                return None
            f.seek(-16 - zlen, 2)
            data = f.read(zlen)
            return data if len(data) == zlen else None
    except Exception:
        return None


def _valid_chrome(p):
    """chrome.exe 存在且体积正常（>1MB）。防释放中断/杀软拦截导致的损坏文件。"""
    try:
        return os.path.isfile(p) and os.path.getsize(p) > 1024 * 1024
    except Exception:
        return False


def _kill_embedded_chrome(log=None):
    """★ 结束所有从内置浏览器释放目录启动的 chrome 进程。

    按镜像路径/命令行包含 EMBED_DIR 精确匹配，绝不碰用户自己安装的浏览器。
    释放前必须先杀掉，否则运行中的 chrome.exe 文件被锁，目录删不掉。
    """
    import subprocess
    try:
        sysroot = os.environ.get("SystemRoot", r"C:\Windows")
        ps_exe = os.path.join(sysroot, "System32", "WindowsPowerShell",
                              "v1.0", "powershell.exe")
        # 同时校验 ExecutablePath 和 CommandLine 都含释放目录，双重防误杀
        script = (
            "Get-CimInstance Win32_Process -Filter \"Name='chrome.exe'\""
            " | Where-Object { ($_.ExecutablePath -and "
            "$_.ExecutablePath.Contains('" + EMBED_DIR + "')) -or "
            "($_.CommandLine -and $_.CommandLine.Contains('" + EMBED_DIR + "')) }"
            " | ForEach-Object { Stop-Process -Id $_.ProcessId -Force }"
        )
        subprocess.run(
            [ps_exe, "-NoProfile", "-NonInteractive", "-ExecutionPolicy",
             "Bypass", "-Command", script],
            timeout=30, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
            creationflags=CREATE_NO_WINDOW)   # ★ 后台执行，不弹前台 PowerShell 窗口
    except Exception:
        pass
    import time as _t
    _t.sleep(1.5)  # 等句柄释放


def embedded_browser(root=None, log=None):
    """内置浏览器（Google Chrome 109 便携包，兼容老系统）。

    查找顺序：
      1. EXE 旁的 内置浏览器/ 目录（旧布局，兼容）
      2. 程序内嵌的浏览器压缩包 → ★ 每次启动都删除旧释放目录并重新解压
         （保证文件永远和程序版本一致，不受残留/损坏/杀软篡改影响）
    找到返回 chrome.exe 完整路径；找不到返回 ""（回退系统已装浏览器）。
    """
    root = root or base_dir()
    exe = os.path.join(EMBED_DIR, "chrome-win64", "chrome.exe")
    for top in ("内置浏览器", "embedded_browser"):
        for sub in ("", "chrome-win64", "chrome-win"):
            p = os.path.join(root, top, sub, "chrome.exe")
            if _valid_chrome(p):
                return p
    if getattr(sys, "frozen", False):
        data = None
        # 优先：--add-data 打进 onefile 归档的浏览器包（随程序解压到 _MEI 临时目录）
        try:
            mei_zip = os.path.join(sys._MEIPASS, "chrome-win64.zip")
            if os.path.exists(mei_zip):
                with open(mei_zip, "rb") as f:
                    data = f.read()
        except Exception:
            data = None
        # 兜底：自释放式（EXE 尾部附加，onefile 下不可用，保留给 onedir 布局）
        if data is None:
            data = _read_embedded_zip(sys.executable)
        if data:
            # ★ 每次启动都重新释放：结束占用进程 → 删除旧目录 → 重新解压
            if log:
                log("正在重新释放内置浏览器（每次启动自动刷新，请稍候）…")
            _kill_embedded_chrome(log)
            try:
                import shutil
                shutil.rmtree(EMBED_DIR, ignore_errors=True)
            except Exception:
                pass
            if os.path.exists(exe):
                # 目录没删干净（个别文件被锁）→ 至少把 chrome.exe 清掉强制重建
                try:
                    os.remove(exe)
                except Exception:
                    pass
            try:
                os.makedirs(EMBED_DIR, exist_ok=True)
                with zipfile.ZipFile(io.BytesIO(data)) as zf:
                    zf.extractall(EMBED_DIR)
                if _valid_chrome(exe):
                    if log:
                        log("内置浏览器释放完成: %s" % EMBED_DIR)
                    return exe
                if log:
                    log("内置浏览器释放异常：chrome.exe 无效"
                        "（可能被杀毒软件拦截或磁盘空间不足）")
            except Exception as ex:
                if log:
                    log("内置浏览器释放失败: %s" % ex)
    else:
        # 非打包环境（开发调试）：保留旧的"有效就用，损坏重释"逻辑
        if _valid_chrome(exe):
            return exe
        if os.path.exists(exe):
            if log:
                log("内置浏览器文件损坏(%.0fKB)，正在重新释放…"
                    % (os.path.getsize(exe) / 1024))
            try:
                import shutil
                shutil.rmtree(EMBED_DIR, ignore_errors=True)
            except Exception:
                pass
    return ""


def detect_browsers(log=None):
    """返回 [(显示名, 路径, 内核)]，已去重。内置浏览器永远排第一。"""
    found, seen = [], set()
    emb = embedded_browser(log=log)
    if emb:
        found.append(("内置浏览器(随软件附带)", emb, "chromium"))
        seen.add(emb.lower())
    for name, kernel, paths in BROWSER_CANDIDATES:
        for p in paths:
            full = os.path.expandvars(p)
            if os.path.exists(full):
                if full.lower() not in seen:
                    seen.add(full.lower())
                    found.append((name, full, kernel))
                break
    if winreg:
        for exe in REG_EXES:
            val = _reg_lookup(exe)
            if val and os.path.exists(val) and val.lower() not in seen:
                seen.add(val.lower())
                found.append((os.path.splitext(os.path.basename(val))[0] + "(注册表)",
                              val, "gecko" if "firefox" in val.lower() else "chromium"))
    return found


def _reg_lookup(exe_name):
    for root, flag in ((winreg.HKEY_LOCAL_MACHINE, winreg.KEY_WOW64_64KEY),
                       (winreg.HKEY_LOCAL_MACHINE, winreg.KEY_WOW64_32KEY),
                       (winreg.HKEY_CURRENT_USER, 0)):
        try:
            key = winreg.OpenKey(
                root, r"SOFTWARE\Microsoft\Windows\CurrentVersion\App Paths\%s" % exe_name,
                0, winreg.KEY_READ | flag)
            val, _ = winreg.QueryValueEx(key, None)
            winreg.CloseKey(key)
            if val and os.path.exists(val):
                return val
        except Exception:
            continue
    return None


def get_browser_version(path):
    try:
        out = subprocess.run(
            ["powershell", "-NoProfile", "-Command",
             "(Get-Item '%s').VersionInfo.ProductVersion" % path],
            capture_output=True, text=True, timeout=10,
            creationflags=0x08000000)
        return (out.stdout or "").strip() or "未知"
    except Exception:
        return "未知"


def migrate_old_profile(acc_id, new_profile, log=print):
    """把旧版（EXE 目录 profiles/<账号>）的登录数据迁到新 ASCII 隔离目录。

    只迁登录相关文件（Local State 的解密密钥 + Cookies），Cache 等
    大文件不迁，几秒完成。迁移后无需重新扫码。
    """
    import shutil
    old = os.path.join(OLD_DATA_DIR, safe_name(acc_id))
    if not os.path.isdir(old):
        return
    if os.path.exists(os.path.join(new_profile, "Default", "Network", "Cookies")):
        return          # 新目录已有登录数据，不重复迁
    try:
        os.makedirs(new_profile, exist_ok=True)
        pairs = [("Local State", "Local State"),
                 (os.path.join("Default", "Network", "Cookies"),
                  os.path.join("Default", "Network", "Cookies")),
                 (os.path.join("Default", "Cookies"),
                  os.path.join("Default", "Cookies")),
                 (os.path.join("Default", "Preferences"),
                  os.path.join("Default", "Preferences"))]
        n = 0
        for src_rel, dst_rel in pairs:
            s = os.path.join(old, src_rel)
            d = os.path.join(new_profile, dst_rel)
            if os.path.exists(s):
                os.makedirs(os.path.dirname(d), exist_ok=True)
                shutil.copy2(s, d)
                n += 1
        if n:
            log("[%s] 已迁移旧登录数据(%d 项)到新隔离目录，无需重新扫码" % (acc_id, n))
    except Exception:
        log("[%s] 旧登录数据迁移失败（不影响使用，重新扫码即可）" % acc_id)


# ============================================================ CDP 客户端
class CDP:
    """极简 Chrome DevTools Protocol 客户端（WebSocket）"""

    def __init__(self, ws_url, timeout=30):
        import websocket
        self.ws = websocket.create_connection(ws_url, timeout=timeout)
        self.mid = 0
        self.events = []

    def send(self, method, params=None, wait=True, timeout=None):
        self.mid += 1
        mid = self.mid
        self.ws.send(json.dumps({"id": mid, "method": method, "params": params or {}}))
        if not wait:
            return None
        old = self.ws.gettimeout()
        if timeout:
            self.ws.settimeout(timeout)
        try:
            while True:
                msg = json.loads(self.ws.recv())
                if msg.get("id") == mid:
                    return msg
                self.events.append(msg)
        finally:
            self.ws.settimeout(old)

    def drain(self, seconds=1.0):
        end = time.time() + seconds
        self.ws.settimeout(0.4)
        try:
            while time.time() < end:
                try:
                    self.events.append(json.loads(self.ws.recv()))
                except Exception:
                    break
        finally:
            self.ws.settimeout(30)

    def ev(self, expr, timeout=25):
        """在页面执行 JS 并返回值"""
        try:
            r = self.send("Runtime.evaluate", {
                "expression": expr, "returnByValue": True, "awaitPromise": True,
                "userGesture": True,
            }, timeout=timeout)
        except Exception as e:
            return "__ERR__%s" % e
        res = r.get("result", {})
        if "exceptionDetails" in res:
            return "__ERR__%s" % res["exceptionDetails"].get("text", "JS异常")
        return res.get("result", {}).get("value")

    def close(self):
        try:
            self.ws.close()
        except Exception:
            pass


# ============================================================ 站点操作
JS_LOGIN = r"""
new Promise(function(resolve){
  var done=false;
  function fin(v){ if(!done){done=true; resolve(v);} }
  setTimeout(function(){ fin({login:false, reason:'timeout'}); }, 8000);
  try{
    if (window.getUserInfoAsync) {
      window.getUserInfoAsync(function(isLogin, info){
        fin({login:!!isLogin, phone:(info&&info.phone)||''});
      });
    } else { fin({login:false, reason:'no-api'}); }
  }catch(e){ fin({login:false, reason:String(e)}); }
})
"""

JS_HEADER_LOGIN = r"""
(function(){
  var h=document.querySelector('header .login');
  var t=h? (h.innerText||'').trim() : '';
  return {text:t, logout: t.indexOf('退出')!==-1};
})()
"""

JS_UID = r"""(function(){
  var m=(document.cookie||'').match(/(?:^|;\s*)userId=(\d+)/);
  return m?m[1]:'';
})()"""

# ★ v1.1.11 掉线检测用：页面到底有没有打开。
#   判「掉线」之前必须先排除「页面根本没加载出来」——
#   网络断了 / Chrome 报错页里，getUserInfoAsync 和 header 都不存在，
#   这时候 if(is_logged_in()==False) 就下结论会把用户冤枉成掉线。
JS_PAGE_READY = r"""(function(){
  return {ready: document.readyState,
          api: !!window.getUserInfoAsync,
          header: !!document.querySelector('header'),
          btns: document.querySelectorAll('span.btn.get').length,
          host: location.host};
})()"""

JS_LIST_GIFTS = r"""
(function(){
  var out=[];
  var bs=document.querySelectorAll('span.btn.get');
  for (var i=0;i<bs.length;i++){
    var b=bs[i], id=b.dataset.id;
    var numEl=document.querySelector('#gift-'+id+' .number');
    var amtEl=document.querySelector('#gift-'+id+' .amount');
    var num=numEl?numEl.textContent.trim():'';
    var parts=num.split('/');
    var left=parts.length==2?parseInt(parts[0]):0;
    var tr=(b.closest)?b.closest('tr'):null;
    var nameEl=tr?tr.querySelector('a.name'):null;
    var descEl=tr?tr.querySelector('td.desc'):null;
    var recEl=document.querySelector('#gift-'+id+' a.record');
    out.push({id:id, status:b.dataset.status||'', text:(b.textContent||'').trim(),
              num:num, left:isNaN(left)?0:left, amount:amtEl?amtEl.textContent.trim():'',
              name:nameEl?(nameEl.innerText||'').trim():'',
              desc:descEl?(descEl.innerText||'').trim().slice(0,60):'',
              record:recEl?(recEl.getAttribute('href')||''):''});
  }
  return out;
})()
"""

# ★ v1.4.0 已删除：JS_CLICK / JS_MODAL / JS_HAS_FORM / JS_PARTITION /
#   JS_RECEIVE / JS_CLOSE —— 这 6 段「怎么抢」的配方**不再保存在客户端**，
#   改由卡密端在签发作业票据时用 K_job 加密下发（见 _recipe / Engine.grab_one）。
#   ⇒ 破解版里没有这些字符串，也就不知道点哪个按钮、调哪个接口。
#   ⇒ 注意 JS_LIST_GIFTS 仍留在本地：它只是把页面上的礼包**列出来**给用户看，
#     不具备任何领取能力；真正的「领取」动作已在服务端配方里。


# ============================================================ 引擎
class Engine:
    def __init__(self, log=print, progress=None, ask=None):
        self.log = log
        self.progress = progress or (lambda *a: None)
        self.ask = ask or (lambda msg: True)
        self.stop_flag = False
        self.proc = None
        self.cdp = None

    # ---------------- 进程管理
    def launch(self, browser, profile, port, url, headless=False):
        os.makedirs(profile, exist_ok=True)
        self._port = port
        self._profile = profile
        # ★ 移植 v10 隔离方法 ③：物理清理会话恢复残留（防"停在百度首页/newtab"）
        self._purge_session_restore(profile)
        args = [browser,
                # ↓ CDP 直连所需（v10 走 selenium 不需要这两项，其余全部一致）
                "--remote-debugging-port=%d" % port,
                "--remote-allow-origins=*",
                "--user-data-dir=%s" % profile,
                "--window-size=1280,800",
                "--no-first-run",
                "--no-default-browser-check",
                # ★ v10 原版三项：禁掉"恢复上次会话"功能本身
                "--disable-features=InfiniteSessionRestore,"
                "SessionRestoreOnStartup,InfiniteSessionRestoreEnable",
                "--disable-session-crashed-bubble",
                "--disable-restore-session-state",
                # ★ v10 原版稳定性 flags（Windows 实测最小集合）
                "--disable-dev-shm-usage",
                "--no-sandbox",
                "--disable-gpu",
                "--disable-gpu-sandbox",
                "--disable-extensions",
                "--disable-background-networking",
                "--disable-component-update",
                "--disable-default-apps"]
        # ★ 移植 v10 隔离方法 ④：Chrome 自身日志落盘，出问题能看崩溃原因
        try:
            chrome_log = os.path.join(
                tempfile.gettempdir(), "zsf_chrome_%s.log"
                % os.path.basename(profile.rstrip("\\/")))
            args.append("--enable-logging=file")
            args.append("--log-file=" + chrome_log)
        except Exception:
            pass
        if headless:
            args.append("--headless=new")
        # （v4.8.2 已删除每账号独立代理功能：直连）
        args.append(url)
        self.log("启动浏览器: %s" % os.path.basename(browser))
        # ★ 后台静默启动：stdin 断开 + CREATE_NO_WINDOW，绝不弹控制台窗口
        self.proc = subprocess.Popen(
            args, stdin=subprocess.DEVNULL,
            stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
            creationflags=CREATE_NO_WINDOW)
        return self.proc

    # ---------------- ★ 移植 v10 隔离方法 ----------------
    @staticmethod
    def _purge_session_restore(profile_dir):
        """物理清空 user-data-dir 里会让 Chrome 自动恢复上次会话的目录。

        上次跑完后 Chrome 会在 Default/Sessions 等目录写"上次打开的标签页"
        快照，下次启动可能自动恢复这些标签页，覆盖掉程序要打开的站点。
        注意（v1.1.1）：**只清"会话恢复"相关的目录**。
        Local Storage / IndexedDB 不能清 —— 很多站点（含本站）把登录 token
        存在 localStorage，清了就等于每次启动都掉登录态。
        """
        import shutil
        for sub in ("Default/Sessions",
                    "Default/Session Storage",
                    "Default/Code Cache",
                    "Default/Cache"):
            p = os.path.join(profile_dir, sub)
            if not os.path.exists(p):
                continue
            try:
                shutil.rmtree(p, ignore_errors=True)
            except Exception:
                pass

    def kill_profile_chrome(self, profile):
        """★ v10 隔离方法②（逐字照搬 grab_gift_engine.kill_profile_chrome）：

        启动前清掉残留的、占着本账号 user-data-dir 的 chrome 进程。
        只杀命令行里带本账号专属 user-data-dir 的 chrome，绝不碰用户正常浏览器。
        注意：PowerShell 单引号字符串不处理反斜杠，路径必须原样传入
        （v10 原版即如此；此前的 \\\\ 转义是错的，会导致 Contains 永远不匹配）。
        """
        try:
            ud = profile
            sysroot = os.environ.get("SystemRoot", r"C:\Windows")
            ps_exe = os.path.join(sysroot, "System32", "WindowsPowerShell",
                                  "v1.0", "powershell.exe")
            # Where-Object 同时校验 CommandLine 含我们的专属 user-data-dir，避免误杀
            script = (
                "Get-CimInstance Win32_Process -Filter \"Name='chrome.exe'\""
                " | Where-Object { $_.CommandLine -and "
                "$_.CommandLine.Contains('--user-data-dir=') -and "
                "$_.CommandLine.Contains('" + ud + "') }"
                " | ForEach-Object { Stop-Process -Id $_.ProcessId -Force }"
            )
            subprocess.run([ps_exe, "-NoProfile", "-NonInteractive",
                            "-Command", script],
                           capture_output=True, timeout=20,
                           creationflags=subprocess.CREATE_NO_WINDOW)   # ★ 后台执行，不弹前台 PowerShell 窗口
            # 等残留进程真的退出、把 user-data-dir 锁释放掉，再拉新会话
            time.sleep(1.5)
        except Exception:
            pass

    def wait_cdp(self, port, timeout=45):
        end = time.time() + timeout
        while time.time() < end:
            if self.stop_flag:
                return False
            try:
                with _NO_PROXY.open("http://127.0.0.1:%d/json/version" % port, timeout=3) as r:
                    json.loads(r.read().decode())
                    return True
            except Exception:
                time.sleep(0.6)
        return False

    def attach(self, port, timeout=30):
        """连接第一个 page 标签页"""
        end = time.time() + timeout
        while time.time() < end:
            if self.stop_flag:
                return None
            try:
                with _NO_PROXY.open("http://127.0.0.1:%d/json/list" % port, timeout=3) as r:
                    tabs = json.loads(r.read().decode())
                pages = [t for t in tabs if t.get("type") == "page" and t.get("webSocketDebuggerUrl")]
                if pages:
                    self.cdp = CDP(pages[0]["webSocketDebuggerUrl"])
                    self.cdp.send("Page.enable")
                    self.cdp.send("Runtime.enable")
                    return self.cdp
            except Exception:
                pass
            time.sleep(0.8)
        return None

    def close(self):
        """优雅关闭浏览器（关键：让 Chrome 正常退出、把 cookie 落盘。
        之前用 terminate 强杀会导致刚登录的 cookie 还在内存里就丢了，
        下次打开就要求重新扫码。）"""
        try:
            if self.cdp:
                self.cdp.close()
        except Exception:
            pass
        self.cdp = None
        if self.proc:
            # 1) 优雅关闭：连浏览器级 websocket 发 Browser.close
            graceful = False
            try:
                port = getattr(self, "_port", None)
                if port:
                    with _NO_PROXY.open("http://127.0.0.1:%d/json/version" % port,
                                        timeout=3) as r:
                        ver = json.loads(r.read().decode())
                    ws_url = ver.get("webSocketDebuggerUrl")
                    if ws_url:
                        import websocket as _ws
                        c = _ws.create_connection(ws_url, timeout=5)
                        c.send(json.dumps({"id": 1, "method": "Browser.close"}))
                        try:
                            c.settimeout(3)
                            c.recv()
                        except Exception:
                            pass
                        c.close()
                        graceful = True
            except Exception:
                graceful = False
            # 2) 等待自然退出
            try:
                self.proc.wait(timeout=10 if graceful else 3)
            except Exception:
                # 3) 兜底强杀
                try:
                    self.proc.terminate()
                    self.proc.wait(timeout=6)
                except Exception:
                    try:
                        self.proc.kill()
                    except Exception:
                        pass
            self.proc = None
        time.sleep(0.8)

    # ---------------- 登录态备份（防浏览器被强杀 / profile 被清 丢 cookie）
    def _cookie_backup_paths(self):
        """备份文件候选路径（口径见模块级 cookie_backup_paths，
        ★ v1.1.11 起与掉线检测共用同一份实现，避免两套规则漂移）。"""
        return cookie_backup_paths(getattr(self, "_profile", "") or "")

    def backup_cookies(self):
        """把当前全部 cookie 备份到 profile **外面**（同时留一份在 profile 内兼容旧版）。

        写多处的原因：profile 被清理软件清空 / Chrome 重置后，外部备份还在，
        下次启动仍能免扫码恢复。
        """
        try:
            if not self.cdp:
                return False
            self.cdp.send("Network.enable")
            r = self.cdp.send("Storage.getCookies", timeout=10) or {}
            cookies = (r.get("result") or {}).get("cookies") or []
            if not cookies:
                return False
            clean = []
            for c in cookies:
                d = {"name": c.get("name"), "value": c.get("value"),
                     "domain": c.get("domain"), "path": c.get("path", "/"),
                     "secure": bool(c.get("secure")),
                     "httpOnly": bool(c.get("httpOnly"))}
                if c.get("sameSite") in ("Strict", "Lax", "None"):
                    d["sameSite"] = c["sameSite"]
                if not c.get("session") and c.get("expires", -1) not in (-1, 0):
                    d["expires"] = float(c["expires"])
                clean.append(d)
            payload = {"saved_at": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                       "profile": os.path.basename(
                           (getattr(self, "_profile", "") or "").rstrip("\\/")),
                       "cookies": clean}
            written = 0
            for f in self._cookie_backup_paths():
                try:
                    # ★ v1.1.31 cookie 备份也加密落盘（内含登录凭证）
                    if _safe_save_json(f, payload, indent=None):
                        written += 1
                except Exception:
                    continue
            if written:
                self.log("已备份 %d 条登录 cookie（写入 %d 个位置）"
                         % (len(clean), written))
                return True
            return False
        except Exception:
            return False

    def restore_cookies(self):
        """未登录时从最新的可用备份恢复 cookie。

        返回 bool（保持旧调用方式不变）；来源文件与时间放在
        self.last_restore_info 里，方便日志里告诉用户"用的哪份备份"。
        """
        self.last_restore_info = ""
        try:
            if not self.cdp:
                return False
            best, best_mt, best_path = None, -1.0, ""
            for f in self._cookie_backup_paths():
                if not os.path.exists(f):
                    continue
                try:
                    mt = os.path.getmtime(f)
                    data = json.loads(_read_data_bytes(f).decode("utf-8-sig"))
                except Exception:
                    continue
                # 兼容旧版：旧文件是裸 list，新版是 {"saved_at":..,"cookies":[..]}
                cookies = data.get("cookies") if isinstance(data, dict) else data
                if not cookies:
                    continue
                if mt > best_mt:
                    best, best_mt, best_path = cookies, mt, f
            if not best:
                return False
            self.cdp.send("Network.enable")
            self.cdp.send("Storage.setCookies", {"cookies": best}, timeout=10)
            self.last_restore_info = "%s（备份时间 %s）" % (
                best_path, datetime.fromtimestamp(best_mt).strftime("%m-%d %H:%M"))
            return True
        except Exception:
            return False

    def diagnose_login_loss(self):
        """未登录时给一句人话原因，方便判断是"被清了"还是"真过期了"。"""
        prof = getattr(self, "_profile", "") or ""
        try:
            if not prof or not os.path.isdir(prof) or not os.listdir(prof):
                return "profile 目录是空的，疑似被清理软件清空或 Chrome 重置"
            if not (os.path.exists(os.path.join(prof, "Default", "Network", "Cookies"))
                    or os.path.exists(os.path.join(prof, "Default", "Cookies"))):
                return "profile 里没有 cookie 数据库（Cookies 文件丢失）"
            if not any(os.path.exists(f) for f in self._cookie_backup_paths()):
                return "cookie 文件在，但没找到任何 cookie 备份"
            return "cookie 文件和备份都在，站点登录凭证多半是过期了" \
                   "（这种只能重新扫码）"
        except Exception:
            return "原因未知"

    # ---------------- 页面操作
    def open_site(self, url):
        self.cdp.send("Page.navigate", {"url": url})
        return True

    def wait_ready(self, timeout=75):
        """等待礼包列表渲染完成（连续多次数量不变视为加载完毕）"""
        end = time.time() + timeout
        last, stable = -1, 0
        while time.time() < end:
            if self.stop_flag:
                return 0
            n = self.cdp.ev("document.querySelectorAll('span.btn.get').length", timeout=15)
            if isinstance(n, int) and n > 0:
                if n == last:
                    stable += 1
                    if stable >= 2:
                        return n
                else:
                    stable = 0
                last = n
            time.sleep(1.5)
        return last if last > 0 else 0

    def is_logged_in(self):
        r = self.cdp.ev(JS_LOGIN, timeout=15)
        if isinstance(r, dict) and r.get("login"):
            return True, r.get("phone", "")
        h = self.cdp.ev(JS_HEADER_LOGIN, timeout=15)
        if isinstance(h, dict) and h.get("logout"):
            return True, h.get("text", "").replace("退出", "").strip()
        return False, ""

    def site_uid(self):
        """站内身份：cookie 里的 userId（每个 profile 独立，可用来判断是否同一身份）"""
        try:
            return str(self.cdp.ev(JS_UID, timeout=10) or "").strip()
        except Exception:
            return ""

    def wait_login(self, timeout=240):
        """等待用户扫码登录（浏览器窗口被关闭时立即中断）"""
        end = time.time() + timeout
        self.log("等待扫码登录（请在浏览器窗口内用微信扫码）…")
        while time.time() < end:
            if self.stop_flag:
                return False
            if self.proc is not None and self.proc.poll() is not None:
                self.log("浏览器窗口已关闭，登录中断。请重新点『扫码登录』")
                return False
            ok, phone = self.is_logged_in()
            if ok:
                self.log("登录成功：%s" % (phone or "已登录"))
                return True
            time.sleep(2.5)
        return False

    def list_gifts(self, only_available=True):
        data = self.cdp.ev(JS_LIST_GIFTS, timeout=25)
        if not isinstance(data, list):
            return []
        if only_available:
            data = [g for g in data if g.get("left", 0) > 0 and g.get("status") == "active"]
        return data

    def grab_one(self, gift, account="", wait=2.2):
        """领取单个礼包：点击 → 弹表单 → 调领取接口 → 读 code/msg

        ★ v1.4.0：所有 JS 选择器 / 接口路径 / 表单模板都从**服务端下发的
          作业配方**读取（见 _recipe）。没有有效作业许可 → _JobError，
          本地**没有任何回落常量**可用 —— 破解版拿不到配方就点不了、发不出。
        """
        R = _recipe("gift")
        js_click = R["js_click"]
        js_has_form = R["js_has_form"]
        js_modal = R["js_modal"]
        js_partition = R["js_partition"]
        js_receive = R["js_receive"]
        js_close = R["js_close"]
        gid = gift["id"]
        # 表单要求 6 位以上游戏账号；未指定则本次随机生成 6 位数字
        if not account or not str(account).strip():
            account = "%06d" % random.randint(0, 999999)
        acc = str(account).strip()
        # 1) 点击『领礼包』，页面弹出填写游戏账号的表单
        r = self.cdp.ev(js_click % gid, timeout=15)
        if r != "ok":
            return {"ok": False, "msg": "按钮不存在或不可点击",
                    "game_account": acc}

        # 2) 等表单出现；若弹的是扫码登录框则说明未登录
        has_form = False
        for _ in range(6):
            time.sleep(0.8)
            if self.cdp.ev(js_has_form, timeout=10) is True:
                has_form = True
                break
            if self.cdp.ev(js_modal, timeout=10) is True:
                self.cdp.ev(js_close, timeout=8)
                return {"ok": False, "msg": "未登录，已弹出扫码登录框",
                        "need_login": True, "game_account": acc}
        if not has_form:
            h = self.cdp.ev(JS_HEADER_LOGIN, timeout=10)
            self.cdp.ev(js_close, timeout=8)
            if isinstance(h, dict) and not h.get("logout"):
                return {"ok": False, "msg": "未出现领取表单，可能未登录",
                        "need_login": True, "game_account": acc}
            return {"ok": False, "msg": "未出现领取表单", "game_account": acc}

        # 3) 读取充值分区（select 可能比表单晚渲染几帧，重试读取几次更稳）
        partition = ""
        for _ in range(6):
            partition = self.cdp.ev(js_partition, timeout=10) or ""
            if partition:
                break
            time.sleep(0.5)
        if not partition:
            self.cdp.ev(js_close, timeout=8)
            return {"ok": False, "msg": "未读取到充值分区",
                    "need_login": False, "game_account": acc}

        # 4) 调接口领取，拿到明确的 code / msg
        self.log("提交领取: gift=%s 游戏账号=%s 分区=%s" % (gid, acc, partition))
        acc_q = urllib.parse.quote(acc, safe="")
        res = self.cdp.ev(js_receive % (gid, acc_q, acc_q, partition), timeout=25)
        if not isinstance(res, dict):
            res = {"code": -1, "msg": "接口无响应"}

        # 5) 关闭弹窗，避免叠加影响下一个礼包
        self.cdp.ev(js_close, timeout=8)

        code, msg = res.get("code"), (res.get("msg") or "")
        ok = (code == 1)

        if ok:
            return {"ok": True, "code": code, "msg": msg or "领取成功",
                    "game_account": acc}
        if code in (-1, None):
            return {"ok": False, "code": code, "msg": msg or "接口调用失败",
                    "game_account": acc}
        return {"ok": False, "code": code, "msg": msg or "领取失败",
                "game_account": acc}


# ============================================================ 日志缓冲
class LogBuffer(object):
    """内存日志缓冲，代替原来内嵌在界面里的 Text 日志框。

    接口刻意兼容 Tk Text 的 get / delete / insert 子集（含 "1.0" / "end" 这类
    索引参数虽然被忽略），这样已有读日志的代码与测试都不用改。

    日志窗口打开时，新行会实时追加进去（set_view / clear_view）。
    """

    def __init__(self, maxlines=3000):
        self._lines = collections.deque(maxlen=int(maxlines))
        self._view = None          # 已打开的日志窗口里的 Text 控件
        self.autoscroll = True     # 日志窗口里的「自动滚动」开关

    # ---- Tk Text 兼容子集
    def insert(self, index, text):
        t = "" if text is None else str(text)
        parts = t.split("\n")
        if parts and parts[-1] == "":
            parts.pop()            # 末尾换行不算一行
        for ln in parts:
            self._lines.append(ln)
        self._flush(parts)

    def get(self, index1=None, index2=None):
        return "".join(l + "\n" for l in self._lines)

    def delete(self, index1=None, index2=None):
        self._lines.clear()
        self._render(view_reset=True)

    def see(self, index=None):
        pass

    def __len__(self):
        return len(self._lines)

    # ---- 日志窗口挂载
    def set_view(self, widget):
        self._view = widget
        self._render(view_reset=True)

    def clear_view(self):
        self._view = None

    def _current(self):
        """最新一行（给界面上的『最近：…』预览用）。"""
        try:
            return self._lines[-1] if self._lines else ""
        except Exception:
            return ""

    def _flush(self, new_lines):
        w = self._view
        if w is None or not new_lines:
            return
        try:
            w.insert("end", "".join(l + "\n" for l in new_lines))
            if len(self._lines) >= self._lines.maxlen:
                self._render(view_reset=True)       # 超上限才整体重画
            elif self.autoscroll:
                w.see("end")
        except Exception:
            self._view = None

    def _render(self, view_reset=False):
        w = self._view
        if w is None:
            return
        try:
            w.delete("1.0", "end")
            if self._lines:
                w.insert("1.0", "".join(l + "\n" for l in self._lines))
                if self.autoscroll:
                    w.see("end")
        except Exception:
            self._view = None


# ============================================================ GUI
class App:
    # ---- ★ v1.1.7 布局定稿：面板画布严格 600×480，坐标单位 px
    #      来源：布局编辑器「复制布局」的最终文本（用户确认稿）。
    #      每个面板一个容器，place 到下面的坐标；容器内部沿用原有 pack/grid。
    LAYOUT_W = 600
    # ★ v1.1.15 480→500：QQ 页「监测」面板要再放「关键字通知」两行，
    #   把底部一排（群签到/点赞/日志）整体下移 20px，画布同步加高。
    #   其它页签的面板是绝对坐标，只是在底部多留 20px 空白，不受影响。
    LAYOUT_H = 500
    LAYOUT = {
        # ★ v1.1.26 全页重排：四周留白 8 / 面板间距 8 统一，
        #   右缘统一到 592、底缘统一到 492（画布 600×500 不变，
        #   窗口总尺寸 600×(500+54)=554 与旧版完全一致）。
        "claim": {
            # 左列 x=8 宽 386（右缘 394），右列 x=402 宽 190（右缘 592），
            # 两列间隙 8；账号面板加高 365→405、领取记录加高 268→293 补齐底部。
            "acc":    (402,   8, 190, 405),
            # ★ v1.1.28 运行设置加一行「定时检测在线」开关：112→138，
            #   领取按钮/记录随之下移，记录 293→267，底缘仍对齐 492。
            "runset": (  8,   8, 386, 138),
            "act":    (  8, 154, 386,  63),
            "result": (  8, 225, 386, 267),
            "status": (402, 421, 190,  30),
            "log":    (402, 459, 190,  33),
        },
        "forum": {
            # 通栏四块：x=8 宽 584，纵向 8px 等距，签到记录加高 155→169。
            "fstate": (  8,   8, 584, 163),
            "fset":   (  8, 179, 584,  92),
            "frec":   (  8, 279, 584, 169),
            "flog":   (  8, 456, 584,  36),
        },
        "qq": {
            # ★ v1.1.13 群列表 392 宽是群行 grid 列宽的调基准，重排保持不动；
            #   监测面板 194→184（右缘 592 对齐），内部状态文字 wraplength
            #   同步 172→160（见 _build_qq 的 rpf 段）。
            "ws":     (  8,   8, 584,  32),
            "qstate": (  8,  48, 584,  30),
            "glist":  (  8,  86, 392, 250),
            "qrpk":   (408,  86, 184, 250),
            "qsign":  (  8, 344, 266, 106),
            "qlike":  (282, 344, 310, 106),
            "qlog":   (  8, 458, 584,  34),
        },
    }
    # 自绘标题栏(26) + 1px 分隔线 + Notebook 页签条 —— 外框 = 面板区 + 这些
    CHROME_H = 54

    def _place(self, parent, tab, key, widget):
        """把面板容器按定稿坐标放进画布。"""
        x, y, w, h = self.LAYOUT[tab][key]
        widget.place(x=x, y=y, width=w, height=h)
        return widget

    def _panel(self, parent, title=None, bg="#ffffff"):
        """面板容器：放得下标题就用 LabelFrame，放不下就用带 1px 边框的 Frame。"""
        if title:
            return self._lf(parent, title)
        return tk.Frame(parent, bg=bg, highlightbackground="#d5d5d5",
                        highlightthickness=1)

    def _lf(self, parent, title):
        """紧凑 LabelFrame：定稿空间很紧，标签行压到最小（padding=0 + 8pt）。"""
        return ttk.LabelFrame(parent, text="  %s  " % title,
                              style="Tight.TLabelframe")

    def __init__(self, root):
        self.root = root
        self.accounts = []       # [{"id","name","logined","time"}]
        self.records = []
        self.engine = None
        self.running = False
        self._checking = False   # ★ v1.1.11 登录态核对线程是否在跑
        self._last_run = {}      # 定时去重：{"__all__" 或 账号id: 日期}
        self._cfg_warns = []     # 配置读取失败提示（UI 建好后统一写进日志）
        self.cfg = self._load_cfg()

        root.title(APP_NAME)
        # ★ v1.1.7 面板区 600×480；外框在此基础上加自绘标题栏 + 页签条，
        #   建完 UI 后会由 _fit_canvas() 自校正到「页面区正好 600×480」
        self._win_w = self.LAYOUT_W
        self._win_h = self.LAYOUT_H + self.CHROME_H
        root.geometry("%dx%d" % (self._win_w, self._win_h))
        root.minsize(self.LAYOUT_W, self.LAYOUT_H + self.CHROME_H)

        self._load_accounts()
        self._load_records()
        self._build_ui()
        self._apply_borderless()
        self._detect_async()
        self._start_timer()
        # ★ 配置保护提示：哪个配置文件坏了/被锁了，一启动就告诉用户
        for w in getattr(self, "_cfg_warns", []):
            self.log("⚠ " + w)

    # ---------------- 无系统标题栏 + 自绘顶栏
    def _apply_borderless(self):
        """隐藏 Windows 系统标题栏，但保留任务栏条目 / 最小化 / 拖边缩放。

        做法：只摘掉 WS_CAPTION（不用 overrideredirect —— 那个会连任务栏条目
        一起丢掉，窗口一旦被挡住就找不回来了）。摘掉后客户区会临时变大，
        所以再设一次 geometry 归一尺寸。
        """
        try:
            if os.name != "nt" or ctypes is None:
                return
            u32 = ctypes.windll.user32
            hwnd = u32.GetParent(self.root.winfo_id()) or self.root.winfo_id()
            self._hwnd = hwnd
            style = u32.GetWindowLongW(hwnd, -16)          # GWL_STYLE
            if style & 0x00C00000:                          # WS_CAPTION
                u32.SetWindowLongW(hwnd, -16, style & ~0x00C00000)
                u32.SetWindowPos(hwnd, 0, 0, 0, 0, 0,
                                 0x0002 | 0x0001 | 0x0004 | 0x0020)  # NOMOVE|NOSIZE|NOZORDER|FRAMECHANGED
            self.root.geometry("%dx%d" % (self._win_w, self._win_h))
            self.root.update_idletasks()
            self.root.after(120, self._fit_canvas)
        except Exception:
            pass

    def _fit_canvas(self):
        """自校正外框：让 Notebook 页面区正好等于定稿的画布 600×480。

        摘掉系统标题栏后客户区尺寸会飘，先量再补，免得 place 的坐标被裁。
        注意：窗口没映射时 winfo_* 返回的是假尺寸，必须等映射后再量。
        """
        try:
            pg = getattr(self, "_canvas_probe", None)
            if pg is None:
                return
            self._fit_tries = getattr(self, "_fit_tries", 0) + 1
            if self._fit_tries > 20:
                return
            if not (pg.winfo_ismapped() and pg.winfo_width() > 50):
                self.root.after(120, self._fit_canvas)
                return
            dw = self.LAYOUT_W - pg.winfo_width()
            dh = self.LAYOUT_H - pg.winfo_height()
            dw = max(-160, min(160, dw))        # 限幅，防一次量错就把窗口放飞
            dh = max(-160, min(160, dh))
            if abs(dw) <= 1 and abs(dh) <= 1:
                self.root.minsize(self.LAYOUT_W, self.LAYOUT_H + 20)
                return
            self._win_w = max(self.LAYOUT_W, self._win_w + dw)
            self._win_h = max(self.LAYOUT_H, self._win_h + dh)
            self.root.geometry("%dx%d" % (self._win_w, self._win_h))
            self.root.after(80, self._fit_canvas)
        except Exception:
            pass

    def _minimize(self):
        try:
            self.root.iconify()
        except Exception:
            pass

    def _close_win(self):
        """自绘的关闭按钮：走和 WM_CLOSE 一样的收尾路径。"""
        try:
            self.root.destroy()          # main() 的 finally 会释放单实例锁
        except Exception:
            pass

    def _drag_start(self, e):
        self._drag_off = (e.x_root - self.root.winfo_x(),
                          e.y_root - self.root.winfo_y())

    def _drag_move(self, e):
        try:
            dx, dy = self._drag_off
            self.root.geometry("+%d+%d" % (e.x_root - dx, e.y_root - dy))
        except Exception:
            pass

    # ---------------- 日志：一行『查看日志』按钮 + 独立窗口
    def _build_log_bar(self, parent, which, label="查看日志", pady=(3, 0),
                       place=None):
        """代替原来的内嵌日志框：一个按钮 + 「最近：…」一行预览。

        面板里看不到历史日志了，但至少还能看到最新一条在动，不会觉得程序死了。
        place=(x,y,w,h) 时按定稿坐标摆放（v1.1.7），否则按老的 pack 布局。
        """
        bar = tk.Frame(parent, bg="#efefef",
                       highlightbackground="#d5d5d5", highlightthickness=1
                       if place else 0)
        if place:
            bar.place(x=place[0], y=place[1], width=place[2], height=place[3])
        else:
            bar.pack(fill="x", padx=4, pady=pady)
        tk.Button(bar, text="📋 %s" % label, font=("Microsoft YaHei", 8),
                  bg="#e8f1ff", fg="#1e6fd9", relief="flat", cursor="hand2",
                  padx=8, command=lambda w=which: self._open_log_window(w)
                  ).pack(side="left")
        var = tk.StringVar(value="（暂无日志）")
        self._log_prev[which] = var
        tk.Label(bar, textvariable=var, font=("Microsoft YaHei", 8), fg="#888",
                 anchor="w").pack(side="left", padx=(8, 6), fill="x", expand=True)
        return bar

    def _push_log(self, which, text):
        """把一行日志写进对应缓冲 + 更新面板上一行预览。"""
        buf = {"main": "logbox", "forum": "forum_logbox",
               "qq": "qq_logbox"}.get(which)
        if not buf:
            return
        try:
            getattr(self, buf).insert("end", text)
        except Exception:
            return
        try:
            var = self._log_prev.get(which)
            if var is not None:
                last = getattr(self, buf)._current()
                var.set("最近：" + (last[:60] + "…" if len(last) > 60 else last))
        except Exception:
            pass

    def _open_log_window(self, which):
        """把日志放到独立窗口里看（可滚动 / 复制 / 清空 / 自动滚动）。"""
        buf = {"main": self.logbox, "forum": self.forum_logbox,
               "qq": self.qq_logbox}.get(which)
        if buf is None:
            return
        titles = {"main": "运行日志", "forum": "论坛签到日志",
                  "qq": "QQ 群签到日志"}
        name = titles.get(which, "日志")
        win = self._logwins.get(which)
        if win is not None:
            try:
                if win.winfo_exists():
                    win.deiconify()
                    win.lift()
                    win.focus_force()
                    return
            except Exception:
                pass
        win = tk.Toplevel(self.root)
        win.title("%s - %s" % (name, APP_NAME))
        # 别再盖在主窗口上（默认位置就是左上角对齐，会正好挡住页签）
        try:
            sw = win.winfo_screenwidth()
            sh = win.winfo_screenheight()
            px = min(self.root.winfo_rootx() + 90, max(0, sw - 800))
            py = min(self.root.winfo_rooty() + 80, max(0, sh - 470))
            win.geometry("780x430+%d+%d" % (px, py))
        except Exception:
            win.geometry("780x430")
        win.minsize(520, 280)

        foot = tk.Frame(win)
        foot.pack(side="bottom", fill="x", padx=6, pady=(2, 6))
        wrap = tk.Frame(win)
        wrap.pack(side="top", fill="both", expand=True, padx=6, pady=(6, 2))
        txt = tk.Text(wrap, font=("Microsoft YaHei", 9), bg="#fbfbfb",
                      relief="flat", wrap="none")
        sb = ttk.Scrollbar(wrap, command=txt.yview)
        txt.configure(yscrollcommand=sb.set)
        sb.pack(side="right", fill="y")
        txt.pack(side="left", fill="both", expand=True)

        auto = tk.BooleanVar(value=True)
        auto.trace_add("write", lambda *a: setattr(buf, "autoscroll", auto.get()))

        def do_copy():
            try:
                self.root.clipboard_clear()
                self.root.clipboard_append(buf.get("1.0", "end"))
            except Exception:
                pass

        def do_clear():
            try:
                buf.delete("1.0", "end")
                txt.delete("1.0", "end")
            except Exception:
                pass

        tk.Button(foot, text="复制全部", font=("Microsoft YaHei", 8), relief="flat",
                  bg="#f2f2f2", cursor="hand2", padx=10, pady=2,
                  command=do_copy).pack(side="left")
        tk.Button(foot, text="清空", font=("Microsoft YaHei", 8), relief="flat",
                  bg="#f2f2f2", cursor="hand2", padx=10, pady=2,
                  command=do_clear).pack(side="left", padx=4)
        tk.Checkbutton(foot, text="自动滚动", variable=auto,
                       font=("Microsoft YaHei", 8)).pack(side="left", padx=6)
        tk.Button(foot, text="关闭", font=("Microsoft YaHei", 8), relief="flat",
                  bg="#f2f2f2", cursor="hand2", padx=12, pady=2,
                  command=lambda: self._close_log_window(which)).pack(side="right")

        self._logwins[which] = win
        buf.set_view(txt)
        if not auto.get():
            txt.see("1.0")
        win.protocol("WM_DELETE_WINDOW",
                     lambda: self._close_log_window(which))

    def _close_log_window(self, which):
        buf = {"main": self.logbox, "forum": self.forum_logbox,
               "qq": self.qq_logbox}.get(which)
        try:
            if buf is not None:
                buf.clear_view()
        except Exception:
            pass
        try:
            w = self._logwins.pop(which, None)
            if w is not None:
                w.destroy()
        except Exception:
            pass

    # ---------------- 数据
    def _load_cfg(self):
        d = {"browser": "", "headless": False, "interval": 2.0,
             "limit": 20, "wait_login": 240, "auto_wait_login": True,
             "timer_enabled": False, "timer_time": "10:00",
             "retry": 3, "claim_one": True}
        data, err = _safe_load_json(CONFIG_FILE)
        if err:
            self._cfg_warns.append(err)
        if data:
            d.update(data)
        return d

    def _save_cfg(self):
        # ★ v1.1.31 加密落盘（原子写）
        _safe_save_json(CONFIG_FILE, self.cfg)

    def _load_accounts(self):
        data, err = _safe_load_json(ACCOUNTS_FILE)
        if err:
            self._cfg_warns.append(err)
        if data:
            try:
                raw = data.get("accounts", [])
                for a in raw:
                    if isinstance(a, dict):
                        st = _status_from_record(a)
                        self.accounts.append({
                            "id": str(a.get("id", "")).strip(),
                            "name": str(a.get("name", "")).strip(),
                            "logined": (st == "ok"),
                            "status": st,
                            "game": str(a.get("game", "") or "").strip(),
                            "uid": str(a.get("uid", "") or "").strip(),
                        })
                    else:
                        self.accounts.append({"id": str(a).strip(), "name": "",
                                              "logined": False, "status": "no",
                                              "game": "", "uid": ""})
            except Exception:
                pass
        self.accounts = [a for a in self.accounts if a["id"]]

    def _save_accounts(self):
        """保存账号：保留原文件其他字段（daily_time / time 等），兼容旧版工具格式"""
        d = {}
        if os.path.exists(ACCOUNTS_FILE):
            try:
                with open(ACCOUNTS_FILE, "r", encoding="utf-8") as f:
                    d = json.load(f)
                if not isinstance(d, dict):
                    d = {}
            except Exception:
                d = {}
        old = {}
        for a in d.get("accounts", []):
            if isinstance(a, dict) and a.get("id") is not None:
                old[str(a["id"])] = a
        newlist = []
        for a in self.accounts:
            base = dict(old.get(a["id"], {}))          # 继承该账号原有字段
            st = acc_status(a)
            base.update({"id": a["id"],
                         "name": a.get("name") or base.get("name", ""),
                         "first_login": bool(st == "ok"),
                         # ★ v1.1.11 掉线状态要落盘，否则重启一次又显示成「已登录」
                         "login_status": st})
            base["game"] = a.get("game", "")        # 真实游戏账号；空=回退随机
            base.pop("proxy", None)                 # v4.8.2 代理功能已删除
            if a.get("uid"):
                base["uid"] = a["uid"]              # 站内身份 userId（防同微信重复登录）
            newlist.append(base)
        d["accounts"] = newlist                         # 顶层其他键（daily_time 等）原样保留
        try:
            with open(ACCOUNTS_FILE, "w", encoding="utf-8") as f:
                json.dump(d, f, ensure_ascii=False, indent=2)
        except Exception:
            pass

    def _load_records(self):
        data, err = _safe_load_json(RECORDS_FILE)
        if err:
            self._cfg_warns.append(err)
        self.records = data if isinstance(data, list) else []
        # ★ v1.1.29 启动即清理超过 5 天的旧领取记录
        self.records = _prune_records_by_time(self.records)
        if len(self.records) != len(data if isinstance(data, list) else []):
            self._save_records()

    def _save_records(self):
        try:
            # ★ v1.1.29 每次落盘前先清 5 天前的旧记录（挂机多天也不涨）
            self.records = _prune_records_by_time(self.records)
            # ★ v1.1.31 加密落盘
            _safe_save_json(RECORDS_FILE, self.records[-5000:])
        except Exception:
            pass

    # ---------------- 界面
    def _build_ui(self):
        try:
            ttk.Style().theme_use("clam")
        except Exception:
            pass
        try:                        # 细进度条：给 189×30 的「进度与状态」腾高度
            ttk.Style().configure("Thin.Horizontal.TProgressbar", thickness=8)
        except Exception:
            pass
        try:                        # 紧凑面板：标签行 padding=0 + 8pt，定稿空间紧
            _st = ttk.Style()
            _st.configure("Tight.TLabelframe", padding=(2, 0, 2, 2))
            _st.configure("Tight.TLabelframe.Label",
                          font=("Microsoft YaHei", 8))
        except Exception:
            pass

        F = ("Microsoft YaHei", 9)
        F8 = ("Microsoft YaHei", 8)
        FB = ("Microsoft YaHei", 9, "bold")

        # ★ v1.1.9 账号面板换成 Treeview —— 注册表头 / 行 / 细滚动条样式
        #   注意：行**不能**用 tag 设背景色 —— tag 优先级高于 style.map，
        #   会把选中高亮吃掉（选中态对本工具很关键）。状态只用 tag 改前景色。
        try:
            _st = ttk.Style()
            _st.configure("Acc.Treeview", font=F, rowheight=21,
                          background="#ffffff", fieldbackground="#ffffff",
                          foreground="#2b3440", borderwidth=0, relief="flat")
            _st.map("Acc.Treeview",
                    background=[("selected", "#cfe3ff")],
                    foreground=[("selected", "#123a63")])
            _st.configure("Acc.Treeview.Heading", font=F8, background="#eef3f9",
                          foreground="#5b6b7c", relief="flat", padding=(4, 3))
            _st.map("Acc.Treeview.Heading", background=[("active", "#e2ebf5")])
            _st.configure("Thin.Vertical.TScrollbar", width=9, arrowsize=9,
                          background="#dfe4ea", troughcolor="#f7f9fc",
                          bordercolor="#f7f9fc", arrowcolor="#8a94a3",
                          relief="flat")
            _st.map("Thin.Vertical.TScrollbar",
                    background=[("active", "#c8d0da")])
        except Exception:
            pass

        self._logwins = {}       # which -> 独立日志窗口 Toplevel
        self._log_prev = {}      # which -> 面板上「最近：…」的 StringVar

        # ---- 顶栏：系统标题栏已隐藏，这里自绘一条 26px 细条
        #      （左边小字只显示名称，版本号放到 EXE 文件名里，右边最小化/关闭）
        top = tk.Frame(self.root, bg="#f3f3f3", height=26)
        top.pack(fill="x")
        top.pack_propagate(False)
        ver_lb = tk.Label(top, text=APP_NAME, bg="#f3f3f3",
                          fg="#8c8c8c", font=("Microsoft YaHei", 8))
        ver_lb.pack(side="left", padx=(8, 0))
        for txt, cmd, hover, hovfg in (("✕", self._close_win, "#e81123", "#ffffff"),
                                       ("—", self._minimize, "#dcdcdc", "#000000")):
            b = tk.Label(top, text=txt, bg="#f3f3f3", fg="#555555",
                         font=("Microsoft YaHei", 9), width=3, cursor="hand2")
            b.pack(side="right")
            b.bind("<Button-1>", lambda e, c=cmd: c())
            b.bind("<Enter>", lambda e, w=b, h=hover, f=hovfg:
                   w.configure(bg=h, fg=f))
            b.bind("<Leave>", lambda e, w=b:
                   w.configure(bg="#f3f3f3", fg="#555555"))
        for w in (top, ver_lb):
            w.bind("<Button-1>", self._drag_start)
            w.bind("<B1-Motion>", self._drag_move)
        tk.Frame(self.root, bg="#d8d8d8", height=1).pack(fill="x")

        body = tk.Frame(self.root)
        body.pack(fill="both", expand=True)   # v1.1.7：去掉内边距，坐标即绝对值

        # ★ 页面容器：礼包领取 / 论坛签到 / QQ群签到（页签占满整宽）
        nb = ttk.Notebook(body)
        nb.pack(fill="both", expand=True)
        main_page = tk.Frame(nb)
        nb.add(main_page, text="  礼包领取  ")
        self._canvas_probe = main_page       # 供 _fit_canvas 量取页面区尺寸

        # ★ v1.1.9 账号面板重做：原 Listbox 太素、账号/状态/身份全挤在一行里。
        #   现改为「统计条 + 两列列表(Treeview) + 选中详情行 + 主色按钮」。
        #   配色跟随 clam 面板底色 #dcdad5 的暖灰系，避免和同页其他面板打架。
        left = self._lf(main_page, "账号（独立profile）")
        self._place(main_page, "claim", "acc", left)

        # ---- 统计条：共 N 个 | 已登录 x / 未登录 y
        stat = tk.Frame(left, bg="#eae8e3")
        stat.pack(fill="x", padx=2, pady=(2, 0))
        self.acc_stat_lb = tk.Label(stat, text="共 0 个", bg="#eae8e3",
                                    fg="#6b6862", font=F8, anchor="w")
        self.acc_stat_lb.pack(side="left", padx=(6, 0))
        self.acc_stat_ok = tk.Label(stat, text="", bg="#eae8e3", fg="#8b8781",
                                    font=F8, anchor="e")
        self.acc_stat_ok.pack(side="right", padx=(0, 6))

        # ---- 账号列表：两列 Treeview（白底，在暖灰面板上像一张卡片）
        wrap = tk.Frame(left, bg="#ffffff", highlightthickness=1,
                        highlightbackground="#c9c6c0")
        wrap.pack(fill="both", expand=True, padx=2, pady=(2, 0))
        self.acc_tree = ttk.Treeview(wrap, columns=("acc", "st"),
                                     show="headings", selectmode="browse",
                                     height=8, style="Acc.Treeview")
        self.acc_tree.heading("acc", text="账号", anchor="w")
        self.acc_tree.heading("st", text="状态", anchor="center")
        self.acc_tree.column("acc", width=104, minwidth=64, anchor="w")
        self.acc_tree.column("st", width=66, minwidth=58, anchor="center",
                             stretch=False)
        acc_sb = ttk.Scrollbar(wrap, orient="vertical",
                               command=self.acc_tree.yview,
                               style="Thin.Vertical.TScrollbar")
        self.acc_tree.configure(yscrollcommand=acc_sb.set)
        acc_sb.pack(side="right", fill="y")
        self.acc_tree.pack(side="left", fill="both", expand=True)
        #   状态只用 tag 改前景色 —— tag 一旦设背景就会盖掉选中高亮
        self.acc_tree.tag_configure("ok", foreground="#1a8f4a")
        self.acc_tree.tag_configure("off", foreground="#c9741a")   # ★ 掉线：暖橙警示
        self.acc_tree.tag_configure("no", foreground="#9b978f")
        self.acc_tree.bind("<<TreeviewSelect>>", self._on_acc_select)

        # ---- 选中详情行：站内身份 / 游戏账号（原来挤在列表行尾，现单独一行）
        self.acc_detail = tk.Label(left, text="", bg="#eae8e3", fg="#9b978f",
                                   font=F8, anchor="w")
        self.acc_detail.pack(fill="x", padx=2, pady=(2, 0))

        # ---- 新增账号：白底输入框（带占位提示）+ 主色「添加」
        f1 = tk.Frame(left)
        f1.pack(fill="x", padx=2, pady=(3, 0))
        self.acc_var = tk.StringVar()
        self.acc_entry = tk.Entry(f1, textvariable=self.acc_var, font=F,
                                  relief="flat", bg="#ffffff", fg="#2b3440",
                                  highlightthickness=1,
                                  highlightbackground="#c9c6c0",
                                  highlightcolor="#1e6fd9",
                                  insertbackground="#2b3440")
        self.acc_entry.pack(side="left", fill="x", expand=True, ipady=3)
        tk.Button(f1, text="添加", command=self.add_account, width=4,
                  bg="#1e6fd9", fg="#ffffff", font=F8, relief="flat", bd=0,
                  cursor="hand2", activebackground="#1857ab",
                  activeforeground="#ffffff").pack(side="left", fill="y",
                                                   padx=(3, 0))
        # 占位提示：独立 Label 浮在输入框上，**不写进 acc_var**
        # （否则空提示会被 add_account 当成账号名添加进去）
        self.acc_ph = tk.Label(f1, text=ACC_PLACEHOLDER, bg="#ffffff",
                               fg="#b3afa8", font=F8, cursor="xterm")
        self.acc_ph.place(x=7, y=5)
        self.acc_entry.bind("<FocusIn>", self._acc_ph_hide)
        self.acc_entry.bind("<Key>", self._acc_ph_hide)
        self.acc_entry.bind("<FocusOut>", self._acc_ph_restore)
        self.acc_entry.bind("<Return>", lambda e: self.add_account())

        # ---- 检测 / 删除 / 导入：等宽扁平按钮（删除用暖红警示色）
        #      ★ v1.1.11 新增「检测」：核对有没有掉线，检测结果直接写进状态列
        f2 = tk.Frame(left)
        f2.pack(fill="x", padx=2, pady=(3, 2))
        for c in range(3):
            f2.columnconfigure(c, weight=1, uniform="accbtn")
        for col, (txt, cmd, bg, fg, hv, hfg) in enumerate((
                ("检测", self.check_accounts_now,
                 "#e2ecdc", "#3f6b2f", "#d3e2c9", "#2f5522"),
                ("删除", self.del_account,
                 "#f0d9d6", "#a83a2c", "#e7c6c1", "#8f2c20"),
                ("导入", self.import_accounts,
                 "#e6e4df", "#55524d", "#dbd8d2", "#3c3934"))):
            b = tk.Button(f2, text=txt, command=cmd, bg=bg, fg=fg, font=F8,
                          relief="flat", bd=0, cursor="hand2", pady=4,
                          activebackground=hv, activeforeground=hfg)
            b.grid(row=0, column=col, sticky="ew",
                   padx=(0 if col == 0 else 4, 0))
            b.bind("<Enter>", lambda e, w=b, c=hv, f=hfg:
                   w.configure(bg=c, fg=f))
            b.bind("<Leave>", lambda e, w=b, c=bg, f=fg:
                   w.configure(bg=c, fg=f))

        self._refresh_accounts()

        # 运行设置（左列顶部）
        setf = self._lf(main_page, "运行设置")
        self._place(main_page, "claim", "runset", setf)

        r1 = tk.Frame(setf)
        r1.pack(fill="x", padx=6, pady=(1, 0))
        tk.Label(r1, text="浏览器:", font=F8).pack(side="left")
        self.browser_var = tk.StringVar()
        self.browser_cb = ttk.Combobox(r1, textvariable=self.browser_var, width=24,
                                       state="readonly", font=F8)
        self.browser_cb.pack(side="left", padx=3)
        self.browser_cb.bind("<<ComboboxSelected>>", self._on_browser_selected)
        tk.Button(r1, text="重新检测", command=self._detect_async,
                  bg="#e8f1ff", relief="flat", font=F8).pack(side="left")

        r2 = tk.Frame(setf)
        r2.pack(fill="x", padx=6, pady=0)
        self.headless_var = tk.BooleanVar(value=self.cfg.get("headless", False))
        tk.Checkbutton(r2, text="无头模式", variable=self.headless_var, font=F8,
                       command=self._on_cfg_change).pack(side="left")
        tk.Label(r2, text="间隔(秒):", font=F8).pack(side="left", padx=(6, 0))
        self.interval_var = tk.StringVar(value=str(self.cfg.get("interval", 2.0)))
        tk.Entry(r2, textvariable=self.interval_var, width=4,
                 font=F8).pack(side="left")
        tk.Label(r2, text="上限:", font=F8).pack(side="left", padx=(6, 0))
        self.limit_var = tk.StringVar(value=str(self.cfg.get("limit", 20)))
        tk.Entry(r2, textvariable=self.limit_var, width=4,
                 font=F8).pack(side="left")
        self.autowait_var = tk.BooleanVar(value=self.cfg.get("auto_wait_login", True))
        tk.Checkbutton(r2, text="未登录自动等待", variable=self.autowait_var,
                       font=F8,
                       command=self._on_cfg_change).pack(side="left", padx=(6, 0))

        r3 = tk.Frame(setf)
        r3.pack(fill="x", padx=6, pady=(0, 1))
        self.timer_var = tk.BooleanVar(value=self.cfg.get("timer_enabled", False))
        tk.Checkbutton(r3, text="定时执行", variable=self.timer_var, font=FB,
                       command=self._on_cfg_change).pack(side="left")
        tk.Label(r3, text="时间:", font=F8).pack(side="left")
        self.timer_time_var = tk.StringVar(value=self.cfg.get("timer_time", "10:00"))
        e_t = tk.Entry(r3, textvariable=self.timer_time_var, width=6, font=F8)
        e_t.pack(side="left")
        e_t.bind("<FocusOut>", lambda e: self._on_cfg_change())
        self.claim_one_var = tk.BooleanVar(value=self.cfg.get("claim_one", True))
        tk.Checkbutton(r3, text="只领一个", variable=self.claim_one_var, font=F8,
                       command=self._on_cfg_change).pack(side="left", padx=(8, 0))
        tk.Label(r3, text="重试:", font=F8).pack(side="left", padx=(8, 0))
        self.retry_var = tk.StringVar(value=str(self.cfg.get("retry", 3)))
        tk.Entry(r3, textvariable=self.retry_var, width=2,
                 font=F8).pack(side="left")

        # ★ v1.1.28 定时检测在线开关：关掉后每 3 小时不再自动开无头浏览器
        #   核登录态（保留「检测」按钮手动查）——降低站点风控触发概率
        r4 = tk.Frame(setf)
        r4.pack(fill="x", padx=6, pady=(0, 1))
        self.auto_check_var = tk.BooleanVar(
            value=self.cfg.get("auto_check", True))
        tk.Checkbutton(r4, text="定时检测在线", variable=self.auto_check_var,
                       font=F8, command=self._on_auto_check_change).pack(
            side="left")
        tk.Label(r4, text="每3小时自动核对，关=只手动检测", font=F8,
                 fg="#999").pack(side="left")

        # 按钮区（两行网格：主操作一行，辅助一行）
        bar = tk.Frame(main_page)
        self._place(main_page, "claim", "act", bar)
        for c in range(3):
            bar.columnconfigure(c, weight=1, uniform="btn")

        self.btn_login = tk.Button(bar, text="① 扫码登录", command=self.do_login,
                                   bg="#2e9e4f", fg="white", relief="flat",
                                   font=FB, pady=2, cursor="hand2")
        self.btn_login.grid(row=0, column=0, sticky="ew", padx=(0, 3))
        self.btn_run = tk.Button(bar, text="② 开始领取", command=self.do_run,
                                 bg="#ff7a00", fg="white", relief="flat",
                                 font=FB, pady=2, cursor="hand2")
        self.btn_run.grid(row=0, column=1, sticky="ew", padx=3)
        self.btn_stop = tk.Button(bar, text="停止", command=self.do_stop, bg="#999",
                                  fg="white", relief="flat", font=FB, pady=2,
                                  state="disabled")
        self.btn_stop.grid(row=0, column=2, sticky="ew", padx=(3, 0))

        # ★ v1.1.2 单账号领取：只跑左侧列表里选中的那一个号，其他号完全不碰
        self.btn_run_one = tk.Button(bar, text="只领选中账号",
                                     command=self.do_run_selected,
                                     bg="#1e6fd9", fg="white", relief="flat",
                                     font=F8, pady=1, cursor="hand2")
        self.btn_run_one.grid(row=1, column=0, columnspan=3, sticky="ew",
                              pady=(2, 0))
        self._update_run_one_btn()

        # 结果表（压缩列宽）
        resf = self._lf(main_page, "结果表")
        self._place(main_page, "claim", "result", resf)
        # ★ v1.1.7 按用户要求去掉「礼包」「金额」两列（礼包名仍在「详情」里）
        cols = ("time", "account", "result", "msg")
        self.tree = ttk.Treeview(resf, columns=cols, show="headings", height=3)
        for c, t, w in [("time", "时间", 100), ("account", "账号", 85),
                        ("result", "结果", 55), ("msg", "详情", 141)]:
            self.tree.heading(c, text=t)
            self.tree.column(c, width=w, anchor="w" if c == "msg" else "center")
        self.tree.pack(fill="both", expand=True, padx=3, pady=(2, 3))
        self.tree.tag_configure("ok", foreground="#2e9e4f")
        self.tree.tag_configure("fail", foreground="#d32f2f")
        # ★ v1.1.0 启动时回填历史领取记录（records.json 一直有存，
        #   之前只在运行中插入表格，关软件再开表格就空了）
        for rec in self.records[-200:]:
            self._add_row(rec)

        # 进度 + 状态（★ v1.1.7 定稿只有 30px 高：进度条与状态文字并到一行）
        stf = tk.Frame(main_page)
        self._place(main_page, "claim", "status", stf)
        self.status_var = tk.StringVar(value="就绪")
        self.pb = ttk.Progressbar(stf, mode="determinate",
                                  style="Thin.Horizontal.TProgressbar")
        # ★ v1.1.11 进度条默认**不显示**：空闲的时候它就是一条 150px 的空灰杠，
        #   什么信息都没有，纯占地方（用户反馈"灰条太长"）。
        #   改成只在「开始领取」真正在跑的时候才包上去 —— 那会儿它才有进度可看。
        #   状态文字靠右先 pack，这样进度条收起/放下都不会让文字左右乱跳。
        self._progress_on = False
        tk.Label(stf, textvariable=self.status_var, anchor="e",
                 font=F8, fg="#555").pack(side="right", padx=(0, 4))

        # 日志：改为『查看日志』按钮 + 独立窗口
        self.logbox = LogBuffer()
        self._build_log_bar(main_page, "main", "运行日志",
                            place=self.LAYOUT["claim"]["log"])

        self.log("就绪（%s）。共 %d 个账号，历史记录 %d 条。" % (VERSION, len(self.accounts), len(self.records)))
        self.log("流程：① 选账号『扫码登录』→ ②『开始领取』（全部）"
                 " 或 『只领选中账号』（单个）")

        # ★ 论坛签到页
        sign_page = tk.Frame(nb)
        nb.add(sign_page, text="  论坛签到  ")
        self._build_forum_page(sign_page)

        # ★ QQ 群签到页（OneBot WS 客户端）
        #   v1.1.7：面板已按定稿坐标排满 600×480 画布，不再需要外层滚动容器
        qq_page = tk.Frame(nb)
        nb.add(qq_page, text="  QQ群签到  ")
        self._build_qq_page(qq_page)

    # ---------------- 论坛签到页
    def _build_forum_page(self, page):
        F = ("Microsoft YaHei", 9)
        F8 = ("Microsoft YaHei", 8)
        FB = ("Microsoft YaHei", 9, "bold")

        # base -> {"cookie": StringVar, "status": StringVar}
        self.forum_vars = {}
        self._forum_stop = False
        self._forum_busy = False
        cfg = self._load_forum_cfg()

        st = cfg.get("_settings", {}) if isinstance(cfg, dict) else {}
        self.auto_sign_var = tk.BooleanVar(value=bool(st.get("auto_sign", False)))
        self.auto_time_var = tk.StringVar(value=st.get("auto_time", "08:00"))
        self.headless_f_var = tk.BooleanVar(value=bool(st.get("headless", False)))
        self._auto_last = str(st.get("last_auto", "") or "")
        self.auto_next_var = tk.StringVar(value="")

        cfgf = self._lf(page, "论坛登录状态")
        self._place(page, "forum", "fstate", cfgf)

        head = tk.Frame(cfgf)
        head.pack(fill="x", padx=6, pady=(2, 0))
        tk.Label(head, text="论坛", font=F8, fg="#555", width=14,
                 anchor="w").pack(side="left")
        tk.Label(head, text="登录状态（Cookie 自动保存）", font=F8, fg="#555",
                 width=24, anchor="w").pack(side="left", padx=(0, 6))
        tk.Label(head, text="操作", font=F8, fg="#555",
                 anchor="w").pack(side="left")

        # ★ v4.7.0 论坛列表改为动态（可手动添加 / 删除），存在配置里
        saved_list = st.get("forum_list") or []
        self._forum_list = []
        if isinstance(saved_list, list):
            for it in saved_list:
                try:
                    nm = str(it.get("name", "")).strip()
                    bu = str(it.get("url", "")).strip()
                except Exception:
                    continue
                if nm and bu:
                    self._forum_list.append((nm, bu))
        if not self._forum_list:                 # 首次运行 / 配置缺失 → 出厂列表
            self._forum_list = [list(x) for x in FORUMS]
        # ★ v1.1.7 定稿 fstate 只有 150px 高：论坛行改成固定高度的可滚动区，
        #   论坛多加几个也不会把「＋ 添加论坛」挤出面板
        rows_wrap = tk.Frame(cfgf)
        rows_wrap.pack(fill="x", padx=6, pady=(0, 2))
        self._fr_canvas = tk.Canvas(rows_wrap, height=81, highlightthickness=0)
        fr_sb = ttk.Scrollbar(rows_wrap, orient="vertical",
                              command=self._fr_canvas.yview)
        self._fr_canvas.configure(yscrollcommand=fr_sb.set)
        fr_sb.pack(side="right", fill="y")
        self._fr_canvas.pack(side="left", fill="x", expand=True)
        self._forum_rows = tk.Frame(self._fr_canvas)
        fr_win = self._fr_canvas.create_window((0, 0), window=self._forum_rows,
                                               anchor="nw")
        self._forum_rows.bind(
            "<Configure>",
            lambda e: self._fr_canvas.configure(
                scrollregion=self._fr_canvas.bbox("all")))
        self._fr_canvas.bind(
            "<Configure>",
            lambda e: self._fr_canvas.itemconfigure(fr_win, width=e.width))
        self._forum_render_rows()

        # ---- 手动添加论坛
        addf = tk.Frame(cfgf)
        addf.pack(fill="x", padx=6, pady=(0, 2))
        tk.Label(addf, text="添加:", font=F8, fg="#555").pack(side="left")
        self.f_new_name = tk.StringVar()
        self.f_new_url = tk.StringVar()
        tk.Entry(addf, textvariable=self.f_new_name, font=F8, width=12,
                 justify="center").pack(side="left", padx=(3, 3))
        tk.Label(addf, text="网址", font=F8, fg="#999").pack(side="left")
        tk.Entry(addf, textvariable=self.f_new_url, font=F8).pack(
            side="left", fill="x", expand=True, padx=(3, 4))
        tk.Button(addf, text="＋ 添加论坛", font=F8, bg="#2e9e4f", fg="white",
                  relief="flat", cursor="hand2",
                  command=self._forum_add_custom).pack(side="left")
        # ★ v1.1.7「论坛登录状态」定稿只有 150px 高：原来那两行说明（网址要填
        #   http(s)://、删除只移除列表不清 Cookie）面板里放不下，改由日志/文档承担

        # ---- 签到设置：定时签到 + 无头模式（替代原来的一键签到/清空按钮）
        setf2 = self._lf(page, "签到设置")
        self._place(page, "forum", "fset", setf2)

        r1 = tk.Frame(setf2)
        r1.pack(fill="x", padx=6, pady=(2, 1))
        tk.Checkbutton(r1, text="每天定时自动签到", variable=self.auto_sign_var,
                       font=F8, command=self._save_forum_settings).pack(side="left")
        tk.Label(r1, text="时间", font=F8, fg="#555").pack(side="left",
                                                          padx=(10, 3))
        tk.Entry(r1, textvariable=self.auto_time_var, font=F8, width=6,
                 justify="center").pack(side="left")
        tk.Label(r1, text="(HH:MM)", font=F8, fg="#999").pack(side="left",
                                                             padx=(3, 14))
        tk.Checkbutton(r1, text="无头模式（不显示浏览器窗口）",
                       variable=self.headless_f_var, font=F8,
                       command=self._save_forum_settings).pack(side="left")

        bar2 = tk.Frame(setf2)
        bar2.pack(fill="x", padx=6, pady=(0, 2))
        for c in range(2):
            bar2.columnconfigure(c, weight=1, uniform="fbtn")
        tk.Button(bar2, text="🌐 立即签到一次", font=FB, bg="#ff7a00",
                  fg="white", relief="flat", pady=2, cursor="hand2",
                  command=self._forum_sign_all).grid(
            row=0, column=0, sticky="ew", padx=(0, 3))
        tk.Button(bar2, text="⏹ 停止", font=FB, bg="#999", fg="white",
                  relief="flat", pady=2, cursor="hand2",
                  command=self._forum_stop_all).grid(
            row=0, column=1, sticky="ew", padx=(3, 0))
        # ★ v1.1.7「签到设置」面板定稿只有 70px 高：把「下次」提示并进按钮行，
        #   原来那两行说明文字（--daemon / 计划任务）面板里放不下，改由日志窗口承担
        tk.Label(bar2, textvariable=self.auto_next_var, font=F8, fg="#555",
                 anchor="w").grid(row=0, column=2, sticky="w", padx=(8, 0))

        # ---- 签到记录表（★ v1.1.0：成功/失败一眼可见，落盘重启不丢）
        self.forum_records = []
        _frec, _ferr = _safe_load_json(FORUM_RECORDS_FILE)
        if _ferr:
            self._cfg_warns.append(_ferr)
        if isinstance(_frec, list):
            # ★ v1.1.29 启动即清理超过 5 天的旧签到记录
            self.forum_records = _prune_records_by_time(_frec)
            if len(self.forum_records) != len(_frec):
                # ★ v1.1.31 加密落盘
                _safe_save_json(FORUM_RECORDS_FILE, self.forum_records[-2000:])
        fcols = ("time", "forum", "result", "msg")
        frecf = self._lf(page, "签到记录表")
        self._place(page, "forum", "frec", frecf)
        self.forum_tree = ttk.Treeview(frecf, columns=fcols, show="headings",
                                       height=4)
        for c, t, w in [("time", "时间", 95), ("forum", "论坛", 110),
                        ("result", "结果", 55), ("msg", "详情", 260)]:
            self.forum_tree.heading(c, text=t)
            self.forum_tree.column(c, width=w, anchor="w" if c == "msg" else "center")
        self.forum_tree.pack(fill="both", expand=True, padx=3, pady=(2, 3))
        self.forum_tree.tag_configure("ok", foreground="#2e9e4f")
        self.forum_tree.tag_configure("already", foreground="#1e6fd9")
        self.forum_tree.tag_configure("fail", foreground="#d32f2f")
        for rec in self.forum_records[-200:]:
            self._forum_add_row(rec)

        # 日志：改为『查看日志』按钮 + 独立窗口
        self.forum_logbox = LogBuffer()
        self._build_log_bar(page, "forum", "签到日志",
                            place=self.LAYOUT["forum"]["flog"])
        n_saved = sum(1 for _n, b in self._forum_list
                      if self.forum_vars[b]["cookie"].get())
        self._forum_log("已保存 %d/%d 个论坛的登录状态。"
                        % (n_saved, len(self._forum_list)))
        self._update_auto_next()
        # 启动定时签到检查（每 30 秒一次）
        try:
            self.root.after(30000, self._auto_sign_tick)
        except Exception:
            pass

    def _forum_render_rows(self):
        """★ v4.7.0 按当前论坛列表重建行（论坛现在可手动添加/删除）。"""
        cfg = self._load_forum_cfg()
        for w in self._forum_rows.winfo_children():
            w.destroy()
        self.forum_vars = {}
        F = ("Microsoft YaHei", 9)
        F8 = ("Microsoft YaHei", 8)
        for name, base in self._forum_list:
            row = tk.Frame(self._forum_rows)
            row.pack(fill="x", pady=1)
            c = cfg.get(base, {})
            cv = tk.StringVar(value=c.get("cookie", ""))
            saved = c.get("saved_at", "")
            sv = tk.StringVar(
                value=("✅ 已保存 %s" % saved) if cv.get() else "○ 未登录")
            self.forum_vars[base] = {"cookie": cv, "status": sv}
            tk.Label(row, text=name, font=F, width=14,
                     anchor="w").pack(side="left")
            lb = tk.Label(row, textvariable=sv, font=F8, width=24, anchor="w",
                          fg=("#2e9e4f" if cv.get() else "#999"))
            lb.pack(side="left", padx=(0, 6))
            self.forum_vars[base]["lb"] = lb
            tk.Button(row, text="登录", font=F8, bg="#2e9e4f", fg="white",
                      relief="flat", cursor="hand2", width=6, pady=0,
                      command=lambda b=base, n=name:
                      self._forum_login_async(b, n)).pack(side="left", padx=(0, 4))
            tk.Button(row, text="签到", font=F8, bg="#1e6fd9", fg="white",
                      relief="flat", cursor="hand2", width=5, pady=0,
                      command=lambda b=base, n=name:
                      self._forum_sign_async([(b, n)])).pack(
                side="left", padx=(0, 4))
            tk.Button(row, text="清除", font=F8, bg="#f2f2f2", relief="flat",
                      cursor="hand2", width=5, pady=0,
                      command=lambda b=base, n=name:
                      self._forum_clear_cookie(b, n)).pack(side="left")
            tk.Button(row, text="删除", font=F8, bg="#ffe9e9", fg="#c62828",
                      relief="flat", cursor="hand2", width=5, pady=0,
                      command=lambda b=base, n=name:
                      self._forum_del_forum(b, n)).pack(side="left", padx=(4, 0))

    def _forum_add_custom(self):
        """★ v4.7.0 手动添加一个论坛（任何 Discuz 站都可以）。"""
        name = (self.f_new_name.get() or "").strip()
        url = (self.f_new_url.get() or "").strip()
        if not name:
            messagebox.showinfo("提示", "请先填写论坛名称")
            return
        if not url:
            messagebox.showinfo("提示", "请先填写论坛网址")
            return
        if not re.match(r"^https?://", url, re.I):
            url = "https://" + url
        if not re.match(r"^https?://[^\s/$.?#].[^\s]*$", url, re.I):
            messagebox.showwarning("提示", "网址格式不对：%s" % url)
            return
        if not url.endswith("/"):
            url += "/"
        for _n, b in self._forum_list:
            if b == url:
                messagebox.showwarning("提示", "该论坛已在列表里：\n%s" % url)
                return
        self._forum_list.append([name, url])
        self._forum_save()
        self._forum_render_rows()
        self.f_new_name.set("")
        self.f_new_url.set("")
        self._forum_log("已添加论坛：%s（%s）" % (name, url))
        self._forum_log("  下一步：点该行的『登录』抓取 Cookie，之后即可签到。")

    def _forum_del_forum(self, base, name):
        """★ v4.7.0 从列表删除论坛（Cookie 保留在文件里，重新添加即恢复）。"""
        if not messagebox.askyesno(
                "删除论坛",
                "从列表移除【%s】？\n\n"
                "已保存的 Cookie 仍保留在 forum_accounts.json 里，"
                "重新添加同一网址即可恢复登录状态。" % name):
            return
        self._forum_list = [[n, b] for n, b in self._forum_list if b != base]
        self._forum_save()
        self._forum_render_rows()
        self._forum_log("已移除论坛：%s（%s）" % (name, base))

    def _forum_log(self, msg):
        def _():
            t = datetime.now().strftime("%H:%M:%S")
            self._push_log("forum", "[%s] %s\n" % (t, msg))
        if threading.current_thread() is threading.main_thread():
            _()
        else:
            try:
                self.root.after(0, _)
            except Exception:
                pass

    # ---- 配置读写
    def _load_forum_cfg(self):
        data, err = _safe_load_json(FORUM_CFG_FILE)
        if err:
            self._cfg_warns.append(err)
        return data if isinstance(data, dict) else {}

    def _forum_cfg_dict(self):
        out = {"_settings": self._forum_settings()}
        # ★ v4.7.0 先原样保留文件里已有的 Cookie（含被删除论坛的），
        #   这样"删除论坛"不会毁掉登录数据，重新添加同一网址即可恢复。
        old = self._load_forum_cfg()
        if isinstance(old, dict):
            for k, v in old.items():
                if k != "_settings" and isinstance(v, dict) and v.get("cookie"):
                    out[k] = {"cookie": v["cookie"],
                              "saved_at": v.get("saved_at", "")}
        for base, v in self.forum_vars.items():
            cookie = v["cookie"].get()
            if cookie:
                out[base] = {"cookie": cookie,
                             "saved_at": (old.get(base) or {}).get("saved_at", "")}
        return out

    def _forum_settings(self):
        return {"auto_sign": bool(getattr(self, "auto_sign_var", None)
                                  and self.auto_sign_var.get()),
                "auto_time": (self.auto_time_var.get().strip()
                              if hasattr(self, "auto_time_var") else "08:00"),
                "headless": bool(getattr(self, "headless_f_var", None)
                                 and self.headless_f_var.get()),
                "last_auto": getattr(self, "_auto_last", ""),
                # ★ v4.7.0 论坛列表本身也进配置（手动添加/删除后重启不丢）
                "forum_list": [{"name": n, "url": b}
                               for n, b in getattr(self, "_forum_list", [])]}

    def _save_forum_settings(self):
        ok = self._forum_save()
        self._update_auto_next()
        if ok:
            self._forum_log("设置已保存（定时签到 %s，无头模式 %s）"
                            % ("开" if self.auto_sign_var.get() else "关",
                               "开" if self.headless_f_var.get() else "关"))

    def _update_auto_next(self):
        """刷新『下次自动签到』提示（支持当天改时间后重试）。"""
        try:
            if not self.auto_sign_var.get():
                self.auto_next_var.set("定时签到：未启用")
                return
            hm = (self.auto_time_var.get() or "").strip()
            m = re.match(r"^([01]?\d|2[0-3]):([0-5]\d)$", hm)
            if not m:
                self.auto_next_var.set("定时签到：时间格式应为 HH:MM")
                return
            hh, mm = int(m.group(1)) % 24, int(m.group(2)) % 60
            now = datetime.now()
            target = now.replace(hour=hh, minute=mm, second=0, microsecond=0)
            # ★ 错过时间点（超 90 秒窗口）或该时间点已执行过 → 显示明天；
            #   正处于到点窗口内还没跑 → 显示今天（马上就执行）
            in_window = now >= target and (now - target).total_seconds() <= 90
            if (_last_run_normalize(self._auto_last) >= _last_run_key(target)
                    or (now >= target and not in_window)):
                target = target + timedelta(days=1)
            self.auto_next_var.set("下次自动签到：%s %s"
                                   % (target.strftime("%m-%d"),
                                      target.strftime("%H:%M")))
        except Exception:
            pass

    def _auto_sign_tick(self):
        """定时器：每 30 秒检查一次；只在到点那一刻（90 秒窗口内）触发，错过不补。"""
        try:
            if self.auto_sign_var.get():
                m = re.match(r"^([01]?\d|2[0-3]):([0-5]\d)$",
                             (self.auto_time_var.get() or "").strip())
                if m:
                    now = datetime.now()
                    target = now.replace(hour=int(m.group(1)) % 24,
                                         minute=int(m.group(2)) % 60,
                                         second=0, microsecond=0)
                    if (now >= target
                            and (now - target).total_seconds() <= 90
                            and _last_run_normalize(
                                self._auto_last) != _last_run_key(target)):
                        self._auto_last = _last_run_key(target)
                        self._forum_log("⏰ 已到定时签到时间 %s，开始自动签到…"
                                        % self.auto_time_var.get().strip())
                        self._forum_save()
                        if not self._forum_busy:
                            self._forum_sign_all()
            self._update_auto_next()
        except Exception:
            pass
        finally:
            try:
                self.root.after(30000, self._auto_sign_tick)
            except Exception:
                pass

    # ==================== QQ 群签到页 ====================
    def _build_qq_page(self, page):
        F = ("Microsoft YaHei", 9)
        F8 = ("Microsoft YaHei", 8)
        FB = ("Microsoft YaHei", 9, "bold")

        self.qq_vars = {}          # gid(str) -> {"enabled","msg","name","count","row","entry"}
        self.qq_order = []         # 群显示顺序
        self._qq_conn = None       # OneBotWS 实例
        self._qq_busy = False
        self._qq_stop = False

        qcfg = self._load_qq_cfg()
        st = qcfg.get("_settings", {}) or {}
        self.qq_url_var = tk.StringVar(value=st.get("url", "ws://127.0.0.1:3001"))
        self.qq_token_var = tk.StringVar(value=st.get("token", ""))
        self.qq_state_var = tk.StringVar(value="○ 未连接")
        self.qq_msg_var = tk.StringVar(value=st.get("default_msg", QQ_DEFAULT_MSG))
        self.qq_like_var = tk.StringVar(value=st.get("like_users", ""))
        self.qq_times_var = tk.StringVar(value=str(st.get("like_times", 5)))
        self.qq_auto_var = tk.BooleanVar(value=bool(st.get("auto_sign", False)))
        self.qq_auto_time_var = tk.StringVar(value=st.get("auto_time", "08:00"))
        self._qq_auto_last = str(st.get("last_auto", "") or "")
        self.qq_auto_next_var = tk.StringVar(value="")
        # 定时点赞：QQ号 框填了才点（★ v1.1.0 已移除「留空则全部好友」）
        self.qq_like_auto_var = tk.BooleanVar(value=bool(st.get("like_auto", False)))
        self.qq_like_auto_time_var = tk.StringVar(
            value=str(st.get("like_auto_time", "08:30")))
        self._qq_like_auto_last = str(st.get("last_like_auto", "") or "")
        self.qq_like_auto_next_var = tk.StringVar(value="")
        # 群列表筛选（只是视图过滤，不写进配置）
        self.qq_filter_var = tk.StringVar(value="")
        self.qq_filter_info_var = tk.StringVar(value="")

        # ★ 2026-09-26 红包监测功能已整体删除（用户要求）。
        #   `_rp_*` 一整套保留原名，因为「关键字通知」复用同一条收包通道
        #   （改名会牵动前端/验收一大片），但其中与红包相关的语义已失效：
        #   `_rp_enabled` / `_rp_target` / `_rp_cnt_hit` 恒为空。
        self._rp_enabled = False                    # ← 红包已删，恒 False
        self._rp_target = ""                        # ← 红包通知目标，无消费者
        self._rp_seen = collections.OrderedDict()   # (群号,消息id) -> ts，去重
        self._rp_stop = threading.Event()
        self._rp_thread = None
        # ---- v1.1.14 推送计数：用来判断"事件到底有没有到"（排障核心）
        self._rp_cnt_all = 0     # 收到的所有事件帧
        self._rp_cnt_grp = 0     # 其中「群消息」帧（任何群）
        self._rp_cnt_mon = 0     # 其中来自「勾选监测群」的群消息
        self._rp_dbg_left = 20   # 头 N 条监测群消息写详细日志（排障用，防刷屏）
        self._rp_snap = 0.0      # 上次打印计数快照的时间
        self._qq_gname = {}                         # gid(str) -> 群名（线程只读）

        # ---- v1.1.15 关键字通知
        #   开关 / 通知号码 / 关键字表都落盘；线程侧只读下面这几个普通属性。
        #   群范围是群列表里第二个勾选框（「关键字」列），与签到各自独立。
        self.qq_kw_var = tk.BooleanVar(value=bool(st.get("kw_on", False)))
        self.qq_kw_qq_var = tk.StringVar(value=str(st.get("kw_notify", "") or ""))
        self.qq_kw_words_var = tk.StringVar(
            value=str(st.get("kw_words", "") or ""))
        self._kw_enabled = bool(st.get("kw_on", False))
        self._kw_target = str(st.get("kw_notify", "") or "").strip()
        self._kw_words_raw = str(st.get("kw_words", "") or "")
        self._kw_words = parse_keywords(self._kw_words_raw)   # 预解析，线程只读
        self._kw_count = 0                          # 关键字已通知次数
        self._rp_cnt_kw = 0                         # 命中关键字的群消息条数
        # 勾选「关键字」列的群号集合（子线程只读快照）
        self._rp_kw_monitored = set()

        # ---- WS 连接（单行紧凑）
        # ★ v1.1.7 定稿只有 32px 高，装不下 LabelFrame 的标题行，
        #   改用带边框的 Frame，标题并在行首提示里
        cf = self._panel(page)
        self._place(page, "qq", "ws", cf)
        r1 = tk.Frame(cf, bg="#ffffff")
        r1.pack(fill="both", expand=True, padx=6, pady=1)
        tk.Label(r1, text="WS 地址:", font=F8, bg="#ffffff").pack(side="left")
        tk.Entry(r1, textvariable=self.qq_url_var, font=F8).pack(
            side="left", fill="x", expand=True, padx=(2, 6))
        tk.Label(r1, text="Token:", font=F8, bg="#ffffff").pack(side="left")
        tk.Entry(r1, textvariable=self.qq_token_var, font=F8, width=10).pack(
            side="left", padx=(2, 6))
        tk.Button(r1, text="连接", font=F8, bg="#2e9e4f", fg="white",
                  relief="flat", cursor="hand2", width=6,
                  command=self._qq_connect).pack(side="left", padx=(0, 4))
        tk.Button(r1, text="断开", font=F8, bg="#f2f2f2", relief="flat",
                  cursor="hand2", width=6,
                  command=self._qq_disconnect).pack(side="left", padx=(0, 4))
        tk.Button(r1, text="⟳ 刷新群列表", font=F8, bg="#e8f1ff", relief="flat",
                  cursor="hand2", command=self._qq_refresh).pack(side="left")

        # ---- 状态行
        stf = tk.Frame(page)
        self._place(page, "qq", "qstate", stf)
        tk.Label(stf, textvariable=self.qq_state_var, font=F8, fg="#2e7d43",
                 anchor="w").pack(side="left", padx=6, pady=3)

        # ---- 群列表
        gf = self._lf(page, "群列表")
        self._place(page, "qq", "glist", gf)
        hd = tk.Frame(gf)
        hd.pack(fill="x", padx=6, pady=(3, 0))
        tk.Label(hd, font=F8, fg="#555", anchor="w",
                 text="勾1=签到，勾2=关键字；消息留空=默认"
                 ).pack(side="left")
        for txt, val in (("反选", None), ("全不选", False), ("全选", True)):
            tk.Button(hd, text=txt, font=F8, bg="#f2f2f2", relief="flat",
                      cursor="hand2", width=4,
                      command=(lambda v=val: self._qq_select_all(v))
                      ).pack(side="right", padx=(3, 0))
        hd2 = tk.Frame(gf)
        hd2.pack(fill="x", padx=6, pady=(3, 0))
        tk.Label(hd2, text="筛选:", font=F8, fg="#555").pack(side="left")
        self.qq_filter_entry = tk.Entry(hd2, textvariable=self.qq_filter_var,
                                        font=F8, width=12)
        self.qq_filter_entry.pack(side="left", padx=(3, 4))
        # 绑变量变化而不是 <KeyRelease>：右键菜单粘贴、拖放粘贴、Ctrl+V
        # 这些都不会触发 KeyRelease，但都会写 StringVar
        self._qq_filter_trace = self.qq_filter_var.trace_add(
            "write", lambda *a: self._qq_apply_filter())
        tk.Button(hd2, text="✕", font=F8, bg="#f2f2f2", relief="flat",
                  cursor="hand2", width=2,
                  command=self._qq_clear_filter).pack(side="left")
        tk.Label(hd2, textvariable=self.qq_filter_info_var, font=F8,
                 fg="#1e6fd9", anchor="e").pack(side="right")
        tk.Label(hd2, text="（群名/群号；全选只对结果）", font=F8,
                 fg="#999", anchor="w").pack(side="left", padx=(8, 0))
        wrap = tk.Frame(gf)
        wrap.pack(fill="both", expand=True, padx=4, pady=(2, 4))
        self.qq_canvas = tk.Canvas(wrap, highlightthickness=0, height=110,
                                   bg="#fdfdfd")
        qsb = ttk.Scrollbar(wrap, orient="vertical", command=self.qq_canvas.yview)
        self.qq_canvas.configure(yscrollcommand=qsb.set)
        qsb.pack(side="right", fill="y")
        self.qq_canvas.pack(side="left", fill="both", expand=True)
        self.qq_inner = tk.Frame(self.qq_canvas, bg="#fdfdfd")
        self._qq_win = self.qq_canvas.create_window((0, 0), window=self.qq_inner,
                                                    anchor="nw")
        self.qq_inner.bind("<Configure>", lambda e: self.qq_canvas.configure(
            scrollregion=self.qq_canvas.bbox("all")))
        self.qq_canvas.bind("<Configure>", lambda e: self.qq_canvas.itemconfigure(
            self._qq_win, width=e.width))
        self.qq_canvas.bind("<Enter>", lambda e: self.qq_canvas.bind_all(
            "<MouseWheel>", self._qq_wheel))
        self.qq_canvas.bind("<Leave>",
                            lambda e: self.qq_canvas.unbind_all("<MouseWheel>"))

        # ---- v1.1.13 红包监测 + v1.1.15 关键字通知（在群列表右侧）
        #   监测「勾选的群」里出现的红包 / 命中关键字的群消息，
        #   私聊通知预设 QQ 号「哪个群、谁发的」。
        rpf = self._lf(page, "红包/关键字监测")
        self._place(page, "qq", "qrpk", rpf)
        # ★ 2026-09-26 红包监测已删：本面板现在只有「关键字通知」。
        #   （原「启用监测」勾选 + 红包通知 QQ 输入框已移除）
        # ---- v1.1.15 关键字通知：独立开关 + 独立通知 QQ
        rk = tk.Frame(rpf)
        rk.pack(fill="x", padx=6, pady=(3, 0))
        tk.Checkbutton(rk, text="关键字通知", variable=self.qq_kw_var, font=F8,
                       anchor="w", command=self._qq_on_kw_change).pack(
            side="left")
        tk.Label(rk, text="QQ:", font=F8).pack(side="left", padx=(6, 0))
        rk_ent = tk.Entry(rk, textvariable=self.qq_kw_qq_var, font=F8, width=8)
        rk_ent.pack(side="left", padx=(2, 0))
        rk_ent.bind("<FocusOut>", lambda e: self._qq_save())
        rk_ent.bind("<Return>", lambda e: self._qq_save())
        self.qq_kw_qq_var.trace_add(
            "write", lambda *a: self._qq_kw_target_changed())
        rw = tk.Frame(rpf)
        rw.pack(fill="x", padx=6, pady=(1, 0))
        tk.Label(rw, text="关键字:", font=F8).pack(side="left")
        rw_ent = tk.Entry(rw, textvariable=self.qq_kw_words_var, font=F8)
        rw_ent.pack(side="left", fill="x", expand=True, padx=(3, 0))
        rw_ent.bind("<FocusOut>", lambda e: self._qq_save())
        rw_ent.bind("<Return>", lambda e: self._qq_save())
        self.qq_kw_words_var.trace_add(
            "write", lambda *a: self._qq_kw_words_changed())
        tk.Label(rpf, textvariable=self.qq_kw_state_var, font=F8, fg="#2e7d43",
                 anchor="w", justify="left", wraplength=160).pack(
            fill="x", padx=8, pady=(1, 0))
        # ★ 2026-09-26 「最近监测」列表 + 「发送测试通知」按钮随红包监测一起删除
        #   （那个列表原先是红包监测的命中记录，测试按钮是给红包通知做联调的）。

        # ---- 底部功能：群签到 ｜ 点赞（定稿已固定宽度/位置，直接 place）
        sf = self._lf(page, "群签到")
        self._place(page, "qq", "qsign", sf)
        s1 = tk.Frame(sf)
        s1.pack(fill="x", padx=6, pady=(2, 1))
        tk.Label(s1, text="默认消息:", font=F8).pack(side="left")
        qmb = ttk.Combobox(s1, textvariable=self.qq_msg_var, font=F8, width=10,
                           values=QQ_MSG_PRESETS)
        qmb.pack(side="left", padx=(3, 8))
        qmb.bind("<<ComboboxSelected>>", lambda e: self._qq_save())
        s3 = tk.Frame(sf)
        s3.pack(fill="x", padx=6, pady=0)
        tk.Checkbutton(s3, text="定时自动签到", variable=self.qq_auto_var,
                       font=F8, command=self._qq_on_auto_change).pack(side="left")
        tk.Entry(s3, textvariable=self.qq_auto_time_var, font=F8, width=5,
                 justify="center").pack(side="left", padx=(4, 6))
        tk.Label(s3, textvariable=self.qq_auto_next_var, font=F8, fg="#555",
                 anchor="w").pack(side="left")
        s2 = tk.Frame(sf)
        s2.pack(fill="x", padx=6, pady=(1, 2))
        s2.columnconfigure(0, weight=1)
        s2.columnconfigure(1, weight=1)
        self.qq_sign_btn = tk.Button(s2, text="🚀 一键签到", font=FB, bg="#ff7a00",
                                     fg="white", relief="flat", pady=1,
                                     cursor="hand2", command=self._qq_sign_async)
        self.qq_sign_btn.grid(row=0, column=0, sticky="ew", padx=(0, 3))
        tk.Button(s2, text="⏹ 停止", font=FB, bg="#999", fg="white", relief="flat",
                  pady=1, cursor="hand2", command=self._qq_stop_all).grid(
            row=0, column=1, sticky="ew", padx=(3, 0))

        lf = self._lf(page, "点赞")
        self._place(page, "qq", "qlike", lf)
        l1 = tk.Frame(lf)
        l1.pack(fill="x", padx=6, pady=(2, 1))
        tk.Label(l1, text="QQ号:", font=F8).pack(side="left")
        tk.Entry(l1, textvariable=self.qq_like_var, font=F8).pack(
            side="left", fill="x", expand=True, padx=(3, 6))
        tk.Label(l1, text="次数:", font=F8).pack(side="left")
        tk.Entry(l1, textvariable=self.qq_times_var, font=F8, width=3,
                 justify="center").pack(side="left", padx=(3, 6))
        tk.Button(l1, text="👍 点赞", font=F8, bg="#1e6fd9", fg="white",
                  relief="flat", cursor="hand2", width=6,
                  command=lambda: self._qq_like_async()).pack(side="left",
                                                              padx=(0, 4))
        l2 = tk.Frame(lf)
        l2.pack(fill="x", padx=6, pady=(1, 0))
        tk.Checkbutton(l2, text="定时自动点赞", variable=self.qq_like_auto_var,
                       font=F8,
                       command=self._qq_on_like_auto_change).pack(side="left")
        tk.Entry(l2, textvariable=self.qq_like_auto_time_var, font=F8, width=5,
                 justify="center").pack(side="left", padx=(4, 6))
        tk.Label(l2, textvariable=self.qq_like_auto_next_var, font=F8, fg="#555",
                 anchor="w").pack(side="left")
        # ★ v1.1.7 定稿只有 103px 高：原来那两行说明压成一行
        tk.Label(lf, font=F8, fg="#888", anchor="w",
                 text="多号用逗号分隔；次数 1-10；定时只点框内号码"
                 ).pack(fill="x", padx=8, pady=(0, 2))

        # 日志：改为『查看日志』按钮 + 独立窗口
        self.qq_logbox = LogBuffer()
        self._build_log_bar(page, "qq", "QQ 签到日志",
                            place=self.LAYOUT["qq"]["qlog"])

        # 用上次保存的群列表先把界面填上（不连接也能看到）
        saved = qcfg.get("groups", {}) or {}
        pre = []
        for gid, g in saved.items():
            if isinstance(g, dict):
                try:
                    pre.append({"id": int(gid), "name": g.get("name", ""),
                                "count": int(g.get("count", 0) or 0)})
                except Exception:
                    continue
        pre.sort(key=lambda x: (-x["count"], x["id"]))
        self._qq_render_groups(pre)
        self._qq_log("就绪。上次保存 %d 个群。" % len(pre))
        self._qq_update_auto_next()
        self._qq_update_like_auto_next()
        self._qq_update_rpk_state()
        # 红包监测是「常驻」功能：上次启用着，这次启动就自动把 WS 连起来，
        # 否则用户会以为监测还在跑其实早断了。
        if self._rp_any_enabled() and (self.qq_url_var.get() or "").strip():
            self._qq_log("监测：已启用，正在自动连接 WS 服务…")
            try:
                self.root.after(1200, self._qq_rpk_autostart)   # 关键字监测自启
            except Exception:
                pass
        try:
            self.root.after(30000, self._qq_auto_tick)
        except Exception:
            pass

    def _qq_wheel(self, event):
        try:
            self.qq_canvas.yview_scroll(int(-event.delta / 120), "units")
        except Exception:
            pass

    def _qq_ui(self, fn):
        """把界面更新切回主线程执行（窗口已销毁时静默忽略）。"""
        try:
            self.root.after(0, fn)
        except Exception:
            pass

    def _qq_log(self, msg):
        def _():
            try:
                t = datetime.now().strftime("%H:%M:%S")
                self._push_log("qq", "[%s] %s\n" % (t, msg))
            except Exception:
                pass
        if threading.current_thread() is threading.main_thread():
            _()
        else:
            try:
                self.root.after(0, _)
            except Exception:
                pass

    def _qq_render_groups(self, groups):
        """重建群列表（保留已有勾选与自定义消息）。"""
        saved = (self._load_qq_cfg().get("groups", {}) or {})
        cur = {gid: {"enabled": v["enabled"].get(), "kw": v["kw"].get(),
                     "msg": v["msg"].get()}
               for gid, v in self.qq_vars.items()}
        for w in self.qq_inner.winfo_children():
            w.destroy()
        self.qq_vars = {}
        self.qq_order = []
        self._qq_gname = {}                 # 重建群名映射（红包通知用）
        if not groups:
            tk.Label(self.qq_inner, font=("Microsoft YaHei", 8), fg="#999",
                     text="尚未拉取群列表：点右上『刷新群列表』（需先连接 WS）").pack(
                anchor="w", padx=8, pady=6)
            self._qq_update_count()
            self._qq_apply_filter()
            return
        for g in groups:
            gid = str(g["id"])
            s = cur.get(gid) or saved.get(gid) or {}
            if not isinstance(s, dict):
                s = {}
            enabled = bool(s.get("enabled", True))       # 新群默认勾选
            kw = bool(s.get("kw", False))                # 关键字默认不勾（防误发）
            msg = str(s.get("msg", "") or "")
            self._qq_add_row(gid, g.get("name", ""), g.get("count", 0),
                             enabled, msg, kw)
        self._qq_save()
        self._qq_update_count()
        self._qq_apply_filter()          # 刷新后沿用当前筛选词
        self._qq_log("群列表已加载：共 %d 个群（新群默认勾选，可自行取消）"
                     % len(groups))

    def _qq_match(self, gid, kw):
        """群号或群名包含关键字（空关键字=全部）。"""
        if not kw:
            return True
        v = self.qq_vars.get(gid) or {}
        return kw in (v.get("name") or "").lower() or kw in gid

    def _qq_apply_filter(self):
        """按筛选框内容显示/隐藏群行（保持原有顺序）。"""
        try:
            kw = (self.qq_filter_var.get() or "").strip().lower()
        except Exception:
            return
        shown = 0
        try:
            # 先全部摘掉，再按顺序把命中的装回去 —— 顺序才不会乱
            for gid in self.qq_order:
                v = self.qq_vars.get(gid)
                if v and v.get("row") is not None:
                    v["row"].pack_forget()
            for gid in self.qq_order:
                v = self.qq_vars.get(gid)
                if not v or v.get("row") is None:
                    continue
                if self._qq_match(gid, kw):
                    v["row"].pack(fill="x")
                    shown += 1
            self.qq_inner.update_idletasks()
            self.qq_canvas.configure(scrollregion=self.qq_canvas.bbox("all"))
        except Exception:
            pass
        try:
            total = len(self.qq_order)
            self.qq_filter_info_var.set(
                ("显示 %d/%d 个群" % (shown, total)) if kw
                else ("共 %d 个群" % total))
        except Exception:
            pass

    def _qq_add_row(self, gid, name, count, enabled, msg, kw=False):
        F8 = ("Microsoft YaHei", 8)
        row = tk.Frame(self.qq_inner, bg="#fdfdfd")
        row.pack(fill="x")
        row.columnconfigure(5, weight=1)      # 输入框列吃掉多余宽度
        ev = tk.BooleanVar(value=bool(enabled))
        kv = tk.BooleanVar(value=bool(kw))    # v1.1.15 关键字监测（独立勾选）
        mv = tk.StringVar(value=msg or "")
        # 列0：签到；列1：关键字 —— 两者各自独立，互不影响
        tk.Checkbutton(row, variable=ev, bg="#fdfdfd",
                       command=self._qq_update_count).grid(row=0, column=0)
        tk.Checkbutton(row, text="关键字", variable=kv, font=F8, fg="#555",
                       bg="#fdfdfd", command=self._qq_update_count).grid(
            row=0, column=1, sticky="w")
        # 群名和「群号·人数」分成两列：真实群名普遍很长，挤在一列会被截断
        # ★ v1.1.13 群列表收窄到 392px
        disp = (name or ("群%s" % gid))[:13]
        tk.Label(row, text=disp, font=F8, anchor="w", width=13).grid(
            row=0, column=2, sticky="w")
        sub = ("%s·%d人" % (gid, count)) if count else gid
        tk.Label(row, text=sub, font=F8, fg="#999", bg="#fdfdfd", anchor="w",
                 width=10).grid(row=0, column=3, sticky="w")
        tk.Label(row, text="消息", font=F8, fg="#888", bg="#fdfdfd").grid(
            row=0, column=4, sticky="e", padx=(3, 0))
        ent = tk.Entry(row, textvariable=mv, font=F8, width=6)
        ent.grid(row=0, column=5, sticky="ew", padx=(3, 4))
        ent.bind("<FocusOut>", lambda e: self._qq_save())
        ent.bind("<Return>", lambda e: self._qq_save())
        self.qq_vars[gid] = {"enabled": ev, "kw": kv, "msg": mv,
                             "name": name, "count": count, "row": row,
                             "entry": ent}
        self._qq_gname[gid] = name          # 关键字通知里要显示群名（子线程只读）
        self.qq_order.append(gid)

    def _qq_update_count(self):
        try:
            checked = [gid for gid in self.qq_order
                       if self.qq_vars.get(gid, {}).get("enabled") is not None
                       and self.qq_vars[gid]["enabled"].get()]
            # ★ 2026-09-26 红包监测已删：不再有「红包」勾选列，也不再收集 rpk。
            # v1.1.15：关键字列是独立勾选，单独维护一份快照
            kw_checked = [gid for gid in self.qq_order
                          if self.qq_vars.get(gid, {}).get("kw") is not None
                          and self.qq_vars[gid]["kw"].get()]
            # 监测线程只读这份快照：勾选集变了就更新
            self._rp_kw_monitored = set(kw_checked)
            n = len(checked)
            self.qq_sign_btn.configure(
                text=("🚀 一键签到（%d 个群）" % n) if n else "🚀 一键签到")
            # ★ v1.1.14：勾选集一变就刷新状态行 —— 否则取消勾选后状态还停在
            #   "监测中（N 个群）"，用户以为在监测、其实已经不在范围里了。
            self._qq_update_rpk_state()
        except Exception:
            pass
        try:
            self._qq_save()
        except Exception:
            pass

    def _qq_select_all(self, val):
        """全选 / 全不选 / 反选：只作用于当前筛选结果（无筛选=全部群）。"""
        try:
            kw = (self.qq_filter_var.get() or "").strip().lower()
        except Exception:
            kw = ""
        n = 0
        for gid in self.qq_order:
            if not self._qq_match(gid, kw):
                continue                     # 被筛掉的群不参与
            v = self.qq_vars.get(gid)
            if not v:
                continue
            v["enabled"].set((not v["enabled"].get()) if val is None else bool(val))
            n += 1
        self._qq_update_count()
        if kw:
            self._qq_log("筛选“%s”：已对 %d 个群执行「%s」"
                         % (kw, n, "全选" if val is True
                            else ("全不选" if val is False else "反选")))

    def _qq_clear_filter(self):
        """清空筛选框并恢复完整列表（写变量即可，trace 会刷新视图）。"""
        try:
            self.qq_filter_var.set("")
        except Exception:
            self._qq_apply_filter()

    # ---- 配置读写
    def _load_qq_cfg(self):
        data, err = _safe_load_json(QQ_CFG_FILE)
        if err:
            self._cfg_warns.append(err)
        return data if isinstance(data, dict) else {}

    def _qq_cfg_dict(self):
        groups = {}
        for gid in self.qq_order:
            v = self.qq_vars.get(gid)
            if not v:
                continue
            try:
                msg = v["msg"].get().strip()
                en = bool(v["enabled"].get())
                kwv = bool(v["kw"].get())
            except Exception:
                continue
            groups[gid] = {"name": v.get("name", ""),
                           "count": v.get("count", 0),
                           "enabled": en, "kw": kwv, "msg": msg}
        try:
            times = int(float(self.qq_times_var.get()))
        except Exception:
            times = 5
        return {"_settings": {"url": self.qq_url_var.get().strip(),
                              "token": self.qq_token_var.get().strip(),
                              "default_msg": self.qq_msg_var.get().strip(),
                              "like_users": self.qq_like_var.get().strip(),
                              "like_times": max(1, min(10, times)),
                              "auto_sign": bool(self.qq_auto_var.get()),
                              "auto_time": self.qq_auto_time_var.get().strip(),
                              "last_auto": getattr(self, "_qq_auto_last", ""),
                              "like_auto": bool(self.qq_like_auto_var.get()),
                              "like_auto_time": self.qq_like_auto_time_var.get().strip(),
                              "last_like_auto": getattr(self, "_qq_like_auto_last", ""),
                              # ---- v1.1.13 红包监测
                              # （★ v1.1.26 rpk_loose 已删：一律只认四种真红包）
                              # ---- v1.1.15 关键字通知
                              "kw_on": bool(self.qq_kw_var.get()),
                              "kw_notify": self.qq_kw_qq_var.get().strip(),
                              "kw_words": self.qq_kw_words_var.get().strip()},
                "groups": groups}

    def _qq_save(self):
        try:
            with open(QQ_CFG_FILE, "w", encoding="utf-8") as f:
                json.dump(self._qq_cfg_dict(), f, ensure_ascii=False, indent=2)
            return True
        except Exception as ex:
            self._qq_log("保存配置失败：%s" % ex)
            return False

    # ---- 连接
    def _qq_connect(self):
        if self._qq_conn is not None and self._qq_conn.is_alive():
            self._qq_log("已处于连接状态，如需重连请先『断开』")
            return
        url = self.qq_url_var.get().strip()
        if not url:
            messagebox.showwarning("提示", "请先填写 WS 地址，例如\n"
                                           "ws://127.0.0.1:3001")
            return
        token = self.qq_token_var.get().strip()
        self._qq_save()
        self.qq_state_var.set("○ 连接中…")
        self._qq_log("正在连接 %s …" % url)

        def worker():
            try:
                c = OneBotWS(url, token, log=self._qq_log)
                c._on_event = self._qq_rpk_on_event    # 群消息监测（关键字）
                c.connect()
            except Exception as ex:
                self._qq_conn = None
                self._qq_ui(lambda: self.qq_state_var.set("○ 未连接"))
                self._qq_log("✗ 连接失败：%s" % ex)
                self._qq_log("  请确认 QQ 机器人框架已启动，且已开启正向 WS "
                             "（NapCat：网络配置 → WebSocket 服务器；"
                             "端口常见 3001 / 8080）")
                self._qq_ui(self._qq_update_rpk_state)
                return
            # 连上了就先记住连接：后面拉群列表失败也不该把连接丢掉
            self._qq_conn = c
            self._qq_rpk_ensure_thread()           # 启用了关键字监测就把收包线程拉起来
            self._qq_ui(self._qq_update_rpk_state)
            who = "%s (%s)" % (c.nickname or "QQ", c.self_id or "?")
            self._qq_ui(lambda: self.qq_state_var.set("✅ 已连接：%s" % who))
            self._qq_log("✅ 已连接：%s" % who)
            try:
                groups = c.get_group_list()
            except Exception as ex:
                self._qq_log("✗ 已连接，但拉取群列表失败：%s"
                             "（可点『刷新群列表』重试）" % ex)
                return
            self._qq_ui(lambda: self._qq_render_groups(groups))
            self._qq_ui(self._qq_update_rpk_state)
        threading.Thread(target=worker, daemon=True).start()

    def _qq_disconnect(self):
        self._rp_stop.set()                     # 停掉红包监测收包线程
        try:
            if self._qq_conn:
                self._qq_conn.close()
        except Exception:
            pass
        self._qq_conn = None
        self.qq_state_var.set("○ 未连接")
        self._qq_update_rpk_state()
        self._qq_log("已断开连接")

    def _qq_refresh(self):
        conn = self._qq_conn
        if conn is None:
            self._qq_log("未连接 WS 服务，请先点『连接』")
            return
        self._qq_log("正在拉取群列表…")

        def worker():
            try:
                if not conn.is_alive() and not self._qq_reconnect(conn):
                    self._qq_log("✗ 连接不可用，无法刷新群列表，请点『连接』后重试")
                    return
                groups = conn.get_group_list()
                self._qq_ui(lambda: self._qq_render_groups(groups))
            except Exception as ex:
                self._qq_log("✗ 拉取群列表失败：%s" % ex)
        threading.Thread(target=worker, daemon=True).start()

    # ---- 签到
    def _qq_reconnect(self, conn):
        """连接断了就自动重连一次。成功返回 True。

        批量签到几十上百个群要跑好几分钟，中途 NapCat 侧断一次连接很常见；
        没有这个兜底的话，剩下的群会一条条刷"尚未连接 WS 服务"，
        既看不出是连接断了，也白白跳过所有群。
        """
        self._qq_log("  ⚠ WS 连接已断开，尝试自动重连…")
        self._qq_ui(lambda: self.qq_state_var.set("○ 重连中…"))
        try:
            conn.connect()
            self._qq_ui(lambda: self.qq_state_var.set("✅ 已重连"))
            self._qq_log("  ✅ 自动重连成功，继续执行")
            return True
        except Exception as ex:
            self._qq_ui(lambda: self.qq_state_var.set("○ 连接已断开"))
            self._qq_log("  ✗ 自动重连失败：%s" % ex)
            return False

    def _qq_sign_async(self, confirm=True):
        if self._qq_busy:
            self._qq_log("已有任务在执行，请稍候…")
            return
        conn = self._qq_conn
        if conn is None:
            self._qq_log("未连接 WS 服务，请先点『连接』")
            return
        if not conn.is_alive():
            # 连接掉了不用让用户手动点『连接』，下面每个目标发送前会自动重连
            self._qq_log("连接已断开，开始前先尝试自动重连…")
        # 在主线程就把每群的专属消息读成字符串快照：子线程读写 Tk 变量是
        # 未定义行为（只靠 mainloop 恰好在跑侥幸能用）
        targets = [(gid, self.qq_vars[gid].get("name") or gid,
                    (self.qq_vars[gid]["msg"].get() or "").strip())
                   for gid in self.qq_order
                   if gid in self.qq_vars and self.qq_vars[gid]["enabled"].get()]
        if not targets:
            self._qq_log("没有勾选任何群，请先勾选需要签到的群")
            return
        default_msg = self.qq_msg_var.get().strip()
        if not default_msg:
            self._qq_log("默认消息为空；未单独填消息的群将被跳过（不发空消息）")
        # 群消息发出去撤不回来。默认勾选 + 上百个群的情况下，误点一次就是
        # 给上百个真实群发消息 —— 先报清规模让用户确认（定时签到跳过此步）。
        if confirm and len(targets) >= 2:
            try:
                n_custom = sum(1 for _g, _nm, _m in targets if _m)
                if n_custom:
                    extra = "其中 %d 个群用它们各自的专属消息，其余用默认消息。" % n_custom
                else:
                    extra = "全部使用默认消息。"
                if not messagebox.askyesno(
                        "确认群签到",
                        "即将给 %d 个群各发送一条消息，发送后无法撤回。\n\n"
                        "默认消息：%s\n%s\n\n确认开始？"
                        % (len(targets), default_msg or "（空）", extra)):
                    self._qq_log("已取消签到（未发送任何消息）")
                    return
            except Exception:
                pass
        self._qq_save()
        self._qq_stop = False
        self._qq_log("―――― 开始签到：%d 个群 ――――" % len(targets))

        def worker():
            self._qq_busy = True
            ok = skip = 0
            n = len(targets)
            i = 0
            retried = set()          # 已因断连重试过一次的群
            try:
                while i < n:
                    if self._qq_stop:
                        self._qq_log("已停止（完成 %d/%d）" % (i, n))
                        break
                    gid, name, own_msg = targets[i]
                    if not conn.is_alive() and not self._qq_reconnect(conn):
                        self._qq_log("⚠ WS 连接不可用，签到中止：已成功 %d 个，"
                                     "剩余 %d 个未发送。请点『连接』恢复后重新签到。"
                                     % (ok, n - i))
                        break
                    try:
                        msg = own_msg or default_msg
                    except Exception:
                        msg = default_msg
                    if not msg:
                        skip += 1
                        self._qq_log("  ⏭ [%d/%d] %s：消息为空，跳过"
                                     % (i + 1, n, name))
                        i += 1
                        continue
                    try:
                        conn.send_group_msg(int(gid), msg)
                        ok += 1
                        self._qq_log("  ✅ [%d/%d] %s：已发送「%s」"
                                     % (i + 1, n, name, msg))
                    except Exception as ex:
                        self._qq_log("  ✗ [%d/%d] %s：%s"
                                     % (i + 1, n, name, ex))
                        if not conn.is_alive() and gid not in retried:
                            retried.add(gid)     # 重连后把这一个群补发一次
                            continue
                    i += 1
                    time.sleep(1.2)
                self._qq_log("签到结束：成功 %d，跳过 %d，共 %d 个群"
                             % (ok, skip, n))
            finally:
                # 连接在批量过程中掉了就把状态改掉，别继续显示"已连接"
                if not conn.is_alive():
                    self._qq_ui(lambda: self.qq_state_var.set("○ 连接已断开"))
                self._qq_busy = False
        threading.Thread(target=worker, daemon=True).start()

    def _qq_stop_all(self):
        self._qq_stop = True
        self._qq_log("已请求停止（等待当前步骤结束）…")

    # ---- 红包监测（★ v1.1.13）
    #   只监测群列表里**勾选**的群：群消息事件里 group_id 在勾选集合内才处理。
    #   收包走 OneBotWS.poll_events（空闲轮询）+ _call 的收包循环顺带分发，
    #   两条路都不可能并发读 socket，所以不会打乱签到/点赞的回包。
    def _qq_kw_target_changed(self):
        """关键字通知 QQ 输入框变化 → 同步线程只读属性。"""
        try:
            self._kw_target = (self.qq_kw_qq_var.get() or "").strip()
        except Exception:
            pass
        self._qq_update_rpk_state()

    def _qq_kw_words_changed(self):
        """关键字输入框变化 → 预解析成列表（线程只读），并落盘。"""
        try:
            self._kw_words_raw = self.qq_kw_words_var.get() or ""
            self._kw_words = parse_keywords(self._kw_words_raw)
        except Exception:
            self._kw_words = []
        self._qq_save()
        self._qq_update_rpk_state()

    def _qq_on_kw_change(self):
        """启用/关闭关键字通知（与红包监测各自独立）。"""
        self._kw_enabled = bool(self.qq_kw_var.get())
        self._kw_target = (self.qq_kw_qq_var.get() or "").strip()
        self._kw_words = parse_keywords(self.qq_kw_words_var.get())
        self._qq_save()
        if self._kw_enabled:
            if not parse_qq_list(self._kw_target):
                self._qq_log("关键字通知：已启用，但还没填通知 QQ 号（填好才发得出）")
            if not self._kw_words:
                self._qq_log("关键字通知：已启用，但还没填关键字（填好才认得出）")
            n = len(self._rp_kw_monitored)
            if n:
                self._qq_log("  关键字范围 = 群列表里勾了「关键字」列的群（当前 %d 个）"
                             % n)
            else:
                self._qq_log("  ⚠ 关键字范围 = 群列表里勾「关键字」列，"
                             "现在一个都没勾 —— 不勾就收不到任何关键词通知")
            self._qq_ensure_monitor()
        else:
            self._qq_log("关键字通知：已关闭")
            self._qq_stop_monitor_if_idle()
        self._qq_update_rpk_state()

    def _rp_any_enabled(self):
        """红包或关键字任一开着，监测线程就该跑（两者共用一条 WS + 一个线程）。"""
        return bool(self._rp_enabled or self._kw_enabled)

    def _qq_ensure_monitor(self):
        """按需拉起 WS 连接 + 收包线程（任一监测开着才有意义）。"""
        if not self._rp_any_enabled():
            return
        conn = self._qq_conn
        if conn is None or not conn.is_alive():
            self._qq_log("监测：当前未连接 WS，正在自动连接…")
            self._qq_connect()
        self._qq_rpk_ensure_thread()

    def _qq_stop_monitor_if_idle(self):
        """两个监测都关了才真正停掉收包线程。"""
        if not self._rp_any_enabled():
            self._rp_stop.set()

    def _kw_state_text(self):
        """关键字通知的状态短句。"""
        if not self.qq_kw_var.get():
            return "关键字:未启用"
        if not parse_qq_list(self.qq_kw_qq_var.get()):
            return "关键字:未填通知QQ"
        if not parse_keywords(self.qq_kw_words_var.get()):
            return "关键字:未填关键词"
        n = len(self._rp_kw_monitored)
        if n == 0:
            return "关键字:⚠未选监测群"
        t = self._rp_thread
        if t is None or not t.is_alive():
            return "关键字:⚠监测未运行"
        conn = self._qq_conn
        if conn is not None and conn.is_alive():
            return "关键字:监测中(%d群)" % n
        return "关键字:等待连接…"

    def _qq_update_rpk_state(self):
        """刷新面板上的状态文字（主线程调用）。

        ★ 2026-09-26 红包监测已删：现在只显示关键字一句。
        （函数名保留 —— 关键字那套回调都调它，改名影响面大。）
        """
        try:
            self.qq_kw_state_var.set(self._kw_state_text())
        except Exception:
            pass

    def _qq_rpk_autostart(self):
        """启动时若任一监测为启用状态，自动把连接和收包线程拉起来。"""
        try:
            if not self._rp_any_enabled():
                return
            if self._qq_conn is None or not self._qq_conn.is_alive():
                self._qq_connect()
            self._qq_rpk_ensure_thread()
        except Exception:
            pass

    def _qq_rpk_ensure_thread(self):
        if not self._rp_any_enabled():
            return
        # ⚠ 必须先清 _rp_stop：老线程可能「还活着、但正打算退出」——
        #   关闭监测→立刻再打开时，它要等本轮 poll_events 跑完才发现 stop
        #   被置位。此时若按 is_alive() 判定"线程还在"就直接返回，
        #   老线程下一轮就退出了 → 留下一个**空转的假监测**（状态还显示"监测中"）。
        #   先清掉 stop，它下一轮判断就会继续跑；真死了再补一个新线程。
        self._rp_stop.clear()
        t = self._rp_thread
        if t is not None and t.is_alive():
            return
        self._rp_thread = threading.Thread(target=self._qq_rpk_loop,
                                           daemon=True, name="qq-rpk-monitor")
        self._rp_thread.start()

    def _qq_rpk_loop(self):
        """监测线程：空闲时不停取一帧事件；连接没起来就等着（不退出）。

        连接由心跳线程负责自愈（OneBotWS 内部），这里只负责「有事件就读」，
        所以 NapCat 短暂重启也不用用户管。

        每 60 秒把**推送计数**写进日志（v1.1.14）——这是判断"收不到红包"
        究竟卡在「服务端没推 / 群没勾 / 没认出来」的唯一可靠依据。
        v1.1.15 起关键字命中也计入同一张表。
        """
        while not self._rp_stop.is_set() and self._rp_any_enabled():
            conn = self._qq_conn
            if conn is None or not conn.is_alive():
                time.sleep(1.0)
                continue
            try:
                conn.poll_events(1.0)
            except Exception:
                time.sleep(0.5)
            now = time.time()
            if now - self._rp_snap >= 60:
                self._rp_snap = now
                # ★ 2026-09-26 红包监测已删：统计行不再有「识别红包」项
                self._qq_log(
                    "[诊断] 推送统计：事件 %d / 群消息 %d / 其中监测群 %d / "
                    "识别关键词 %d / 已通知 %d（关键字 %d 个群）"
                    % (self._rp_cnt_all, self._rp_cnt_grp, self._rp_cnt_mon,
                       self._rp_cnt_kw, self._kw_count,
                       len(self._rp_kw_monitored)))

    def _qq_rpk_on_event(self, ev):
        """OneBot 事件回调（跑在收包线程里）。

        ⚠ 它在 OneBotWS 持有 _io 锁时被调用，**不能**在这里同步发请求；
        要发私聊就另起线程（下面 _qq_kw_notify）。
        UI 更新一律走 _qq_ui。
        """
        try:
            if not self._rp_any_enabled():
                return
            if not isinstance(ev, dict):
                return
            # ★ v1.1.14 计数：**任何** post_type 的事件帧都算一条，
            #   用来判断"推送通道到底通不通"（收到 0 = 服务端没推）。
            self._rp_cnt_all += 1
            if str(ev.get("post_type")) not in ("message", "message_sent"):
                return
            if str(ev.get("message_type")) != "group":
                return
            self._rp_cnt_grp += 1
            gid = ev.get("group_id")
            if gid is None:
                return
            gid_s = str(gid)
            # ★ 2026-09-26 红包监测已删：本通道只服务「关键字通知」。
            want_kw = (bool(self._kw_enabled) and bool(self._kw_words)
                       and gid_s in self._rp_kw_monitored)
            if not want_kw:
                return
            self._rp_cnt_mon += 1
            sender = ev.get("sender") if isinstance(ev.get("sender"), dict) else {}
            uid = ev.get("user_id", "")
            sname = str(sender.get("card") or sender.get("nickname") or "")
            kword = _find_keyword(ev, self._kw_words) if want_kw else None
            # ★ v1.1.14 排障：头 N 条「监测群」消息写详细日志（含原文），
            #   这样"到底有没有收到""为什么没认出来"一眼可见；N 用完就不写了。
            if self._rp_dbg_left > 0:
                self._rp_dbg_left -= 1
                self._qq_log(
                    "[诊断] 群%s(%s) %s：段=%s%s 原文=%s"
                    % (gid_s, self._qq_gname.get(gid_s, ""), sname,
                       _seg_types(ev.get("message")),
                       (" 关键词=%s" % kword) if kword else "",
                       _short(ev.get("raw_message"), 90)))
            # 同一条消息只处理一次（消息 id 优先；缺 id 就用内容摘要当键）
            mid = ev.get("message_id")
            key = (gid_s, str(mid) if mid is not None
                   else "%s-%s-%s" % (ev.get("user_id"), ev.get("time"),
                                      len(str(ev.get("raw_message") or ""))))
            seen = self._rp_seen
            if key in seen:
                return
            if not kword:
                return
            seen[key] = time.time()
            while len(seen) > 2000:
                seen.popitem(last=False)         # 只做去重，别无限涨
            gname = self._qq_gname.get(gid_s, "")
            title = ("群「%s」(%s)" % (gname, gid_s)) if gname else ("群 %s" % gid_s)
            # ---- 关键字通知
            if kword:
                self._rp_cnt_kw += 1
                ktargets = parse_qq_list(self._kw_target)
                if ktargets:
                    text = kw_notify_text(gid_s, gname, sname, uid, kword,
                                          _short(_msg_search_text(ev), 60))
                    threading.Thread(target=self._qq_kw_notify,
                                     args=(ktargets, text, title, kword),
                                     daemon=True).start()
                else:
                    self._qq_log("关键字通知：%s 命中「%s」，但未填通知 QQ 号，已忽略"
                                 % (title, kword))
        except Exception:
            pass

    def _qq_kw_notify(self, targets, text, title, keyword):
        """真正发关键字私聊通知（独立线程：从收包线程里再发请求会死锁）。"""
        conn = self._qq_conn
        if conn is None or not conn.is_alive():
            self._qq_log("关键字通知：%s 命中「%s」，但 WS 未连接，发送失败"
                         % (title, keyword))
            return
        okn = 0
        for q in targets:
            try:
                conn.send_private_msg(q, text)
                okn += 1
            except Exception as ex:
                self._qq_log("关键字通知：私聊 %s 失败：%s" % (q, ex))
        if okn:
            self._kw_count += 1
            self._qq_log("🔔 关键字通知：%s 命中「%s」，已私聊通知 %d 个号码"
                         % (title, keyword, okn))
        ts = datetime.now().strftime("%H:%M:%S")
        self._qq_ui(lambda: self._rp_add_hit(
            ts, "关键词「%s」%s" % (keyword, title)))

    def _rp_add_hit(self, ts, title):
        """关键字命中后的界面刷新（主线程）。

        ★ 2026-09-26 红包监测已删：「最近监测」列表控件也一起删了，
        这里只刷新状态文字（命中记录仍会写进日志）。
        """
        self._qq_update_rpk_state()

    def _rp_monitored_snapshot(self):
        """只读快照（调试/测试用）。线程侧请用 self._rp_kw_monitored。"""
        return set(self._rp_kw_monitored)

    # ---- 点赞（★ v1.1.0 已移除「给全部好友点赞」：好友数不可预知、
    #      requests = 好友数 × 次数，动辄上千次请求，极易触发 QQ 风控，
    #      现在只给输入框里明确填写的 QQ 号点赞）
    def _qq_like_async(self, _users=None):
        if self._qq_busy:
            self._qq_log("已有任务在执行，请稍候…")
            return
        conn = self._qq_conn
        if conn is None:
            self._qq_log("未连接 WS 服务，请先点『连接』")
            return
        if not conn.is_alive():
            self._qq_log("连接已断开，开始前先尝试自动重连…")
        try:
            times = max(1, min(10, int(float(self.qq_times_var.get()))))
        except Exception:
            times = 5
        us = list(_users) if _users else parse_qq_list(self.qq_like_var.get())
        if not us:
            self._qq_log("请填写要点赞的 QQ 号（多个用逗号 / 空格分隔）")
            return
        self._qq_save()
        self._qq_stop = False
        n_users = list(us)                # 别给 us 赋值，否则闭包变量变局部

        def worker():
            self._qq_busy = True
            ok = 0
            try:
                target_ids = n_users
                if not target_ids:
                    self._qq_log("没有可点赞的目标")
                    return
                self._qq_log("开始点赞：%d 个 QQ，每人 %d 次"
                             % (len(target_ids), times))
                n = len(target_ids)
                i = 0
                retried = set()
                while i < n:
                    if self._qq_stop:
                        self._qq_log("已停止（完成 %d/%d）" % (i, n))
                        break
                    uid = target_ids[i]
                    if not conn.is_alive() and not self._qq_reconnect(conn):
                        self._qq_log("⚠ WS 连接不可用，点赞中止：已成功 %d 个，"
                                     "剩余 %d 个未处理。" % (ok, n - i))
                        break
                    try:
                        conn.send_like(uid, times)
                        ok += 1
                        self._qq_log("  👍 [%d/%d] %s" % (i + 1, n, uid))
                    except Exception as ex:
                        self._qq_log("  ✗ [%d/%d] %s：%s" % (i + 1, n, uid, ex))
                        if not conn.is_alive() and uid not in retried:
                            retried.add(uid)
                            continue
                    i += 1
                    time.sleep(1.2)
                self._qq_log("点赞结束：成功 %d/%d" % (ok, n))
            except Exception as ex:
                self._qq_log("✗ 点赞异常：%s" % ex)
            finally:
                if not conn.is_alive():
                    self._qq_ui(lambda: self.qq_state_var.set("○ 连接已断开"))
                self._qq_busy = False
        threading.Thread(target=worker, daemon=True).start()

    # ★ v1.1.0 「全部好友点赞」已整体移除：
    #   原 _qq_confirm_like_all（读取好友列表 + 弹规模确认框）随之删除，
    #   只保留给指定 QQ 号点赞（安全、可控、不会误触风控）。

    # ---- 定时
    def _qq_on_auto_change(self):
        self._qq_save()
        self._qq_update_auto_next()
        self._qq_log("定时签到已%s（时间 %s）"
                     % ("启用" if self.qq_auto_var.get() else "关闭",
                        self.qq_auto_time_var.get().strip() or "08:00"))

    def _qq_update_auto_next(self):
        try:
            if not self.qq_auto_var.get():
                self.qq_auto_next_var.set("定时签到：未启用")
                return
            m = re.match(r"^([01]?\d|2[0-3]):([0-5]\d)$",
                         (self.qq_auto_time_var.get() or "").strip())
            if not m:
                self.qq_auto_next_var.set("定时签到：时间格式应为 HH:MM")
                return
            hh, mm = int(m.group(1)) % 24, int(m.group(2)) % 60
            now = datetime.now()
            target = now.replace(hour=hh, minute=mm, second=0, microsecond=0)
            # ★ 错过时间点（超 90 秒窗口）或已执行过 → 显示明天
            in_window = now >= target and (now - target).total_seconds() <= 90
            if (_last_run_normalize(self._qq_auto_last) >= _last_run_key(target)
                    or (now >= target and not in_window)):
                target = target + timedelta(days=1)
            self.qq_auto_next_var.set("下次：%s %s"
                                      % (target.strftime("%m-%d"),
                                         target.strftime("%H:%M")))
        except Exception:
            pass

    def _qq_auto_tick(self):
        try:
            now = datetime.now()
            if self.qq_auto_var.get():
                m = re.match(r"^([01]?\d|2[0-3]):([0-5]\d)$",
                             (self.qq_auto_time_var.get() or "").strip())
                if m:
                    target = now.replace(hour=int(m.group(1)) % 24,
                                         minute=int(m.group(2)) % 60,
                                         second=0, microsecond=0)
                    if (now >= target
                            and (now - target).total_seconds() <= 90
                            and _last_run_normalize(
                                self._qq_auto_last) != _last_run_key(target)):
                        self._qq_auto_last = _last_run_key(target)
                        self._qq_log("⏰ 已到定时签到时间 %s，开始自动签到…"
                                     % self.qq_auto_time_var.get().strip())
                        self._qq_save()
                        if self._qq_conn is not None and self._qq_conn.is_alive():
                            self._qq_sign_async(confirm=False)   # 无人值守，别弹确认框
                        else:
                            self._qq_log("  未连接 WS 服务，本次跳过"
                                         "（请让程序保持连接状态）")
            # 定时点赞：与定时签到同一套 30 秒轮询，但各自独立记"做没做"；
        # ★ v1.1.0 只点输入框里填的 QQ 号，不再有「全部好友」模式
            if self.qq_like_auto_var.get():
                m = re.match(r"^([01]?\d|2[0-3]):([0-5]\d)$",
                             (self.qq_like_auto_time_var.get() or "").strip())
                if m:
                    target = now.replace(hour=int(m.group(1)) % 24,
                                         minute=int(m.group(2)) % 60,
                                         second=0, microsecond=0)
                    if (now >= target
                            and (now - target).total_seconds() <= 90
                            and _last_run_normalize(
                                self._qq_like_auto_last) != _last_run_key(target)):
                        self._qq_fire_like_auto(target)
            self._qq_update_auto_next()
            self._qq_update_like_auto_next()
        except Exception:
            pass
        finally:
            try:
                self.root.after(30000, self._qq_auto_tick)
            except Exception:
                pass

    def _qq_on_like_auto_change(self):
        self._qq_save()
        self._qq_update_like_auto_next()
        self._qq_log("定时点赞已%s（时间 %s）"
                     % ("启用" if self.qq_like_auto_var.get() else "关闭",
                        self.qq_like_auto_time_var.get().strip() or "08:30"))

    def _qq_update_like_auto_next(self):
        try:
            if not self.qq_like_auto_var.get():
                self.qq_like_auto_next_var.set("定时点赞：未启用")
                return
            m = re.match(r"^([01]?\d|2[0-3]):([0-5]\d)$",
                         (self.qq_like_auto_time_var.get() or "").strip())
            if not m:
                self.qq_like_auto_next_var.set("定时点赞：时间格式应为 HH:MM")
                return
            hh, mm = int(m.group(1)) % 24, int(m.group(2)) % 60
            now = datetime.now()
            target = now.replace(hour=hh, minute=mm, second=0, microsecond=0)
            # ★ 错过时间点（超 90 秒窗口）或已执行过 → 显示明天
            in_window = now >= target and (now - target).total_seconds() <= 90
            if (_last_run_normalize(self._qq_like_auto_last) >= _last_run_key(target)
                    or (now >= target and not in_window)):
                target = target + timedelta(days=1)
            self.qq_like_auto_next_var.set("下次：%s %s"
                                           % (target.strftime("%m-%d"),
                                              target.strftime("%H:%M")))
        except Exception:
            pass

    def _qq_fire_like_auto(self, target=None):
        """到点触发定时点赞。返回 True=本次已处理（成功/跳过都算，该时间点不再重试）；
        返回 False=正忙没动，留给下一个 30 秒周期再试。"""
        if self._qq_busy:
            return False          # 可能正在签到，等它跑完
        if target is None:
            target = datetime.now()
        self._qq_like_auto_last = _last_run_key(target)
        self._qq_save()
        if self._qq_conn is None or not self._qq_conn.is_alive():
            self._qq_log("⏰ 已到定时点赞时间，但未连接 WS 服务，本次跳过"
                         "（请让程序保持连接状态）")
            return True
        users = parse_qq_list(self.qq_like_var.get())
        if users:
            self._qq_log("⏰ 已到定时点赞时间 %s，给 %d 个 QQ 点赞…"
                         % (self.qq_like_auto_time_var.get().strip(), len(users)))
            self._qq_like_async(_users=users)
        else:
            # ★ v1.1.0「全部好友点赞」已移除：没填 QQ 号就本次跳过，不发任何请求
            self._qq_log("⏰ 已到定时点赞时间 %s，但 QQ 号为空，本次跳过"
                         "（请先在『QQ号』框里填要点赞的号码）"
                         % self.qq_like_auto_time_var.get().strip())
        return True

    def _forum_set_status(self, base, text, color="#2e9e4f"):
        def _():
            try:
                v = self.forum_vars[base]
                v["status"].set(text)
                v["lb"].configure(fg=color)
            except Exception:
                pass
        self._forum_ui(_)

    def _forum_set_cookie(self, base, cookie):
        """写回 cookie（自动切回主线程）。"""
        def _():
            try:
                self.forum_vars[base]["cookie"].set(cookie)
            except Exception:
                pass
        self._forum_ui(_)

    def _forum_ui(self, fn):
        """把 Tk 操作切回主线程执行（Tk 变量只能主线程读写）。"""
        if threading.current_thread() is threading.main_thread():
            fn()
            return
        try:
            self.root.after(0, fn)
        except Exception:
            pass

    def _forum_save(self):
        try:
            with open(FORUM_CFG_FILE, "w", encoding="utf-8") as f:
                json.dump(self._forum_cfg_dict(), f, ensure_ascii=False,
                          indent=2)
            return True
        except Exception as ex:
            self._forum_log("保存配置失败：%s" % ex)
            return False

    # ---- 登录：内置浏览器手动登录 → 自动抓 Cookie
    def _forum_login_async(self, base, name):
        if self._forum_busy:
            self._forum_log("已有任务在执行，请先等待完成或点『停止』。")
            return
        self._forum_stop = False
        headless = False                      # 主线程读，子线程只用普通 bool
        try:
            headless = bool(self.headless_f_var.get())
        except Exception:
            pass
        t = threading.Thread(target=self._forum_login_flow,
                             args=(base, name, headless), daemon=True)
        t.start()

    def _forum_login_flow(self, base, name, headless=False):
        self._forum_busy = True
        try:
            if headless:
                self._forum_log("  提示：手动登录必须显示浏览器窗口，本次忽略无头模式；"
                                "签到本身在后台完成，不弹窗口。")
            self._forum_do_login(base, name)
        finally:
            self._forum_busy = False

    def _forum_do_login(self, base, name, auto=False):
        """★ v1.1.29 从 _forum_login_flow 拆出的登录主体。

        打开内置浏览器等登录成功 → 抓 Cookie+UA → 校验并保存。
        不管理 _forum_busy（调用方负责），返回 (成功?, cookie, ua)；
        auto=True 时日志按『403 自动恢复』文案输出。
        """
        eng = None
        try:
            if auto:
                self._forum_log("  ↻ 403 已自动重试仍被拦截 → 清 Cookie 重新登录…")
            else:
                self._forum_log("―――――― %s：打开浏览器登录 ――――――" % name)
            path = embedded_browser(log=self._forum_log)
            if not path:
                self._forum_log("  ✗ 未找到内置浏览器，无法打开登录窗口")
                return False, "", ""
            host = urllib.parse.urlparse(base).netloc
            parts = host.split(".")
            root_domain = ".".join(parts[-2:]) if len(parts) >= 2 else host
            profile = os.path.join(FORUM_LOGIN_DIR, host.replace(".", "_"))
            try:
                os.makedirs(FORUM_LOGIN_DIR, exist_ok=True)
            except Exception:
                pass
            eng = Engine(log=self._forum_log)
            port = free_port()
            eng.kill_profile_chrome(profile)
            login_url = base + "member.php?mod=logging&action=login"
            eng.launch(path, profile, port, login_url, headless=False)
            if not eng.wait_cdp(port, timeout=60):
                self._forum_log("  ✗ 浏览器启动失败（CDP 未就绪）")
                return False, "", ""
            if not eng.attach(port):
                self._forum_log("  ✗ 无法连接浏览器页面")
                return False, "", ""
            if auto:
                self._forum_log("  浏览器已打开：若站点还记着该浏览器会自动"
                                "完成登录；没登录则请在窗口里手动登录一次"
                                "（最长等 5 分钟）…")
            else:
                self._forum_log("  浏览器已打开，请在该窗口内输入账号密码完成登录"
                                "（程序自动检测，最长 5 分钟）…")
            end = time.time() + 300
            detected = False
            while time.time() < end and not self._forum_stop:
                try:
                    v = eng.cdp.ev(
                        "(function(){var h=document.documentElement.innerHTML;"
                        "return (h.indexOf('action=logout')>=0||"
                        "h.indexOf('action%3Dlogout')>=0)?1:0})()")
                    if v == 1:
                        detected = True
                        break
                except Exception:
                    pass
                time.sleep(2)
            if not detected:
                self._forum_log("  ✗ 未检测到登录成功（超时或已取消），窗口将关闭")
                self._forum_set_status(base, "○ 未登录", "#999")
                return False, "", ""
            self._forum_log("  ✓ 检测到登录成功，正在抓取 Cookie…")
            time.sleep(2)
            cookie = cdp_all_cookies(port, host_filter=root_domain)
            if not cookie:
                self._forum_log("  ✗ 未抓取到 Cookie（请重试一次）")
                return False, "", ""
            # ★ v1.1.24 连浏览器 UA 一起存：签到请求必须用同一 UA，
            #   否则 Cloudflare/雷池等 WAF 的防护 Cookie 校验不过 → 403
            ua = cdp_browser_ua(port)
            self._forum_set_status(base, "○ 校验中…", "#e08a00")
            signer = DiscuzForumSigner(base, cookie=cookie, log=self._forum_log,
                                       ua=ua)
            ok, info = signer.login()
            if not ok:
                self._forum_log("  ✗ Cookie 校验未通过：%s" % info)
                self._forum_set_status(base, "○ 未登录", "#999")
                return False, "", ""
            self._forum_set_cookie(base, cookie)
            now = datetime.now().strftime("%m-%d %H:%M")
            cfg = self._load_forum_cfg()
            cfg[base] = {"cookie": cookie, "ua": ua, "saved_at": now}
            try:
                with open(FORUM_CFG_FILE, "w", encoding="utf-8") as f:
                    json.dump(cfg, f, ensure_ascii=False, indent=2)
            except Exception as ex:
                self._forum_log("  保存失败：%s" % ex)
            self._forum_set_status(base, "✅ 已保存 %s" % now)
            self._forum_log("  ✅ %s：Cookie 已保存（%d 字符），下次可直接签到"
                            % (name, len(cookie)))
            return True, cookie, ua
        except Exception as ex:
            self._forum_log("  ✗ 异常：%s" % ex)
            return False, "", ""
        finally:
            try:
                if eng:
                    eng.close()
            except Exception:
                pass

    # ---- 签到
    def _forum_sign_all(self):
        # 列表项是 (名称, 网址)，签到内部要 (网址, 名称)，这里务必换序
        self._forum_sign_async([(base, name)
                                for name, base in self._forum_list])

    def _forum_sign_async(self, targets):
        if self._forum_busy:
            self._forum_log("已有任务在执行，请稍候…")
            return
        self._forum_stop = False
        # 归一化：无论调用方传 (网址, 名称) 还是 (名称, 网址) 都不出错。
        # cookie 表按网址存，所以拿"谁是网址"来判定（踩过坑：批量签到曾把
        # FORUMS 原样传入，导致用论坛名查 cookie → 全部报『未登录』）。
        # 关键：本函数在主线程被调用，此处就把 cookie 读成纯字符串快照，
        # 子线程只处理字符串 —— 在子线程里读写 Tk 变量是未定义行为。
        cfg = self._load_forum_cfg()
        plan = []
        for a, b in targets:
            if a in self.forum_vars:
                base, name = a, b
            elif b in self.forum_vars:
                base, name = b, a
            else:
                continue
            _cv = (self.forum_vars.get(base) or {}).get("cookie")
            ck = (_cv.get() if _cv is not None else "") or \
                ((cfg.get(base) or {}).get("cookie") or "").strip()
            # ★ v1.1.24 签到请求要用抓 Cookie 时浏览器的 UA（WAF 绑 UA 校验）
            _ua = ((cfg.get(base) or {}).get("ua") or "").strip()
            plan.append((base, name, ck, _ua))

        def worker():
            self._forum_busy = True
            recovered = set()      # ★ v1.1.29 每个论坛每次运行只自动恢复一次
            try:
                for base, name, cookie, ua in plan:
                    if self._forum_stop:
                        self._forum_log("已停止。")
                        break
                    self._forum_log("―――――― %s ――――――" % name)
                    if not cookie:
                        self._forum_log("  ✗ 未登录，请先点『登录』获取 Cookie")
                        continue
                    signer = DiscuzForumSigner(base, cookie=cookie,
                                               log=self._forum_log, ua=ua)
                    status, msg = signer.sign()
                    icon = {"ok": "✅", "already": "☑", "fail": "✗"}.get(
                        status, "•")
                    self._forum_log("  %s %s：%s" % (icon, name, msg))
                    # ★ v1.1.0 写进签到记录表（表格 + forum_records.json）
                    self._forum_save_record(name, status, msg)
                    if status == "fail" and "失效" in msg:
                        self._forum_set_status(base, "⚠ Cookie 已失效", "#d32f2f")
                    # ★ v1.1.29 持续 403 拦截（Cookie 与浏览器/WAF 失配）→
                    #   自动恢复：清该论坛 Cookie → 重新登录抓新 Cookie →
                    #   再签一次。每个论坛只恢复一次，失败不循环重试。
                    if (status == "fail" and "HTTP 403" in str(msg)
                            and base not in recovered and not self._forum_stop):
                        recovered.add(base)
                        self._forum_set_status(base, "⚠ 403拦截 自动恢复中…",
                                               "#e65100")
                        self._forum_ui(lambda b=base, n=name:
                                       self._forum_clear_cookie(b, n))
                        ok2, ck2, ua2 = self._forum_do_login(base, name,
                                                             auto=True)
                        if not ok2:
                            self._forum_log("  ✗ %s：自动重登未成功，"
                                            "请手动点『登录』后重试" % name)
                            self._forum_set_status(base, "✗ 自动重登失败",
                                                   "#d32f2f")
                            continue
                        self._forum_log("  ↻ 重登成功，重新签到 %s …" % name)
                        signer2 = DiscuzForumSigner(base, cookie=ck2,
                                                    log=self._forum_log,
                                                    ua=ua2)
                        st2, msg2 = signer2.sign()
                        icon2 = {"ok": "✅", "already": "☑",
                                 "fail": "✗"}.get(st2, "•")
                        self._forum_log("  %s %s：%s" % (icon2, name, msg2))
                        self._forum_save_record(name, st2, msg2)
                        self._forum_set_status(
                            base,
                            {"ok": "✅ 签到成功", "already": "☑ 已签到"}.get(
                                st2, "✗ 签到失败"),
                            "#2e9e4f" if st2 in ("ok", "already") else "#d32f2f")
            finally:
                self._forum_busy = False

        threading.Thread(target=worker, daemon=True).start()

    def _forum_stop_all(self):
        self._forum_stop = True
        self._forum_log("已请求停止（等待当前步骤结束）…")

    # ---- 签到记录（★ v1.1.0）
    def _forum_add_row(self, rec):
        """往签到记录表插一行（线程安全：只允许经 after() 在主线程调）。"""
        try:
            self.forum_tree.insert("", "end", values=(
                rec.get("time", ""), rec.get("forum", ""),
                rec.get("result", ""), rec.get("msg", "")),
                tags=(rec.get("tag", "fail"),))
            kids = self.forum_tree.get_children()
            if kids:
                self.forum_tree.see(kids[-1])
        except Exception:
            pass

    def _forum_save_record(self, forum_name, status, msg):
        """签到结果落记录：内存列表 + 表格 + forum_records.json（可在任意线程调）。"""
        rec = {"time": datetime.now().strftime("%m-%d %H:%M:%S"),
               "forum": forum_name,
               "result": {"ok": "成功", "already": "已签",
                          "fail": "失败"}.get(status, str(status)),
               "tag": status if status in ("ok", "already", "fail") else "fail",
               "msg": str(msg)}
        self.forum_records.append(rec)
        self._forum_ui(lambda: self._forum_add_row(rec))
        try:
            # ★ v1.1.29 每次落盘前先清 5 天前的旧记录（挂机多天也不涨）
            self.forum_records = _prune_records_by_time(self.forum_records)
            with open(FORUM_RECORDS_FILE, "w", encoding="utf-8") as f:
                json.dump(self.forum_records[-2000:], f, ensure_ascii=False,
                          indent=2)
        except Exception:
            pass

    def _forum_clear_cookie(self, base, name):
        self.forum_vars[base]["cookie"].set("")
        cfg = self._load_forum_cfg()
        cfg.pop(base, None)
        try:
            # ★ v1.1.31 加密落盘
            _safe_save_json(FORUM_CFG_FILE, cfg)
        except Exception:
            pass
        self._forum_set_status(base, "○ 未登录", "#999")
        self._forum_log("%s：已清除登录状态" % name)

    def _forum_clear_all(self):
        for name, base in self._forum_list:   # 列表项是 (名称, 网址)
            if base in self.forum_vars:
                self.forum_vars[base]["cookie"].set("")
                self._forum_set_status(base, "○ 未登录", "#999")
        try:
            with open(FORUM_CFG_FILE, "w", encoding="utf-8") as f:
                json.dump({}, f)
        except Exception:
            pass
        self._forum_log("已清空全部论坛登录状态")

    # ---------------- 小工具
    def log(self, msg):
        def _():
            t = datetime.now().strftime("%H:%M:%S")
            self._push_log("main", "[%s] %s\n" % (t, msg))
        if threading.current_thread() is threading.main_thread():
            _()
        else:
            self.root.after(0, _)

    def status(self, msg):
        def _():
            self.status_var.set(msg)
        self.root.after(0, _)

    def open_site(self):
        webbrowser.open(SITE_URL)
        self.log("已打开 %s" % SITE_URL)

    def _on_cfg_change(self):
        try:
            self.cfg["headless"] = self.headless_var.get()
            self.cfg["auto_wait_login"] = self.autowait_var.get()
            self.cfg["timer_enabled"] = self.timer_var.get()
            self.cfg["timer_time"] = self.timer_time_var.get().strip()
            try:
                self.cfg["retry"] = max(0, min(3, int(float(self.retry_var.get()))))
            except Exception:
                pass
            self.cfg["claim_one"] = self.claim_one_var.get()
            self._save_cfg()
        except Exception:
            pass

    # ---------------- 定时任务
    def _start_timer(self):
        def loop():
            while True:
                try:
                    time.sleep(20)
                    if not self.timer_var.get() or self.running:
                        continue
                    now = datetime.now()
                    want = self.timer_time_var.get().strip()
                    m = re.match(r"^([01]?\d|2[0-3]):([0-5]\d)$", want)
                    if not m:
                        continue
                    target = now.replace(hour=int(m.group(1)) % 24,
                                         minute=int(m.group(2)) % 60,
                                         second=0, microsecond=0)
                    # ★ 只在到点那一刻（90 秒窗口内）触发：
                    #   错过不补执行（比如设了 03:00，06:20 才开软件不会立刻领取），
                    #   当天改时间后新时间点到点仍会触发（精确时间点去重）。
                    if (now >= target
                            and (now - target).total_seconds() <= 90
                            and self._last_run.get("__all__") != _last_run_key(target)):
                        self._last_run["__all__"] = _last_run_key(target)
                        self.log("⏰ 定时触发（统一 %s），开始自动领取（顺序执行，不并行）"
                                 % target.strftime("%H:%M"))
                        self.root.after(0, self.do_run)
                except Exception:
                    pass
        threading.Thread(target=loop, daemon=True).start()

    # ---------------- 浏览器
    def _detect_async(self):
        def work():
            browsers = detect_browsers(log=self.log)
            self.root.after(0, self._fill_browsers, browsers)
        threading.Thread(target=work, daemon=True).start()
        self.log("正在检测本机浏览器…")

    def _fill_browsers(self, browsers):
        self.browsers = browsers
        labels = ["%s  (%s)" % (n, p) for n, p, k in browsers]
        self.browser_cb["values"] = labels
        if labels:
            saved = self.cfg.get("browser", "")
            # ★ 内置浏览器存在时默认用它，除非用户明确手动选过别的
            emb = embedded_browser()
            if emb and not self.cfg.get("browser_manual"):
                saved = emb
            idx = 0
            for i, (n, p, k) in enumerate(browsers):
                if p == saved:
                    idx = i
                    break
            self.browser_cb.current(idx)
            self.cfg["browser"] = browsers[idx][1]
            self._save_cfg()
            self.log("检测到 %d 款浏览器：%s" % (
                len(browsers), "、".join("%s(%s)" % (n, get_browser_version(p))
                                        for n, p, k in browsers[:4])))
        else:
            self.log("未检测到浏览器，请点『手动选择』指定。")
        # ★ v1.1.25 启动不再自动核对登录态（用户要求：每次打开都开一堆
        #   无头浏览器太重）——只在两种时机查：每 3 小时到点自动查、
        #   用户点「检测」手动查。
        # ★ v1.1.28 自动查受「定时检测在线」开关控制（cfg.auto_check），
        #   关掉后只点「检测」按钮才查。
        self._auto_check_arm()

    def _auto_check_enabled(self):
        """「定时检测在线」开关（★ v1.1.28）：默认开，老配置没有该键也照常。"""
        try:
            return bool(self.cfg.get("auto_check", True))
        except Exception:
            return True

    def _auto_check_arm(self):
        """开关打开且尚未排程 → 安排下一个 3 小时检查点。"""
        if not self._auto_check_enabled():
            return
        if getattr(self, "_auto_check_armed", False):
            return
        self._auto_check_armed = True
        try:
            self._auto_check_after = self.root.after(
                3 * 3600 * 1000, self._auto_check_tick)
        except Exception:
            self._auto_check_after = None

    def _auto_check_disarm(self):
        """开关关闭 → 撤掉已排程的检查点；重新勾选时再排。"""
        aid = getattr(self, "_auto_check_after", None)
        if aid:
            try:
                self.root.after_cancel(aid)
            except Exception:
                pass
        self._auto_check_after = None
        self._auto_check_armed = False

    def _on_auto_check_change(self):
        """「定时检测在线」勾选框（★ v1.1.28）：开=每3小时自动核；关=只手动。"""
        self.cfg["auto_check"] = bool(self.auto_check_var.get())
        self._save_cfg()
        if self.cfg["auto_check"]:
            self._auto_check_arm()
            self.log("已开启定时检测在线：每 3 小时自动核对一次登录态。")
        else:
            self._auto_check_disarm()
            self.log("已关闭定时检测在线：只在你点「检测」按钮时才核对。")

    def _auto_check_tick(self):
        """★ v1.1.23 定时器：每 3 小时自动核对一遍账号登录态。
        领取任务运行中 / 核对进行中就跳过这一轮（下轮再查），绝不抢 profile。
        ★ v1.1.28 受「定时检测在线」开关控制：关掉后不查也不再续排。"""
        self._auto_check_after = None
        try:
            if (self._auto_check_enabled() and self.accounts
                    and not self.running
                    and not getattr(self, "_checking", False)):
                self.log("⏰ 每 3 小时自动检查登录态…")
                self.check_accounts_async()
        except Exception:
            pass
        # 开关还开着才排下一轮；关了就停，重新勾选时由 _auto_check_arm 再排
        if self._auto_check_enabled():
            try:
                self._auto_check_after = self.root.after(
                    3 * 3600 * 1000, self._auto_check_tick)
            except Exception:
                self._auto_check_after = None
        else:
            self._auto_check_armed = False

    def _on_browser_selected(self, _evt=None):
        """用户手动改了下拉框选择 → 记住这个选择（不再自动跳回内置浏览器）"""
        b = self._cur_browser()
        if b:
            self.cfg["browser"] = b[1]
            self.cfg["browser_manual"] = True
            self._save_cfg()

    def pick_browser(self):
        p = filedialog.askopenfilename(title="选择浏览器程序",
                                       filetypes=[("可执行程序", "*.exe"), ("所有文件", "*.*")])
        if p:
            self.browsers = getattr(self, "browsers", []) + [("自定义", p, "chromium")]
            self.browser_cb["values"] = ["%s  (%s)" % (n, pp) for n, pp, k in self.browsers]
            self.browser_cb.current(len(self.browsers) - 1)
            self.cfg["browser"] = p
            self.cfg["browser_manual"] = True
            self._save_cfg()

    def _cur_browser(self):
        i = self.browser_cb.current()
        if i is None or i < 0 or not getattr(self, "browsers", []):
            return None
        return self.browsers[i]

    # ---------------- 账号
    def _acc_ph_hide(self, _evt=None):
        """输入框获得焦点/开始打字 → 收起占位提示。"""
        try:
            self.acc_ph.place_forget()
        except Exception:
            pass

    def _acc_ph_restore(self, _evt=None):
        """输入框失焦且内容为空 → 把占位提示放回来。"""
        try:
            if self.root.focus_get() is self.acc_entry:
                return
            if not self.acc_var.get().strip():
                self.acc_ph.place(x=7, y=5)
                self.acc_ph.lift()
        except Exception:
            pass

    def _refresh_accounts(self):
        """重建账号列表（Treeview）。

        iid 直接用账号下标字符串，选中时 `int(iid)` 即 self.accounts 的下标，
        这样增删后不需要额外的 id→行 映射。

        ★ v1.1.11 状态三态：已登录 / 掉线 / 未登录 —— 掉线单独用警示色标出来，
        用户一眼就知道哪个号要重新扫码。
        """
        tree = getattr(self, "acc_tree", None)
        if tree is None:
            return
        tree.delete(*tree.get_children())
        n_ok = n_off = n_no = 0
        for i, a in enumerate(self.accounts):
            st = acc_status(a)
            text, tag, _color = ACC_STATUS[st]
            if st == "ok":
                n_ok += 1
            elif st == "off":
                n_off += 1
            else:
                n_no += 1
            tree.insert("", "end", iid=str(i),
                        values=(a["id"], text), tags=(tag,))
        n_all = len(self.accounts)
        lb = getattr(self, "acc_stat_lb", None)
        if lb is not None:
            lb.config(text="共 %d 个" % n_all)
        ok_lb = getattr(self, "acc_stat_ok", None)
        if ok_lb is not None:
            txt, fg = self._acc_stat_text()
            ts = getattr(self, "_last_check_ts", 0.0)
            if txt and ts:   # ★ v1.1.23 让用户知道检查结果是什么时候查的
                txt += " · 检查 %s" % time.strftime(
                    "%H:%M", time.localtime(ts))
            ok_lb.config(text=txt, fg=fg)
        self._on_acc_select()

    def _acc_stat_text(self):
        """★ v1.1.23 账号统计条文案（已登录/掉线计数），两处共用。"""
        n_ok = n_off = n_no = 0
        for a in self.accounts:
            st = acc_status(a)
            if st == "ok":
                n_ok += 1
            elif st == "off":
                n_off += 1
            else:
                n_no += 1
        if not self.accounts:
            return "", "#8b8781"
        if n_off:
            # 掉线是要用户动手处理的，优先把它顶到统计条上
            return "已登录 %d · 掉线 %d" % (n_ok, n_off), "#c9741a"
        return ("已登录 %d / 未登录 %d" % (n_ok, n_no),
                "#1a8f4a" if n_ok else "#8b8781")

    def _update_check_time_label(self):
        """★ v1.1.23 核对完成后只刷统计条文案，不重建账号列表（保住选中态）。"""
        ok_lb = getattr(self, "acc_stat_ok", None)
        if ok_lb is None:
            return
        txt, fg = self._acc_stat_text()
        ts = getattr(self, "_last_check_ts", 0.0)
        if txt and ts:
            txt += " · 检查 %s" % time.strftime("%H:%M", time.localtime(ts))
        try:
            ok_lb.config(text=txt, fg=fg)
        except Exception:
            pass

    def _selected_account(self):
        tree = getattr(self, "acc_tree", None)
        if tree is None:
            return None
        sel = tree.selection()
        if not sel:
            return None
        try:
            return self.accounts[int(sel[0])]
        except Exception:
            return None

    def _on_acc_select(self, event=None):
        """账号选中回调：同步『只领选中账号』按钮 + 底部详情行。"""
        self._update_run_one_btn()
        lb = getattr(self, "acc_detail", None)
        if lb is None:
            return
        acc = self._selected_account()
        if not acc:
            lb.config(text=_fit_vis("点选账号查看站内身份", 30), fg="#9b978f")
            return
        # ★ v1.1.11 掉线的号直接给出下一步动作，别让用户自己猜
        if acc_status(acc) == "off":
            lb.config(text=_fit_vis("%s  ⚠ 掉线，请重新扫码登录" % acc["id"], 30),
                      fg="#c9741a")
            return
        bits = []
        uid = _fmt_uid(acc.get("uid"))
        if uid:
            bits.append("站内:%s" % uid)
        if acc.get("game"):
            bits.append("游戏:%s" % acc["game"])
        if bits:
            txt = "%s  %s" % (acc["id"], "  ".join(bits))
        else:
            txt = "%s  （未记录身份）" % acc["id"]
        # 身份抓取失败 → 用警示色标出来（原样式里这条超长错误串把列表行挤爆了）
        bad = str(acc.get("uid") or "").startswith("__ERR__")
        lb.config(text=_fit_vis(txt, 30), fg="#b3541e" if bad else "#5c5954")

    def _update_run_one_btn(self):
        btn = getattr(self, "btn_run_one", None)
        if btn is None:
            return
        acc = self._selected_account()
        try:
            if acc:
                btn.config(text="只领选中账号 [%s]" % acc["id"])
            else:
                btn.config(text="只领选中账号（先在右侧选中）")
        except Exception:
            pass

    def do_run_selected(self):
        """★ v1.1.2 只给左侧列表里选中的这一个号抢，其余账号不启动浏览器。"""
        if self.running:
            messagebox.showinfo("提示", "任务正在运行，请先『停止』")
            return
        acc = self._selected_account()
        if not acc:
            messagebox.showinfo(
                "提示", "请先在右侧账号列表里点选要点领取的账号，\n再点『只领选中账号』。")
            return
        self.do_run(targets=[acc])

    def add_account(self):
        v = self.acc_var.get().strip()
        if not v:
            return
        if any(a["id"] == v for a in self.accounts):
            messagebox.showinfo("提示", "账号已存在")
            return
        acc = {"id": v, "name": "", "logined": False, "status": "no",
               "game": "", "uid": ""}
        self.accounts.append(acc)
        self.acc_var.set("")
        self._refresh_accounts()
        self._save_accounts()
        self.log("添加账号: %s" % v)
        self._acc_ph_restore()        # 清空后把占位提示放回来
        # ★ v1.1.11 添加时就核一遍：这个号以前登录过没？是不是已经掉线了？
        #   （本地没有登录数据 → 直接就是「未登录」，不用白开一次浏览器）
        if local_login_hint(v) == "no":
            self.log("[%s] 本地没有该账号的登录数据，需要点『扫码登录』" % v)
        else:
            self.log("[%s] 本地有登录数据，正在核对是否掉线…" % v)
            self.check_accounts_async(only=acc)

    def del_account(self):
        tree = getattr(self, "acc_tree", None)
        sel = tree.selection() if tree is not None else ()
        if not sel:
            messagebox.showinfo("提示", "请先在账号列表里选中要删除的账号。")
            return
        try:
            idx = int(sel[0])
            a = self.accounts[idx]
        except Exception:
            return
        if not messagebox.askyesno("确认", "删除账号 %s ？\n（浏览器 profile 目录会保留）" % a["id"]):
            return
        self.accounts.pop(idx)
        self._refresh_accounts()
        self._save_accounts()
        self.log("删除账号: %s" % a["id"])

    def import_accounts(self):
        p = filedialog.askopenfilename(title="选择 accounts.json",
                                       filetypes=[("JSON", "*.json"), ("所有文件", "*.*")])
        if not p:
            return
        try:
            # ★ v1.1.31 兼容加密导出/旧明文两种文件
            d = _safe_load_json(p)[0]
            n = 0
            for a in d.get("accounts", []):
                aid = str(a.get("id", "")).strip() if isinstance(a, dict) else str(a).strip()
                if aid and not any(x["id"] == aid for x in self.accounts):
                    st = _status_from_record(a) if isinstance(a, dict) else "no"
                    self.accounts.append({
                        "id": aid,
                        "name": str(a.get("name", "")) if isinstance(a, dict) else "",
                        "logined": (st == "ok"),
                        "status": st,
                        "game": str(a.get("game", "") or "").strip() if isinstance(a, dict) else "",
                        "uid": str(a.get("uid", "") or "").strip() if isinstance(a, dict) else "",
                        "browser": str(a.get("browser", "") or "").strip() if isinstance(a, dict) else "",
                    })
                    n += 1
            self._refresh_accounts()
            self._save_accounts()
            self.log("导入 %d 个账号" % n)
            messagebox.showinfo("完成", "导入 %d 个账号" % n)
            # ★ v1.1.11 导入进来的「已登录」是文件里写的，得实地核一遍才知道掉没掉线
            if n:
                self.check_accounts_async()
        except Exception as e:
            messagebox.showerror("错误", str(e))

    # ---------------- ★ v1.1.11 掉线检测
    def _set_acc_status(self, acc, s, why=""):
        """更新账号登录态 + 落盘 + 写日志（后台线程安全）。

        只在状态真的变了才刷新列表 —— 每次核对都重建会让用户当前选中的
        账号跳掉，而选中态对这个工具很关键。
        """
        old = acc_status(acc)
        acc_set_status(acc, s)
        self._save_accounts()
        self.log("[%s] 登录态：%s%s"
                 % (acc["id"], ACC_STATUS[s][0], ("（%s）" % why) if why else ""))
        if old != s:
            self.root.after(0, self._refresh_accounts)

    def _check_engine(self):
        """检测专用引擎：不弹任何框（后台线程里跑），一律无头启动不打扰用户。"""
        b = self._cur_browser()
        if not b or b[2] != "chromium":
            return None
        e = Engine(log=self.log, ask=lambda m: True)
        e.browser = b[1]
        e.headless = True
        return e

    def check_accounts_now(self):
        """『检测』按钮：手动核一遍，掉线的号一眼就看出来了。"""
        if not self.accounts:
            messagebox.showinfo("提示", "还没有账号，先在下面输入账号 ID 点『添加』。")
            return
        self.check_accounts_async()

    def check_accounts_async(self, only=None):
        """核对账号是否已经掉线（后台跑，不阻塞界面）。

        判据分两级，先便宜的、再准的：
          1) 只看磁盘：没登录记录 → 未登录；cookie 全过期 → 直接判掉线
          2) 开一次无头浏览器问站点「还认我吗」→ 认=已登录，不认=掉线
        只有本地确实存着凭证的号才会走到第 2 步，不会平白多开一堆浏览器。
        """
        if getattr(self, "_checking", False):
            self.log("登录态核对正在进行中，稍等一下…")
            return
        if self.running:
            self.log("任务运行中，先不核对登录态（避免抢同一个 profile）")
            return
        targets = [only] if only is not None else list(self.accounts)
        targets = [a for a in targets if a.get("id")]
        if not targets:
            return
        self._checking = True
        threading.Thread(target=self._check_worker, args=(targets,),
                         daemon=True).start()

    def _check_worker(self, targets):
        e = None
        try:
            self.status("正在核对 %d 个账号的登录态…" % len(targets))
            self.log("开始核对 %d 个账号的登录态（只看掉没掉线）…" % len(targets))
            need_browser = []
            for acc in targets:
                hint = local_login_hint(acc["id"])
                if hint == "off":
                    self._set_acc_status(acc, "off", "本地 cookie 已全部过期")
                elif hint == "ok":
                    need_browser.append(acc)
                elif acc_status(acc) == "ok":
                    # 以前显示「已登录」，但本地连凭证都没有了 → 就是掉线
                    self._set_acc_status(acc, "off", "本地已无该账号的登录数据")
            for acc in need_browser:
                if self.running:
                    self.log("任务已开始运行，剩下账号的核对留到下次")
                    break
                if e is None:
                    e = self._check_engine()
                    if e is None:
                        self.log("没检测到可用浏览器，本次只能给出本地判断的结果")
                        break
                self.status("正在核对 %s …" % acc["id"])
                st = self._verify_online(e, acc)
                if st == "ok":
                    self._set_acc_status(acc, "ok", "浏览器核对通过")
                elif st == "off":
                    self._set_acc_status(acc, "off", "站点已不认这份登录态")
                else:
                    self.log("[%s] 没核对出结果（浏览器没起来 / 页面没加载出来），"
                             "保持原状态" % acc["id"])
            self._save_accounts()
            n_off = sum(1 for a in targets if acc_status(a) == "off")
            self.log("登录态核对结束：%d 个账号，掉线 %d 个%s"
                     % (len(targets), n_off,
                        "（掉线的号请重新扫码登录）" if n_off else ""))
        except Exception as ex:
            self.log("登录态核对异常: %s" % ex)
        finally:
            if e is not None:
                try:
                    e.close()
                except Exception:
                    pass
            self._checking = False
            self._last_check_ts = time.time()   # ★ v1.1.23 统计条显示「检查 HH:MM」
            try:
                self.root.after(0, self._update_check_time_label)
            except Exception:
                pass
            self.status("就绪")

    def _verify_online(self, e, acc):
        """开一次无头浏览器，用和领取流程同一套判据问站点「还认这个账号吗」。

        返回 "ok" / "off" / "unknown"：  浏览器没起来、页面没加载出来
        都返回 unknown —— 判不了就老老实实保持原状态，绝不乱标掉线。
        """
        profile = account_profile(acc["id"])
        # 注意：profile 目录可能已经被清掉、只剩外部 cookie 备份 —— 这种情况
        # 不要提前判死，交给浏览器起来之后用备份恢复，才能拿到真实结论。
        self._migrate_old_profile(acc["id"], profile)   # 旧数据先搬过来再验
        port = free_port()
        try:
            e.kill_profile_chrome(profile)   # 清掉占着这个 profile 的残留 chrome
        except Exception:
            pass                             # 只是清场，失败不该拖垮整次核对
        try:
            e.launch(e.browser, profile, port, SITE_URL, headless=True)
        except Exception as ex:
            self.log("[%s] 核对用浏览器启动失败: %s" % (acc["id"], ex))
            return "unknown"
        try:
            if not e.wait_cdp(port, timeout=45):
                return "unknown"
            if not e.attach(port):
                return "unknown"
            e.open_site(SITE_URL)
            if not self._page_alive(e):
                return "unknown"
            ok, _phone, answered = self._site_logged_in(e)
            if not ok and e.restore_cookies():
                self.log("[%s] 试一次 cookie 备份恢复…" % acc["id"])
                e.open_site(SITE_URL)
                if self._page_alive(e):
                    ok, _phone, answered = self._site_logged_in(e)
            if ok:
                e.backup_cookies()      # 顺手续一次备份，延长备份寿命
                return "ok"
            # ★ 关键：站点"明确回答不认识"才算掉线。
            #   浏览器在核对途中被抢走/被关掉（比如用户这时点了开始领取，
            #   领取流程会先 kill 掉占着同一个 profile 的 chrome），
            #   CDP 一问就断 —— 这时候什么都没问出来，绝不能当掉线处理。
            if not answered:
                self.log("[%s] 没问到站点（浏览器中途被关闭/页面失联），结果作废"
                         % acc["id"])
                return "unknown"
            return "off"
        except Exception as ex:
            self.log("[%s] 核对异常: %s" % (acc["id"], ex))
            return "unknown"
        finally:
            e.close()

    def _page_alive(self, e, timeout=30):
        """页面到底有没有打开？判掉线之前必须先排除「页面没加载出来」。

        断网 / Chrome 报错页里 getUserInfoAsync 和 header 都不存在，
        这时候直接把 is_logged_in() 的 False 当成掉线，会冤枉用户。
        """
        end = time.time() + timeout
        while time.time() < end:
            r = e.cdp.ev(JS_PAGE_READY, timeout=10)
            if isinstance(r, dict) and str(r.get("ready")) == "complete":
                if (r.get("api") or r.get("header") or (r.get("btns") or 0) > 0):
                    return True
            time.sleep(1.5)
        return False

    @staticmethod
    def _site_logged_in(e, tries=2, gap=1.5):
        """问站点两次登录态，返回 (是否已登录, 手机号, 站点有没有真的回答)。

        第三个返回值是判掉线的安全阀：只有站点**明确回答**了"不认识你"，
        才允许标掉线；CDP 断线 / 页面失联时 ev() 只回 '__ERR__…' 字符串、
        两个 JS 都拿不到字典，answered=False，上层就会放弃本次结论。
        """
        answered = False
        for i in range(max(1, tries)):
            try:
                r = e.cdp.ev(JS_LOGIN, timeout=20)
            except Exception:
                r = None
            if isinstance(r, dict):
                answered = True
                if r.get("login"):
                    return True, (r.get("phone") or ""), True
            try:
                h = e.cdp.ev(JS_HEADER_LOGIN, timeout=20)
            except Exception:
                h = None
            if isinstance(h, dict):
                answered = True
                if h.get("logout"):
                    return True, str(h.get("text", "")).replace("退出", "").strip(), True
            if i + 1 < tries:
                time.sleep(gap)
        return False, "", answered

    # ---------------- 进度条（★ v1.1.11 按需显示）
    def _show_progress(self, on):
        """进度条只在「开始领取」跑起来时露出来，跑完就收回去。

        空闲时它是条空灰杠，白占 150px 面板宽度；收起后「进度与状态」只剩
        一句状态文字，界面干净得多。
        """
        on = bool(on)
        if on == getattr(self, "_progress_on", False):
            return
        self._progress_on = on

        def _():
            try:
                if on:
                    self.pb.pack(side="left", fill="x", expand=True,
                                 padx=(4, 6), pady=6)
                    self.pb.config(value=0)
                else:
                    self.pb.pack_forget()
            except Exception:
                pass
        self.root.after(0, _)

    # ---------------- 运行
    def _set_busy(self, busy):
        def _():
            self.btn_run.config(state="disabled" if busy else "normal")
            self.btn_login.config(state="disabled" if busy else "normal")
            b1 = getattr(self, "btn_run_one", None)
            if b1 is not None:
                b1.config(state="disabled" if busy else "normal")
            self.btn_stop.config(state="normal" if busy else "disabled",
                                 bg="#e53935" if busy else "#999")
        self.root.after(0, _)

    def _apply_filter(self, gifts):
        """筛选/排序已全部移除，原样返回候选列表"""
        return list(gifts)

    def claimed_ids(self, acc_id):
        """读取 records.json,返回该账号已成功领取的礼包 ID 集合"""
        s = set()
        for r in self.records:
            if (r.get("account") == acc_id and r.get("result") == "成功"
                    and r.get("gift")):
                s.add(r["gift"])
        return s

    def _plan(self, acc, raw_gifts):
        """筛选 -> 排除已领 -> 返回 (gifts, claimed, cand)，
        运行流程唯一的候选计算入口"""
        gifts = self._apply_filter(raw_gifts)
        claimed = self.claimed_ids(acc["id"])
        cand = [g for g in gifts if g["id"] not in claimed]
        return gifts, claimed, cand

    def _start_engine(self):
        try:
            self._on_cfg_change()      # 保存界面上的最新设置
        except Exception:
            pass
        b = self._cur_browser()
        if not b:
            messagebox.showinfo("提示", "请先检测/选择浏览器")
            return None
        if b[2] != "chromium":
            messagebox.showwarning("提示", "仅支持 Chromium 内核浏览器（Chrome/Edge/360/2345 等）")
            return None
        try:
            interval = float(self.interval_var.get())
            limit = int(self.limit_var.get())
        except Exception:
            messagebox.showinfo("提示", "间隔/上限请填数字")
            return None
        try:
            retry = max(0, min(3, int(float(self.retry_var.get()))))
        except Exception:
            retry = 3
        self.cfg.update({"browser": b[1], "interval": interval, "limit": limit,
                         "retry": retry, "claim_one": self.claim_one_var.get()})
        self._save_cfg()

        e = Engine(log=self.log, ask=lambda m: messagebox.askyesno("确认", m))
        e.browser = b[1]
        e.interval = interval
        e.limit = limit
        e.retry = retry
        e.claim_one = self.claim_one_var.get()
        e.headless = self.headless_var.get()
        e.auto_wait_login = self.autowait_var.get()
        return e

    def _migrate_old_profile(self, acc_id, new_profile):
        migrate_old_profile(acc_id, new_profile, log=self.log)

    def _open_for_account(self, e, acc, url=SITE_URL):
        """用内置浏览器 + 账号独立 profile 打开浏览器并连接"""
        browser = e.browser
        # ★ v10 隔离方法①：纯 ASCII 干净路径（LOCALAPPDATA 下）
        profile = os.path.join(DATA_DIR, "browser_data_" + safe_name(acc["id"]))
        self._migrate_old_profile(acc["id"], profile)   # 旧数据搬迁，免重扫
        port = free_port()
        # ★ v10 隔离方法②：启动前清掉占着本账号 profile 的残留 chrome
        e.kill_profile_chrome(profile)
        self.log("[%s] 浏览器=%s  隔离目录=%s  调试端口=%d"
                 % (acc["id"], os.path.basename(browser),
                    os.path.basename(profile), port))
        # 旧系统提醒（Chrome 110+ 不支持 Win7/8/8.1/2012/2012R2）
        if not getattr(self, "_os_warned", False):
            try:
                if sys.getwindowsversion().major < 10:
                    self.log("!! 检测到 Windows 7/8/2012R2 或更旧系统：内置 Chrome 153"
                             " 官方不支持，可能无法启动")
                    self.log("!! 若启动失败：请安装系统浏览器（Chrome 109 是最后支持"
                             " 2012R2 的版本），并在下拉框选择它")
                    self._os_warned = True
            except Exception:
                pass
        # 启动（失败自动回退到下一个可用浏览器）
        candidates = [browser]
        try:
            for _n, _p, _k in detect_browsers():
                if _p.lower() != str(browser).lower() and _p not in candidates:
                    candidates.append(_p)
        except Exception:
            pass
        launched = False
        last_err = None
        for cand in candidates:
            try:
                e.launch(cand, profile, port, url, headless=e.headless)
                if cand != browser:
                    self.log("[%s] 已自动回退使用浏览器: %s" % (acc["id"], cand))
                launched = True
                break
            except OSError as ex:
                last_err = ex
                self.log("[%s] 启动 %s 失败: %s"
                         % (acc["id"], os.path.basename(cand), ex))
                port = free_port()      # 换端口再试下一个
        if not launched:
            self.log("[%s] 所有浏览器均无法启动（最后错误: %s）" % (acc["id"], last_err))
            self.log("!! 常见原因：① 服务器系统过旧（2012R2）不支持 Chrome 153；"
                     "② 浏览器文件被杀毒软件拦截/损坏")
            self.log("!! 解决：安装 Chrome 109（最后支持 2012R2 的版本）后，"
                     "在浏览器下拉框选择它")
            return False
        if not e.wait_cdp(port, timeout=60):
            self.log("浏览器启动超时")
            return False
        if not e.attach(port):
            self.log("无法连接浏览器")
            return False
        e.open_site(url)
        n = e.wait_ready()
        if not n:
            self.log("页面加载异常，未找到礼包按钮")
            return False
        # 若 cookie 因浏览器被强杀 / profile 被清 而丢失，尝试从备份恢复并重载
        ok, _ = e.is_logged_in()
        if not ok:
            why = e.diagnose_login_loss()
            self.log("[%s] 磁盘登录态丢失（%s），正在从 cookie 备份恢复…"
                     % (acc["id"], why))
            if e.restore_cookies():
                self.log("[%s]   备份来源：%s" % (acc["id"],
                                                  e.last_restore_info or "未知"))
                e.open_site(url)
                e.wait_ready()
                if e.is_logged_in()[0]:
                    self.log("[%s] cookie 备份恢复成功，无需重新扫码" % acc["id"])
                    e.backup_cookies()       # 恢复成功后立刻回写一份新备份
                else:
                    self.log("[%s] 备份已注入但仍未登录：站点登录凭证已失效，"
                             "这次需要重新扫码（扫码后会自动刷新备份）" % acc["id"])
            else:
                self.log("[%s] 没找到任何可用的 cookie 备份，"
                         "需要重新扫码（扫码后会自动建立备份）" % acc["id"])
        self.log("[%s] 页面就绪，发现 %d 个礼包按钮" % (acc["id"], n))
        return True

    def _capture_uid(self, acc, e):
        """读取站内身份 userId，并检测是否与其他账号登录了同一个身份"""
        uid = ""
        try:
            uid = str(e.site_uid() or "")
        except Exception:
            pass
        if not uid:
            self.log("[%s] 未能读取站内身份(userId)" % acc["id"])
            return ""
        acc["uid"] = uid
        for other in self.accounts:
            if other is acc or other.get("uid") != uid:
                continue
            self.log("!! 警告：账号 %s 和 %s 登录的是同一个站内身份(userId=%s)"
                     % (acc["id"], other["id"], uid))
            self.log("!! 两个账号会共用同一份领取资格，第二个账号会提示“已领取/已领过”。")
            self.log("!! 要真正多开：重新登录时先在手机微信里切换到另一个微信号，再扫码。")
            try:
                self.root.after(0, lambda: messagebox.showwarning(
                    "发现重复身份",
                    "账号 %s 和 %s 登录的是同一个站内身份(userId=%s)。\n\n"
                    "这说明两次扫码用的是同一个微信。\n"
                    "两个账号会共用同一份领取资格，无法双倍领取。\n\n"
                    "解决办法：选中其中一个账号点【扫码登录】，\n"
                    "在浏览器里先点网页右上角【退出】，再切换到另一个微信扫码。"
                    % (acc["id"], other["id"], uid)))
            except Exception:
                pass
            break
        return uid

    def do_login(self):
        acc = self._selected_account()
        if not acc:
            messagebox.showinfo("提示", "请先选中一个账号")
            return
        if self.running:
            return
        self.running = True
        self._set_busy(True)
        threading.Thread(target=self._login_worker, args=(acc,), daemon=True).start()

    def _login_worker(self, acc):
        # ★ v4.8.0：与老工具【抢礼包工具1.0】完全一致的登录流程——
        #   打开浏览器 → 用户自己在网页里登录（扫码）→ 点【是】保存。
        #   不自动检测登录态、不自动等待扫码、不多弹任何框。
        #   浏览器里若显示的是别的账号：用户自己点网页右上角【退出】再扫码。
        e = self._start_engine()
        if not e:
            self.running = False
            self._set_busy(False)
            return
        self.engine = e
        try:
            self.status("正在为账号 %s 打开浏览器…" % acc["id"])
            if not self._open_for_account(e, acc):
                return
            self.log("[%s] 请在弹出的浏览器窗口里登录本账号（微信扫码）。" % acc["id"])
            self.log("   若浏览器里显示的是别的账号：先点网页右上角【退出】，"
                     "再扫码登录本账号。")
            ok = True
            try:
                ok = bool(messagebox.askyesno(
                    "扫码登录",
                    "账号 %s：请在弹出的浏览器窗口里用微信扫码登录。\n\n"
                    "如果浏览器里显示的是别的账号：\n"
                    "  先点网页右上角【退出】，再扫码登录本账号。\n\n"
                    "登录完成后点【是】保存；点【否】放弃本次登录。" % acc["id"]))
            except Exception:
                ok = True
            if ok:
                # 用户确认后做一次只读核对（不拦截流程）
                okv, phone = e.is_logged_in()
                if okv:
                    self.log("[%s] 已登录 %s（站内身份 userId=%s）"
                             % (acc["id"], phone or "",
                                e.site_uid() or "未知"))
                else:
                    self.log("[%s] 未检测到登录态（仍按你的确认记录为已登录；"
                             "若扫错了可重新点【扫码登录】再扫一次）" % acc["id"])
                acc_set_status(acc, "ok")
                e.backup_cookies()   # 立即备份 cookie，防止浏览器关闭时丢失
            else:
                self.log("[%s] 已放弃本次登录" % acc["id"])
            uid = self._capture_uid(acc, e)
            self._save_accounts()
            self.root.after(0, self._refresh_accounts)
            self.log("[%s] 登录流程结束：%s" % (acc["id"], "成功" if ok else "未完成"))
        except Exception as ex:
            self.log("异常: %s" % ex)
        finally:
            e.close()
            self.running = False
            self._set_busy(False)
            self.status("就绪")

    def do_run(self, targets=None):
        if self.running:
            return
        if not (targets or self.accounts):
            messagebox.showinfo("提示", "请先添加账号")
            return
        self.running = True
        self._set_busy(True)
        self._show_progress(True)      # ★ 有进度可看了，把进度条放出来
        threading.Thread(target=self._run_worker, args=(targets,), daemon=True).start()

    def do_stop(self):
        if self.engine:
            self.engine.stop_flag = True
        self.log("正在停止…")

    def _run_worker(self, targets=None):
        e = self._start_engine()
        if not e:
            self.running = False
            self._set_busy(False)
            self._show_progress(False)
            return
        self.engine = e
        total_ok = 0
        try:
            targets = list(targets) if targets else list(self.accounts)
            if len(targets) == 1:
                self.log(">> 单账号模式：本次只处理 %s，其他账号不启动浏览器"
                         % targets[0]["id"])
            else:
                self.log("共 %d 个账号，顺序执行：抢完一个再抢下一个，绝不并行"
                         % len(targets))
            for ai, acc in enumerate(targets):
                if e.stop_flag:
                    break
                if ai > 0:
                    self.log("上一个账号已处理完毕，切换到下一个")
                self.log("======== 账号 %s (%d/%d) ========" % (acc["id"], ai + 1, len(targets)))
                self.status("处理账号 %s …" % acc["id"])
                try:
                    if not self._open_for_account(e, acc):
                        continue
                    ok, phone = e.is_logged_in()
                    if not ok:
                        if e.auto_wait_login and not e.headless:
                            self.status("账号 %s 未登录，等待扫码…" % acc["id"])
                            ok = e.wait_login(self.cfg.get("wait_login", 240))
                            # ★ v1.1.11 等扫码也没等到 → 这个号就是掉线了
                            acc_set_status(acc, "ok" if ok else "off")
                            self._save_accounts()
                            self.root.after(0, self._refresh_accounts)
                        if not ok:
                            self.log("[%s] 掉线了（登录态已失效），跳过。"
                                     "请先点『① 扫码登录』重新扫码" % acc["id"])
                            continue
                    acc_set_status(acc, "ok")
                    e.backup_cookies()          # 刷新 cookie 备份
                    self._capture_uid(acc, e)
                    self._save_accounts()

                    raw = e.list_gifts(True)
                    gifts, claimed, cand = self._plan(acc, raw)
                    self.log("[%s] 可领取 %d 个" % (acc["id"], len(gifts)))
                    if not gifts:
                        self.log("[%s] 没有可领取的礼包，跳过" % acc["id"])
                        continue
                    self.log("[%s] 排除已领过 %d 个，剩余候选 %d 个"
                             % (acc["id"], len(claimed), len(cand)))
                    if not cand:
                        self.log("[%s] 已全部领过，跳过" % acc["id"])
                        continue
                    # 新规则：只从多个礼包里选 1 个领取，不多领
                    if e.claim_one:
                        todo = cand[:1]
                        pick = todo[0]
                        self.log("[%s] 规则：只领一个（不多领）→ 选中 %s %s"
                                 % (acc["id"], pick["id"],
                                    ("「%s」" % pick["name"]) if pick.get("name") else ""))
                    else:
                        todo = cand[: e.limit]
                        self.log("[%s] 批量模式：本次上限 %d 个" % (acc["id"], e.limit))
                    self.root.after(0, lambda m=len(todo): self.pb.config(maximum=max(m, 1), value=0))
                    ok_n = 0
                    for i, g in enumerate(todo):
                        if e.stop_flag:
                            break
                        r = e.grab_one(g, account=acc.get("game", ""),
                                       wait=max(1.2, e.interval))
                        # 失败自动重试（未登录/已停止/终态业务错误时不重试）
                        tries = 1
                        while (not r.get("ok")) and tries <= e.retry and not e.stop_flag \
                                and not r.get("need_login") \
                                and not _is_terminal(r.get("msg", "")):
                            tries += 1
                            self.log("[%s] %s 第 %d 次重试" % (acc["id"], g["id"], tries))
                            time.sleep(1.5)
                            r = e.grab_one(g, account=acc.get("game", ""),
                                       wait=max(1.2, e.interval))
                        if (not r.get("ok")) and _is_terminal(r.get("msg", "")):
                            self.log("[%s] %s 终态错误，不再重试: %s"
                                     % (acc["id"], g["id"], r.get("msg", "")))
                        rec = {"time": datetime.now().strftime("%m-%d %H:%M:%S"),
                               "account": acc["id"], "gift": g["id"],
                               "amount": g.get("amount", ""),
                               "game_account": r.get("game_account", ""),
                               "result": "成功" if r.get("ok") else "失败",
                               "msg": ("%s  账号:%s  %s" % (
                                   g.get("name", ""),
                                   r.get("game_account", ""),
                                   r.get("msg", ""))).strip()}
                        self.records.append(rec)
                        if r.get("ok"):
                            ok_n += 1
                        self.root.after(0, self._add_row, rec)
                        self.root.after(0, lambda v=i + 1: self.pb.config(value=v))
                        self.status("[%s] %d/%d  %s" % (acc["id"], i + 1, len(todo), rec["result"]))
                        if r.get("need_login"):
                            self.log("[%s] 掉线了（领取时站点要求重新登录），停止该账号"
                                     % acc["id"])
                            acc_set_status(acc, "off")
                            self._save_accounts()
                            self.root.after(0, self._refresh_accounts)
                            break
                        time.sleep(random.uniform(e.interval * 0.6, e.interval * 1.3))
                    total_ok += ok_n
                    self.log("[%s] 完成：成功 %d / 尝试 %d" % (acc["id"], ok_n, len(todo)))
                except Exception as ex:
                    self.log("[%s] 异常: %s" % (acc["id"], ex))
                finally:
                    e.close()
                    if e.stop_flag:
                        break
                    time.sleep(1.0)
            self._save_records()
            self.log("===== 全部结束，累计成功 %d 个 =====" % total_ok)
            self.status("完成，累计成功 %d 个" % total_ok)
        except Exception as ex:
            self.log("严重异常: %s" % ex)
        finally:
            e.close()
            self.running = False
            self._set_busy(False)
            self._show_progress(False)     # ★ 跑完了把进度条收回去

    def _add_row(self, rec):
        # ★ v1.1.7 表格去掉了「礼包」「金额」两列，这里同步少插两个值
        self.tree.insert("", "end", values=(rec["time"], rec["account"],
                                            rec["result"], rec["msg"]),
                         tags=("ok" if rec["result"] == "成功" else "fail",))
        self.tree.see(self.tree.get_children()[-1] if self.tree.get_children() else "")


def _pid_alive(pid):
    try:
        out = subprocess.run(["tasklist", "/FI", "PID eq %d" % pid, "/NH"],
                             capture_output=True, timeout=10,
                             creationflags=0x08000000)
        data = (out.stdout or b"").decode("utf-8", "ignore")
        return str(pid) in data
    except Exception:
        return False


def acquire_lock():
    """单实例锁：防止多开导致同一账号的浏览器 profile 被两个进程争抢"""
    try:
        pid = 0
        if os.path.exists(LOCK_FILE):
            try:
                with open(LOCK_FILE, "r") as f:
                    pid = int((f.read() or "0").strip())
            except Exception:
                pid = 0
        if pid and pid != os.getpid() and _pid_alive(pid):
            return False
        with open(LOCK_FILE, "w") as f:
            f.write(str(os.getpid()))
        return True
    except Exception:
        return True


def release_lock():
    """退出时清掉自己写的那把锁。

    不释放的话 app.lock 会永远留在程序目录里（虽然 acquire_lock 能识别
    死 PID 并接管，但目录里多个无用文件容易让人误以为程序还在跑）。
    只删内容等于自己 PID 的那把，绝不碰别人的。
    """
    try:
        if not os.path.exists(LOCK_FILE):
            return
        with open(LOCK_FILE, "r") as f:
            pid = int((f.read() or "0").strip() or "0")
        if pid == os.getpid():
            os.remove(LOCK_FILE)
    except Exception:
        pass


def _safe_print(s):
    """向控制台打印日志，编码不支持时降级重试。

    打包成 --noconsole EXE 后，stdout 往往是 GBK 控制台；日志里的
    ✅ ✓ ☑ ✗ ⏰ 等字符不在 GBK 里，直接 print 会抛 UnicodeEncodeError，
    被上层的 try/except 吞掉 —— 结果是"命令行里整行日志凭空消失"。
    这里按实际编码 replace 一次，至少把中文和主体信息打出来。
    """
    try:
        print(s, flush=True)
        return
    except Exception:
        pass
    try:
        enc = getattr(sys.stdout, "encoding", None) or "utf-8"
        print(str(s).encode(enc, "replace").decode(enc, "replace"), flush=True)
    except Exception:
        pass


def _headless_unlock():
    """无头入口（--sign / --daemon）先取一次 K_data。

    ★ v1.3.0：账号池是用 K_data 封的，没验证就读不出（读到的是密文）。
      这里静默验证一次拿钥匙；卡密无效/服务端不可达 → 池子保持锁定 →
      无头模式读不到账号 = 什么都不签。
    副作用（正面）：--daemon／--sign 不再是「绕过卡密的免费入口」——
      没有有效卡密，无头模式是空转。
    """
    try:
        g = CardGate()
        if g.card:
            g.verify()
        return g
    except Exception:
        return None


def headless_sign_once():
    """无头模式：不打开界面，用已保存的 Cookie 静默签到一次后退出。

    用法：小工具_v4.8.4.exe --sign
    配合 Windows 计划任务即可实现真正的『定时 + 无头』签到。
    结果写入程序目录下的 forum_sign.log。
    """
    _headless_unlock()                    # ★ v1.3.0：先取 K_data，否则读不懂密文
    cfg = {}
    try:
        cfg = _safe_load_json(FORUM_CFG_FILE)[0] or {}
    except Exception:
        cfg = {}
    lines = []

    def log(msg):
        s = "[%s] %s" % (datetime.now().strftime("%Y-%m-%d %H:%M:%S"), msg)
        lines.append(s)
        _safe_print(s)

    log("无头签到开始")
    if not [k for k in cfg if not k.startswith("_")]:
        log("未找到已保存的论坛登录状态，请先在界面里登录论坛")
    # ★ v4.7.0 论坛列表改为动态：优先用配置里保存的列表（含手动添加的）
    _fl = (cfg.get("_settings") or {}).get("forum_list") or []
    flist = [(str(i.get("name", "")), str(i.get("url", "")))
             for i in _fl if isinstance(i, dict)
             and i.get("name") and i.get("url")] or list(FORUMS)
    done = 0
    for name, base in flist:
        ck = ((cfg.get(base) or {}).get("cookie") or "").strip()
        if not ck:
            log("%s：跳过（未登录）" % name)
            continue
        log("―――――― %s ――――――" % name)
        try:
            s = DiscuzForumSigner(base, cookie=ck, log=log,
                                  ua=((cfg.get(base) or {}).get("ua") or ""))
            st, msg = s.sign()
            tag = {"ok": "✓ 成功", "already": "☑ 已签到"}.get(st, "✗ 失败")
            log("%s：%s %s" % (name, tag, msg))
            if st in ("ok", "already"):
                done += 1
        except Exception as ex:
            log("%s：异常 %s" % (name, ex))
    log("无头签到结束（%d 个论坛）" % done)
    try:
        # ★ v1.1.29 追加前先删掉 5 天前的旧行，日志不无限膨胀
        _prune_log_file(os.path.join(base_dir(), "forum_sign.log"))
        with open(os.path.join(base_dir(), "forum_sign.log"), "a",
                  encoding="utf-8") as f:
            f.write("\n".join(lines) + "\n")
    except Exception:
        pass

    # ---- QQ 群签到（需在 QQ 页勾选『每天定时自动签到』；独立日志，互不影响）
    if os.path.exists(QQ_CFG_FILE):
        qlines = []

        def qlog(msg):
            s = "[%s] %s" % (datetime.now().strftime("%Y-%m-%d %H:%M:%S"), msg)
            qlines.append(s)
            _safe_print(s)

        qlog("无头 QQ 群签到开始")
        try:
            qq_headless_sign(log=qlog)
        except Exception as ex:
            qlog("异常：%s" % ex)
        try:
            # ★ v1.1.29 追加前先删掉 5 天前的旧行，日志不无限膨胀
            _prune_log_file(QQ_LOG_FILE)
            with open(QQ_LOG_FILE, "a", encoding="utf-8") as f:
                f.write("\n".join(qlines) + "\n")
        except Exception:
            pass


def daemon_mode(interval=30):
    """无界面常驻守护：按界面里保存的定时设置自动签到。

    用法：小工具_v4.8.4.exe --daemon
    适合放进「启动」文件夹 / 计划任务，实现开机后按点自动签到。
    设置改完后需重启本进程才生效；结果写入 forum_sign.log。
    """
    _headless_unlock()                    # ★ v1.3.0：先取 K_data，否则读不懂密文

    def _load():
        try:
            cfg = _safe_load_json(FORUM_CFG_FILE)[0]
            return cfg if isinstance(cfg, dict) else {}
        except Exception:
            pass
        return {}

    def _logfile(msg):
        try:
            with open(os.path.join(base_dir(), "forum_sign.log"), "a",
                      encoding="utf-8") as f:
                f.write("[%s] %s\n"
                        % (datetime.now().strftime("%Y-%m-%d %H:%M:%S"), msg))
        except Exception:
            pass
        _safe_print(msg)

    # ★ v1.1.29 守护启动时清一遍 5 天前的旧日志行
    _prune_log_file(os.path.join(base_dir(), "forum_sign.log"))
    st = _load().get("_settings", {}) or {}
    if not st.get("auto_sign"):
        _logfile("未启用定时签到：请先在界面勾选『每天定时自动签到』并保存")
        return
    target_hm = str(st.get("auto_time", "08:00") or "08:00")
    last = str(st.get("last_auto", "") or "")
    _logfile("定时签到守护启动：每天 %s 自动签到" % target_hm)
    while True:
        try:
            m = re.match(r"^([01]?\d|2[0-3]):([0-5]\d)$", target_hm)
            if m:
                now = datetime.now()
                target = now.replace(hour=int(m.group(1)) % 24,
                                     minute=int(m.group(2)) % 60,
                                     second=0, microsecond=0)
                # 只在到点那一刻（90 秒窗口内）触发，错过不补执行
                if (now >= target
                        and (now - target).total_seconds() <= 90
                        and _last_run_normalize(last) != _last_run_key(target)):
                    last = _last_run_key(target)
                    _logfile("到点，开始自动签到")
                    headless_sign_once()
                    try:                    # 回写 last_auto，重启不重复
                        c2 = _load()
                        s2 = c2.get("_settings", {}) or {}
                        s2["last_auto"] = last
                        c2["_settings"] = s2
                        _safe_save_json(FORUM_CFG_FILE, c2)
                    except Exception:
                        pass
        except Exception as ex:
            _logfile("守护循环异常：%s" % ex)
        time.sleep(interval)


# ============================================================ 卡密门禁（★ v1.1.18）
# 启动先验证卡密（机器码绑定），通过才进主界面；运行中每 60s 心跳 ——
# 服务端封卡 / 封 IP / 封机器码立刻踢下线并自动退出；心跳同时带回「最新版本」，
# 发现新版**先询问用户**（★ v1.1.20 用户自选更不更新）：同意后从服务端
# 托管包（管理页上传）下载，下载完自动替换自身并重启，全程不弹浏览器。
# ★ 2026-10-09 用户要求「最严」：**取消离线宽限** —— 连不上卡密服务端就立刻
#   锁死（不再有 2 小时宽限）。运行中心跳一旦断开，下一轮（≤60s）直接踢下线；
#   验证时连不上服务端也不再放行。
# ★ 服务端地址全程不出现明文：内置地址以加密形式烧进程序（打包前 build.bat
#   从 卡密服务端地址.txt 生成 _card_embed.py），本机配置文件同样加密存储；
#   管理员用隐藏后台（Ctrl+Alt+U）查看/修改。
import base64
import hashlib
import platform
import uuid

CARD_CFG_FILE = os.path.join(base_dir(), "card_config.json")   # 卡密+加密地址

GRACE_MAX_H = 0.0                  # ★ 2026-10-09 取消离线宽限（原 2.0 小时）

_XOR_CLI = b"zsfCardCli9"


def _enc_addr(s):
    """服务端地址/密码 → XOR+base64（配置文件与内置常量都用它，不落明文）。"""
    b = str(s).encode("utf-8")
    x = bytes(c ^ _XOR_CLI[i % len(_XOR_CLI)] for i, c in enumerate(b))
    return base64.b64encode(x).decode("ascii")


def _dec_addr(e):
    try:
        x = base64.b64decode(str(e).encode("ascii"))
        return bytes(c ^ _XOR_CLI[i % len(_XOR_CLI)]
                     for i, c in enumerate(x)).decode("utf-8")
    except Exception:
        return ""


# 内置服务端地址（加密态）。打包前 build.bat 会按 卡密服务端地址.txt 重新生成
# _card_embed.py；源码直跑/文件缺失时用下面的兜底值。
try:
    from _card_embed import CARD_SERVER_ENC as _ENC_SERVER_DEFAULT
except Exception:
    _ENC_SERVER_DEFAULT = "EgcSM1tdS3JCUAtUQlZ1T0pdeVReD08="  # http://<已脱敏>:8765

# 隐藏管理后台密码（加密态存储；要改密码就换这串：python -c 用 _enc_addr 生成）
_PANEL_PASS_ENC = "GxcLKg9KXHs="                      # admin888

DEFAULT_CARD_SERVER = _dec_addr(_ENC_SERVER_DEFAULT) or "http://127.0.0.1:8765"


def get_machine_code():
    """机器码：系统 MachineGuid(优先) + MAC + 主机名/系统，sha256 取 32 位大写。

    Windows 用注册表 MachineGuid（重装系统才会变，比 wmic 快且稳，
    新版 Win11 已移除 wmic）；mac 用 IOPlatformUUID；Linux 用 machine-id。
    """
    parts = []
    try:
        if os.name == "nt":
            try:
                import winreg
                with winreg.OpenKey(
                        winreg.HKEY_LOCAL_MACHINE,
                        r"SOFTWARE\Microsoft\Cryptography", 0,
                        winreg.KEY_READ | winreg.KEY_WOW64_64KEY) as k:
                    guid, _ = winreg.QueryValueEx(k, "MachineGuid")
                    if guid:
                        parts.append(str(guid).upper())
            except Exception:
                pass
        elif sys.platform == "darwin":
            out = subprocess.run(
                ["ioreg", "-rd1", "-c", "IOPlatformExpertDevice"],
                capture_output=True, timeout=10)
            m = re.search(r'"IOPlatformUUID"\s*=\s*"([^"]+)"',
                          (out.stdout or b"").decode("utf-8", "replace"))
            if m:
                parts.append(m.group(1))
        else:
            for f in ("/etc/machine-id", "/var/lib/dbus/machine-id"):
                if os.path.exists(f):
                    with open(f) as fh:
                        parts.append(fh.read().strip()[:64])
                    break
    except Exception:
        pass
    try:
        parts.append("%012x" % uuid.getnode())
    except Exception:
        pass
    parts.append("%s|%s%s" % (platform.node(), platform.system(),
                              platform.release()))
    return hashlib.sha256("|".join(parts).encode("utf-8")).hexdigest()[
        :32].upper()


def _card_cfg_load():
    # ★ v1.1.31 加密落盘；★ v1.3.0 改用引导密钥（验证前必须可读）
    data = _safe_load_json(CARD_CFG_FILE, _boot_key())[0]
    return data if isinstance(data, dict) else {}


def _card_cfg_save(cfg):
    # ★ v1.1.31 加密落盘（含卡密 + 服务端地址）；★ v1.3.0 引导密钥
    _safe_save_json(CARD_CFG_FILE, cfg, indent=1, key=_boot_key())


def _challenge(base, timeout=8):
    """向卡密服务端要一个一次性随机数（挑战应答用）。"""
    req = urllib.request.Request(
        base.rstrip("/") + "/api/challenge", data=b"{}",
        headers={"Content-Type": "application/json",
                 "User-Agent": "zsf-tool/" + VERSION})
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return str(json.loads(r.read().decode("utf-8")).get("nonce") or "")


def _handshake_mac(scope, nonce, payload, session_key=None):
    """挑战应答 HMAC —— 必须与服务端 _mac_for 逐字节一致。

    ★ v1.0.3 非对称升级：
    - 如果 session_key 不为 None → 用 ECDH 协商的会话密钥做 HMAC（非对称模式）
    - 如果 session_key 为 None → 回退到旧 PSK 模式（降级兼容）
    """
    if scope == "verify":
        core = "%s|%s|%s|%s" % (nonce, scope,
                                str(payload.get("card", "")).strip().upper(),
                                _norm_machine(payload.get("machine", "")))
    else:
        core = "%s|%s|%s" % (nonce, scope, str(payload.get("token", "")))
    if session_key:
        # ★ ECDH 非对称模式：用协商出的会话密钥
        return hmac.new(session_key, core.encode("utf-8"),
                        hashlib.sha256).hexdigest()
    else:
        # 降级：旧 PSK 模式
        return hmac.new(_psk().encode("utf-8"), core.encode("utf-8"),
                        hashlib.sha256).hexdigest()


def _card_post(base, path, payload, timeout=12):
    """POST JSON 到卡密服务端，返回 dict。网络/解析失败抛异常。

    ★ v1.0.3 非对称升级：
    1) 优先走 ECDH：客户端临时密钥对 → 协商会话密钥 → HMAC 签名
    2) 降级：如果 cryptography 不可用或服务端不支持 → 回退旧 PSK 模式
    """
    payload = dict(payload)
    scope = path.rsplit("/", 1)[-1]           # verify / heartbeat / consume
    nonce = _challenge(base, timeout=min(timeout, 8))
    session_key = None
    if nonce:
        # ★ 优先 ECDH 非对称模式
        ek_der, session_key = _ecdh_session()
        if ek_der and session_key:
            payload["nonce"] = nonce
            payload["mac"] = _handshake_mac(scope, nonce, payload, session_key)
            payload["ecdh_pk"] = base64.b64encode(ek_der).decode("ascii")
        else:
            # 降级：回退到 PSK 对称模式
            payload["nonce"] = nonce
            payload["mac"] = _handshake_mac(scope, nonce, payload)
    req = urllib.request.Request(
        base.rstrip("/") + path,
        data=json.dumps(payload).encode("utf-8"),
        headers={"Content-Type": "application/json",
                 "User-Agent": "zsf-tool/" + VERSION})
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return json.loads(r.read().decode("utf-8"))


def _ver_tuple(s):
    try:
        return tuple(int(x) for x in re.findall(r"\d+", str(s))[:4])
    except Exception:
        return ()


# ------------------------------------------------ 卡密门禁本体
class CardGate(object):
    """验证 + 心跳 + 更新检查。"""

    def __init__(self):
        self.cfg = _card_cfg_load()
        # 服务端地址：本机加密配置 → 旧明文配置(迁移) → 内置加密默认值
        srv = _dec_addr(self.cfg.get("server_enc") or "")
        if not srv:
            srv = str(self.cfg.get("server") or "")
        self.server = (srv or DEFAULT_CARD_SERVER).strip()
        self.card = (self.cfg.get("card") or "").strip().upper()
        self.machine = get_machine_code()
        self.ok = False            # 验证放行标志（验证窗口写）
        self.token = ""
        self.type = "time"
        self.remain = ""
        self.has_kdata = False     # ★ v1.3.0 是否已拿到服务端 K_data（账号池钥匙）
        # ★ v1.3.0 本机「上次用过的片号」—— 存引导配置里（验证前可读），
        #   重启后带上它向服务端补片，才能打开上次那片密钥封的账号池。
        try:
            self.last_epoch = int(self.cfg.get("k_epoch") or -1)
        except Exception:
            self.last_epoch = -1
        # ★ 2026-10-09「最严」：取消离线宽限 —— grace_hours 恒为 0，
        #   连不上服务端 = 不放行（见 _offline_grace / heartbeat_loop）。
        self.grace_hours = min(float(self.cfg.get("grace_hours")
                                     or GRACE_MAX_H), GRACE_MAX_H)
        self.latest = {}           # 心跳带回的最新版本（服务端托管更新包）
        self.online = None         # None=未知 True=在线 False=离线
        self._notified = ""        # 已提示过的新版本（防重复弹窗）
        # ★ v1.1.30 管理员文字推送：记录已读到的最大序号（重启不重播）
        try:
            self.push_seen = int(self.cfg.get("push_seen") or 0)
        except Exception:
            self.push_seen = 0
        self._pending_push = []    # 已收到但还没弹给用户的文字
        self._stop = threading.Event()

    # ---- 验证（同步，验证窗口的后台线程里调）
    def verify(self):
        """返回 (True, 提示, False) 放行；(False, 提示, fatal) 拦下。
        ★ v1.1.23 fatal=True 只表示封卡/封机/封IP（程序退出）；
        过期/次数用完**不再退出** —— 验证窗口会清空卡密框让用户直接填新卡密。"""
        if not self.card:
            return False, "请输入卡密", False
        try:
            r = _card_post(self.server, "/api/verify",
                           {"card": self.card, "machine": self.machine,
                            "version": VERSION, "push_seen": self.push_seen,
                            "k_epoch": self.last_epoch})
        except Exception:
            ok, msg = self._offline_grace()
            return ok, msg, False
        if not r.get("ok"):
            m = r.get("msg", "验证失败")
            fatal = bool(r.get("banned"))
            if ("过期" in m) or ("用完" in m):
                m = m + "（可直接输入新卡密继续使用）"
            return False, m, fatal
        self._apply_ok(r)
        if not self.has_kdata:
            return (True, "验证通过，剩余 %s（警告：未取到业务密钥，"
                    "本机账号池不可用，请联系管理员）" % self.remain, False)
        return True, "验证通过，剩余 %s" % self.remain, False

    def _offline_grace(self):
        # ★ 2026-10-09「最严」：取消离线宽限 —— 服务端不可达 = 不放行。
        #   （保留方法名与返回签名，避免调用点全改；语义恒为「拦下」。）
        return False, "无法连接卡密服务端，请检查网络或联系管理员"

    def _apply_ok(self, r):
        self.token = r.get("token", "")
        self.type = r.get("type", "time")
        self.remain = r.get("remain", "")
        # ★ v1.3.0 命门：把服务端下发的 K_data 装进内存 —— 账号池/cookie 池
        #   的唯一密钥。patch 掉校验就拿不到它（见 _data_key / _safe_save_json）。
        had = _kdata_ready()
        old_ep = _KDATA.get("epoch")
        self.has_kdata = _kdata_install(r, self.card, self.machine)
        new_ep = _KDATA.get("epoch")
        if self.has_kdata and (not had or new_ep != old_ep):
            _reseal_all_pools()    # 首次迁移 / 轮换收口（幂等）
        try:
            self.last_epoch = int(_KDATA.get("epoch")
                                  if _KDATA.get("epoch") is not None else -1)
        except Exception:
            pass
        self.grace_hours = min(float(r.get("grace_hours") or GRACE_MAX_H),
                               GRACE_MAX_H)
        self.latest = r.get("latest") or {}
        self.online = True
        self.cfg.update({"server_enc": _enc_addr(self.server),
                         "card": self.card, "last_ok": time.time(),
                         "grace_hours": self.grace_hours,
                         "k_epoch": self.last_epoch})
        self.cfg.pop("server", None)       # 迁移掉旧明文地址
        _card_cfg_save(self.cfg)

    # ---- ★ v1.1.30 管理员文字推送：按 seq 去重，重启不重播
    def _queue_push(self, r):
        items = r.get("push") or []
        for it in items:
            try:
                seq = int(it.get("seq") or 0)
            except Exception:
                seq = 0
            text = str(it.get("text") or "").strip()
            if text and seq > self.push_seen:
                self._pending_push.append(text)
            if seq > self.push_seen:
                self.push_seen = seq
        if items:
            self.cfg["push_seen"] = self.push_seen
            _card_cfg_save(self.cfg)

    def _flush_push(self, ui):
        """把已收到的文字逐条交给界面层展示。"""
        while self._pending_push:
            ui("push", self._pending_push.pop(0))

    def newer_version(self):
        # ★ v1.1.22 直接更新模式：**不比较版本号大小** —— 服务端
        # latest.version 与当前版本号不同即提示；管理员改一个没用过的
        # 版本号即可重推任意版本。
        v = str(self.latest.get("version") or "").strip()
        if not v or v == VERSION:
            return False
        try:                       # 该版本号已成功应用过（exe 版本没变），
            with open(_marker_file(), "r", encoding="utf-8") as f:
                m = json.load(f)   # 不再反复提示（防更新循环）
            if (str(m.get("ver") or "") == v
                    and str(m.get("exe") or "") == VERSION):
                return False
        except Exception:
            pass
        return True

    # ---- 计次卡：每次启动扣 1 次（后台，失败不阻塞）
    def consume_once(self):
        if self.type != "count" or not self.token:
            return

        def work():
            try:
                _card_post(self.server, "/api/consume",
                           {"token": self.token, "n": 1}, timeout=8)
            except Exception:
                pass
        threading.Thread(target=work, daemon=True).start()

    # ---- 心跳循环（后台线程；ui(kind, msg) 回调由主线程经 root.after 执行）
    def heartbeat_loop(self, ui):
        # ★ v1.1.18 进主界面立刻查一次更新（验证响应里已带 latest），不等 60s
        nv0 = str(self.latest.get("version") or "")
        if nv0 and nv0 != self._notified and self.newer_version():
            self._notified = nv0
            ui("update")
        self._flush_push(ui)          # 验证阶段收到的推送，进界面后补弹
        while not self._stop.wait(60):
            try:
                r = _card_post(self.server, "/api/heartbeat",
                               {"token": self.token, "version": VERSION,
                                "push_seen": self.push_seen,
                                "k_epoch": self.last_epoch})
            except Exception:
                # ★ 2026-10-09「最严」：取消离线宽限 —— 心跳一断即视为掉线，
                #   立刻踢下线（不再等 2 小时宽限）。
                if self.online is not False:
                    self.online = False
                    ui("offline")
                ui("kick", "与服务端失去联系，已锁定（无离线宽限）")
                return
            if not r.get("ok"):
                if r.get("banned"):
                    ui("kick", r.get("msg", "此卡密已被封禁"))
                    return
                if r.get("relogin"):
                    ok, msg, _f = self.verify()
                    if not ok:
                        ui("kick", msg)
                        return
                    ui("online")
                    continue
                ui("kick", r.get("msg", "验证失败"))
                return
            self._apply_ok(r)
            self._flush_push(ui)
            if not self.online:
                self.online = True
                ui("online")
            nv = str(self.latest.get("version") or "")
            if self.newer_version() and nv != self._notified:
                self._notified = nv
                ui("update")


def run_card_gate(gate):
    """卡密验证窗口（程序入口第一屏）。返回 True = 放行进主程序。"""
    root = tk.Tk()
    root.title("小工具")
    root.resizable(False, False)
    frm = tk.Frame(root, padx=24, pady=16)
    frm.pack()
    tk.Label(frm, text="本工具需要卡密激活", font=("Microsoft YaHei", 11, "bold"),
             fg="#1a5fb4").grid(row=0, column=0, columnspan=3,
                                sticky="w", pady=(0, 10))
    tk.Label(frm, text="机器码").grid(row=1, column=0, sticky="e",
                                     padx=(0, 6), pady=3)
    mc_var = tk.StringVar(value=gate.machine)
    tk.Entry(frm, textvariable=mc_var, width=36, state="readonly",
             font=("Consolas", 9)).grid(row=1, column=1, sticky="w", pady=3)

    def copy_mc():
        root.clipboard_clear()
        root.clipboard_append(gate.machine)
        var_status.set("机器码已复制，发给管理员查询/封禁")
    tk.Button(frm, text="复制", width=6, command=copy_mc).grid(
        row=1, column=2, padx=(6, 0), pady=3)
    tk.Label(frm, text="卡　密").grid(row=2, column=0, sticky="e",
                                     padx=(0, 6), pady=3)
    var_card = tk.StringVar(value=gate.card)
    e_card = tk.Entry(frm, textvariable=var_card, width=36,
                      font=("Consolas", 10))
    e_card.grid(row=2, column=1, columnspan=2, sticky="w", pady=3)
    # ★ v1.1.17 不再显示「服务端」栏 —— 客户不应知道服务端地址；
    #   管理员用 Ctrl+Alt+A 呼出隐藏后台查看/修改（地址全程加密存储）。
    var_status = tk.StringVar(value="")
    tk.Label(frm, textvariable=var_status, fg="#666", anchor="w", width=46,
             wraplength=360, justify="left").grid(
        row=3, column=0, columnspan=3, sticky="w", pady=(8, 2))
    btns = tk.Frame(frm)
    btns.grid(row=4, column=0, columnspan=3, pady=(8, 0))
    busy = {"on": False}

    def finish(ok):
        gate.ok = ok
        try:
            root.destroy()
        except Exception:
            pass

    def do_verify(auto=False):
        if busy["on"]:
            return
        card = var_card.get().strip().upper()
        if not card:
            var_status.set("请输入卡密")
            return
        gate.card = card
        busy["on"] = True
        var_status.set("正在自动登录…" if auto else "正在验证…")

        def work():
            ok, msg, fatal = gate.verify()

            def fin():
                nonlocal ok, msg, fatal
                busy["on"] = False
                var_status.set(msg)
                if ok:
                    finish(True)
                elif fatal:
                    # ★ v1.1.23 只有封卡/封机器码/封IP 才退出
                    messagebox.showerror("验证失败",
                                         msg + "\n\n程序即将退出。", parent=root)
                    finish(False)
                elif ("过期" in msg) or ("用完" in msg):
                    # ★ v1.1.23 卡密到期/次数用完：不退出，清空卡密框让
                    #   用户直接输入新卡密（旧卡密从本机配置里删掉，
                    #   避免下次启动还拿死卡自动登录）
                    messagebox.showwarning("卡密已失效", msg, parent=root)
                    gate.card = ""
                    gate.cfg.pop("card", None)
                    _card_cfg_save(gate.cfg)
                    var_card.set("")
                    var_status.set("请输入新卡密后点「验证并进入」")
                    e_card.focus_set()
                else:
                    messagebox.showerror("验证失败", msg, parent=root)
            try:
                root.after(0, fin)
            except Exception:
                pass
        threading.Thread(target=work, daemon=True).start()

    tk.Button(btns, text="验证并进入", width=13,
              command=lambda: do_verify(False)).pack(side="left", padx=6)
    tk.Button(btns, text="退出", width=9, command=root.destroy).pack(
        side="left", padx=6)
    tk.Label(frm, text="没有卡密？请联系管理员购买。卡密与电脑绑定，"
                       "换机请联系管理员解绑。", fg="#999").grid(
        row=5, column=0, columnspan=3, sticky="w", pady=(10, 0))
    # 管理员隐藏后台：Ctrl+Alt+U（客户不知道这个入口）
    root.bind_all("<Control-Alt-u>",
                  lambda e: _open_admin_panel(root, gate))
    root.bind_all("<Control-Alt-U>",
                  lambda e: _open_admin_panel(root, gate))

    # 居中
    root.update_idletasks()
    w, h = root.winfo_reqwidth(), root.winfo_reqheight()
    root.geometry("+%d+%d" % ((root.winfo_screenwidth() - w) // 2,
                              (root.winfo_screenheight() - h) // 2 - 60))
    if gate.card:                       # 存过卡密：打开即自动登录
        root.after(300, lambda: do_verify(auto=True))
    root.mainloop()
    return gate.ok


def _open_admin_panel(parent, gate):
    """★ 隐藏管理后台（Ctrl+Alt+U + 密码 admin888）：
    查看/修改对接卡密端的 IP，方便换服务器。新地址**只以加密形式**（server_enc）
    写进 card_config.json，文件里搜不到明文；保存后立即生效（心跳/重验证走新地址）。"""
    try:
        key = simpledialog.askstring("管理后台", "请输入管理密码：",
                                     parent=parent, show="*")
    except Exception:
        return
    if key is None:
        return
    if _enc_addr(key) != _PANEL_PASS_ENC:
        messagebox.showerror("管理后台", "密码错误。", parent=parent)
        return
    top = tk.Toplevel(parent)
    top.title("管理后台 · 对接服务端地址")
    top.resizable(False, False)
    top.transient(parent)
    frm = tk.Frame(top, padx=16, pady=12)
    frm.pack()
    tk.Label(frm, text="当前服务端地址").grid(row=0, column=0, sticky="w")
    cur = tk.Entry(frm, width=36)
    cur.insert(0, gate.server)
    cur.config(state="readonly")
    cur.grid(row=0, column=1, sticky="w", pady=2)
    tk.Label(frm, text="新地址").grid(row=1, column=0, sticky="w")
    ent = tk.Entry(frm, width=36)
    ent.grid(row=1, column=1, sticky="w", pady=2)
    st = tk.Label(frm, text="换服务器：填新 IP:端口 → 测试连接 → 保存并生效。",
                  fg="#888", wraplength=300, justify="left")
    st.grid(row=2, column=0, columnspan=2, sticky="w")

    def norm(u):
        u = (u or "").strip()
        if u and "://" not in u:
            u = "http://" + u
        return u.rstrip("/")

    def do_save():
        u = norm(ent.get())
        if not u.startswith(("http://", "https://")):
            st.config(text="地址要以 http:// 或 https:// 开头", fg="#c0392b")
            return
        gate.server = u                    # 立即生效：心跳/重新验证都走新地址
        gate.cfg.update({"server_enc": _enc_addr(u)})   # 文件里只有密文
        gate.cfg.pop("server", None)
        _card_cfg_save(gate.cfg)
        cur.config(state="normal")
        cur.delete(0, "end")
        cur.insert(0, u)
        cur.config(state="readonly")
        st.config(text="已保存并立即生效（文件内为加密存储）。"
                       "若新服务器没有这张卡，下次验证时按提示处理。",
                  fg="#1e8e3e")

    def do_test():
        u = norm(ent.get()) or gate.server
        st.config(text="正在连接 %s …" % u, fg="#888")

        def work():
            try:
                req = urllib.request.Request(u.rstrip("/") + "/")
                with urllib.request.urlopen(req, timeout=8) as r:
                    body = r.read().decode("utf-8", "replace")
                good = "管理入口" in body
                top.after(0, lambda: st.config(
                    text=("连接成功，是卡密服务端。" if good else
                          "连上了，但响应不像卡密服务端，请核对地址。"),
                    fg=("#1e8e3e" if good else "#b06000")))
            except Exception as e:
                top.after(0, lambda: st.config(
                    text="连接失败：%s" % e, fg="#c0392b"))
        threading.Thread(target=work, daemon=True).start()

    def do_reset():
        ent.delete(0, "end")
        ent.insert(0, DEFAULT_CARD_SERVER)
        st.config(text="已填入内置默认地址，点「保存并生效」后启用。", fg="#888")

    def do_clear():
        if not messagebox.askyesno(
                "清除本机配置",
                "清除本机卡密配置？（卡密需重新输入，服务端地址恢复内置默认）",
                parent=top):
            return
        try:
            if os.path.exists(CARD_CFG_FILE):
                os.remove(CARD_CFG_FILE)
        except Exception:
            pass
        gate.cfg = {}
        gate.server = DEFAULT_CARD_SERVER
        gate.card = ""
        st.config(text="本机卡密配置已清除，重启程序后重新输入卡密。", fg="#b06000")

    btns = tk.Frame(frm)
    btns.grid(row=3, column=0, columnspan=2, pady=(8, 0))
    tk.Button(btns, text="保存并生效", width=12,
              command=do_save).pack(side="left", padx=4)
    tk.Button(btns, text="测试连接", width=10,
              command=do_test).pack(side="left", padx=4)
    tk.Button(btns, text="恢复默认", width=10,
              command=do_reset).pack(side="left", padx=4)
    tk.Button(btns, text="清除本机配置", width=12,
              command=do_clear).pack(side="left", padx=4)
    try:
        top.grab_set()
    except Exception:
        pass


# ---------------- 在线更新（★ v1.1.23 只保留服务端托管包一个更新源）
# 外链更新源（v1.1.21 短暂存在过）已删除：管理页不再支持链接源，
# 客户端也不再做任何直链解析 —— 推送统一走服务端托管包。


def _update_src(latest):
    """★ v1.1.23 判定更新来源：('server', None)=服务端托管包（管理页上传，
    客户端从 /api/download 下载）；('', None)=未设置。"""
    latest = latest or {}
    if latest.get("src") == "upload" or latest.get("file"):
        return ("server", None) if latest.get("file") else ("", None)
    return "", None


UPDATE_MARKER_FILE = ""    # 测试可重定向；空 = base_dir()/update_done.json


def _marker_file():
    """★ v1.1.22 已成功应用的更新记录（防「版本号填错」更新循环）。"""
    return UPDATE_MARKER_FILE or os.path.join(base_dir(),
                                              "update_done.json")


def _is_pe_file(path):
    """下载包必须是 PE（MZ 头），防止把错误文件/半截包替换进程序。"""
    try:
        with open(path, "rb") as f:
            return f.read(2) == b"MZ"
    except Exception:
        return False


def _extract_pe(pkg, dest, prog):
    """★ v1.1.22 下载包格式兼容：裸 exe（MZ）直接用；zip/rar 压缩包自动
    解出其中最大的 .exe（rar 走系统自带 tar.exe，Win10 1803+ 可解 RAR5）。
    ★ v1.1.23 多文件推送：压缩包里除主 exe 外的其余文件（dll/数据/子exe…）
    暂存到 dest+"_x"，_apply_update 会把它们装进程序目录（保持包内相对路径）。
    成功 True；失败写 prog["err"]（更新失败弹窗会显示原因）。"""
    xdir = dest + "_x"
    shutil.rmtree(xdir, ignore_errors=True)   # 清掉上次尝试的残留
    prog.pop("extras_dir", None)
    try:
        with open(pkg, "rb") as f:
            head = f.read(8)
    except Exception as e:
        prog["err"] = "读取下载文件失败 %r" % e
        return False
    if head[:2] == b"MZ":
        try:
            os.replace(pkg, dest)
            return True
        except Exception as e:
            prog["err"] = "保存新版本失败 %r" % e
            return False
    if head[:4] not in (b"PK\x03\x04", b"Rar!"):
        prog["err"] = "下载内容不是有效的 exe/zip/rar（文件头 %r）" % head[:4]
        return False
    tmpd = dest + "_un"
    shutil.rmtree(tmpd, ignore_errors=True)
    os.makedirs(tmpd, exist_ok=True)
    try:
        if head[:4] == b"PK\x03\x04":
            with zipfile.ZipFile(pkg) as z:
                z.extractall(tmpd)
        else:
            tar = os.path.join(os.environ.get("SystemRoot", r"C:\Windows"),
                               "System32", "tar.exe")
            if not os.path.exists(tar):
                prog["err"] = "系统缺少 tar.exe 无法解压 RAR，请上传 exe 或 zip"
                return False
            p = subprocess.run([tar, "-xf", os.path.abspath(pkg), "-C", tmpd],
                               capture_output=True, timeout=600,
                               creationflags=0x08000000)
            if p.returncode != 0:
                prog["err"] = "RAR 解压失败，请改传 exe 或 zip"
                return False

        def _safe_rel(rel):
            """★ 防压缩包路径穿越（zip slip）：只允许正常相对路径。"""
            parts = [p for p in str(rel).replace("\\", "/").split("/")
                     if p not in ("", ".")]
            if not parts or any(p == ".." or ":" in p for p in parts):
                return ""
            return os.path.join(*parts)

        best = ""                 # 包里最大的 PE exe = 新主程序
        extras = []               # 其余文件 (相对路径, 源绝对路径)
        for dp, _dn, fns in os.walk(tmpd):
            for fn in fns:
                q = os.path.join(dp, fn)
                rel = os.path.relpath(q, tmpd)
                if fn.lower().endswith(".exe") and _is_pe_file(q):
                    if not best or os.path.getsize(q) > os.path.getsize(best):
                        if best:  # 之前认定的主 exe 降级为附加文件
                            extras.append((os.path.relpath(best, tmpd), best))
                        best = q
                        continue
                extras.append((rel, q))
        if not best and not extras:
            prog["err"] = "压缩包是空的"
            return False
        if best:
            shutil.copyfile(best, dest)
        else:
            # ★ v1.1.23 任意文件推送：包里没有 exe —— 全部当附加文件，
            #   _apply_update 只装文件、不替换主程序（重启后生效）
            prog["no_main"] = True
        if extras:
            n_x = 0
            for rel, src in extras:
                r = _safe_rel(rel)
                if not r:
                    continue
                t = os.path.join(xdir, r)
                try:
                    os.makedirs(os.path.dirname(t), exist_ok=True)
                    shutil.copyfile(src, t)
                    n_x += 1
                except Exception:
                    pass
            if n_x:
                prog["extras_dir"] = xdir
        return True
    except subprocess.TimeoutExpired:
        prog["err"] = "解压超时，请改传 exe 或 zip"
        return False
    except Exception as e:
        prog["err"] = "压缩包解压失败 %r（请改传 exe 或 zip）" % e
        return False
    finally:
        shutil.rmtree(tmpd, ignore_errors=True)


def _download_to(url, dest, prog, timeout=600, extra=None):
    """流式下载 url → dest（先 .part 再改名）。成功 True；失败清理后 False。"""
    try:
        hd = {"User-Agent": "zsf-tool/" + VERSION}
        if extra:
            hd.update(extra)
        req = urllib.request.Request(url, headers=hd)
        with urllib.request.urlopen(req, timeout=timeout) as r:
            prog["total"] = int(r.headers.get("Content-Length") or 0)
            tmp = dest + ".part"
            with open(tmp, "wb") as f:
                while True:
                    b = r.read(1 << 16)
                    if not b:
                        break
                    f.write(b)
                    prog["got"] += len(b)
        os.replace(tmp, dest)
        return True
    except Exception:
        try:
            if os.path.exists(dest + ".part"):
                os.remove(dest + ".part")
        except Exception:
            pass
        return False


def _update_worker(gate, prog):
    """后台下载新版本：★ v1.1.23 更新源只保留服务端托管包（管理页上传，
    /api/download 下载）。★ v1.1.22 下载包兼容裸 exe/zip/rar（自动解出
    exe，多文件推送还会把其余文件装进程序目录），失败原因写入 prog["err"]。"""
    latest = gate.latest or {}
    dest = os.path.join(base_dir(), "小工具_更新_tmp.exe")
    pkg = os.path.join(base_dir(), "小工具_更新_tmp.pkg")
    prog["dest"] = dest
    for p in (dest, pkg, dest + "_x"):   # 清掉上次运行残留，防误判
        try:
            if os.path.isdir(p):
                shutil.rmtree(p, ignore_errors=True)
            elif os.path.exists(p):
                os.remove(p)
        except Exception:
            pass
    kind, _url = _update_src(latest)
    try:
        if kind == "server":
            if _download_to(gate.server.rstrip("/") + "/api/download",
                            pkg, prog) and _extract_pe(pkg, dest, prog):
                prog["state"] = "done"
                return
        else:
            prog["err"] = "服务端未设置更新包，请联系管理员上传"
    except Exception as e:
        prog["err"] = "更新流程异常 %r" % e
    if not prog.get("err"):
        prog["err"] = "网络下载失败"
    prog["state"] = "fail"


def _install_extras(prog, d):
    """★ v1.1.23 把更新包里的附加文件装进程序目录 d（保持包内相对路径）。
    返回成功安装的个数；单个文件失败不拦整体。"""
    xd = prog.pop("extras_dir", None) or ""
    if not xd or not os.path.isdir(xd):
        return 0
    n_x = 0
    for dp, _dn, fns in os.walk(xd):
        for fn in fns:
            src = os.path.join(dp, fn)
            tgt = os.path.join(d, os.path.relpath(src, xd))
            try:
                os.makedirs(os.path.dirname(tgt), exist_ok=True)
                shutil.copyfile(src, tgt)
                n_x += 1
            except Exception:
                pass
    shutil.rmtree(xd, ignore_errors=True)
    prog["extra_files"] = n_x
    return n_x


def _apply_update(prog, root):
    """下载完成后替换自身并重启。运行中的 exe 不能覆盖/删除但**能改名**：
    当前 exe → 小工具_old_<pid>.exe，新包顶上原名，拉起新进程后本进程退出。
    ★ v1.1.23 任意文件推送：包里没有 exe 时只把文件装进程序目录、
    不替换主程序也不重启（重启后生效）。"""
    new = prog.get("dest") or ""
    if prog.get("no_main"):
        d = (os.path.dirname(sys.executable) if getattr(sys, "frozen", False)
             else base_dir())
        n_x = _install_extras(prog, d)
        try:                   # 记录已应用，防止每次启动反复提示
            with open(_marker_file(), "w", encoding="utf-8") as f:
                json.dump({"ver": str(prog.get("ver") or ""), "exe": VERSION,
                           "ts": time.time()}, f)
        except Exception:
            pass
        messagebox.showinfo(
            "更新文件已安装",
            "已安装 %d 个更新文件（本次没有新主程序），重启程序后生效。"
            % n_x, parent=root)
        return True
    if not new or not os.path.exists(new):
        return False
    cur = sys.executable if getattr(sys, "frozen", False) else ""
    if not cur:
        messagebox.showinfo(
            "更新已下载", "开发模式不做自动替换，新版本已下载到：\n%s" % new,
            parent=root)
        return False
    d = os.path.dirname(cur)
    old = os.path.join(d, "小工具_old_%d.exe" % os.getpid())
    try:
        os.rename(cur, old)
    except Exception:
        messagebox.showerror(
            "自动更新失败",
            "无法替换程序文件（可能被杀毒软件拦截），请手动运行新版本：\n%s"
            % new, parent=root)
        return False
    try:
        os.replace(new, cur)
    except Exception:
        try:                       # 回滚：保证当前版本还能继续用
            os.rename(old, cur)
        except Exception:
            pass
        messagebox.showerror("自动更新失败",
                             "替换程序文件失败，请手动安装新版本。", parent=root)
        return False
    # ★ v1.1.23 多文件推送：压缩包里的其余文件装进程序目录（保持相对路径）
    _install_extras(prog, d)
    try:
        subprocess.Popen([cur], cwd=d, creationflags=0x00000008)
    except Exception:
        subprocess.Popen([cur], cwd=d)
    try:                       # ★ v1.1.22 记录已应用的 latest 版本（防
        with open(_marker_file(), "w", encoding="utf-8") as f:
            json.dump({"ver": str(prog.get("ver") or ""), "exe": VERSION,
                       "ts": time.time()}, f)   # 包内版本没跟上时死循环）
    except Exception:
        pass
    return True


def _cleanup_old_updates():
    """启动后台清掉上次自动更新留下的 小工具_old_*.exe
    （老进程退出前文件还占着，删不掉就隔 3 秒重试）。"""
    d = base_dir()
    for _ in range(10):
        left = False
        try:
            names = os.listdir(d)
        except Exception:
            return
        for name in names:
            if name.startswith("小工具_old_") and name.endswith(".exe"):
                try:
                    os.remove(os.path.join(d, name))
                except Exception:
                    left = True
        if not left:
            return
        time.sleep(3)


def _auto_update(gate, root):
    """发现新版本（心跳回调，主线程）：★ v1.1.20 改为**用户自选** ——
    先弹询问「是否立即更新」，同意才下载并自动替换重启；点「否」本次运行
    内不再打扰（下次启动会再次询问）。更新源：服务端托管包（管理页上传）。"""
    latest = gate.latest or {}
    ver = str(latest.get("version") or "")
    if not ver or not gate.newer_version():
        return
    note = (latest.get("note") or "").strip()
    if not messagebox.askyesno(
            "发现新版本",
            "发现新版本 v%s（当前 %s）%s\n\n是否立即更新？\n\n"
            "「是」= 自动下载并重启完成升级\n"
            "「否」= 暂不更新，下次启动再提醒"
            % (ver, VERSION, ("\n\n更新说明：" + note) if note else ""),
            parent=root):
        return                      # 用户选择暂不更新（心跳已记 _notified，本次不再弹）
    prog = {"got": 0, "total": 0, "state": "run", "ver": ver, "dest": ""}
    top = tk.Toplevel(root)
    top.title("正在下载更新")
    top.resizable(False, False)
    top.transient(root)
    tk.Label(top, text="正在下载 v%s（当前 %s）…"
             % (ver, VERSION), fg="#1a5fb4",
             font=("Microsoft YaHei", 10, "bold")).pack(padx=20, pady=(14, 4))
    if note:
        tk.Label(top, text=note, fg="#555", wraplength=330,
                 justify="left").pack(padx=20, pady=(0, 4))
    tk.Label(top, text="下载完成后程序将自动重启，请保持网络畅通，请勿关闭本窗口。",
             fg="#888").pack(padx=20, pady=(0, 6))
    bar = ttk.Progressbar(top, length=330, maximum=1000)
    bar.pack(padx=20, pady=(0, 4))
    lab = tk.Label(top, text="")
    lab.pack(padx=20, pady=(0, 12))

    def poll():
        if prog["state"] == "run":
            if prog["total"]:
                bar["value"] = 1000.0 * prog["got"] / prog["total"]
                lab.config(text="%.1f / %.1f MB" % (
                    prog["got"] / 1048576.0, prog["total"] / 1048576.0))
            else:
                lab.config(text="已下载 %.1f MB" % (prog["got"] / 1048576.0))
            top.after(300, poll)
            return
        try:
            top.destroy()
        except Exception:
            pass
        if prog["state"] == "done" and _apply_update(prog, root):
            return                 # 新进程已拉起，本进程随窗口销毁退出
        if prog["state"] == "fail":
            err = str(prog.get("err") or "").strip()
            messagebox.showerror(
                "更新失败",
                "下载新版本未成功%s，请稍后重启程序再试（启动时会再次询问），\n"
                "或联系管理员获取新版。"
                % (("（%s）" % err) if err else ""), parent=root)
    top.after(300, poll)
    threading.Thread(target=_update_worker, args=(gate, prog),
                     daemon=True).start()


def _start_card_heartbeat(gate, root):
    """拉起心跳线程；掉线/被封/更新通过 root.after 回到主线程处理。"""

    def ui(kind, msg=""):
        def _do():
            if kind == "kick":
                try:
                    messagebox.showerror("卡密已失效",
                                         msg + "\n\n程序将自动退出。",
                                         parent=root)
                except Exception:
                    pass
                try:
                    root.destroy()
                except Exception:
                    pass
            elif kind == "offline":
                try:
                    root.title("%s  [卡密:离线-重试中]" % APP_NAME)
                except Exception:
                    pass
            elif kind == "online":
                try:
                    root.title("%s  [卡密:在线 %s]" % (APP_NAME, gate.remain))
                except Exception:
                    pass
            elif kind == "push":
                # ★ v1.1.30 管理员文字推送
                try:
                    messagebox.showinfo("管理员推送", msg, parent=root)
                except Exception:
                    pass
            elif kind == "update":
                _auto_update(gate, root)
        try:
            root.after(0, _do)
        except Exception:
            pass

    threading.Thread(target=gate.heartbeat_loop, args=(ui,),
                     daemon=True).start()


def main():
    argv = sys.argv[1:]
    if any(a in ("--sign", "--auto-sign", "--headless-sign") for a in argv):
        headless_sign_once()          # 无头：不开界面，签完即退
        return
    if "--daemon" in argv:
        daemon_mode()                 # 无界面常驻：按保存的时间自动签到
        return
    # ★ v1.1.18 自动更新残留清理：上一次「改名让位」的旧 exe 删掉
    threading.Thread(target=_cleanup_old_updates, daemon=True).start()
    # ★ v1.1.16 卡密门禁：先验证卡密，通过才进主界面
    gate = CardGate()
    if not run_card_gate(gate):
        return
    gate.consume_once()               # 计次卡：本次启动扣 1 次
    if not acquire_lock():
        r = tk.Tk()
        r.withdraw()
        messagebox.showwarning(
            "已在运行",
            "程序已经在运行中，请勿重复启动。\n\n"
            "多开会让同一个账号的浏览器 profile 被两个进程争抢，导致启动失败。")
        r.destroy()
        return
    root = tk.Tk()
    App(root)
    if gate.online:
        root.title("%s  [卡密:在线 %s]" % (APP_NAME, gate.remain))
    # 管理员隐藏后台（改内置服务端地址）：主界面里 Ctrl+Alt+U 同样呼出
    root.bind_all("<Control-Alt-u>",
                  lambda e: _open_admin_panel(root, gate))
    root.bind_all("<Control-Alt-U>",
                  lambda e: _open_admin_panel(root, gate))
    # 心跳：服务端据此看在线、可封禁 IP/机器码、可推送文字消息
    _start_card_heartbeat(gate, root)
    try:
        root.mainloop()
    finally:
        release_lock()            # 正常/异常退出都把自己的锁清掉


if __name__ == "__main__":
    main()