# -*- coding: utf-8 -*-
"""_ecc_pure.py —— 纯标准库 P-256（secp256r1 / prime256v1）非对称内核。

为什么有这个文件
================
打包后的便携运行时（payload/runtime/python）**没有 cryptography 包、连
site-packages 都没有**。于是客户端里 `try: from cryptography... except: _HAS_ECC=False`
在打包版里恒为 False → `_ecdh_session()` 直接返回 (None, None) → 非对称"名存实亡"，
实际降级走 PSK 对称。

本模块用**纯 Python**实现 P-256 的 ECDH 与 ECDSA(SHA-256) + SPKI/DER 编解码，
零第三方依赖、离线可用。这样：
  · 小工具端 / 卡密端在没有 cryptography 的机器上也能真正做非对称；
  · 打包期可以用它做 ECC 签名，运行期用它做公钥验签（防篡改/防重打包）。

API（够用就好）
    keygen()                      -> (d:int, Q:(x,y))
    pub_to_der(Q)                 -> SPKI DER (X9.62 uncompressed)
    pub_from_der(der)             -> Q
    ecdh(d, Qpeer)                -> shared_x:int
    hkdf_sha256(ikm, salt, info, length) -> bytes
    sign(msg:bytes, d:int)        -> DER ECDSA 签名
    verify(msg:bytes, sig_der, Q) -> bool

正确性：与 `cryptography`(OpenSSL) 双向交叉验证通过（见 02/_test_ecc_pure.py）。
"""
import hashlib
import hmac
import secrets

# ---------------- 曲线参数（NIST P-256） ----------------
P = 0xffffffff00000001000000000000000000000000ffffffffffffffffffffffff
A = 0xffffffff00000001000000000000000000000000fffffffffffffffffffffffc  # = -3 mod P
B = 0x5ac635d8aa3a93e7b3ebbd55769886bc651d06b0cc53b0f63bce3c3e27d2604b
N = 0xffffffff00000000ffffffffffffffffbce6faada7179e84f3b9cac2fc632551
G = (0x6b17d1f2e12c4247f8bce6e563a440f277037d812deb33a0f4a13945d898c296,
     0x4fe342e2fe1a7f9b8ee7eb4a7c0f9e162bce33576b315ececbb6406837bf51f5)

INF = None  # 无穷远点


# ---------------- 有限域 / 点运算 ----------------
def _inv(a, m):
    return pow(a % m, -1, m)


def _is_on_curve(pt):
    if pt is INF:
        return True
    x, y = pt
    return (y * y - (x * x * x + A * x + B)) % P == 0


def _pt_add(p1, p2):
    if p1 is INF:
        return p2
    if p2 is INF:
        return p1
    x1, y1 = p1
    x2, y2 = p2
    if x1 == x2 and (y1 + y2) % P == 0:
        return INF
    if p1 == p2:
        lam = (3 * x1 * x1 + A) * _inv(2 * y1, P) % P
    else:
        lam = (y2 - y1) * _inv(x2 - x1, P) % P
    x3 = (lam * lam - x1 - x2) % P
    y3 = (lam * (x1 - x3) - y1) % P
    return (x3, y3)


def _pt_mul(k, pt):
    k %= N
    r = INF
    while k:
        if k & 1:
            r = _pt_add(r, pt)
        pt = _pt_add(pt, pt)
        k >>= 1
    return r


# ---------------- 密钥 / ECDH ----------------
def keygen():
    """返回 (私钥 d:int, 公钥 Q:(x,y))。"""
    d = secrets.randbelow(N - 1) + 1
    return d, _pt_mul(d, G)


def ecdh(d, q_peer):
    """ECDH：返回共享点的 x 坐标（int）。双方各用自己的私钥 × 对方公钥。"""
    if not _is_on_curve(q_peer):
        raise ValueError("peer public key not on curve")
    sh = _pt_mul(d, q_peer)
    if sh is INF:
        raise ValueError("invalid shared point")
    return sh[0]


# ---------------- SPKI DER（X9.62 uncompressed） ----------------
# P-256 公钥 SPKI 固定前缀：ecPublicKey + prime256v1
_SPKI_PREFIX = bytes.fromhex(
    "3059301306072a8648ce3d020106082a8648ce3d030107034200")


def pub_to_der(q):
    x, y = q
    return _SPKI_PREFIX + b"\x04" + x.to_bytes(32, "big") + y.to_bytes(32, "big")


def pub_from_der(der):
    """解析 SPKI DER（严格按 P-256 固定结构），返回 (x,y)。"""
    if not isinstance(der, (bytes, bytearray)):
        raise ValueError("der must be bytes")
    der = bytes(der)
    i = der.find(_SPKI_PREFIX)
    if i >= 0:
        body = der[i + len(_SPKI_PREFIX):]
    else:
        # 宽松兜底：找 0x03 0x42 0x00 0x04 标记
        j = der.find(b"\x03\x42\x00\x04")
        if j < 0:
            raise ValueError("not a P-256 SPKI key")
        body = der[j + 3:]
    if len(body) < 65 or body[0] != 0x04:
        raise ValueError("bad point encoding")
    x = int.from_bytes(body[1:33], "big")
    y = int.from_bytes(body[33:65], "big")
    q = (x, y)
    if not _is_on_curve(q):
        raise ValueError("point not on curve")
    return q


# ---------------- HKDF-SHA256（RFC5869，够用子集） ----------------
def _hmac(key, msg):
    return hmac.new(key, msg, hashlib.sha256).digest()


def hkdf_sha256(ikm, salt, info, length):
    if salt is None:
        salt = b"\x00" * 32
    prk = _hmac(salt, ikm)
    out = b""
    t = b""
    ctr = 1
    while len(out) < length:
        t = _hmac(prk, t + info + bytes([ctr]))
        out += t
        ctr += 1
    return out[:length]


# ---------------- ECDSA(SHA-256) ----------------
def _der_sig_encode(r, s):
    def _int(v):
        b = v.to_bytes((v.bit_length() + 7) // 8 or 1, "big")
        if b[0] & 0x80:
            b = b"\x00" + b
        return b"\x02" + bytes([len(b)]) + b
    body = _int(r) + _int(s)
    return b"\x30" + bytes([len(body)]) + body


def _der_sig_decode(sig):
    if not sig or sig[0] != 0x30:
        raise ValueError("bad DER signature")
    # 极简 DER 解析：顺序读两个 INTEGER
    i = 2
    if sig[1] & 0x80:                      # 长长度
        n = sig[1] & 0x7F
        i = 2 + n
    vals = []
    for _ in range(2):
        if sig[i] != 0x02:
            raise ValueError("bad DER int")
        ln = sig[i + 1]
        vals.append(int.from_bytes(sig[i + 2:i + 2 + ln], "big"))
        i += 2 + ln
    return vals[0], vals[1]


def _e_digest(msg):
    h = hashlib.sha256(msg).digest()
    e = int.from_bytes(h, "big")
    # P-256 的 N 为 256 bit，取左侧 256 bit 即全部
    return e


def sign(msg, d):
    """用私钥 d 对 msg 做 ECDSA-P256-SHA256，返回 DER 签名。"""
    e = _e_digest(msg)
    while True:
        k = secrets.randbelow(N - 1) + 1
        pt = _pt_mul(k, G)
        r = pt[0] % N
        if r == 0:
            continue
        s = (_inv(k, N) * (e + r * d)) % N
        if s == 0:
            continue
        return _der_sig_encode(r, s)


def verify(msg, sig_der, q):
    """用公钥 q 验 DER 签名。返回 True/False（任何异常都当验签失败）。"""
    try:
        r, s = _der_sig_decode(sig_der)
    except Exception:
        return False
    if not (1 <= r < N and 1 <= s < N):
        return False
    if not _is_on_curve(q):
        return False
    e = _e_digest(msg)
    w = _inv(s, N)
    u1 = (e * w) % N
    u2 = (r * w) % N
    pt = _pt_add(_pt_mul(u1, G), _pt_mul(u2, q))
    if pt is INF:
        return False
    return pt[0] % N == r


# ---------------- 便捷：PEM 私钥读取（构建/服务端用） ----------------
def load_pem_private_key_d(data):
    """从 PKCS8 PEM（未加密）里取出私钥整数 d。

    只解析 P-256 EC 私钥，够构建脚本/服务端在没有 cryptography 时用。
    """
    import base64 as _b64
    if isinstance(data, str):
        data = data.encode("utf-8")
    txt = data.decode("ascii", "ignore")
    body = "".join(l.strip() for l in txt.splitlines()
                   if l and not l.startswith("-----"))
    der = _b64.b64decode(body)
    # SEC1 ECPrivateKey: SEQUENCE { INTEGER 1, OCTET STRING <d>, ... }
    # PKCS8: SEQUENCE { INTEGER 0, SEQUENCE{...}, OCTET STRING <SEC1> }
    def _read_tlv(buf, i):
        tag = buf[i]
        ln = buf[i + 1]
        j = i + 2
        if ln & 0x80:
            n = ln & 0x7F
            ln = int.from_bytes(buf[j:j + n], "big")
            j += n
        return tag, buf[j:j + ln], j + ln

    def _walk(buf):
        tag, val, _ = _read_tlv(buf, 0)
        if tag != 0x30:
            raise ValueError("not SEQUENCE")
        k = 0
        items = []
        while k < len(val):
            t, v, k = _read_tlv(val, k)
            items.append((t, v))
        return items

    items = _walk(der)
    # PKCS8：第二项是 SEQUENCE(AlgorithmIdentifier)，第三项是 OCTET STRING
    for t, v in items:
        if t == 0x04 and len(v) > 10:
            try:
                inner = _walk(v)
                for t2, v2 in inner:
                    if t2 == 0x04 and 20 <= len(v2) <= 40:
                        return int.from_bytes(v2, "big")
            except Exception:
                pass
    # SEC1 fallback：第一个 OCTET STRING 就是 d
    for t, v in items:
        if t == 0x04 and 20 <= len(v) <= 40:
            return int.from_bytes(v, "big")
    raise ValueError("no EC private scalar found")


# ---------------- 便捷：PEM 私钥写出（服务端纯模式生成密钥时用） ----------------
def _der_len(n):
    if n < 0x80:
        return bytes([n])
    b = n.to_bytes((n.bit_length() + 7) // 8, "big")
    return bytes([0x80 | len(b)]) + b


def pub_of(d):
    """由私钥整数 d 求公钥点 (x,y)。"""
    return _pt_mul(d, G)


def dump_pem_private_key_d(d):
    """把私钥整数 d 写成 SEC1 PEM（'EC PRIVATE KEY'）。

    含 version / privateKey / [0] 曲线 OID / [1] 公钥，OpenSSL / cryptography /
    本模块的 load_pem_private_key_d 都能读回。这样服务端在**没有 cryptography**
    的机器上也能生成并持久化一份标准 P-256 私钥。
    """
    import base64 as _b64
    q = _pt_mul(d, G)
    x, y = q
    body = (b"\x02\x01\x01"                                  # version = 1
            + b"\x04\x20" + d.to_bytes(32, "big")            # privateKey
            + b"\xa0\x0a\x06\x08\x2a\x86\x48\xce\x3d\x03\x01\x07"   # [0] prime256v1
            + b"\xa1\x44\x03\x42\x00\x04"
            + x.to_bytes(32, "big") + y.to_bytes(32, "big"))  # [1] publicKey
    der = b"\x30" + _der_len(len(body)) + body
    b64 = _b64.b64encode(der).decode("ascii")
    lines = [b64[i:i + 64] for i in range(0, len(b64), 64)]
    return ("-----BEGIN EC PRIVATE KEY-----\n" + "\n".join(lines)
            + "\n-----END EC PRIVATE KEY-----\n")


__all__ = ["keygen", "ecdh", "pub_to_der", "pub_from_der", "hkdf_sha256",
           "sign", "verify", "load_pem_private_key_d", "dump_pem_private_key_d",
           "pub_of", "P", "N", "G"]
