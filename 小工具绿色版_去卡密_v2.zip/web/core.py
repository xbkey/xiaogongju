# -*- coding: utf-8 -*-
"""加载原程序模块，并在缺第三方库时注入等价实现。

原则：**不动原源码**。原程序 `zsf_gift_grabber.py` 里的
Engine / DiscuzForumSigner / OneBotWS / CardGate 以及所有模块级工具函数
全部原样复用，网页版只重写「界面与编排」那一层。
"""

import importlib.util
import os
import sys
import threading
import types
import urllib.error

from . import wsclient

LOCK = threading.Lock()
_CORE = None               # 已加载的原程序模块
CORE_PATH = ""             # 实际使用的 zsf_gift_grabber.py 绝对路径

# 默认源码位置（用户附件目录）。可用环境变量 ZSF_SRC 覆盖。
_DEFAULT_DIR = os.path.join(
    os.path.expanduser("~"), "Downloads",
    "小工具源码网络版等2项文件", "小工具源码")

_SRC_FILE = "zsf_gift_grabber.py"


def _read_src_hint(here):
    """支持 SRC_DIR.txt：里面写一行源码目录，方便用户手动指定。"""
    try:
        with open(os.path.join(here, "SRC_DIR.txt"), "r", encoding="utf-8") as f:
            for line in f:
                line = line.strip().strip('"')
                if line and not line.startswith("#"):
                    return line
    except Exception:
        pass
    return ""


def find_src_dir():
    """定位原程序源码目录。

    优先级：环境变量 ZSF_SRC > SRC_DIR.txt > 目标目录自带
            > 上一级目录 > 上一级的子目录 > 默认下载目录。
    """
    here = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))  # zsf-web/
    cands = []

    env = (os.environ.get("ZSF_SRC") or "").strip().strip('"')
    if env:
        cands.append(env)

    hint = _read_src_hint(here)
    if hint:
        cands.append(hint if os.path.isabs(hint)
                     else os.path.join(here, hint))

    # 把源码整包拷进 zsf-web/ 也能直接跑
    cands.append(here)
    cands.append(os.path.join(here, "小工具源码"))

    up = os.path.dirname(here)
    cands.append(up)
    cands.append(os.path.join(up, "小工具源码"))

    # 同级目录扫描（例如 zsf-web 和 小工具源码 并排放在同一个文件夹里）
    try:
        for nm in sorted(os.listdir(up)):
            p = os.path.join(up, nm)
            if os.path.isdir(p):
                cands.append(p)
    except Exception:
        pass

    cands.append(_DEFAULT_DIR)

    seen = set()
    for d in cands:
        if not d:
            continue
        d = os.path.abspath(d)
        if d in seen:
            continue
        seen.add(d)
        if os.path.isfile(os.path.join(d, _SRC_FILE)):
            return d
    return ""


_WS_BACKEND = None


def _ensure_websocket():
    """没有真 websocket-client 时，用纯标准库实现顶上去。

    原程序所有 `import websocket` 都写在函数内部（延迟导入），
    所以只要在第一次用到之前塞进 sys.modules 就行。

    幂等：桩装进去之后 `import websocket` 当然也能成功，
    所以不能靠 try-import 判断，必须认「是不是我们自己那个模块」。
    """
    global _WS_BACKEND
    if _WS_BACKEND is not None:
        return _WS_BACKEND
    if sys.modules.get("websocket") is wsclient:
        _WS_BACKEND = "builtin(web/wsclient.py)"
        return _WS_BACKEND
    try:
        import websocket  # noqa: F401
        _WS_BACKEND = "websocket-client"
    except Exception:
        sys.modules["websocket"] = wsclient
        _WS_BACKEND = "builtin(web/wsclient.py)"
    return _WS_BACKEND


class _AnyStub(object):
    """万能桩对象：任何属性访问/调用都返回另一个桩。

    只在 tkinter 缺失时用于让原模块「能 import 成功」——网页版永远不建窗口，
    所有界面代码路径都不会被执行，所以桩不会真的被调用。
    """

    __slots__ = ("_name",)

    def __init__(self, name="stub"):
        object.__setattr__(self, "_name", name)

    def __getattr__(self, item):
        return _AnyStub("%s.%s" % (self._name, item))

    def __setattr__(self, k, v):
        pass

    def __call__(self, *a, **k):
        return _AnyStub("%s()" % self._name)

    def __getitem__(self, k):
        return _AnyStub("%s[..]" % self._name)

    def __setitem__(self, k, v):
        pass

    def __delitem__(self, k):
        pass

    def __iter__(self):
        return iter(())

    def __len__(self):
        return 0

    def __bool__(self):
        return False

    def __enter__(self):
        return self

    def __exit__(self, *a):
        return False

    def __repr__(self):
        return "<tk-stub %s>" % self._name


def _install_tk_stub():
    """tkinter 装不上（精简版 Python）时注入桩模块。

    原程序顶部有 `import tkinter as tk` / `from tkinter import ttk, ...`，
    但网页版只用它的 Engine / DiscuzForumSigner / OneBotWS / CardGate，
    一行界面代码都不跑，所以桩模块完全够用。
    """
    if "tkinter" in sys.modules:
        return False
    mod = types.ModuleType("tkinter")

    def _ga(attr, _n="tkinter"):
        return _AnyStub("%s.%s" % (_n, attr))

    mod.__getattr__ = _ga
    sys.modules["tkinter"] = mod
    for sub in ("ttk", "messagebox", "filedialog", "simpledialog",
                "scrolledtext", "font", "constants"):
        sm = types.ModuleType("tkinter." + sub)

        def _gs(attr, _n="tkinter." + sub):
            return _AnyStub("%s.%s" % (_n, attr))

        sm.__getattr__ = _gs
        sys.modules["tkinter." + sub] = sm
    return True


def tk_stub_used():
    return getattr(sys.modules.get("tkinter"), "_zsf_stub", False)


# ★ 与老版本卡密服务端的兼容层（原源码一个字不改）
# 现象：卡密端报「无法连接卡密服务端，请检查网络或联系管理员」，
#       但 TCP 通、远端 /api/verify 也在 —— 只有 /api/challenge 返回 404。
# 原因：客户端 v1.1.31 起每次请求前先领一次性挑战码（GET/POST /api/challenge）
#       做 HMAC 握手；而**远端跑的是没有这个接口的老服务端**。
#       原程序 _challenge() 不吞异常，404 直接抛出 → 被 verify() 当成"连不上"。
# 修法：原程序 _card_post 本来就写成 `nonce = _challenge(...)` + `if nonce:`
#       —— 设计上就允许"拿不到挑战码就不带握手"（老协议）。
#       所以加载后把 _challenge 包一层：**只有**服务端明确答 404（接口不存在）
#       才退回空挑战码；网络错误照旧抛出，不掩盖真实的连不上的问题。
def _install_legacy_card_compat(mod):
    orig = getattr(mod, "_challenge", None)
    if not callable(orig):
        return "skip"

    def _challenge_soft(base, timeout=8):
        try:
            return orig(base, timeout)
        except urllib.error.HTTPError as ex:
            if ex.code == 404:
                return ""          # 老服务端没有 /api/challenge → 走无握手旧协议
            raise
    mod._challenge = _challenge_soft
    return "on"


def load():
    """加载并缓存原程序模块。多次调用只加载一次。"""
    global _CORE, CORE_PATH
    with LOCK:
        if _CORE is not None:
            return _CORE
        # ★ 必须最先做：原模块里所有 `import websocket` 都写在函数内部（延迟导入），
        #   一旦漏了这一步，第一次用浏览器/QQ 就会 ModuleNotFoundError。
        #   打包的运行时里并没有 websocket 包，所以这步不能靠调用方自觉。
        _ensure_websocket()
        src = find_src_dir()
        if not src:
            raise RuntimeError(
                "没找到 zsf_gift_grabber.py。请把网页版放到小工具源码目录下，"
                "或设置环境变量 ZSF_SRC 指向源码目录。")
        if src not in sys.path:
            sys.path.insert(0, src)      # 让 _card_embed 等同级模块可导入
        # tkinter 缺失（精简版 Python）→ 注入桩模块，保证原模块能 import
        try:
            import tkinter  # noqa: F401
        except Exception:
            if _install_tk_stub():
                sys.modules["tkinter"]._zsf_stub = True
        path = os.path.join(src, _SRC_FILE)
        # ★ 2026-10-05 加固：EXE 里这份源码是**密文** —— 有 _zsfc（加固启动器装的）
        #   就在内存里解密加载；没有（开发态 / 明文文件夹版）就退回标准加载。
        try:
            import _zsfc
        except Exception:
            _zsfc = None
        if _zsfc is not None:
            mod = _zsfc.load_module("zsf_core", path)
        else:
            spec = importlib.util.spec_from_file_location("zsf_core", path)
            mod = importlib.util.module_from_spec(spec)
            sys.modules["zsf_core"] = mod
            spec.loader.exec_module(mod)
        _install_legacy_card_compat(mod)
        _CORE = mod
        CORE_PATH = path
        return mod


def ws_backend():
    """当前用的是真库还是内置实现（启动日志里说明一下）。"""
    return _ensure_websocket()
