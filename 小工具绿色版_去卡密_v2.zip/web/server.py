# -*- coding: utf-8 -*-
"""网页版 HTTP 服务（纯标准库：ThreadingHTTPServer + SSE 实时推送）。

不依赖任何第三方包，双击 run_web.py / 启动网页版.bat 就能用。

接口一览
    GET  /                        网页界面
    GET  /api/state               全量状态（首屏 + 轮询兜底）
    GET  /api/events              SSE：日志 / 状态 / 事件实时推送
    GET  /api/logs?ch=&n=         取某个频道的日志尾巴
    POST /api/logs/clear          清空日志
    POST /api/gift/*              礼包领取（账号/检查在线/扫码登录/领取/设置/浏览器策略）
    POST /api/forum/*             论坛签到（列表/登录/签到/停止/设置）
    POST /api/qq/*                QQ 群签到（连接/群列表/签到/点赞/监测）
    POST /api/card/*              卡密激活 / 换卡 / 重试
    POST /api/notice/*            公告（卡密端文字推送的落地副本：标记已读/清空）
    POST /api/set_port            改监听端口（写入设置并热切换监听）
    GET  /api/ping                健康检查
"""

import json
import mimetypes
import os
import socket
import sys
import threading
import time
import traceback
import urllib.parse
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

from . import core
from . import guard
from . import settings as wsettings
from .logs import BUS
from .service import get_service, mask_addr, client_ctx

STATIC_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "static")
APP_TITLE = "小工具 网页版"


def _read_body(handler):
    try:
        n = int(handler.headers.get("Content-Length") or 0)
    except Exception:
        n = 0
    if n <= 0:
        return {}
    raw = handler.rfile.read(n)
    if not raw:
        return {}
    try:
        data = json.loads(raw.decode("utf-8", "replace"))
        return data if isinstance(data, dict) else {"_": data}
    except Exception:
        return {}


class Handler(BaseHTTPRequestHandler):
    protocol_version = "HTTP/1.1"
    server_version = "zsf-web"

    # ------------------------------------------------------------ 基础输出
    def log_message(self, fmt, *args):
        # 静态资源/心跳日志不刷屏，只把错误写进内存日志
        try:
            if "/api/ping" in str(args[0] if args else ""):
                return
        except Exception:
            pass

    def handle_one_request(self):
        """浏览器关标签页 / SSE 断流是常态，别让它往控制台喷一屏堆栈。"""
        try:
            return BaseHTTPRequestHandler.handle_one_request(self)
        except (ConnectionResetError, ConnectionAbortedError,
                BrokenPipeError, TimeoutError):
            self.close_connection = True

    def handle(self):
        try:
            return BaseHTTPRequestHandler.handle(self)
        except (ConnectionResetError, ConnectionAbortedError,
                BrokenPipeError, TimeoutError):
            self.close_connection = True

    def _send(self, code, body, ctype="application/json; charset=utf-8",
              extra=None):
        if isinstance(body, (dict, list)):
            body = json.dumps(body, ensure_ascii=False)
        if isinstance(body, str):
            body = body.encode("utf-8")
        self.send_response(code)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        for k, v in (extra or {}).items():
            self.send_header(k, v)
        self.end_headers()
        try:
            self.wfile.write(body)
        except Exception:
            pass

    def _json(self, obj, code=200):
        self._send(code, obj)

    def _err(self, msg, code=400):
        self._send(code, {"ok": False, "msg": str(msg)})

    # ------------------------------------------------------------ GET
    def do_GET(self):
        u = urllib.parse.urlparse(self.path)
        path = u.path
        if path in ("/", "/index.html"):
            return self._serve_static("index.html")
        if path == "/api/ping":
            return self._json({"ok": True, "ts": time.time()})
        if path == "/api/events":
            return self._sse()
        if path == "/api/state":
            svc = get_service()
            # ★ net 也要带上：网页「设置 → 访问端口」靠它显示当前端口/地址。
            #   注意：这里必须和 ROUTES["/api/state"]（api_state）保持一致，
            #   do_GET 是走这条内联分支的，不要只改那边。
            return self._json({"ok": True,
                               "state": svc.state(self._client_ctx()),
                               "net": net_info()})
        if path == "/api/logs":
            # ★ 2026-10-06：日志也要过门禁 —— 否则「别的 IP」不激活就能翻日志
            if not self._gate_or_403():
                return
            q = urllib.parse.parse_qs(u.query)
            ch = (q.get("ch") or ["main"])[0]
            n = int((q.get("n") or ["400"])[0] or 400)
            return self._json({"ok": True, "ch": ch, "lines": BUS.tail(ch, n),
                               "status": BUS.status()})
        if path.startswith("/static/"):
            return self._serve_static(path[len("/static/"):])
        if path == "/favicon.ico":
            return self._send(204, b"", "image/x-icon")
        return self._err("not found: %s" % path, 404)

    def _serve_static(self, rel):
        rel = rel.replace("\\", "/").lstrip("/")
        # 防目录穿越
        full = os.path.normpath(os.path.join(STATIC_DIR, rel))
        if not full.startswith(os.path.normpath(STATIC_DIR)):
            return self._err("bad path", 403)
        if not os.path.isfile(full):
            return self._err("no such file", 404)
        ctype = mimetypes.guess_type(full)[0] or "application/octet-stream"
        if ctype.startswith("text/") or ctype in ("application/javascript",):
            ctype += "; charset=utf-8"
        try:
            # ★ 2026-10-05 加固：静态文件在 EXE 里是**密文** —— 交给 _zsfc 内存解密。
            try:
                import _zsfc
            except Exception:
                _zsfc = None
            if _zsfc is not None:
                data = _zsfc.read(full)
            else:
                with open(full, "rb") as f:
                    data = f.read()
        except Exception as ex:
            return self._err(ex, 500)
        self._send(200, data, ctype)

    def _sse(self):
        # ★ 2026-10-06：未激活的「别的 IP」只放行 card / kill 两种事件 ——
        #   二维码、日志、论坛登录表单这些敏感流一律不推（否则换个机器打开网页
        #   就能把服务器浏览器的登录二维码截走）。
        locked = self._client_locked()
        q = BUS.subscribe()
        try:
            self.send_response(200)
            self.send_header("Content-Type", "text/event-stream; charset=utf-8")
            self.send_header("Cache-Control", "no-cache")
            self.send_header("Connection", "keep-alive")
            self.send_header("X-Accel-Buffering", "no")
            self.end_headers()
            # 首包：把当前状态位推一遍，避免前端要等下一次事件才显示
            init = {"t": "hello", "locked": locked,
                    "status": {} if locked else BUS.status()}
            self.wfile.write(("data: %s\n\n" % json.dumps(init, ensure_ascii=False))
                             .encode("utf-8"))
            self.wfile.flush()
            while True:
                try:
                    item = q.get(timeout=15)
                    if locked and not _sse_allowed_when_locked(item):
                        continue
                    payload = "data: %s\n\n" % json.dumps(item, ensure_ascii=False)
                except Exception:
                    payload = ": ping\n\n"          # 心跳，防中间层断链
                self.wfile.write(payload.encode("utf-8"))
                self.wfile.flush()
        except Exception:
            pass
        finally:
            BUS.unsubscribe(q)

    # ------------------------------------------------------------ POST
    def do_POST(self):
        u = urllib.parse.urlparse(self.path)
        path = u.path
        try:
            body = _read_body(self)
        except Exception:
            body = {}
        try:
            fn = ROUTES.get(path)
            if fn is None:
                return self._err("未知接口：%s" % path, 404)
            fn(self, body, urllib.parse.parse_qs(u.query))
        except Exception as ex:
            BUS.log("main", "接口 %s 异常：%s" % (path, ex))
            BUS.log("main", traceback.format_exc().strip().splitlines()[-1])
            self._err("服务端异常：%s" % ex, 500)

    # ------------------------------------------------------------ 工具
    def _svc(self):
        return get_service()

    def _client_ctx(self):
        """这次请求的「访问地址」上下文（用于「按访问地址的卡密门禁」）。

        ★ 2026-10-09：维度从「客户端 IP」升级为「IP + Host/X-Forwarded-For」——
        走反向代理 / frp / 隧道时对端会被看成本机（127.0.0.1），此时改用 Host 或
        XFF 区分；换个访问网址进去同样要重新输卡密（见 service.client_ctx）。
        """
        try:
            ip = self.client_address[0] if self.client_address else ""
        except Exception:
            ip = ""
        ip = str(ip or "")
        if ip.startswith("::ffff:"):
            ip = ip[7:]
        try:
            host = self.headers.get("Host") if self.headers else ""
        except Exception:
            host = ""
        try:
            xff = self.headers.get("X-Forwarded-For") if self.headers else ""
        except Exception:
            xff = ""
        try:
            return client_ctx(ip, host, xff)
        except Exception:
            return None

    def _client_locked(self):
        """这个「访问地址」现在是不是被卡密门闩挡着。"""
        try:
            open_, _msg = self._svc().card_gate_open(self._client_ctx())
            return not open_
        except Exception:
            return True

    def _gate_or_403(self):
        """卡密被踢下线后锁住业务接口（等价 EXE 版自动退出）。

        ★ 2026-10-06：带上访问地址 —— 别的机器 / 别的 IP 的浏览器必须自己
        激活过一次卡密，否则同样 403（宿主回环直连不受影响）。
        """
        svc = self._svc()
        open_, msg = svc.card_gate_open(self._client_ctx())
        if not open_:
            self._err(msg, 403)
            return None
        return svc


# ======================================================================
# 路由实现
# ======================================================================
def api_state(h, body, q):
    h._json({"ok": True, "state": h._svc().state(h._client_ctx()),
             "net": net_info()})


def api_logs_clear(h, body, q):
    svc = h._gate_or_403()
    if not svc:
        return
    ch = str(body.get("ch") or "").strip() or None
    BUS.clear(ch)
    h._json({"ok": True})


# ---------------- 礼包领取 ----------------
def api_gift_cfg(h, body, q):
    svc = h._gate_or_403()
    if not svc:
        return
    h._json({"ok": True, "cfg": svc.update_cfg(body.get("patch") or body)})


def api_gift_detect(h, body, q):
    svc = h._gate_or_403()
    if not svc:
        return
    svc.detect_async()
    h._json({"ok": True})


def api_gift_browser(h, body, q):
    svc = h._gate_or_403()
    if not svc:
        return
    h._json(svc.pick_browser_path(body.get("path")))

def api_gift_acc_add(h, body, q):
    svc = h._gate_or_403()
    if not svc:
        return
    h._json(svc.add_account(body.get("id"), body.get("name"), body.get("game")))


def api_gift_acc_update(h, body, q):
    svc = h._gate_or_403()
    if not svc:
        return
    h._json(svc.update_account(body.get("id"), body))


def api_gift_acc_del(h, body, q):
    svc = h._gate_or_403()
    if not svc:
        return
    h._json(svc.del_account(body.get("id")))


def api_gift_acc_import(h, body, q):
    svc = h._gate_or_403()
    if not svc:
        return
    h._json(svc.import_accounts(body.get("accounts") or []))


def api_gift_login(h, body, q):
    svc = h._gate_or_403()
    if not svc:
        return
    h._json(svc.login(body.get("id")))


def api_gift_online(h, body, q):
    """★ 检查：核对**全部**账号是否在线（登录态）。

    用户要求：在「删除账号」后面加一个【检查】按钮，一键检查所有账号是否在线。
    核对走原有的 _check_worker（与登录/领取同一条判断逻辑），结果由
    `bus.event("accounts")` 实时推到账号表的「登录态」列，进度看日志。
    """
    svc = h._gate_or_403()
    if not svc:
        return
    if svc.checking:
        return h._json({"ok": False, "msg": "正在检查中，稍等一下…"})
    if svc.running:
        return h._json({"ok": False, "msg": "任务运行中，先不检查（避免抢同一个 profile）"})
    if not svc.accounts:
        return h._json({"ok": False, "msg": "还没有账号，先添加账号"})
    n = len(svc.accounts)
    if not svc.check_accounts():
        return h._json({"ok": False, "msg": "检查没能开始（稍后再试）"})
    return h._json({"ok": True, "msg": "已开始检查 %d 个账号是否在线…" % n})


def api_gift_qr(h, body, q):
    """★ 需求⑬：取「服务器浏览器里那张扫码二维码」。

    工具挂在服务器上时，扫码框是在服务器那台机器的浏览器里弹出来的 ——
    人在别的电脑上打开网页是看不到的。登录等待期间后端会把那张码截下来
    经 SSE（kind=qr）告诉网页「有码了」，网页再来这里取图。
    刷新页面 / 换台电脑都拿得到同一张；没在扫码时返回 qr=None。
    """
    svc = h._gate_or_403()
    if not svc:
        return
    h._json(svc.qr_state())


# ---------------- ★ 需求⑱：论坛登录「外网填表」 ----------------
def api_forum_form(h, body, q):
    """取当前论坛登录表单状态（有没有验证码 / 验证码图 / 是不是密保页）。"""
    svc = h._gate_or_403()
    if not svc:
        return
    h._json(svc.forum_form_state())


def api_forum_form_submit(h, body, q):
    """把网页上填的账号 / 密码 / 验证码写回服务器浏览器并提交。

    ★ 2026-10-09：已删除「手机号 + 短信验证码」登录，只认账号 / 密码 / 图形验证码。
    """
    svc = h._gate_or_403()
    if not svc:
        return
    h._json(svc.forum_form_submit(
        user=body.get("user") or body.get("username") or "",
        pwd=body.get("pass") or body.get("password") or "",
        cap=body.get("cap") or body.get("captcha") or "",
        answer=body.get("answer") or "",
        mode=body.get("mode") or ""))


def api_forum_form_refresh_cap(h, body, q):
    """★ 2026-09-26：外网点验证码 → 换一张（代点那张图）。"""
    svc = h._gate_or_403()
    if not svc:
        return
    h._json(svc.forum_form_refresh_cap())


def api_forum_form_close(h, body, q):
    svc = h._svc()
    # 用户自己点「关闭」→ force=True，连失败状态一起清掉
    h._json(svc.forum_form_close(force=True))


def api_gift_run(h, body, q):
    svc = h._gate_or_403()
    if not svc:
        return
    ids = body.get("ids") or None
    if isinstance(ids, str):
        ids = [x.strip() for x in ids.split(",") if x.strip()]
    h._json(svc.run(ids))


def api_gift_stop(h, body, q):
    svc = h._svc()
    h._json(svc.stop())


# ---------------- 论坛签到 ----------------
def api_forum_add(h, body, q):
    svc = h._gate_or_403()
    if not svc:
        return
    h._json(svc.forum_add(body.get("name"), body.get("url")))


def api_forum_del(h, body, q):
    svc = h._gate_or_403()
    if not svc:
        return
    h._json(svc.forum_del(body.get("base")))


def api_forum_login(h, body, q):
    svc = h._gate_or_403()
    if not svc:
        return
    h._json(svc.forum_login(body.get("base"), body.get("name"),
                            body.get("account_name") or "",
                            body.get("account_id") or None))


def api_forum_sign(h, body, q):
    svc = h._gate_or_403()
    if not svc:
        return
    targets = body.get("targets") or None
    h._json(svc.forum_sign(targets))


def api_forum_stop(h, body, q):
    svc = h._svc()
    h._json(svc.forum_stop_all())


def api_forum_clear(h, body, q):
    svc = h._gate_or_403()
    if not svc:
        return
    base = body.get("base")
    if base:
        h._json(svc.forum_clear_cookie(base, body.get("account_id") or None))
    else:
        h._json(svc.forum_clear_all())


def api_forum_account_del(h, body, q):
    svc = h._gate_or_403()
    if not svc:
        return
    h._json(svc.forum_account_del(body.get("base"), body.get("account_id")))


def api_forum_account_rename(h, body, q):
    svc = h._gate_or_403()
    if not svc:
        return
    h._json(svc.forum_account_rename(body.get("base"), body.get("account_id"),
                                     body.get("name")))


def api_forum_settings(h, body, q):
    svc = h._gate_or_403()
    if not svc:
        return
    h._json(svc.forum_save_settings(body.get("patch") or body))


# ---------------- QQ 群签到 ----------------
def api_qq_settings(h, body, q):
    svc = h._gate_or_403()
    if not svc:
        return
    h._json(svc.qq_save_settings(body.get("patch") or body))


def api_qq_groups(h, body, q):
    svc = h._gate_or_403()
    if not svc:
        return
    h._json(svc.qq_save_groups(body.get("cid"), body.get("groups") or {}))


def api_qq_select_all(h, body, q):
    svc = h._gate_or_403()
    if not svc:
        return
    h._json(svc.qq_set_all(str(body.get("action") or "all"),
                           body.get("cid") or None))


def api_qq_conn_add(h, body, q):
    svc = h._gate_or_403()
    if not svc:
        return
    h._json(svc.qq_conn_add(body.get("url"), body.get("token"),
                            body.get("remark")))


def api_qq_conn_edit(h, body, q):
    svc = h._gate_or_403()
    if not svc:
        return
    h._json(svc.qq_conn_edit(body.get("cid"), body.get("url"),
                             body.get("token"), body.get("remark")))


def api_qq_conn_del(h, body, q):
    svc = h._gate_or_403()
    if not svc:
        return
    h._json(svc.qq_conn_del(body.get("cid")))


def api_qq_connect(h, body, q):
    svc = h._gate_or_403()
    if not svc:
        return
    h._json(svc.qq_connect(body.get("cid") or None,
                           body.get("url"), body.get("token")))


def api_qq_disconnect(h, body, q):
    svc = h._svc()
    h._json(svc.qq_disconnect(body.get("cid") or None))


def api_qq_refresh(h, body, q):
    svc = h._gate_or_403()
    if not svc:
        return
    h._json(svc.qq_refresh(body.get("cid") or None))


def api_qq_sign(h, body, q):
    svc = h._gate_or_403()
    if not svc:
        return
    confirm = bool(body.get("confirm", True))
    gids = body.get("gids") or None
    cids = body.get("cids") or None
    h._json(svc.qq_sign(confirm=confirm, gids=gids, cids=cids))


def api_qq_stop(h, body, q):
    svc = h._svc()
    h._json(svc.qq_stop_all())


def api_qq_like(h, body, q):
    svc = h._gate_or_403()
    if not svc:
        return
    users = body.get("users")
    if isinstance(users, str):
        try:
            users = svc.C.parse_qq_list(users)
        except Exception:
            users = None
    h._json(svc.qq_like(users, body.get("cid") or None))


# ---------------- QQ 反向 WS（★ 2026-10-09）----------------
def api_qq_reverse_status(h, body, q):
    svc = h._svc()
    h._json({"ok": True, "rev": svc.qq_rev_status()})


def api_qq_reverse_start(h, body, q):
    svc = h._gate_or_403()
    if not svc:
        return
    h._json(svc.qq_rev_start(body.get("host"), body.get("port"),
                             body.get("path"), body.get("token")))


def api_qq_reverse_stop(h, body, q):
    svc = h._svc()
    h._json(svc.qq_rev_stop())


# ---------------- 卡密 ----------------
def api_card_status(h, body, q):
    svc = h._svc()
    ctx = h._client_ctx()
    gate_open, gate_msg = svc.card_gate_open(ctx)
    h._json({"ok": True, "card": svc.card, "gate_open": gate_open,
             "gate_msg": gate_msg,
             "client_ip": (ctx.label if ctx is not None else ""),
             "client_key": (ctx.key if ctx is not None else "")})


def api_card_verify(h, body, q):
    svc = h._svc()
    # ★ 2026-10-06：把访问地址传进去 —— 别的 IP 激活成功后要解锁它自己
    # ★ 2026-10-09：ctx 含 IP + Host/XFF，代理场景也能区分
    h._json(svc.card_verify(body.get("card"), ctx_arg=h._client_ctx()))


def api_card_retry(h, body, q):
    """重新校验卡密（等价原版重启软件）：本地存过卡密就直接重验。

    给「初始化失败 / 校验卡住」留个逃生口，避免用户只能重启进程。
    """
    svc = h._svc()
    svc._spawn(svc.card_init, name="card-init")
    h._json({"ok": True})


# ---------------- 公告（卡密端「文字推送」的落地副本） ----------------
def api_notice_read(h, body, q):
    """全部标记已读：公告区的新内容不再显示红色。"""
    svc = h._svc()
    h._json(svc.mark_notices_read())


def api_notice_clear(h, body, q):
    """清空本地公告记录（卡密端的推送队列不受影响）。"""
    svc = h._svc()
    h._json(svc.clear_notices())


# ★ 用户要求：小工具端（网页版）设置页里的 诊断 / 文字推送 / 管理后台 三块已删除，
#   所以这两个后端接口一并撤掉 —— 客户端不再有任何指向卡密端管理功能的入口：
#     /api/card/admin  管理后台转发代理（转发到卡密服务端 /admin/api/*）
#     /api/diag        网页版环境自检（排障改用命令行 `run_web.py --check`）
#   管理相关操作请在卡密端自己的管理页（http://<卡密端>:<端口>/admin）里做。


# ---------------- 设置：监听端口 ----------------
def api_set_port(h, body, q):
    """改监听端口：写进设置文件 + 热切换监听（不用重启程序）。

    先落盘再切换 —— 万一切换失败就回滚，避免「这次失败、下次启动又撞同一个端口」。
    """
    svc = h._gate_or_403()
    if not svc:
        return
    newp = wsettings.valid_port(body.get("port"))
    if newp is None:
        return h._err("端口要填 %d~%d 之间的整数" % (wsettings.PORT_MIN, wsettings.PORT_MAX))

    cur = net_info()["port"]
    if newp == cur:
        wsettings.set_port(newp)
        return h._json({"ok": True, "port": newp, "url": net_info()["url"],
                        "msg": "端口没变"})

    wsettings.set_port(newp)
    try:
        switch_port(newp)
    except OSError as ex:
        wsettings.set_port(cur)
        return h._err("端口 %d 用不了（多半被别的程序占用）：%s" % (newp, ex))
    except Exception as ex:
        wsettings.set_port(cur)
        return h._err("切换端口失败：%s" % ex)

    url = net_info()["url"]
    svc.log("[设置] 监听端口已改为 %d，新地址 %s" % (newp, url))
    h._json({"ok": True, "port": newp, "url": url})


def api_set_lan(h, body, q):
    """勾选「允许其它电脑访问」：把绑定地址在 127.0.0.1 / 0.0.0.0 之间切换。

    ★ 用户报的「丢到服务器上、别的电脑打不开」绝大多数就是这里：
      默认只绑 127.0.0.1，别的电脑必然连不上。以前只能靠命令行加 --lan，
      现在网页里勾一下就行，而且会记住（下次启动自动生效）。
    """
    svc = h._gate_or_403()
    if not svc:
        return
    raw = body.get("lan")
    if isinstance(raw, str):
        want = raw.strip().lower() in ("1", "true", "yes", "on")
    else:
        want = bool(raw)

    if bool(net_info()["lan"]) == want:
        wsettings.set_lan(want)
        return h._json({"ok": True, "net": net_info(), "msg": "没有变化"})

    try:
        switch_lan(want)
    except OSError as ex:
        wsettings.set_lan(bool(net_info()["lan"]))   # 回滚：按实际生效的写
        return h._err("切换失败：%s（端口可能被别的程序占用）" % ex)

    wsettings.set_lan(want)
    n = net_info()
    svc.log("[设置] 其它电脑访问：%s（监听 %s:%d）"
            % ("已允许" if want else "已关闭", n["host"], n["port"]))
    h._json({"ok": True, "net": n})


ROUTES = {
    "/api/state": api_state,
    "/api/logs/clear": api_logs_clear,
    "/api/gift/cfg": api_gift_cfg,
    "/api/gift/detect": api_gift_detect,
    "/api/gift/browser": api_gift_browser,
    "/api/gift/accounts": api_gift_acc_add,
    "/api/gift/accounts/update": api_gift_acc_update,
    "/api/gift/accounts/delete": api_gift_acc_del,
    "/api/gift/accounts/import": api_gift_acc_import,
    "/api/gift/login": api_gift_login,
    "/api/gift/online": api_gift_online,
    "/api/gift/qr": api_gift_qr,
    "/api/forum/form": api_forum_form,
    "/api/forum/form/submit": api_forum_form_submit,
    "/api/forum/form/close": api_forum_form_close,
    "/api/forum/form/refresh_cap": api_forum_form_refresh_cap,
    "/api/gift/run": api_gift_run,
    "/api/gift/stop": api_gift_stop,
    "/api/forum/add": api_forum_add,
    "/api/forum/delete": api_forum_del,
    "/api/forum/login": api_forum_login,
    "/api/forum/sign": api_forum_sign,
    "/api/forum/stop": api_forum_stop,
    "/api/forum/clear": api_forum_clear,
    "/api/forum/account/delete": api_forum_account_del,
    "/api/forum/account/rename": api_forum_account_rename,
    "/api/forum/settings": api_forum_settings,
    "/api/qq/settings": api_qq_settings,
    "/api/qq/groups": api_qq_groups,
    "/api/qq/select_all": api_qq_select_all,
    "/api/qq/conn/add": api_qq_conn_add,
    "/api/qq/conn/edit": api_qq_conn_edit,
    "/api/qq/conn/delete": api_qq_conn_del,
    "/api/qq/connect": api_qq_connect,
    "/api/qq/disconnect": api_qq_disconnect,
    "/api/qq/refresh": api_qq_refresh,
    "/api/qq/sign": api_qq_sign,
    "/api/qq/stop": api_qq_stop,
    "/api/qq/like": api_qq_like,
    "/api/qq/reverse/status": api_qq_reverse_status,
    "/api/qq/reverse/start": api_qq_reverse_start,
    "/api/qq/reverse/stop": api_qq_reverse_stop,
    "/api/card/status": api_card_status,
    "/api/card/verify": api_card_verify,
    "/api/card/retry": api_card_retry,
    "/api/notice/read": api_notice_read,
    "/api/notice/clear": api_notice_clear,
    "/api/set_port": api_set_port,
    "/api/set_lan": api_set_lan,
}


def _sse_allowed_when_locked(item):
    """未激活客户端能收到的事件白名单：只放「卡密状态变化 / 被强制关闭」。"""
    if not isinstance(item, dict) or item.get("t") != "event":
        return False
    return item.get("kind") in ("card", "kill")


class Server(ThreadingHTTPServer):
    daemon_threads = True
    allow_reuse_address = True

    def handle_error(self, request, client_address):
        """断连类异常静默处理，其它异常照常打印，方便排障。"""
        ex = sys.exc_info()[1]
        if isinstance(ex, (ConnectionResetError, ConnectionAbortedError,
                           BrokenPipeError, TimeoutError)):
            return
        return ThreadingHTTPServer.handle_error(self, request, client_address)


def _lan_ips():
    """本机所有可被局域网访问的 IPv4（不含回环）。取不到就返回空列表。

    只用主机名解析，不写任何 IP 字面量（本项目硬规矩：源码里不出现明文 IP）。
    """
    ips = []
    try:
        hostname = socket.gethostname()
        try:
            for ip in socket.gethostbyname_ex(hostname)[2]:
                if ip and not ip.startswith("127.") and ip not in ips:
                    ips.append(ip)
        except Exception:
            pass
        if not ips:
            ip = socket.gethostbyname(hostname)
            if ip and not ip.startswith("127."):
                ips.append(ip)
    except Exception:
        pass
    return ips


def _is_lan(host):
    return host in ("0.0.0.0", "::", "") or (host not in ("127.0.0.1", "localhost", "::1"))


def _port_busy(host, port):
    """这个端口是不是已经被占用了。

    ★ 2026-09-25 用户要求「8000 端口如果占用自动顺延 +1」。
      原来这里只有一句 `bind()` 试一下——**在 Windows 上判不出来**：
      Windows 的 SO_REUSEADDR 允许「抢绑一个别人正在 listen 的端口」，
      bind 会成功返回，于是自动顺延永远不触发（浏览器打开后一片空白/连到别的程序）。
      所以改成两步判：
        ① 先 connect 一下：连得上 = 已经有人在监听，铁定占用；
        ② 再试独占 bind：管住 TIME_WAIT 残留、只绑了别的地址这类情况。
    """
    probe = "127.0.0.1" if host in ("0.0.0.0", "::", "") else host
    try:
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            s.settimeout(0.35)
            if s.connect_ex((probe, port)) == 0:
                return True
    except OSError:
        pass
    try:
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            excl = getattr(socket, "SO_EXCLUSIVEADDRUSE", None)
            if excl is not None:            # Windows 专有；其它平台 getattr 拿不到
                try:
                    s.setsockopt(socket.SOL_SOCKET, excl, 1)
                except OSError:
                    pass
            s.bind((probe, port))
            return False
    except OSError:
        return True


def pick_port(host, start=8000, tries=40):
    """从 start 往上找第一个可用端口（占用就 +1 顺延）。

    找不到就原样返回 start —— 让上层照常去 bind，那时会抛 OSError，
    错误信息比在这里吞掉更有用。
    """
    try:
        start = int(start)
    except Exception:
        start = wsettings.DEFAULT_PORT
    for p in range(start, min(start + max(1, int(tries)), 65536)):
        if not _port_busy(host, p):
            return p
    return start


# ---------------- 当前监听信息（「设置」页改端口要用） ----------------
class _Net(object):
    """当前在跑的 HTTP 监听器。改端口时在这里换掉，主循环不用动。"""

    def __init__(self):
        self.lock = threading.Lock()
        self.httpd = None
        self.host = "127.0.0.1"
        self.port = wsettings.DEFAULT_PORT


NET = _Net()
_STOP = threading.Event()


def _serve_loop(httpd):
    try:
        httpd.serve_forever()
    except Exception:
        pass


def net_info():
    """给前端的监听信息。

    ★ 只回 127.0.0.1 的地址：局域网地址属于「明文 IP」，按项目硬规矩
      不进网页、不进任何接口（要查本机 IP 请在那台机器上执行 ipconfig）。
    """
    with NET.lock:
        host, port = NET.host, NET.port
    return {
        "host": "0.0.0.0" if _is_lan(host) else "127.0.0.1",
        "port": int(port),
        "lan": _is_lan(host),
        "url": "http://127.0.0.1:%d/" % port,
    }


def _start_listener(host, port):
    """起一个监听器并记进 NET（serve / switch_port / switch_lan 共用）。"""
    httpd = Server((host, port), Handler)
    threading.Thread(target=_serve_loop, args=(httpd,),
                     daemon=True, name="http").start()
    with NET.lock:
        NET.httpd, NET.host, NET.port = httpd, host, port
    return httpd


def _stop_listener(httpd):
    """只关「接受新连接」的套接字：正在处理本请求的连接不受影响。"""
    if httpd is None:
        return
    try:
        httpd.shutdown()
    except Exception:
        pass
    try:
        httpd.server_close()
    except Exception:
        pass


def switch_port(new_port, new_host=None):
    """把监听热切到新端口（可选同时换绑定地址）。

    **先起新监听、成功了才关旧的** —— 新端口被占用时抛 OSError，
    原来的服务**不受影响**，调用方可以安全地报错回滚。
    """
    with NET.lock:
        old, cur_host, cur_port = NET.httpd, NET.host, NET.port
    if old is None:
        raise OSError("服务尚未就绪")
    host = new_host or cur_host
    if new_port == cur_port and host == cur_host:
        return new_port

    if host != cur_host:
        # 换绑定地址时端口没变、旧套接字还占着这个端口，没法「先起新的」；
        # 只能先关再绑。绑定失败就把原来的恢复回来，尽量不留真空。
        _stop_listener(old)
        with NET.lock:
            NET.httpd = None
        try:
            _start_listener(host, new_port)
        except OSError:
            try:
                _start_listener(cur_host, cur_port)
            except OSError:
                pass
            raise
        return new_port

    _start_listener(host, new_port)
    _stop_listener(old)
    return new_port


def switch_lan(flag):
    """勾选/取消「允许其它电脑访问」：换绑定地址（0.0.0.0 / 127.0.0.1），端口不变。

    ★ 默认**不开**：这个界面本身没有登录（卡密是绑机器的），对局域网敞开等于
      把工具交给同网段的任何人，所以必须用户显式勾选。
    """
    with NET.lock:
        cur_host, cur_port = NET.host, NET.port
    if _is_lan(cur_host) == bool(flag):
        return cur_port
    return switch_port(cur_port, new_host=("0.0.0.0" if flag else "127.0.0.1"))


def serve(host="0.0.0.0", port=8000, open_browser=True):
    """启动 HTTP 服务（阻塞）。返回退出码。

    默认绑 0.0.0.0（对其它电脑开放）——这是「监听方式默认为 0.0.0.0」的要求，
    也是用户报的「丢到服务器上、自己电脑打不开」的根治办法。
    要只绑本机就显式传 host="127.0.0.1"（run_web.py 会按设置文件决定）。
    """
    # 单实例：和 EXE 版共用同一把 app.lock，避免两个进程抢同一个浏览器 profile
    C = core.load()
    if not C.acquire_lock():
        print("!! 程序已在运行中（app.lock 被占用）。多开会让同一账号的浏览器 "
              "profile 被两个进程争抢，请先关掉另一个实例。")
        return 3

    svc = get_service()
    # 机器码同步算一次：card_init 是后台线程（见下），横幅打印时它还没跑完，
    # 直接读 svc.card["machine"] 会拿到空串——而用户要拿这个码去申请卡密。
    try:
        machine = C.get_machine_code()
    except Exception:
        machine = ""
    print(" 机器码   : %s" % (machine or "(读取失败；请看网页『设置』页)"))
    BUS.log("main", "%s %s 启动" % (APP_TITLE, C.VERSION))

    # ★ 2026-10-05 加固（用户要求：禁止被调试 + 加密所有文件）。
    #   硬命中（真调试器 / 硬件断点 / PEB）→ **静默退出**，
    #   不提示、不记日志、不给任何线索；软命中（抓包工具等）只记日志。
    def _guard_hit(hits, msg):
        guard._die()

    threading.Thread(target=lambda: guard.guard(
        mode="block", deep=True, on_hit=_guard_hit),
        daemon=True, name="guard").start()
    # 常驻复检：启动后才挂上调试器也能被逮到
    threading.Thread(target=guard.watchdog, args=(3.0,),
                     daemon=True, name="guard-wd").start()
    for _h in guard.soft():
        try:
            BUS.log("main", "运行环境提示：%s" % _h)
        except Exception:
            pass

    if not os.path.exists(os.path.join(STATIC_DIR, "index.html")):
        print("!! 缺少 web/static/index.html，网页界面无法显示")

    # 卡密门禁（后台线程，不阻塞界面加载；未激活时前端显示激活页）
    threading.Thread(target=svc.card_init, daemon=True, name="card-init").start()
    # 浏览器检测 + 定时调度
    svc.detect_async()
    svc.start_scheduler()

    # ★ 端口被占用就自动 +1 顺延（run_web.py 已经先挑过一轮，
    #   这里兜的是「挑完到绑上之间被别的程序抢走」那一瞬间的竞争）。
    _want = int(port)
    try:
        httpd = Server((host, port), Handler)
    except OSError:
        port = pick_port(host, _want + 1)
        httpd = Server((host, port), Handler)
    if port != _want:
        print(" 端口     : %d 已被占用，已自动顺延到 %d" % (_want, port))

    # 记下当前监听器：网页「设置」页改端口时要在这里换（见 switch_port）
    with NET.lock:
        NET.httpd, NET.host, NET.port = httpd, host, port
    _STOP.clear()

    # ★ 本机浏览器要打开的是回环地址：绑 0.0.0.0 时直接打开 http://0.0.0.0:8000/
    #   在部分浏览器上会被当成非法地址 / 走代理，所以这里单独算一个回环 URL。
    url = "http://127.0.0.1:%d/" % port
    # ★ 控制台/日志里不出现明文客户端 IP：回环就写 localhost，其它一律脱敏
    _shown_host = ("localhost"
                   if host in ("127.0.0.1", "0.0.0.0", "::", "::1", "")
                   else mask_addr(host))
    shown = "http://%s:%d/" % (_shown_host, port)
    print(" 界面地址 : %s" % shown)
    print(" 改端口   : 网页「设置 → 访问端口」里改（改完自动跳新地址，不用重启）")
    if _is_lan(host):
        # 运维自己要照着这个地址在「别的电脑」上打开，所以必须给可用地址；
        # 这是本机自己的地址、只打在这台机器的控制台上（等价于运维自己跑 ipconfig），
        # 不写进网页、不写进任何接口。
        print(" 其它电脑 : 用下面的地址访问（本机防火墙/安全组要放行 %d 端口）" % port)
        ips = _lan_ips()
        if ips:
            for ip in ips:
                print("            http://%s:%d/" % (ip, port))
        else:
            print("            （读不到本机地址，请在服务器上执行 ipconfig 看 IPv4 地址）")
        print("            放行命令（管理员 CMD 里执行一次）：")
        print("            netsh advfirewall firewall add rule name=\"小工具网页版 %d\" "
              "dir=in action=allow protocol=TCP localport=%d" % (port, port))
    else:
        # 只有用户**主动**取消勾选才会走到这里（默认是 0.0.0.0）。
        print(" 其它电脑 : 已改成只让本机访问（只有这台机器能开）。")
        print("            要放开：勾选网页「设置 → 访问端口」里的「允许其它电脑访问」，")
        print("            或加 --lan / --host 0.0.0.0 启动。")
    BUS.log("main", "界面地址 %s" % shown)
    if open_browser:
        try:
            import webbrowser
            threading.Timer(0.8, lambda: webbrowser.open(url)).start()
        except Exception:
            pass
    # 接受连接的循环放在后台线程：主线程只等退出信号。
    #   这样才能支持「网页里改端口」—— switch_port 需要能换掉正在跑的监听器。
    threading.Thread(target=_serve_loop, args=(httpd,),
                     daemon=True, name="http").start()
    try:
        while not _STOP.wait(0.5):
            # ★ 需求⑯：管理员在卡密端点了 封卡/解绑/封IP/封机器码/踢下线 →
            #   这里要求「强制关闭小工具主程序」。service 收到 kill 后会置这个标志，
            #   主循环看到就整进程退出（不是只把接口 403）。
            if get_service().kill_requested():
                print(" 卡密端已要求本机退出（%s），程序即将关闭。"
                      % get_service().kill_reason())
                break
    except KeyboardInterrupt:
        pass
    finally:
        _STOP.set()
        with NET.lock:
            cur, NET.httpd = NET.httpd, None
        if cur is not None:
            try:
                cur.shutdown()
            except Exception:
                pass
            try:
                cur.server_close()
            except Exception:
                pass
        try:
            if svc.engine is not None:
                svc.engine.stop_flag = True
        except Exception:
            pass
        C.release_lock()
    return 0
