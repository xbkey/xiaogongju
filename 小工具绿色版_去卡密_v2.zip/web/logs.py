# -*- coding: utf-8 -*-
"""日志总线：内存环形缓冲 + SSE 广播 + 状态位。

原程序每个页签各有一个 LogBuffer（main / forum / qq），网页版保持同样的
分频道，另外加一条通用事件通道，用于把「账号列表变了 / 领取记录 +1 /
QQ 连接状态变了」这类状态变化实时推给浏览器。
"""

import collections
import queue
import threading
import time
from datetime import datetime

CHANNELS = ("main", "forum", "qq", "card")
MAX_LINES = 3000
MAX_SUBS = 32


class Bus(object):
    def __init__(self):
        self._lock = threading.Lock()
        self._buf = {c: collections.deque(maxlen=MAX_LINES) for c in CHANNELS}
        self._subs = []                      # [queue.Queue]
        self._status = {}                    # 各模块的当前状态短句

    # ------------------------------------------------------------ 日志
    def log(self, channel, msg, ts=True):
        """写一行日志（可跨线程调用）。"""
        if channel not in self._buf:
            channel = "main"
        line = "[%s] %s" % (datetime.now().strftime("%H:%M:%S"), msg) if ts \
            else str(msg)
        with self._lock:
            self._buf[channel].append(line)
        self._push({"t": "log", "ch": channel, "line": line})
        return line

    def log_multi(self, channel, text):
        """把多行文本按行拆开写（原程序习惯一次 insert 多行）。"""
        out = []
        for ln in str(text).replace("\r\n", "\n").split("\n"):
            if ln.strip():
                out.append(self.log(channel, ln, ts=False))
        return out

    def tail(self, channel, n=400):
        if channel not in self._buf:
            return []
        items = list(self._buf[channel])
        return items[-int(n):] if n else items

    def clear(self, channel=None):
        with self._lock:
            targets = CHANNELS if not channel else (channel,)
            for c in targets:
                if c in self._buf:
                    self._buf[c].clear()
        self._push({"t": "cleared", "ch": channel or ""})

    # ------------------------------------------------------------ 状态
    def set_status(self, key, text):
        with self._lock:
            self._status[key] = text
        self._push({"t": "status", "key": key, "text": text})

    def status(self, key=None):
        with self._lock:
            if key is None:
                return dict(self._status)
            return self._status.get(key, "")

    # ------------------------------------------------------------ 事件
    def event(self, kind, data=None):
        """状态变化广播：前端收到后按 kind 拉取对应接口。"""
        self._push({"t": "event", "kind": kind, "data": data, "ts": time.time()})

    # ------------------------------------------------------------ 订阅
    def subscribe(self):
        q = queue.Queue(maxsize=2000)
        with self._lock:
            while len(self._subs) >= MAX_SUBS:
                self._subs.pop(0)
            self._subs.append(q)
        return q

    def unsubscribe(self, q):
        with self._lock:
            try:
                self._subs.remove(q)
            except ValueError:
                pass

    def _push(self, item):
        with self._lock:
            subs = list(self._subs)
        for q in subs:
            try:
                q.put_nowait(item)
            except queue.Full:
                # 浏览器卡住时丢弃最旧的一条，绝不阻塞业务线程
                try:
                    q.get_nowait()
                    q.put_nowait(item)
                except Exception:
                    pass


BUS = Bus()
