# -*- coding: utf-8 -*-
"""小工具 网页版（后端包）。

web/core.py     加载原程序模块（不改原源码）
web/service.py  业务编排（原 App 的逻辑，界面层换成 Bus + REST）
web/server.py   标准库 HTTP 服务 + SSE
web/wsclient.py 纯标准库 WebSocket 客户端（缺 websocket-client 时顶替）
web/logs.py     日志总线
"""

__all__ = ["core", "service", "server", "wsclient", "logs"]
