/* 小工具 网页版 —— 前端逻辑（无框架，纯 DOM） */
'use strict';

const $ = (s, r) => (r || document).querySelector(s);
const $$ = (s, r) => Array.from((r || document).querySelectorAll(s));
const esc = (s) => String(s == null ? '' : s)
  .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
  .replace(/"/g, '&quot;');

let S = null;                 // 最近一次 /api/state 的 state
let NETI = null;              // 最近一次 /api/state 的 net（监听端口等）
let selAcc = '';              // 礼包页选中账号
let logCh = 'main';           // 日志抽屉当前频道
let portTouched = false;      // 用户是否手动改过端口输入框（别被刷新覆盖掉）
let lanTouched = false;       // 用户是否手动动过「允许其它电脑访问」勾选框
const preview = {};           // 各频道最近一行
const MAXLOG = 2000;

/* ============================ 基础请求 ============================ */
async function api(path, body, method) {
  const opt = { method: method || (body === undefined ? 'GET' : 'POST'),
                headers: { 'Content-Type': 'application/json' } };
  if (body !== undefined) opt.body = JSON.stringify(body || {});
  const r = await fetch(path, opt);
  let data = null;
  try { data = await r.json(); } catch (e) { data = { ok: false, msg: 'HTTP ' + r.status }; }
  if (r.status === 403) { onGateClosed(data && data.msg); }
  return data;
}

/* ============================ 提示 ============================ */
function toast(msg, kind) {
  if (!msg) return;
  const d = document.createElement('div');
  d.className = 'toast ' + (kind || '');
  d.textContent = msg;
  $('#toasts').appendChild(d);
  setTimeout(() => { try { d.remove(); } catch (e) {} }, 5200);
}
function confirmBox(text, okText) {
  return new Promise((resolve) => {
    $('#masktext').textContent = text;
    $('#mask-yes').textContent = okText || '是';
    $('#mask-no').classList.remove('hidden');   // 二选一弹窗要把「否」放回来
    $('#mask').classList.remove('hidden');
    const done = (v) => { $('#mask').classList.add('hidden');
      $('#mask-yes').onclick = null; $('#mask-no').onclick = null; resolve(v); };
    $('#mask-yes').onclick = () => done(true);
    $('#mask-no').onclick = () => done(false);
  });
}
/* 只有一个「知道了」的提示弹窗 —— 用于管理员推送 / 服务端告警：
   原桌面版是 messagebox.showinfo（模态、必须点掉），网页版用 toast 一闪就没了
   容易被错过，所以这里改成同样的模态框。 */
function alertBox(text, okText) {
  return new Promise((resolve) => {
    $('#masktext').textContent = text;
    $('#mask-yes').textContent = okText || '知道了';
    $('#mask-no').classList.add('hidden');
    $('#mask').classList.remove('hidden');
    $('#mask-yes').onclick = () => {
      $('#mask').classList.add('hidden');
      $('#mask-no').classList.remove('hidden');
      $('#mask-yes').onclick = null;
      resolve(true);
    };
  });
}

/* ============================ 状态刷新 ============================ */
let refreshTimer = null;
function refresh(delay) {
  clearTimeout(refreshTimer);
  refreshTimer = setTimeout(doRefresh, delay === undefined ? 250 : delay);
}
async function doRefresh() {
  const r = await api('/api/state');
  if (!r || !r.ok) return;
  S = r.state;
  NETI = r.net || null;
  render();
}

function render() {
  if (!S) return;
  $('#ver').textContent = S.app.version;
  $('#chip-src').textContent = S.app.src;
  $('#chip-src').title = '源码目录：' + S.app.src;
  $('#chip-ws').textContent = 'WS: ' + S.app.ws_backend;
  $('#chip-status').textContent = S.gift.status || '就绪';

  renderCard();
  renderNet();
  renderNotice();
  renderGift();
  renderForum();
  renderQQ();
}

/* ============================ 端口 ============================ */
/* ★ 局域网地址属于「明文 IP」，按项目硬规矩不进网页 —— 这里只显示回环地址，
   要查本机 IP 请在那台机器上执行 ipconfig。 */
function renderNet() {
  const n = NETI || {};
  const cur = n.port || 8000;
  const nowEl = $('#set-port-now');
  if (!nowEl) return;                       // 老页面缓存兜底
  nowEl.textContent = cur;
  $('#set-port-url').textContent = n.url || ('http://127.0.0.1:' + cur + '/');
  $('#set-bind-now').textContent = n.host || '0.0.0.0';
  $('#set-lan-now').textContent = n.lan ? '可以访问' : '打不开（只限本机）';
  const box = $('#set-port');
  if (box && !portTouched && !box.value) box.value = cur;
  const cb = $('#set-lan');
  if (cb && !lanTouched) cb.checked = !!n.lan;

  if (n.lan) {
    $('#set-port-hint').innerHTML =
      '<b>默认</b>监听 ' + (n.host || '0.0.0.0') + ':' + cur + '，别的电脑/手机可以打开。' +
      '本机地址在上面「本机地址」里；要给别人用的是 <code>服务器IP:' + cur +
      '</code>（IP 在服务器上执行 <code>ipconfig</code> 看）。';
  } else {
    $('#set-port-hint').innerHTML =
      '你关掉了对外访问：现在只监听 127.0.0.1，也就是<b>只有这台机器能打开</b>。' +
      '想让别的电脑能开，把下面的勾重新勾上。';
  }

  $('#set-lan-hint').innerHTML = n.lan
    ? '别的电脑还是打不开？按顺序查：<br>' +
      '① 服务器防火墙放行端口（管理员 CMD 里执行一次）：<br>' +
      '<code>netsh advfirewall firewall add rule name="小工具 ' + cur +
      '" dir=in action=allow protocol=TCP localport=' + cur + '</code><br>' +
      '② 云服务器（阿里云/腾讯云…）还要在控制台<b>安全组</b>里放行同一个端口；<br>' +
      '③ 地址要填<b>服务器的内网/公网 IP</b>，别填 127.0.0.1；<br>' +
      '④ 家里/公司路由器后面的话，要在路由器上做端口映射。<br>' +
      '<b>不需要对外</b>就取消这个勾（会记住，下次启动只有本机能开）。'
    : '勾上并保存后，会改回监听 0.0.0.0，别的电脑就能打开了（会记住，下次启动自动生效）。' +
      '<br><b>注意</b>：这个界面本身没有登录（卡密是绑机器的），开放后同网段能访问到的人就能操作，' +
      '建议只在内网/公司网用，公网请套一层带账号密码的反代。';
}

/* ============================ 卡密 ============================ */
function renderCard() {
  const c = S.card || {};
  const chip = $('#chip-card');
  let txt = '卡密: ';
  // ★ 2026-10-06：本机（这个访问 IP）没激活过 → 遮罩挡住，先提示它去激活
  if (c.client_locked) txt += '本机未激活';
  else if (c.kicked) txt += '已失效';
  // ★ online===false = 与服务端失去联系。★ 2026-10-09 起已取消离线宽限：
  //   断线即会锁定，这里如实提示（收不到推送、即将失效）。
  else if (c.ok) txt += (c.online === false ? '已断线(即将锁定)·'
                                            : '在线·') + (c.remain || '');
  else if (c.need_activate) txt += '未激活';
  else txt += '校验中';
  chip.textContent = txt;
  chip.className = 'chip ' + (c.kicked || !c.ok || c.client_locked ? 'bad' : 'ok');

  // 卡密三态：checking（校验中，输卡密也没用）/ activate（待激活）/ kicked（已失效）
  // ★ 2026-10-06：client_locked（这个访问 IP 没激活过）永远当「待激活」处理 ——
  //   必须让用户看到卡密输入框，而不是「校验中」。
  const checking = !c.ok && !c.kicked && !c.need_activate && !c.client_locked;
  $('#gate').classList.toggle('hidden', !!c.ok && !c.client_locked);
  $('#gate-row').classList.toggle('hidden', checking);
  $('#gate-wait').classList.toggle('hidden', !checking);
  $('#gate-ver').textContent = S.app.version;
  $('#gate-machine').textContent = c.machine || '-';
  const gcip = $('#gate-client-ip');
  if (gcip) gcip.textContent = c.client_ip || '-';
  // ★ 不再在小工具端展示「服务端」地址（用户要求：小工具端删除；
  //   地址只在卡密端管理页可见，且那边也是脱敏标签）
  // ★ 需求⑯：被卡密端强制关闭时，锁死界面并弹出告知（别再引导「输入新卡密」）
  if (c.kicked && S && S.app && S.app.kill) {
    $('#gate-tip').textContent = c.msg || '本程序已被管理员关闭';
    $('#gate-row').classList.add('hidden');
    $('#gate-wait').classList.add('hidden');
    if (!killShown) killNotice(c.msg);
  } else if (c.kicked) {
    $('#gate-tip').textContent = '卡密已失效：' + (c.msg || '') + '，请输入新卡密继续使用';
  } else if (c.client_locked) {
    // ★ 2026-10-06：别的机器 / 别的 IP / 别的访问网址 —— 说明「本机（地址）」没激活过
    $('#gate-tip').textContent = '此电脑（' + (c.client_ip || '本机') +
      '）未激活卡密，请输入卡密后使用；换一台电脑 / 换一个 IP / 换一个访问网址打开都要重新激活。';
  } else if (checking) $('#gate-tip').textContent = c.msg || '正在校验卡密，请稍候…';
  else $('#gate-tip').textContent = '请输入卡密后开始使用';
  $('#set-card-state').textContent = c.client_locked
    ? '本机未激活'
    : (c.kicked
       ? (S && S.app && S.app.kill ? '已被管理员关闭' : '已失效')
       : (c.ok ? (c.online === false ? '已断线' : '在线') : '未激活'));
  // ★ 需求⑭：剩余时间按服务端给的秒数显示（会自己往前走，不再是个死数字）
  setLeft(c.left_secs, c.remain);
  $('#set-machine').textContent = c.machine || '-';
}
/* ===== ★ 需求⑭：一切时间以「卡密端时间」为准，本机时间只用于每 15 秒推进显示 =====
   用户反馈：「有个卡密一直处于离线」「还有一个卡密一直是 59 分钟从来不变」。
   之前「剩余」直接用服务端给的整句文案（"59分钟"），它只在**心跳那一刻**更新，
   所以两次心跳之间就是个不动的死数。这里改成：拿到 `left_secs` 后本地按
   **服务端时钟**每秒递减着显示，并且短时卡最后一分钟能看到秒在走。 */
let tk = { base: 0, local: 0 };      // 服务端剩余秒数 / 记下时的本机 ms
function fmtLeft(sec) {
  sec = Math.max(0, Math.floor(sec));
  if (sec <= 0) return '已到期';
  const d = Math.floor(sec / 86400), r1 = sec % 86400;
  const h = Math.floor(r1 / 3600), r2 = r1 % 3600;
  const m = Math.floor(r2 / 60), s = r2 % 60;
  if (d) return d + '天' + h + '小时';
  if (h) return h + '小时' + m + '分';
  if (m) return (m < 2) ? (m + '分' + s + '秒') : (m + '分钟');
  return s + '秒';
}
function tickLeft() {
  if (!tk.base) return;
  const el = $('#set-card-remain');
  if (!el) return;
  const gone = Math.floor((Date.now() - tk.local) / 1000);
  el.textContent = fmtLeft(tk.base - gone);
}
function setLeft(secs, fallbackText) {
  const el = $('#set-card-remain');
  if (!el) return;
  if (secs === undefined || secs === null || secs < 0) {
    tk.base = 0;
    el.textContent = fallbackText || '-';
    return;
  }
  tk.base = secs;
  tk.local = Date.now();
  tickLeft();
}

function onGateClosed(msg) {
  toast(msg || '卡密已失效', 'err');
  // ★ 需求⑯：被卡密端强制关闭时，不要提示「重新激活」——
  //   那种情况（封卡/解绑/封IP/封机器码）重填卡密也没用，得找管理员。
  const kill = S && S.app && S.app.kill;
  if (kill && !killShown) killNotice(S.app.kill_msg || msg);
  refresh(0);
}

/* ============================ 公告（卡密端推送） ============================ */
/* ★ 用户要求：小工具端设置前面加一个「公告」，内容就是卡密端「文字推送」发过来的；
   卡密端推来新内容时，公告区把新内容**显示成红色**，读过之后转普通色。
   数据来自 /api/state 的 notice（后端落盘在 公告.json，重启不丢）。 */
function renderNotice() {
  const box = $('#notice-list');
  if (!box) return;
  const n = (S && S.notice) || { list: [], unread: 0 };
  const items = (n.list || []).slice().reverse();   // 新推的排最上面
  const unread = n.unread || 0;

  // 页签同样提示：有未读 → 变红 + 括号里写未读条数
  const tab = $('#tab-notice');
  if (tab) {
    tab.textContent = '📢 公告' + (unread ? '（' + unread + '）' : '');
    tab.classList.toggle('alert', unread > 0);
  }

  if (!items.length) {
    box.className = 'notice-list';
    box.textContent = '（暂无公告）';
  } else {
    box.className = 'notice-list';
    box.innerHTML = items.map((it) => {
      const un = !it.read;
      return '<div class="notice-item' + (un ? ' un' : '') + '">'
        + '<div class="notice-head">' + (un ? '<span class="notice-dot">新</span>' : '')
        + '<span class="notice-ts">' + esc(it.ts || '') + '</span></div>'
        + '<div class="notice-text">' + esc(it.text || '') + '</div></div>';
    }).join('');
  }
  $('#notice-count').textContent = items.length
    ? ('共 ' + items.length + ' 条' + (unread ? ' · 未读 ' + unread : ' · 已全部读过'))
    : '';
}

/* ============================ 礼包领取 ============================ */
function renderGift() {
  const g = S.gift, c = g.cfg;
  const map = { 'cfg-interval': c.interval, 'cfg-limit': c.limit, 'cfg-retry': c.retry,
                'cfg-wait': c.wait_login };
  for (const k in map) { const el = $('#' + k); if (el !== document.activeElement) el.value = map[k]; }
  const cks = { 'cfg-claim-one': c.claim_one,
                'cfg-autowait': c.auto_wait_login,
                'cfg-timer': c.timer_enabled };
  for (const k in cks) { const el = $('#' + k); el.checked = !!cks[k]; }
  const tt = $('#cfg-timer-time');
  if (tt !== document.activeElement) tt.value = c.timer_time || '10:00';

  // 账号表
  const tb = $('#acc-table tbody');
  tb.innerHTML = '';
  let nOk = 0, nOff = 0, nNo = 0;
  g.accounts.forEach((a) => {
    const st = a.status || 'no';
    if (st === 'ok') nOk++; else if (st === 'off') nOff++; else nNo++;
    const tr = document.createElement('tr');
    tr.className = (a.id === selAcc ? 'sel ' : '') + 'st-' + st;
    tr.innerHTML = '<td>' + esc(a.id) + '</td>'
      + '<td class="st-' + st + '">' + esc(a.status_text || '') + '</td>';
    tr.firstChild.onclick = () => { selAcc = a.id; renderGift(); };
    tb.appendChild(tr);
  });
  let stat = '共 ' + g.accounts.length + ' 个';
  if (g.accounts.length) stat += ' · 已登录 ' + nOk + ' / 掉线 ' + nOff + ' / 未登录 ' + nNo;
  if (g.checking) stat += ' · 核对中…';
  if (g.last_check_ts) stat += ' · 检查 ' + new Date(g.last_check_ts * 1000).toTimeString().slice(0, 5);
  $('#acc-stat').textContent = stat;

  const acc = g.accounts.find((a) => a.id === selAcc);
  $('#acc-detail').textContent = acc
    ? (acc.id + (acc.uid_text ? '  站内:' + acc.uid_text : '') + (acc.game ? '  游戏:' + acc.game : '')
       + (acc.status === 'off' ? '  ⚠ 掉线，请重新扫码登录' : ''))
    : '点选账号查看站内身份';
  const gg = $('#acc-game');
  if (gg !== document.activeElement) gg.value = acc ? (acc.game || '') : '';
  $('#btn-login').disabled = !acc || !!g.login;
  $('#btn-acc-del').disabled = !acc;
  $('#btn-run-one').disabled = !acc || g.running;
  $('#btn-login').textContent = g.login ? ('登录中：' + g.login) : '扫码登录';

  // 领取记录
  const rb = $('#rec-table tbody');
  rb.innerHTML = '';
  g.records.slice().reverse().forEach((r) => {
    const tr = document.createElement('tr');
    tr.className = r.result === '成功' ? 'ok' : 'fail';
    tr.innerHTML = '<td>' + esc(r.time) + '</td><td>' + esc(r.account) + '</td>'
      + '<td>' + esc(r.result) + '</td><td>' + esc(r.msg) + '</td>';
    rb.appendChild(tr);
  });
  $('#rec-count').textContent = '共 ' + g.records.length + ' 条（最多保留 5 天）';

  // 进度
  const p = g.progress || {};
  if (p.on && p.max) {
    $('#pb').style.width = Math.round(100 * (p.cur / p.max)) + '%';
    $('#pb-text').textContent = p.cur + ' / ' + p.max;
  } else {
    $('#pb').style.width = '0';
    $('#pb-text').textContent = g.running ? '运行中…' : '空闲';
  }

  // 设置页浏览器下拉
  const sel = $('#set-browser');
  const cur = g.cur_browser || '';
  const sig = g.browsers.map((b) => b.path).join('|') + '#' + cur;
  if (sel.dataset.sig !== sig) {
    sel.dataset.sig = sig;
    sel.innerHTML = '';
    if (!g.browsers.length) sel.innerHTML = '<option value="">（未检测到浏览器）</option>';
    g.browsers.forEach((b) => {
      const o = document.createElement('option');
      o.value = b.path;
      o.textContent = b.name + '  —  ' + b.path + (b.path === cur ? '  ← 当前' : '');
      sel.appendChild(o);
    });
    sel.value = cur;
  }
}

/* ============================ 论坛（多账号） ============================ */
/* ★ 2026-10-09 同一个论坛可挂多个账号（每个账号独立浏览器 profile，登录态互不覆盖）。
   列表按「论坛 → 账号」两级渲染：
     · 论坛主行：论坛名 + 网址 + 账号数，「＋ 账号 / 全部签到 / 删除论坛」
     · 账号子行：账号名 + 登录状态，「重登 / 签到 / 清除 / 删除账号」 */
function renderForum() {
  const f = S.forum;
  const tb = $('#forum-table tbody');
  tb.innerHTML = '';
  f.list.forEach((it) => {
    // —— 论坛主行 ——
    const main = document.createElement('tr');
    main.className = 'forum-main';
    const cell = document.createElement('td');
    cell.colSpan = 3;
    cell.className = 'forum-main-cell';
    const title = document.createElement('div');
    title.className = 'forum-title';
    title.innerHTML = '<b>' + esc(it.name) + '</b>'
      + '<span class="hint">　' + esc(it.base) + '</span>'
      + '<span class="badge">' + (it.n || 0) + ' 个账号</span>';
    const ops = document.createElement('div');
    ops.className = 'forum-ops';
    ops.appendChild(mkBtn('＋ 账号', 'btn tiny primary', () => forumLogin(it, '', '')));
    ops.appendChild(mkBtn('全部签到', 'btn tiny',
      () => api('/api/forum/sign', { targets: [[it.base, it.name]] })));
    ops.appendChild(mkBtn('删除论坛', 'btn tiny danger', async () => {
      if (await confirmBox('删除【' + it.name + '】？\n\n'
          + '· 会从列表移除这个论坛\n'
          + '· 同时删除它在本机保存的**全部账号**登录 Cookie\n'
          + '· 该站专用的浏览器数据也一并清掉\n\n'
          + '只清这一个站的，其它论坛不受影响。')) {
        api('/api/forum/delete', { base: it.base });
      }
    }));
    cell.appendChild(title);
    cell.appendChild(ops);
    main.appendChild(cell);
    tb.appendChild(main);

    // —— 每个账号一行 ——
    (it.accounts || []).forEach((a, i) => {
      const tr = document.createElement('tr');
      tr.className = 'forum-acc';
      const nameTd = document.createElement('td');
      nameTd.className = 'forum-acc-name';
      nameTd.innerHTML = '<span class="tree">└</span> '
        + esc(a.name || ('账号' + (i + 1)));
      const stTd = document.createElement('td');
      stTd.className = a.saved ? 'st-ok' : 'st-no';
      stTd.textContent = a.saved
        ? ('✅ 已保存 ' + (a.saved_at || '') + (a.ua ? '' : '（缺 UA，建议重登一次）'))
        : '○ 未登录（点『＋ 账号』或『重登』去登）';
      const opTd = document.createElement('td');
      opTd.className = 'op';
      opTd.appendChild(mkBtn('重登', 'btn tiny', () => forumLogin(it, a.name, a.id)));
      opTd.appendChild(mkBtn('改名', 'btn tiny', async () => {
        const cur = a.name || ('账号' + (i + 1));
        const nm = prompt('给这个账号起个名字（好认就行）：', cur);
        if (nm === null) return;
        const v = String(nm).trim();
        if (!v) return toast('名字不能为空', 'err');
        if (v === cur) return;
        const r = await api('/api/forum/account/rename', { base: it.base, account_id: a.id, name: v });
        if (r && r.ok) toast('已改名为「' + r.name + '」', 'ok');
        else toast((r && r.msg) || '改名失败', 'err');
      }));
      opTd.appendChild(mkBtn('签到', 'btn tiny',
        () => api('/api/forum/sign', { targets: [[it.base, it.name, a.id]] })));
      opTd.appendChild(mkBtn('清除', 'btn tiny', async () => {
        if (await confirmBox('清除【' + it.name + ' / ' + (a.name || '') + '】的登录 Cookie？')) {
          api('/api/forum/clear', { base: it.base, account_id: a.id });
        }
      }));
      opTd.appendChild(mkBtn('删除账号', 'btn tiny danger', async () => {
        if (await confirmBox('删除【' + it.name + ' / ' + (a.name || '') + '】这个账号？\n\n'
            + '· 只删这一个账号的登录态与专属浏览器数据\n'
            + '· 同论坛的其它账号不受影响')) {
          api('/api/forum/account/delete', { base: it.base, account_id: a.id });
        }
      }));
      tr.appendChild(nameTd);
      tr.appendChild(stTd);
      tr.appendChild(opTd);
      tb.appendChild(tr);
    });
    if (!(it.accounts || []).length) {
      const tr = document.createElement('tr');
      tr.className = 'forum-acc';
      // ★ 2026-10-10 用户要求：删掉这里的「＋ 加账号」按钮（论坛主行已有「＋ 账号」，此处重复）
      tr.innerHTML = '<td class="forum-acc-name"><span class="tree">└</span> 暂无账号</td>'
        + '<td class="st-no">○ 未登录</td><td class="op"></td>';
      tb.appendChild(tr);
    }
  });
  if (!f.list.length) tb.innerHTML = '<tr><td colspan="3" class="hint">还没有论坛，先添加一个</td></tr>';

  const st = f.settings;
  $('#f-auto').checked = !!st.auto_sign;
  $('#f-headless').checked = !!st.headless;
  const at = $('#f-auto-time');
  if (at !== document.activeElement) at.value = st.auto_time || '08:00';
  $('#f-next').textContent = '下次自动签到：' + (f.next || '未启用');
  $('#btn-forum-sign-all').disabled = !!f.busy;
  $('#btn-forum-stop').disabled = !f.busy;

  const rb = $('#frec-table tbody');
  rb.innerHTML = '';
  f.records.slice().reverse().forEach((r) => {
    const tr = document.createElement('tr');
    tr.className = (r.tag === 'ok' ? 'ok' : (r.tag === 'already' ? 'already' : 'fail'));
    tr.innerHTML = '<td>' + esc(r.time) + '</td><td>' + esc(r.forum) + '</td>'
      + '<td>' + esc(r.result) + '</td><td>' + esc(r.msg) + '</td>';
    rb.appendChild(tr);
  });
  $('#frec-count').textContent = '共 ' + f.records.length + ' 条（最多保留 5 天）';
}

/* ======================== QQ（多账号 / 多 WS 连接） ======================== */
let qqSig = '';
let qqPick = '';      // 群列表当前查看哪个 QQ 账号（connection id）
let qqEditId = '';    // 正在行内编辑的连接 id
function renderQQ() {
  const q = S.qq, st = q.settings;
  const setv = (id, v) => { const el = $('#' + id); if (el && el !== document.activeElement) el.value = v; };
  setv('qq-msg', st.default_msg || '签到');
  setv('qq-like', st.like_users || '');
  setv('qq-times', st.like_times || 5);
  setv('qq-kw-qq', st.kw_notify || '');
  setv('qq-kw-words', st.kw_words || '');
  setv('qq-auto-time', st.auto_time || '08:00');
  setv('qq-like-auto-time', st.like_auto_time || '08:30');
  const cks = { 'qq-kw': st.kw_on, 'qq-auto': st.auto_sign, 'qq-like-auto': st.like_auto };
  for (const k in cks) { const el = $('#' + k); if (el && document.activeElement !== el) el.checked = !!cks[k]; }
  const selMsg = $('#qq-msg-preset');
  if (selMsg && !selMsg.dataset.init) {
    selMsg.dataset.init = '1';
    selMsg.innerHTML = '<option value="">常用语…</option>';
    (q.presets || []).forEach((p) => {
      const o = document.createElement('option'); o.value = p; o.textContent = p; selMsg.appendChild(o);
    });
    selMsg.onchange = () => { if (selMsg.value) { $('#qq-msg').value = selMsg.value;
      api('/api/qq/settings', { patch: { default_msg: selMsg.value } }); } };
  }

  const conns = q.conns || [];
  if (!conns.some((c) => c.id === qqPick)) qqPick = conns.length ? conns[0].id : '';

  // —— 连接表（每行 = 一个 QQ 号）——
  const ctb = $('#qq-conn-table tbody');
  ctb.innerHTML = '';
  conns.forEach((c) => {
    const tr = document.createElement('tr');
    if (c.id === qqPick) tr.className = 'cur';
    const editing = (qqEditId === c.id);
    const isRev = (c.mode === 'reverse');
    const badge = isRev ? '<span class="rev-badge">反向</span> ' : '';
    const rmk = editing ? '<input class="qq-e-remark" value="' + esc(c.remark) + '">'
                        : (badge + esc(c.remark || '（未命名）'));
    const url = editing ? '<input class="qq-e-url" value="' + esc(c.url) + '">'
                        : (isRev ? '<span class="hint">反向 WS（框架连入）</span>' : esc(c.url));
    const tok = editing ? '<input class="qq-e-token" value="' + esc(c.token) + '">'
                        : (c.token ? '••••' : '—');
    tr.innerHTML = '<td>' + rmk + '</td><td>' + url + '</td><td>' + tok + '</td>'
      + '<td class="' + (c.connected ? 'st-ok' : 'st-no') + '">'
      + esc(c.status || '○ 未连接')
      + (c.connected && c.nickname
          ? '<br><span class="hint">' + esc(c.nickname) + ' (' + esc(c.self_id) + ')</span>' : '')
      + '</td><td class="op"></td>';
    const op = tr.querySelector('.op');
    if (editing) {
      op.appendChild(mkBtn('保存', 'btn tiny primary', async () => {
        const r = await api('/api/qq/conn/edit', { cid: c.id,
          remark: tr.querySelector('.qq-e-remark').value,
          url: tr.querySelector('.qq-e-url').value,
          token: tr.querySelector('.qq-e-token').value });
        if (r && r.ok) { qqEditId = ''; refresh(0); }
        else if (r && r.msg) toast(r.msg, 'err');
      }));
      op.appendChild(mkBtn('取消', 'btn tiny', () => { qqEditId = ''; renderQQ(); }));
    } else {
      if (isRev) {
        // 反向连接：不用手动「连接」（框架会自己连进来），连上后只能「踢出」
        if (c.connected) {
          op.appendChild(mkBtn('踢出', 'btn tiny danger',
            () => api('/api/qq/disconnect', { cid: c.id })));
        } else {
          const sp = document.createElement('span');
          sp.className = 'hint';
          sp.textContent = '等待框架连入';
          op.appendChild(sp);
        }
      } else {
        op.appendChild(mkBtn(c.connected ? '断开' : '连接', 'btn tiny', () => {
          if (c.connected) api('/api/qq/disconnect', { cid: c.id });
          else { qqPick = c.id; api('/api/qq/connect', { cid: c.id }); }
        }));
      }
      op.appendChild(mkBtn('⟳', 'btn tiny', () => { qqPick = c.id; api('/api/qq/refresh', { cid: c.id }); }));
      op.appendChild(mkBtn('查看', 'btn tiny' + (c.id === qqPick ? ' primary' : ''),
        () => { qqPick = c.id; qqSig = ''; renderQQ(); }));
      op.appendChild(mkBtn('编辑', 'btn tiny', () => { qqEditId = c.id; renderQQ(); }));
      op.appendChild(mkBtn('删除', 'btn tiny danger', async () => {
        if (await confirmBox('删除连接【' + (c.remark || c.id) + '】？\n'
            + '· 会断开并移除这条 QQ 账号连接\n'
            + '· 它的群勾选 / 专属消息也一并删除')) {
          if (qqPick === c.id) qqPick = '';
          api('/api/qq/conn/delete', { cid: c.id });
        }
      }));
    }
    ctb.appendChild(tr);
  });
  if (!conns.length) {
    ctb.innerHTML = '<tr><td colspan="5" class="hint">还没有 QQ 连接。'
      + '正向 WS：在下方填地址（例如 ws://127.0.0.1:3001）点「＋ 添加并连接」；'
      + '反向 WS：启动下面的「反向 WS 监听」，让机器人框架连进来（会自动出现在这里）。'
      + '需要多个 QQ 号就再加几条。</td></tr>';
  }

  // —— 账号选择下拉 + 状态条 ——
  const pick = $('#qq-conn-pick');
  if (pick) {
    const psig = conns.map((c) => c.id + '|' + (c.remark || '') + '|' + c.connected + '|' + c.self_id).join(';');
    if (pick.dataset.sig !== psig) {
      pick.dataset.sig = psig;
      pick.innerHTML = '';
      conns.forEach((c) => {
        const o = document.createElement('option'); o.value = c.id;
        o.textContent = (c.remark || c.id)
          + (c.connected ? ('　' + (c.nickname || 'QQ') + ' ' + (c.self_id || '')) : '（未连接）');
        pick.appendChild(o);
      });
    }
    if (pick.value !== qqPick) pick.value = qqPick;
  }
  const nAlive = conns.filter((c) => c.connected).length;
  $('#qq-state').textContent = conns.length
    ? ('共 ' + conns.length + ' 个 QQ 账号 · ' + nAlive + ' 个在线　' + (q.status || ''))
    : '○ 未连接（先添加一条 WS 连接）';
  $('#qq-next').textContent = '下次：' + (q.next || '未启用');
  $('#qq-like-next').textContent = '下次：' + (q.next_like || '未启用');
  $('#qq-diag').innerHTML = esc(q.kw_state);
  $('#btn-qq-sign').disabled = !!q.busy;
  $('#btn-qq-stop').disabled = !q.busy;

  // 命中列表
  const hb = $('#qq-hits');
  const hs = (q.hits || []).join('\n');
  if (hb.dataset.sig !== hs) { hb.dataset.sig = hs;
    hb.innerHTML = (q.hits || []).map((h) => '<div>' + esc(h) + '</div>').join('')
      || '<div class="hint">（暂无）</div>'; }

  // —— 群列表（当前选中账号自己的那份）——
  const cur = conns.find((c) => c.id === qqPick);
  const groups = cur ? (cur.groups || []) : [];
  const kw = ($('#qq-filter').value || '').trim().toLowerCase();
  const shown = groups.filter((g) => !kw || (g.name || '').toLowerCase().includes(kw) || g.gid.includes(kw));
  const sig = qqPick + '|' + groups.map((g) => g.gid).join(',') + '#' + shown.map((g) => g.gid).join(',');
  if (qqSig !== sig) {
    qqSig = sig;
    const box = $('#qq-groups');
    box.innerHTML = '';
    shown.forEach((g) => {
      const row = document.createElement('div');
      row.className = 'grow-row';
      row.dataset.gid = g.gid;
      row.innerHTML =
        '<input type="checkbox" class="c-en">'
        + '<input type="checkbox" class="c-kw">'
        + '<span class="gname" title="' + esc(g.gid + ' ' + g.name) + '">'
        + esc((g.name || ('群' + g.gid)).slice(0, 16)) + '<br><span class="hint">'
        + esc(g.gid) + (g.count ? '·' + g.count + '人' : '') + '</span></span>'
        + '<input type="text" class="m-msg" placeholder="专属消息">';
      const en = row.querySelector('.c-en'),
            kwc = row.querySelector('.c-kw'),
            msg = row.querySelector('.m-msg');
      const push = (patch) => api('/api/qq/groups', { cid: qqPick, groups: { [g.gid]: patch } });
      en.onchange = () => push({ enabled: en.checked });
      kwc.onchange = () => push({ kw: kwc.checked });
      msg.onchange = () => push({ msg: msg.value });
      box.appendChild(row);
    });
    if (!shown.length) {
      box.innerHTML = '<div class="hint" style="padding:8px">'
        + (cur ? '这个账号还没有群列表：点上面的『⟳ 刷新该账号群列表』（需先连上该账号）'
               : '还没有 QQ 连接：先启动 QQ 机器人框架并开启正向 WS，然后添加连接')
        + '</div>';
    }
  }
  // 同步勾选 / 消息（不破坏输入焦点）
  $$('#qq-groups .grow-row').forEach((row) => {
    const g = groups.find((x) => x.gid === row.dataset.gid);
    if (!g) return;
    const set = (sel, v) => { const el = row.querySelector(sel); if (el !== document.activeElement) el.checked = !!v; };
    set('.c-en', g.enabled); set('.c-kw', g.kw);
    const m = row.querySelector('.m-msg');
    if (m !== document.activeElement && m.value !== (g.msg || '')) m.value = g.msg || '';
  });
  const nSel = groups.filter((g) => g.enabled).length;
  $('#qq-count').textContent = groups.length
    ? ('共 ' + groups.length + ' 个 · 已勾选 ' + nSel + (kw ? ' · 筛选出 ' + shown.length + ' 个' : ''))
    : '';

  // —— ★ 2026-10-09 反向 WS 监听面板（配置 + 运行状态）——
  // ★ 2026-10-10 用户要求：监听地址/路径/Token 三个输入框已删，固定 0.0.0.0 / 空 / 空，只留端口
  const rv = q.rev || {};
  setv('qq-rev-port', rv.port || 6700);
  const rs = $('#qq-rev-status');
  if (rs) {
    rs.textContent = (rv.status || '○ 未监听')
      + (rv.on ? ('　｜ 反向连接 ' + (rv.n_reverse_alive || 0) + '/' + (rv.n_reverse || 0) + ' 在线')
               : '');
  }
  const bStart = $('#btn-qq-rev-start'), bStop = $('#btn-qq-rev-stop');
  if (bStart) bStart.disabled = !!rv.on;
  if (bStop) bStop.disabled = !rv.on;
}

/* 触发某论坛「登录一个账号」：
   · 「＋ 账号」→ 不带 account_id，后端自动分配新账号（a2 / a3…，各自独立 profile）
   · 「重登」  → 带 account_id，覆盖该账号
   登录在下方「论坛登录（外网填写）」面板里填，不用看服务器那台机器的屏幕。 */
function forumLogin(it, accName, accId) {
  toast('已开始登录：本页下方会出现「论坛登录（外网填写）」面板，'
        + '在那里填账号 / 密码或手机号就能登；'
        + '也可以直接在服务器那台机器的浏览器窗口里登录。', 'warn');
  api('/api/forum/login', { base: it.base, name: it.name,
                            account_name: accName || '', account_id: accId || '' });
}

function mkBtn(text, cls, fn) {
  const b = document.createElement('button');
  b.className = cls; b.textContent = text; b.onclick = fn;
  return b;
}

/* ============================ 日志 ============================ */
function pushLog(ch, line) {
  preview[ch] = line;
  const p = $('#prev-' + ch);
  if (p) p.textContent = line;
  if (ch === logCh && !$('#drawer').classList.contains('hidden')) {
    const body = $('#log-body');
    body.textContent += line + '\n';
    if (body.textContent.length > 400000) {
      body.textContent = body.textContent.slice(-200000);
    }
    if ($('#log-autoscroll').checked) body.scrollTop = body.scrollHeight;
  }
}
async function openDrawer(ch) {
  logCh = ch || logCh;
  $$('.logtab').forEach((b) => b.classList.toggle('active', b.dataset.ch === logCh));
  $('#drawer').classList.remove('hidden');
  const r = await api('/api/logs?ch=' + logCh + '&n=' + MAXLOG);
  if (r && r.ok) {
    $('#log-body').textContent = r.lines.join('\n') + '\n';
    $('#log-body').scrollTop = $('#log-body').scrollHeight;
  }
}

/* ============================ ★ 扫码同步（需求⑬） ============================
   工具挂在服务器上时，扫码框是在**服务器那台机器**的浏览器里弹出来的。
   后端登录等待期间会把那张码截下来，通过 SSE（kind=qr）说一声「有码了」，
   这里来 /api/gift/qr 取图显示 —— 于是人在别的电脑上打开网页也能直接扫。
   刷新页面 / 换台电脑打开，启动时补一次拉取，正在扫码也拿得到同一张。 */
let qrLastTs = 0;
async function refreshQr() {
  const r = await api('/api/gift/qr', {});
  if (!r || !r.ok) return;
  const panel = $('#qr-panel'), img = $('#qr-img');
  if (!panel || !img) return;
  const q = r.qr;
  const stage = r.stage || '';
  if (!q) {
    // ★ 2026-09-26：浏览器还在起 / 码还没弹出来的时候，别让外网的人
    //   对着一片空白干等（以前只有「有码/没码」两态，中间几十秒啥也没有）。
    if (stage === 'starting' || stage === 'waiting') {
      qrLastTs = 0;
      img.removeAttribute('src');
      $('#qr-who').textContent = '';
      $('#qr-tip').innerHTML = (stage === 'starting')
        ? '正在打开<b>服务器那台机器</b>的浏览器…（首次启动可能要十几秒）'
        : '<b>服务器那台机器</b>的浏览器已打开，正在等二维码弹出来…';
      panel.classList.remove('hidden');
      return;
    }
    qrLastTs = 0;
    panel.classList.add('hidden');
    img.removeAttribute('src');
    return;
  }
  if (q.ts === qrLastTs) return;        // 同一张：不重设 src，免得白白闪一下
  qrLastTs = q.ts;
  img.src = q.png;
  $('#qr-who').textContent = q.acc ? ('账号 ' + q.acc) : '';
  const when = new Date((q.ts || 0) * 1000).toLocaleTimeString();
  $('#qr-tip').innerHTML = '这是<b>服务器那台机器</b>浏览器里弹出的二维码（' + when +
    ' 出的码），已实时同步过来；用微信扫它即可。';
  panel.classList.remove('hidden');
}
function hideQr() {
  const panel = $('#qr-panel');
  if (panel) panel.classList.add('hidden');
}

/* ============================ SSE ============================ */
let sseOK = false;   // 连接是否活着；断了就用高频轮询顶上
function startSSE() {
  const es = new EventSource('/api/events');
  es.onopen = () => {
    sseOK = true;
    // ★ 2026-09-26：断线期间服务端推的事件全丢了，重连上先补拉一次
    refreshQr();
    // ★★ 2026-09-26：SSE（重）连上时补拉一次论坛表单 ——
    //   断线那段时间里服务端推的 forum_form 事件是收不到的，不补拉的话
    //   面板就永远不出现（扫码那条链路早就这么做了，这条漏了）。
    refreshForumForm();
  };
  es.onmessage = (ev) => {
    let m = null;
    try { m = JSON.parse(ev.data); } catch (e) { return; }
    if (m.t === 'log') { pushLog(m.ch, m.line); return; }
    if (m.t === 'status') {
      if (m.key === 'qq') { $('#qq-state').textContent = m.text; }
      if (m.key === 'main') { $('#chip-status').textContent = m.text; }
      return;
    }
    if (m.t === 'hello') { Object.keys(m.status || {}).forEach((k) => {
      if (k === 'qq') $('#qq-state').textContent = m.status[k];
      if (k === 'main') $('#chip-status').textContent = m.status[k];
    });
      // ★ 需求⑬：断线重连 / 首次连上时补一次 —— 断的那段时间里出的码不能漏
      refreshQr();
      // ★ 2026-09-26：同样把论坛登录表单补拉一次（同一个漏子）
      refreshForumForm();
      return; }
    if (m.t === 'cleared') { if (!m.ch || m.ch === logCh) $('#log-body').textContent = ''; return; }
    // 事件广播统一是 {t:'event', kind, data}（见 web/logs.py Bus.event）
    if (m.t === 'event') {
      const k = m.kind, d = m.data || {};
      if (k === 'record') toast('领取' + d.result + '：' + d.account + ' ' + d.msg,
        d.result === '成功' ? 'ok' : 'err');
      else if (k === 'forum_record') toast('论坛签到：' + d.forum + ' ' + d.result,
        d.tag === 'fail' ? 'err' : 'ok');
      else if (k === 'qq_hit') toast('监测命中：' + d, 'warn');
      else if (k === 'card_ok') toast('卡密验证通过：' + (d.msg || ''), 'ok');
      else if (k === 'push') {
        // 卡密端「管理员文字推送」→ 模态弹窗（原桌面版就是 messagebox，不能错过）
        alertBox('【管理员推送】\n\n' + (d.text || ''), '知道了');
      }
      else if (k === 'alert') { alertBox(d.text || '提示', '知道了'); return; }
      // ★ 需求⑯：卡密端要求本机退出主程序（封卡 / 解绑 / 封IP / 封机器码 / 踢下线）
      else if (k === 'kill') {
        killNotice(d.msg || '本机已被管理员强制下线');
        return;
      }
      else if (k === 'login') {
        if (d.ok === true) toast('账号 ' + d.id + ' 登录完成：' + (d.msg || ''), 'ok');
        else if (d.ok === false) toast('账号 ' + d.id + '：' + (d.msg || '未完成'), 'warn');
      }
      // ★ 需求⑬：服务器浏览器里出了码 / 码没了 —— 去取一下二维码图
      else if (k === 'qr') { refreshQr(); return; }
      // ★ 需求⑱：论坛登录页的表单（含验证码）同步过来了
      else if (k === 'forum_form') { refreshForumForm(); return; }
      refresh(0);
      return;
    }
    // 兜底：以后新增的任何事件类型，一律拉一次状态，避免界面不刷新。
    refresh(0);
  };
  es.onerror = () => { sseOK = false; /* EventSource 会自动重连，onopen 里再置回 true */ };
}

/* ================= ★ 需求⑯ 被卡密端强制关闭 =================
   卡密端点了 封卡 / 解绑 / 封IP / 封机器码 / 踢下线 →
   后端已经置了退出标志，进程会在这一两秒内自己退掉。
   这里先把话说清楚（不可关闭的模态），免得用户以为程序「莫名消失」。
   注意：**不提示「重新激活」** —— 这种情况重填卡密也没用，
   得让管理员先解封 / 重新授权。 */
let killShown = false;
function killNotice(msg) {
  if (killShown) return;
  killShown = true;
  const m = $('#mask');
  $('#masktext').innerHTML = '<b style="color:#d32f2f">本程序已被管理员关闭</b>\n\n'
    + (msg || '') + '\n\n程序即将退出。若需继续使用，请联系管理员。';
  $('#masktext').style.whiteSpace = 'pre-wrap';
  $('#mask-yes').textContent = '知道了';
  $('#mask-no').classList.add('hidden');
  m.classList.remove('hidden');
  $('#mask-yes').onclick = () => { m.classList.add('hidden'); };
}

/* ================= ★ 需求⑱ 论坛登录「外网填表」 =================
   服务器那台机器打开的 Discuz 登录页，账号/密码/验证码同步到本页；
   人在别的电脑上（外网）填完点提交，后端代填并提交。
   ★ 2026-09-26：验证码可点开放大 / 换一张。
   ★ 2026-10-09 用户要求「删除手机号登录」：「手机号 / 短信验证码」整块删掉，
     只保留「账号 + 密码 + 图形验证码」；同时「验证码」行改为**常显**。 */
let fformLastCap = 0;
let fformLastSeq = 0;
let fformMode = '';   // 服务器那边当前的登录方式（现仅 account）
async function refreshForumForm() {
  const panel = $('#fform-panel');
  if (!panel) return;
  const r = await api('/api/forum/form', {});
  if (!r || !r.ok) return;
  const f = (r.form) || {};
  if (!f.on) {
    panel.classList.add('hidden');
    fformLastCap = 0;
    fformLastSeq = 0;
    return;
  }
  $('#fform-who').textContent = f.name ? ('论坛 ' + f.name) : '';
  const fl = f.fields || {};
  // ★ 2026-09-26：以**服务器那边的页签**为准（tabMode 最可靠）。
  // ★★ 2026-10-09 用户要求「删除手机号登录」：不再有 phone 分支 ——
  //   判得出「账号登录」就按识别结果收敛；判不出（还在起浏览器 / 页面没加载 /
  //   站点结构不认）就 showAll，把账号/密码两行都放出来，用户直接填。
  const knownMode = String(f.tabMode || f.mode || '');
  const mode = knownMode || (fl.user ? 'account' : '');
  fformMode = mode;
  // 没判出登录方式 → 兜底把输入行全放出来（否则用户连字都敲不进去）
  const showAll = !knownMode;
  // 顶部那句提示写清「服务器那边现在是哪一种登录」，用户不用猜
  const tip = $('#fform-tip');
  if (tip) {
    const tn = f.tab_text ? ('服务器那边选的是「' + f.tab_text + '」') : '';
    // ★ stage：starting=在起浏览器 / loading=等页面 / login|captain=已就绪 /
    //          manual=没读到表单（别一直挂着"正在等"）/ failed=打不开
    const stage = f.stage || '';
    let head = '这是<b>服务器那台机器</b>浏览器里的登录页，已同步过来。';
    if (stage === 'starting') {
      head = '正在打开服务器那台机器的浏览器…（首次启动可能要十几秒）';
    } else if (stage === 'loading') {
      head = '正在等服务器那边的登录页加载出来…（页面打开较慢时请稍候）';
    } else if (stage === 'manual') {
      head = '<b style="color:#b06000">没能自动读到登录表单</b>：'
        + '可以直接在服务器那台机器的浏览器窗口里登录，'
        + '程序在后台持续重试识别；识别到就会自动同步到这里。';
    } else if (stage === 'failed') {
      head = '<b style="color:#c00">服务器那边没能打开登录页</b>';
    }
    // ★ 没读到表单结构（含「还在起浏览器 / 还在加载」）时，别再让面板空着 ——
    //   直接把「照自己的登录方式填下面的框」说清楚，用户不用猜为什么没框。
    if (showAll) {
      head += '<br><b style="color:#1a5fb4">没读到服务器那边的表单结构不要紧，'
        + '直接填下面的框就行</b>：填「账号 + 密码」。'
        + '站点还要图片验证码的话，它就摆在「验证码」那一行右边'
        + '（看不清就点一下那张图换一张）。用不着的行留空即可。';
    }
    tip.innerHTML = head + (tn ? '　<b style="color:#1a5fb4">' + esc(tn) + '</b>' : '');
  }
  // 账号登录 → 账号/密码。★ 删除手机号行后**不能再碰 `#fform-phone-wrap`**
  //   （元素已不存在，$() 返回 null，.classList 一取就抛异常 → 整个面板崩掉，
  //    这种「改了这行崩那行」的坑本项目踩过好几次了）。
  $('#fform-user-wrap').classList.toggle('hidden', !(showAll || fl.user));
  $('#fform-pass-wrap').classList.toggle('hidden', !(showAll || fl.pass));
  // ★★ 2026-10-09 用户要求「有的论坛有验证码，在网页端登录需要显示出来」：
  //   —— 「验证码」这一行**常显**（不再按证据藏起来）。站点有验证码时图会显示在
  //      右边；一时没取到图就显示占位提示，用户随时有地方填 / 换。
  const capPng = f.cap_png || '';
  const capProbe = f.cap_probe || {};
  const capCand = Number(capProbe.n || 0);
  const capWant = !!(fl.cap || capCand);
  const capShow = !!capPng || capWant;      // 仅用于占位文案措辞
  $('#fform-cap-wrap').classList.remove('hidden');
  $('#fform-q-wrap').classList.toggle('hidden', !fl.secq);
  // ★★ 2026-09-26 用户说的「同步账号密码过来」：
  //   服务器浏览器里**已经填进去的值**（账号）同步过来，外网这边
  //   直接就能看见，不用重新敲一遍。（密码出于安全不外发。）
  const fd = f.filled || {};
  const setIfEmpty = (id, v) => {
    const el = $(id);
    if (!el || !v) return;
    if (!el.value) el.value = v;        // 用户已经填了/改过就不覆盖
  };
  setIfEmpty('#fform-user', fl.user ? (fd.user || '') : '');
  // ★★ 2026-10-09 删除手机号登录：`#fform-phone` 元素已不存在，不再同步手机号。
  // ★ 诊断行：读不到表单时，把「服务器那边现在开着什么页」直接摊开给用户看，
  //   一眼能分清是没导航过去 / 页面报错 / 还是这个站的结构我们不认。
  const pe = $('#fform-probe');
  if (pe) {
    const pb = f.probe || {};
    const st2 = f.stage || '';
    const want = (st2 === 'starting' || st2 === 'loading' || st2 === 'manual'
      || st2 === 'failed');
    if (want && (pb.url || pb.title || pb.err || pb.inputs >= 0)) {
      let t = '服务器那边现在开着：' + esc(pb.url || '(读不到地址)');
      if (pb.title) t += '　标题「' + esc(pb.title) + '」';
      if (pb.inputs >= 0) t += '　页面上 ' + pb.inputs + ' 个输入框';
      if (pb.err) t += '　<span style="color:#c00">' + esc(pb.err) + '</span>';
      pe.innerHTML = t;
      pe.classList.remove('hidden');
    } else {
      pe.classList.add('hidden');
    }
  }
  // ★ 验证码：seq 变了才换图（同图不重设 src，免得闪）；换图时清空旧输入
  if (f.cap_png && (f.cap_ts !== fformLastCap || f.cap_seq !== fformLastSeq)) {
    fformLastCap = f.cap_ts;
    fformLastSeq = f.cap_seq;
    const src = f.cap_png;
    const imgEl = $('#fform-cap-img');
    // ★★ 2026-10-09 用户报「网页端一直自己换」：图**真的换了**才清输入框。
    //   服务端已经做了「同一张图不重复推」的止血；这里再加一道闸 ——
    //   万一同样的图又推了一遍（data:URL 逐字节相同），绝不能把用户
    //   刚敲进去的验证码抹掉（那是用户手感上「一直自己换 / 老被清空」的直接来源）。
    const changed = (imgEl.src !== src);
    imgEl.src = src;
    const zi = $('#cap-zoom-img');
    if (zi && !$('#cap-zoom').classList.contains('hidden')) zi.src = src;
    if (changed) {
      $('#fform-cap').value = '';
      $('#fform-msg').textContent = '验证码已更新，请照着图填';
    }
  }
  // ★ 兜底时「验证码」行会先于图出现（服务器那边还没取到图）——
  //   这时别摆一个破图的空框，改成虚线占位，图一到自动换回真图。
  //   ★★ 2026-09-26 用户报「图还没取到…」：光说「还没取到」用户无从下手，
  //     所以这里同时把**服务器那边的诊断**（几张图 / 几个候选 / URL / 失败原因）
  //     摊到面板上（#fform-cap-probe），跟 #fform-probe 一个套路。
  const _ci = $('#fform-cap-img');
  if (_ci) {
    const _hasImg = !!(_ci.src || '');
    _ci.classList.toggle('hidden', !_hasImg);
    const _cp = $('#fform-cap-ph');
    if (_cp) {
      _cp.classList.toggle('hidden', _hasImg || !capShow);
      if (!_hasImg && capShow) {
        // 分清「正在取」和「取不到」：说要验证码但图还没到 = 正在取
        _cp.textContent = (capWant && !capProbe.err) ? '正在取图…' : '图没取到';
      }
    }
    const _cz = $('#btn-fform-cap-zoom');
    if (_cz) _cz.classList.toggle('hidden', !_hasImg);   // 没图就别给「放大」
    const _cpr = $('#fform-cap-probe');
    if (_cpr) {
      const _why = (!_hasImg && capShow) ? String(capProbe.err || '') : '';
      if (_why) {
        let t = '服务器那边：页面共 ' + Number(capProbe.imgs || 0) + ' 张图，'
          + '认出的验证码图 ' + capCand + ' 个。';
        if (capProbe.url) t += '第一张 ' + esc(String(capProbe.url).slice(0, 70)) + '　';
        t += '<span style="color:#c00">' + esc(_why) + '</span>';
        _cpr.innerHTML = t;
        _cpr.classList.remove('hidden');
      } else {
        _cpr.classList.add('hidden');
      }
    }
  }
  if (f.msg) $('#fform-msg').textContent = f.msg;
  panel.classList.remove('hidden');
}
function hideForumForm() {
  const panel = $('#fform-panel');
  if (panel) panel.classList.add('hidden');
  closeCapZoom();
  api('/api/forum/form/close', {});
}
async function submitForumForm() {
  // ★★ 2026-10-09 用户要求「删除手机号登录」：不再读 `#fform-phone`
  //    （元素已删除，读它必崩）—— 只认「账号 + 密码 + 图形验证码」。
  const user = $('#fform-user').value.trim();
  const pass = $('#fform-pass').value;
  if (!user) {
    $('#fform-msg').textContent = '请先填账号';
    return;
  }
  if (fformMode === 'account'
      && !$('#fform-pass-wrap').classList.contains('hidden') && !pass) {
    $('#fform-msg').textContent = '请先填密码';
    return;
  }
  const body = { user: user, pass: pass,
                 cap: $('#fform-cap').value.trim(),
                 answer: $('#fform-answer').value.trim(),
                 mode: fformMode };      // ★ 交给后端先切到正确页签
  $('#fform-msg').textContent = '正在提交…';
  const r = await api('/api/forum/form/submit', body);
  $('#fform-msg').textContent = (r && r.ok)
    ? (r.submitted ? '已提交，正在检测登录结果…' : (r.msg || '已填写'))
    : ((r && r.msg) || '提交失败');
  if (r && r.ok && r.submitted) {
    $('#fform-pass').value = '';       // 密码不留着
  }
}
/* ★★ 2026-10-09 用户要求「删除手机号登录」：
   至此「短信验证码」这条链路**前后端全部删除** —— 前端的 `sendForumCode()`、
   后端的 `forum_form_send_code()` 与 `/api/forum/form/send_code` 路由、
   以及 `JS_FORUM_SEND_CODE` 探测脚本，一并移除。 */
/* ★ 2026-09-26：换一张验证码（代点服务器那边那张图） */
async function refreshForumCap() {
  $('#fform-msg').textContent = '正在换一张验证码…';
  const r = await api('/api/forum/form/refresh_cap', {});
  if (!r || !r.ok) {
    $('#fform-msg').textContent = (r && r.msg) || '刷新失败';
    return;
  }
  await refreshForumForm();
  $('#fform-cap').value = '';
  $('#fform-msg').textContent = '验证码已换，请重新填';
}
/* 点验证码 → 放大浮层（太小看不清，用户反馈） */
function openCapZoom() {
  const src = $('#fform-cap-img').src;
  if (!src) return;
  $('#cap-zoom-img').src = src;
  $('#cap-zoom').classList.remove('hidden');
}
function closeCapZoom() {
  const z = $('#cap-zoom');
  if (z) z.classList.add('hidden');
}

/* ============================ 事件绑定 ============================ */
function bind() {
  // 页签
  $$('.tab[data-tab]').forEach((b) => b.onclick = () => {
    $$('.tab[data-tab]').forEach((x) => x.classList.remove('active'));
    b.classList.add('active');
    $$('.page').forEach((p) => p.classList.toggle('active', p.id === 'page-' + b.dataset.tab));
  });
  $('#btn-log').onclick = () => openDrawer(logCh);
  $$('.logtab').forEach((b) => b.onclick = () => openDrawer(b.dataset.ch));
  $('#btn-drawer-close').onclick = () => $('#drawer').classList.add('hidden');
  $('#btn-log-clear').onclick = async () => { await api('/api/logs/clear', { ch: logCh });
    $('#log-body').textContent = ''; };
  // ★ 需求⑬：扫码面板「收起」
  $('#btn-qr-hide').onclick = hideQr;
  // ★ 需求⑱：论坛登录外网填表
  $('#btn-fform-hide').onclick = hideForumForm;
  $('#btn-fform-submit').onclick = submitForumForm;
  // ★★ 2026-09-26 用户要求「点击就可以刷新」：
  //   面板里那张验证码图**点一下 = 换一张**。
  //   （原来点图是放大 —— 那会儿图只有 38px 太小才要放大；现在图放大到 56px
  //     够看了，点它换一张更顺手。「换一张」按钮也在，给不看提示的人。）
  //   要看更大就点右边的「放大」按钮 → 走原来的浮层逻辑，没动。
  //   注意：`#btn-fform-send`（发送短信验证码）已随短信行一起删除 → 不再绑定。
  $('#fform-cap-img').onclick = refreshForumCap;
  $('#btn-fform-cap-refresh').onclick = refreshForumCap;
  $('#btn-fform-cap-zoom').onclick = openCapZoom;
  $('#btn-cap-zoom-refresh').onclick = async () => { await refreshForumCap(); };
  $('#btn-cap-zoom-close').onclick = closeCapZoom;
  $('#cap-zoom').onclick = (e) => { if (e.target.id === 'cap-zoom') closeCapZoom(); };

  // 卡密激活
  const doGate = async () => {
    const card = $('#gate-card').value.trim();
    if (!card) { $('#gate-msg').textContent = '请输入卡密'; return; }
    $('#gate-msg').textContent = '正在验证…';
    const r = await api('/api/card/verify', { card });
    $('#gate-msg').textContent = (r && r.msg) || '';
    if (r && r.ok) { $('#gate-card').value = ''; toast('卡密验证通过', 'ok'); }
    refresh(0);
  };
  $('#gate-btn').onclick = doGate;
  $('#gate-card').onkeydown = (e) => { if (e.key === 'Enter') doGate(); };
  $('#gate-retry').onclick = async () => {
    $('#gate-tip').textContent = '正在重新校验卡密…';
    await api('/api/card/retry', {});
    refresh(0);
  };

  // 礼包：设置
  const cfgPatch = () => api('/api/gift/cfg', { patch: {
    interval: $('#cfg-interval').value, limit: $('#cfg-limit').value,
    retry: $('#cfg-retry').value, wait_login: $('#cfg-wait').value,
    claim_one: $('#cfg-claim-one').checked,
    auto_wait_login: $('#cfg-autowait').checked,
    timer_enabled: $('#cfg-timer').checked, timer_time: $('#cfg-timer-time').value } });
  ['cfg-interval', 'cfg-limit', 'cfg-retry', 'cfg-wait', 'cfg-timer-time'].forEach((id) =>
    $('#' + id).onchange = cfgPatch);
  ['cfg-claim-one', 'cfg-autowait', 'cfg-timer'].forEach((id) =>
    $('#' + id).onchange = cfgPatch);
  // ★ 按用户要求，礼包页「操作」面板只剩进度条 —— 唯一的操作按钮「只领选中账号」
  //   已在 2026-09-28 挪到右侧账号面板的【检查】后面。
  //   「开始领取（全部账号）」「停止」「打开站点」「我已完成登录」「定时检测在线」
  //   「🔌 掉线」以及原先那个重新扫码登录的按钮，共七个控件均已删。
  //   领取现在只有两条触发路径：只领选中账号、定时领取。
  $('#btn-run-one').onclick = async () => {
    if (!selAcc) return toast('请先在账号列表点选账号', 'warn');
    const r = await api('/api/gift/run', { ids: [selAcc] }); if (r && r.msg) toast(r.msg, 'err');
  };
  $('#btn-acc-add').onclick = async () => {
    const v = $('#acc-id').value.trim();
    if (!v) return;
    const r = await api('/api/gift/accounts', { id: v });
    if (r && !r.ok) toast(r.msg, 'err'); else $('#acc-id').value = '';
  };
  $('#acc-id').onkeydown = (e) => { if (e.key === 'Enter') $('#btn-acc-add').click(); };
  $('#btn-acc-game').onclick = async () => {
    if (!selAcc) return toast('先选中一个账号', 'warn');
    await api('/api/gift/accounts/update', { id: selAcc, game: $('#acc-game').value.trim() });
    toast('已保存游戏账号');
  };
  $('#btn-acc-del').onclick = async () => {
    if (!selAcc) return;
    // ★ 用户要求：删账号顺手把这个账号的 Cookie 一起删掉（profile 目录保留）
    if (await confirmBox('删除账号 ' + selAcc + ' ？\n'
        + '（会一并删掉该账号的 Cookie，等于退出登录；浏览器 profile 目录保留）', '删除')) {
      const r = await api('/api/gift/accounts/delete', { id: selAcc });
      selAcc = '';
      if (r && r.ok) {
        toast(r.cookies ? ('已删除，并清掉 ' + r.cookies + ' 个 Cookie 文件') : '已删除',
              'ok');
      }
    }
  };
  // ★ 用户要求：删除账号后面加一个【检查】，一键核对**所有账号**是否在线。
  //   这里只管触发，结果由后端 SSE 推到账号表的「登录态」列（进度看日志）。
  $('#btn-acc-check').onclick = async () => {
    const r = await api('/api/gift/online', {});
    if (r && r.msg) toast(r.msg, r.ok ? 'ok' : 'warn');
  };
  $('#acc-import').onchange = async (e) => {
    const f = e.target.files[0]; if (!f) return;
    try {
      const txt = await f.text();
      const d = JSON.parse(txt);
      const list = Array.isArray(d) ? d : (d.accounts || []);
      const r = await api('/api/gift/accounts/import', { accounts: list });
      toast('导入 ' + ((r && r.n) || 0) + ' 个账号', 'ok');
    } catch (ex) { toast('文件解析失败：' + ex, 'err'); }
    e.target.value = '';
  };
  $('#btn-login').onclick = async () => {
    if (!selAcc) return;
    const r = await api('/api/gift/login', { id: selAcc });
    toast((r && r.msg) || '已打开浏览器', r && r.ok ? 'warn' : 'err');
  };
  // ★ 「我已完成登录」已删：扫完码由程序自己检测并保存（窗口一直开着，扫多久都行）
  // ★ 「取消登录」也已删（用户要求）：登录窗口关掉即等于取消，不再单独给按钮；
  //   后端 /api/gift/login/cancel 连同 Service.cancel_login() 一并撤掉，防长回来。

  // 论坛
  $('#btn-forum-add').onclick = async () => {
    const r = await api('/api/forum/add', { name: $('#f-new-name').value, url: $('#f-new-url').value });
    if (r && !r.ok) toast(r.msg, 'err');
    else { $('#f-new-name').value = ''; $('#f-new-url').value = ''; }
  };
  $('#btn-forum-save').onclick = async () => {
    await api('/api/forum/settings', { patch: { auto_sign: $('#f-auto').checked,
      auto_time: $('#f-auto-time').value, headless: $('#f-headless').checked } });
    toast('设置已保存', 'ok');
  };
  $('#btn-forum-sign-all').onclick = () => api('/api/forum/sign', {});
  $('#btn-forum-stop').onclick = () => api('/api/forum/stop', {});
  $('#btn-forum-clear-all').onclick = async () => {
    if (await confirmBox('清空全部论坛的登录状态（Cookie）？', '清空')) api('/api/forum/clear', {});
  };

  // QQ（多账号：一个 QQ 号 = 一条 WS 连接）
  $('#btn-qq-conn-add').onclick = async () => {
    const url = ($('#qq-new-url').value || '').trim();
    if (!url) return toast('请先填写 WS 地址，例如 ws://127.0.0.1:3001', 'err');
    const r = await api('/api/qq/conn/add', { url: url,
      token: $('#qq-new-token').value, remark: $('#qq-new-remark').value });
    if (r && r.ok) {
      $('#qq-new-remark').value = ''; $('#qq-new-url').value = ''; $('#qq-new-token').value = '';
      if (r.id) qqPick = r.id;
      toast('已添加并开始连接', 'ok');
      refresh(0);
    } else if (r && r.msg) toast(r.msg, 'err');
  };
  $('#qq-conn-pick').onchange = () => { qqPick = $('#qq-conn-pick').value; qqSig = ''; renderQQ(); };
  $('#btn-qq-refresh').onclick = () => api('/api/qq/refresh', { cid: qqPick || null });
  $('#qq-filter').oninput = () => { qqSig = ''; renderQQ(); };
  $('#btn-qq-all').onclick = () => api('/api/qq/select_all', { action: 'all', cid: qqPick || null });
  $('#btn-qq-none').onclick = () => api('/api/qq/select_all', { action: 'none', cid: qqPick || null });
  $('#btn-qq-invert').onclick = () => api('/api/qq/select_all', { action: 'invert', cid: qqPick || null });
  $('#btn-qq-sign').onclick = async () => {
    // ★ 一键签到 = 所有账号，各账号只签它自己勾选的群
    const r0 = await api('/api/qq/sign', { confirm: true });
    if (r0 && r0.need_confirm) {
      const txt = '即将用 ' + (r0.n_accounts || 1) + ' 个 QQ 账号，给共 ' + r0.n
        + ' 个群各发送一条消息，发送后无法撤回。\n\n默认消息：'
        + (r0.default_msg || '（空）') + '\n'
        + (r0.n_custom ? '其中 ' + r0.n_custom + ' 个群用它们各自的专属消息，其余用默认消息。'
                       : '全部使用默认消息。')
        + '\n\n确认开始？';
      if (await confirmBox(txt, '发送')) api('/api/qq/sign', { confirm: false });
    } else if (r0 && !r0.ok && r0.msg) { toast(r0.msg, 'err'); }
  };
  $('#btn-qq-stop').onclick = () => api('/api/qq/stop', {});
  $('#btn-qq-like').onclick = async () => {
    await api('/api/qq/settings', { patch: { like_users: $('#qq-like').value, like_times: $('#qq-times').value } });
    // ★ 点赞用「当前查看的那个账号」的 WS 连接（没选就由后端取第一个在线的）
    const r = await api('/api/qq/like', { users: $('#qq-like').value, cid: qqPick || null });
    if (r && !r.ok) toast(r.msg, 'err');
  };
  const qqSet = () => api('/api/qq/settings', { patch: {
    default_msg: $('#qq-msg').value, like_users: $('#qq-like').value,
    like_times: $('#qq-times').value,
    kw_on: $('#qq-kw').checked,
    kw_notify: $('#qq-kw-qq').value, kw_words: $('#qq-kw-words').value,
    auto_sign: $('#qq-auto').checked, auto_time: $('#qq-auto-time').value,
    like_auto: $('#qq-like-auto').checked, like_auto_time: $('#qq-like-auto-time').value } });
  ['qq-msg', 'qq-like', 'qq-times', 'qq-kw-qq',
   'qq-kw-words', 'qq-auto-time', 'qq-like-auto-time'].forEach((id) => $('#' + id).onchange = qqSet);
  ['qq-kw', 'qq-auto', 'qq-like-auto'].forEach((id) => $('#' + id).onchange = qqSet);

  // ★ 2026-10-09 反向 WS：启动 / 停止监听（配置在启动时一并落盘）
  $('#btn-qq-rev-start').onclick = async () => {
    // ★ 2026-10-10 输入框已删：host/path/token 不传（后端默认 0.0.0.0 / 空 / 空）
    const r = await api('/api/qq/reverse/start', {
      port: $('#qq-rev-port').value });
    if (r && r.ok) toast('反向 WS 监听已启动', 'ok');
    else if (r && r.msg) toast(r.msg, 'err');
    refresh(0);
  };
  $('#btn-qq-rev-stop').onclick = async () => {
    await api('/api/qq/reverse/stop', {});
    toast('反向 WS 监听已停止', 'ok');
    refresh(0);
  };

  // 公告（卡密端推送的落地副本）
  $('#btn-notice-read').onclick = async () => {
    await api('/api/notice/read', {});
    toast('公告已标记为已读', 'ok');
    refresh(0);
  };
  $('#btn-notice-clear').onclick = async () => {
    if (await confirmBox('清空本机已收到的公告？\n'
                         + '（只是本地这份记录，卡密端的推送队列不受影响）', '清空')) {
      await api('/api/notice/clear', {});
      refresh(0);
    }
  };

  // 设置
  $('#btn-set-detect').onclick = () => api('/api/gift/detect', {});
  $('#set-browser').onchange = () => api('/api/gift/browser', { path: $('#set-browser').value });
  $('#btn-set-browser-path').onclick = async () => {
    const r = await api('/api/gift/browser', { path: $('#set-browser-path').value.trim() });
    if (r && !r.ok) toast(r.msg, 'err'); else toast('已切换浏览器', 'ok');
  };
  $('#btn-set-card').onclick = async () => {
    const r = await api('/api/card/verify', { card: $('#set-new-card').value.trim() });
    toast((r && r.msg) || '', r && r.ok ? 'ok' : 'err');
    if (r && r.ok) $('#set-new-card').value = '';
  };
  // ★ 「修改卡密服务端地址」已删（用户要求）：输入框 / 保存按钮 / 后端那条改地址的路由
  //   一并撤掉，服务端地址只在首次配置时确定，界面不再给改的口子；防长回来。
  // 端口：改完服务端会热切换到新端口，这里再把浏览器也带过去
  $('#set-port').oninput = () => { portTouched = true; };
  // ★ 跳转地址要用**当前访问用的主机名**：服务器上用别的电脑访问时是
  //   http://服务器IP:8000，如果直接跳到后端给的 127.0.0.1:新端口，
  //   就会跳到「自己这台电脑」上去，页面必然打不开。
  const sameHostUrl = (p) => {
    const h = window.location.hostname;
    return 'http://' + (h && h !== '0.0.0.0' ? h : '127.0.0.1') + ':' + p + '/';
  };
  $('#btn-set-port').onclick = async () => {
    const v = String($('#set-port').value).trim();
    const cur = (NETI && NETI.port) || 8000;
    if (!/^\d+$/.test(v)) return toast('端口要填数字', 'err');
    const n = Number(v);
    if (n < 1024 || n > 65535) return toast('端口要填 1024 ~ 65535 之间的整数', 'err');
    if (n === cur) return toast('端口没变', 'err');
    if (!(await confirmBox('把访问端口从 ' + cur + ' 改成 ' + n +
                           '？改完页面会自动跳到新地址。', '切换'))) return;
    const r = await api('/api/set_port', { port: n });
    if (!r || !r.ok) return toast((r && r.msg) || '切换失败', 'err');
    toast('端口已改为 ' + r.port + '，正在打开新地址…', 'ok');
    setTimeout(() => { window.location.href = sameHostUrl(r.port); }, 900);
  };

  // 「允许其它电脑访问」：勾选/取消后热切换绑定地址（不用重启）
  $('#set-lan').onchange = () => { lanTouched = true; };
  $('#btn-set-lan').onclick = async () => {
    const want = !!($('#set-lan') || {}).checked;
    const had = !!(NETI && NETI.lan);
    const cur = (NETI && NETI.port) || 8000;
    if (want === had) return toast('没有变化', 'err');
    if (want) {
      if (!(await confirmBox('改成允许其它电脑访问？' +
                             '局域网上能看到这台机器的人都能打开这个界面（它本身没有登录），' +
                             '请确认是在可信的内网里。', '开启'))) return;
    } else {
      if (!(await confirmBox('关掉其它电脑的访问？' +
                             '如果你正在用别的电脑远程访问这个页面，保存后会立刻断开，' +
                             '需要回到服务器上的 http://127.0.0.1:' + cur + '/ 继续操作。',
                             '关闭'))) return;
    }
    const r = await api('/api/set_lan', { lan: want });
    if (!r || !r.ok) return toast((r && r.msg) || '切换失败', 'err');
    NETI = r.net || NETI;
    lanTouched = false;
    renderNet();
    toast(want ? '已允许其它电脑访问，下次启动也会记住' : '已关掉其它电脑访问', 'ok');
  };
  // ★ 诊断 / 文字推送 / 管理后台 三块已从设置页移除（属于卡密端），
  //   对应的 /api/diag 与 /api/card/admin 前端调用也一并删掉。
}

/* ============================ 启动 ============================ */
document.addEventListener('DOMContentLoaded', async () => {
  bind();
  startSSE();
  await doRefresh();
  // ★ 需求⑬：正在服务器那头扫码时打开本页 / 换台电脑打开 —— 立刻把码显示出来
  refreshQr();
  // ★ 需求⑱：正在填论坛登录表单时打开本页 —— 立刻把表单显示出来
  refreshForumForm();
  // ★ 需求⑭：剩余时间每 5 秒自己往前走（数字不再定住不动）
  setInterval(tickLeft, 5000);
  // ★ 需求⑯：万一 SSE 断了，也要能发现「被卡密端强制关闭」
  setInterval(async () => {
    if (killShown) return;
    const r = await api('/api/state');
    if (r && r.state && r.state.app && r.state.app.kill) {
      killNotice(r.state.app.kill_msg);
    }
  }, 5000);
  // ★★ 2026-09-26 修「二维码在外网电脑上不显示」：
  //   和论坛表单是同一个病 —— 二维码面板以前也**只靠 SSE 推送**更新，
  //   外网长连接一断，重连期间服务端推的 qr 事件永久丢失，码就再也不出现。
  //   这里自己每 3 秒拉一次，彻底不依赖 SSE。
  //   （同一张码不会重设 src，见 refreshQr 里的 ts 判断，不会闪。）
  setInterval(refreshQr, 3000);
  // ★★ 2026-09-26 修「点了登录，面板不出现」的真凶：
  //   论坛表单面板以前**只靠 SSE 推送**更新。人在外网访问时 SSE 长连接常被
  //   代理 / 路由器掐断，重连那段时间里服务端发的 forum_form 事件永久丢失，
  //   面板就再也不会出现 —— 只能手动刷新页面（扫码链路有 hello 补拉，
  //   偏偏这条漏了）。这里自己每 3 秒拉一次，彻底不依赖 SSE。
  setInterval(refreshForumForm, 3000);
  // 兜底轮询：SSE 正常时界面靠推送实时更新，这两条几乎用不到；
  // SSE 万一断了，3 秒一次顶上，避免又出现「要等一会 / 得手动刷新」。
  setInterval(doRefresh, 15000);
  setInterval(() => { if (!sseOK) doRefresh(); }, 3000);
  if (window.location.hash) {
    const b = document.querySelector('.tab[data-tab="' + window.location.hash.slice(1) + '"]');
    if (b) b.click();
  }
  window.addEventListener('beforeunload', () => {});
});
