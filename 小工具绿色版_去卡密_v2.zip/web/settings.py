# -*- coding: utf-8 -*-
"""网页版自己的少量设置（目前只有「监听端口」）。

存放位置：
  * 单文件版（小工具端.exe）：`%LOCALAPPDATA%\\XiaoGongJu\\web_settings.json`
    —— 由启动器通过 ZSF_DATA_ROOT 告诉这里；升级 exe **不会**覆盖它；
  * 文件夹版 / 开发环境：程序根目录（`web/` 的上一级）下的 `web_settings.json`。

只存「网页版界面/服务」层面的东西，绝不碰原程序的 config.json 等业务数据。
"""

import json
import os

DATA_ROOT_ENV = "ZSF_DATA_ROOT"
FILE_NAME = "web_settings.json"

DEFAULT_PORT = 8000
PORT_MIN = 1024
PORT_MAX = 65535

# ★ 监听方式默认值：True = 绑 0.0.0.0（别的电脑能连）。
#   用户要求「监听方式默认为 0.0.0.0」——开箱即对局域网开放，省得放到服务器上
#   还要先去找开关。不想要对外的话，网页里把勾取消掉即可（会落盘 lan=false 覆盖默认）。
LAN_DEFAULT = True

_HERE = os.path.dirname(os.path.abspath(__file__))


def base_dir():
    """设置文件所在目录：单文件版用数据根目录，否则用程序根目录。"""
    root = (os.environ.get(DATA_ROOT_ENV) or "").strip().strip('"').strip("'")
    if root:
        return root
    return os.path.dirname(_HERE)


def path():
    return os.path.join(base_dir(), FILE_NAME)


def load():
    try:
        with open(path(), encoding="utf-8") as fh:
            d = json.load(fh)
        return d if isinstance(d, dict) else {}
    except (OSError, ValueError):
        return {}


def save(d):
    p = path()
    os.makedirs(os.path.dirname(p), exist_ok=True)
    tmp = p + ".tmp"
    with open(tmp, "w", encoding="utf-8") as fh:
        json.dump(d, fh, ensure_ascii=False, indent=2)
    os.replace(tmp, p)
    return p


def valid_port(v):
    """端口合法就返回 int，否则 None。"""
    if isinstance(v, bool):
        return None
    try:
        n = int(str(v).strip())
    except (TypeError, ValueError):
        return None
    return n if PORT_MIN <= n <= PORT_MAX else None


def saved_port():
    """上次保存的端口；没有/不合法返回 None。"""
    return valid_port(load().get("port"))


def set_port(n):
    n = valid_port(n)
    if n is None:
        raise ValueError("端口不合法")
    d = load()
    d["port"] = n
    save(d)
    return n


def saved_lan():
    """上次是不是选了「允许其它电脑访问」。

    **默认 True**：没设置过就绑 0.0.0.0（对其它电脑开放）。
    ⚠ 这个界面本身没有登录（卡密是绑机器的），默认敞开是用户明确要求的取舍；
      不想对外就在网页里取消勾选，落盘的 `lan=false` 会覆盖默认值。
    """
    return bool(load().get("lan", LAN_DEFAULT))


def set_lan(flag):
    d = load()
    d["lan"] = bool(flag)
    save(d)
    return bool(flag)
