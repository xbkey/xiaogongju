# -*- coding: utf-8 -*-
"""纯标准库 WebSocket 客户端（RFC 6455）。

为什么需要它：原程序（zsf_gift_grabber.py）通过 `import websocket`
（websocket-client 第三方库）做两件事：

  1. CDP 直连浏览器（http://127.0.0.1:<port>/json/list 给的 webSocketDebuggerUrl）
  2. OneBot 11 正向 WS（NapCat / LLOneBot / Lagrange 等）

网页版要能在**没装 websocket-client 的机器**上跑，所以这里用 socket + ssl
自己实现一份，只覆盖原程序实际用到的那几个接口（见下），接口名与
websocket-client 保持一致，`web/core.py` 会在检测到真库缺失时把它注册成
`sys.modules["websocket"]`，原程序代码一行都不用改。

用到的接口（已按原源码逐处核对）：
    create_connection(url, timeout=..., additional_headers=[...],
                      http_no_proxy=[...])  -> WebSocket
    WebSocket.create_connection(...)
    WebSocket.send(str | bytes)
    WebSocket.recv() -> str
    WebSocket.settimeout(seconds)
    WebSocket.close()
    WebSocketTimeoutException          # poll_events 靠它判断“这一秒没有事件”
    WebSocketConnectionClosedException
"""

import base64
import errno
import os
import select
import socket
import ssl
import struct
import urllib.parse

__all__ = [
    "WebSocket", "create_connection",
    "WebSocketException", "WebSocketTimeoutException",
    "WebSocketConnectionClosedException", "WebSocketBadStatusException",
    # ★ 2026-10-09 反向 WS（OneBot 11 反向 WebSocket）：小工具端当服务端
    "WSListener", "accept_websocket",
]

# 供原程序 _ws_header_kw() 探测：它会在 websocket 模块源码里搜
# "additional_headers" 来决定 create_connection 的附头参数名。
# 本文件源码里出现了该字符串（就是上面这几行），探测结果即为
# "additional_headers" —— 与下面 create_connection 的签名一致。
_DEFAULT_HEADER_KW = "additional_headers"

_OP_CONT = 0x0
_OP_TEXT = 0x1
_OP_BINARY = 0x2
_OP_CLOSE = 0x8
_OP_PING = 0x9
_OP_PONG = 0xA

_GUID = b"258EAFA5-E914-47DA-95CA-C5AB0DC85B11"
_DEFAULT_HEADERS = [("User-Agent", "zsf-web/1.0")]


class WebSocketException(Exception):
    pass


class WebSocketTimeoutException(WebSocketException):
    """recv() 超时（socket 层面）—— poll_events 用它当“暂无事件”。"""


class WebSocketConnectionClosedException(WebSocketException):
    pass


class WebSocketBadStatusException(WebSocketException):
    def __init__(self, message, status_code=None, status_message=None):
        super().__init__(message)
        self.status_code = status_code
        self.status_message = status_message


class WebSocket(object):
    def __init__(self, timeout=None):
        self.sock = None
        self.timeout = timeout
        self._recv_buf = b""
        self._frag_op = 0
        self._frag_data = b""
        self.connected = False
        self.sock_opt = (socket.IPPROTO_TCP, socket.TCP_NODELAY)
        self.suppress_ragged_eofs = True
        # ★ 2026-10-09 反向 WS：服务端模式下**发出的帧不掩码**（RFC 6455 §5.1），
        #   收帧逻辑不变（客户端发来的帧本来就带掩码，_read_frame 会解）。
        self._is_server = False

    # ------------------------------------------------------------------ 连接
    def connect(self, url, timeout=None, header=None, additional_headers=None,
                http_no_proxy=None, **options):
        """握手建连。header / additional_headers 两种名字都收（原程序会探测）。"""
        parsed = urllib.parse.urlparse(url)
        scheme = (parsed.scheme or "").lower()
        if scheme not in ("ws", "wss"):
            raise WebSocketException("只支持 ws:// / wss:// 地址：%s" % url)
        host = parsed.hostname
        if not host:
            raise WebSocketException("WS 地址缺少主机名：%s" % url)
        port = parsed.port or (443 if scheme == "wss" else 80)
        path = parsed.path or "/"
        if parsed.query:
            path += "?" + parsed.query

        if timeout is not None:
            self.timeout = timeout
        self.sock = self._open_socket(host, port, scheme, timeout)

        headers = list(_DEFAULT_HEADERS)
        extra = additional_headers or header or []
        for h in extra:
            if isinstance(h, str):
                if ":" in h:
                    k, v = h.split(":", 1)
                    headers.append((k.strip(), v.strip()))
                else:
                    headers.append((h.strip(), ""))
            elif isinstance(h, (tuple, list)) and len(h) == 2:
                headers.append((str(h[0]), str(h[1])))
            elif isinstance(h, dict):
                for k, v in h.items():
                    headers.append((str(k), str(v)))
        if not any(k.lower() == "host" for k, _v in headers):
            headers.append(("Host", host if port in (80, 443) else "%s:%d" % (host, port)))

        key = base64.b64encode(os.urandom(16)).decode("ascii")
        lines = ["GET %s HTTP/1.1" % path]
        sent_host = False
        for k, v in headers:
            if k.lower() == "host":
                sent_host = True
            lines.append("%s: %s" % (k, v))
        if not sent_host:
            lines.append("Host: %s" % host)
        lines += [
            "Upgrade: websocket",
            "Connection: Upgrade",
            "Sec-WebSocket-Key: " + key,
            "Sec-WebSocket-Version: 13",
            "",
            "",
        ]
        self._sendall("\r\n".join(lines).encode("utf-8"))

        status_line, resp_headers = self._read_handshake()
        code = self._parse_status(status_line)
        if code != 101:
            self.close()
            raise WebSocketBadStatusException(
                "WebSocket 握手失败：%s" % status_line.strip(), code, status_line.strip())
        expect = base64.b64encode(
            __import__("hashlib").sha1(key.encode("ascii") + _GUID).digest()
        ).decode("ascii")
        got = resp_headers.get("sec-websocket-accept", "")
        if got and got != expect:
            self.close()
            raise WebSocketBadStatusException("Sec-WebSocket-Accept 校验失败", 101,
                                              status_line.strip())
        self.connected = True
        return self

    def _open_socket(self, host, port, scheme, timeout):
        """建 TCP（必要时 TLS）。超时用 max(连接超时, 5s) 建连，之后按 set 的来。"""
        conn_timeout = timeout if timeout else 10
        try:
            sock = socket.create_connection((host, port), timeout=conn_timeout)
        except socket.gaierror as ex:
            raise WebSocketException("域名解析失败 %s: %s" % (host, ex))
        except OSError as ex:
            if ex.errno == errno.EINPROGRESS:
                raise WebSocketException("连接 %s:%d 超时" % (host, port))
            raise WebSocketException("连接 %s:%d 失败: %s" % (host, port, ex))
        try:
            sock.setsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY, 1)
        except Exception:
            pass
        if scheme == "wss":
            # 浏览器调试端口 / 内网机器人框架基本都是自签证书，跳过校验
            ctx = ssl.create_default_context()
            ctx.check_hostname = False
            ctx.verify_mode = ssl.CERT_NONE
            try:
                sock = ctx.wrap_socket(sock, server_hostname=host)
            except Exception as ex:
                try:
                    sock.close()
                except Exception:
                    pass
                raise WebSocketException("TLS 握手失败: %s" % ex)
        if self.timeout is not None:
            sock.settimeout(self.timeout)
        return sock

    def _parse_status(self, line):
        try:
            parts = str(line).split()
            return int(parts[1])
        except Exception:
            return 0

    def _read_handshake(self, limit=1 << 20):
        data = b""
        while b"\r\n\r\n" not in data:
            try:
                chunk = self.sock.recv(4096)
            except socket.timeout:
                raise WebSocketTimeoutException("等待握手响应超时")
            if not chunk:
                raise WebSocketException("握手期间连接被关闭")
            data += chunk
            if len(data) > limit:
                raise WebSocketException("握手响应过大")
        head, _, rest = data.partition(b"\r\n\r\n")
        self._recv_buf = rest
        text = head.decode("utf-8", "replace")
        lines = text.split("\r\n")
        status_line = lines[0] if lines else ""
        headers = {}
        for ln in lines[1:]:
            if ":" in ln:
                k, v = ln.split(":", 1)
                headers[k.strip().lower()] = v.strip()
        if "sec-websocket-accept" not in headers:
            # 有些实现大小写不统一，宽松兜一层
            for k, v in list(headers.items()):
                if k.lower() == "sec-websocket-accept":
                    headers["sec-websocket-accept"] = v
        return status_line, headers

    def _sendall(self, data):
        if self.sock is None:
            raise WebSocketConnectionClosedException("连接已关闭")
        try:
            self.sock.sendall(data)
        except socket.timeout:
            raise WebSocketTimeoutException("发送超时")
        except OSError as ex:
            self.connected = False
            raise WebSocketConnectionClosedException("发送失败: %s" % ex)

    # ------------------------------------------------------------------ 收发
    def send(self, payload):
        """客户端发出的帧必须掩码（RFC 6455 §5.3）。"""
        if isinstance(payload, str):
            payload = payload.encode("utf-8")
        elif isinstance(payload, (bytes, bytearray)):
            payload = bytes(payload)
        else:
            payload = str(payload).encode("utf-8")
        self._send_frame(_OP_TEXT, payload)

    def send_binary(self, payload):
        self._send_frame(_OP_BINARY, bytes(payload))

    def _send_frame(self, opcode, payload):
        if self.sock is None:
            raise WebSocketConnectionClosedException("连接已关闭")
        head = bytearray()
        head.append(0x80 | opcode)            # FIN=1
        n = len(payload)
        # ★ 反向 WS：服务端发出的帧**不带掩码**；客户端发出的帧必须掩码（RFC 6455 §5.1）。
        do_mask = not self._is_server
        mask = os.urandom(4) if do_mask else b""
        if n < 126:
            head.append((0x80 | n) if do_mask else n)
        elif n < 65536:
            head.append((0x80 | 126) if do_mask else 126)
            head += struct.pack(">H", n)
        else:
            head.append((0x80 | 127) if do_mask else 127)
            head += struct.pack(">Q", n)
        if do_mask:
            head += mask
            payload = bytes(b ^ mask[i % 4] for i, b in enumerate(payload))
        self._sendall(bytes(head) + payload)

    def settimeout(self, timeout):
        self.timeout = timeout
        if self.sock is not None:
            try:
                self.sock.settimeout(timeout)
            except Exception:
                pass

    def gettimeout(self):
        return self.timeout

    def recv(self):
        """收一条完整消息，返回 str（原程序所有 recv 都按 JSON 文本用）。

        超时抛 WebSocketTimeoutException；对端关闭返回 ""（websocket-client 行为）。
        """
        while True:
            frame = self._read_frame()
            if frame is None:
                return ""
            fin, opcode, data = frame
            if opcode == _OP_PING:
                try:
                    self._send_frame(_OP_PONG, data)
                except Exception:
                    pass
                continue
            if opcode == _OP_PONG:
                continue
            if opcode == _OP_CLOSE:
                try:
                    self._send_frame(_OP_CLOSE, data[:125])
                except Exception:
                    pass
                self.connected = False
                try:
                    if self.sock:
                        self.sock.close()
                except Exception:
                    pass
                self.sock = None
                return ""
            if opcode == _OP_CONT:
                if not self._frag_op:
                    continue
                self._frag_data += data
                if fin:
                    payload, self._frag_data = self._frag_data, b""
                    op, self._frag_op = self._frag_op, 0
                    return self._decode(op, payload)
                continue
            if opcode in (_OP_TEXT, _OP_BINARY):
                if not fin:
                    self._frag_op, self._frag_data = opcode, data
                    continue
                return self._decode(opcode, data)
            # 未知 opcode：忽略，继续读下一帧
            continue

    @staticmethod
    def _decode(opcode, payload):
        if opcode == _OP_BINARY:
            # 原程序只用文本；二进制帧兜底解成 latin-1，保证不丢内容
            return payload.decode("latin-1")
        return payload.decode("utf-8", "replace")

    def _read_exact(self, n):
        while len(self._recv_buf) < n:
            try:
                chunk = self.sock.recv(65536)
            except socket.timeout:
                raise WebSocketTimeoutException("接收超时")
            except OSError as ex:
                self.connected = False
                raise WebSocketConnectionClosedException("接收失败: %s" % ex)
            if not chunk:
                return None
            self._recv_buf += chunk
        out, self._recv_buf = self._recv_buf[:n], self._recv_buf[n:]
        return out

    def _read_frame(self):
        """返回 (fin, opcode, payload) 或 None（对端已关闭）。"""
        if self.sock is None:
            return None
        head = self._read_exact(2)
        if head is None:
            return None
        b1, b2 = head[0], head[1]
        fin = bool(b1 & 0x80)
        opcode = b1 & 0x0F
        masked = bool(b2 & 0x80)
        length = b2 & 0x7F
        if length == 126:
            ext = self._read_exact(2)
            if ext is None:
                return None
            length = struct.unpack(">H", ext)[0]
        elif length == 127:
            ext = self._read_exact(8)
            if ext is None:
                return None
            length = struct.unpack(">Q", ext)[0]
        mask = b""
        if masked:
            mask = self._read_exact(4)
            if mask is None:
                return None
        data = b""
        if length:
            data = self._read_exact(length)
            if data is None:
                return None
        if masked and data:
            data = bytes(b ^ mask[i % 4] for i, b in enumerate(data))
        return fin, opcode, data

    # ------------------------------------------------------------------ 关闭
    def close(self, status=None, reason=None, timeout=3):
        try:
            if self.sock is not None:
                payload = b""
                if status is not None:
                    payload = struct.pack(">H", int(status)) + \
                        (reason or "").encode("utf-8")[:123]
                self._send_frame(_OP_CLOSE, payload)
        except Exception:
            pass
        self.connected = False
        try:
            if self.sock is not None:
                self.sock.close()
        except Exception:
            pass
        self.sock = None
        self._recv_buf = b""

    def __enter__(self):
        return self

    def __exit__(self, *exc):
        self.close()
        return False

    # 原程序个别路径会用 ws.sock 判活（OneBotWS.is_alive 只判 self.ws 非空）
    def fileno(self):
        return self.sock.fileno() if self.sock else -1

    def is_ready(self):
        try:
            if self.sock is None:
                return False
            r, _w, _x = select.select([self.sock], [], [], 0)
            return bool(r)
        except Exception:
            return False


def create_connection(url, timeout=None, header=None, additional_headers=None,
                      http_no_proxy=None, **options):
    """与 websocket-client 同名的入口。返回已握手的 WebSocket 对象。"""
    ws = WebSocket()
    ws.connect(url, timeout=timeout, header=header,
               additional_headers=additional_headers,
               http_no_proxy=http_no_proxy, **options)
    return ws


def enable_trace(*_a, **_kw):
    return None


# ======================================================================
# ★ 2026-10-09 反向 WS（OneBot 11 反向 WebSocket）
# ----------------------------------------------------------------------
# 正向 WS：机器人框架开服务端，我们（客户端）连过去 —— 用上面的 create_connection。
# 反向 WS：**我们开服务端**，机器人框架连进来 —— 用下面的 WSListener + accept_websocket。
#
#   · 连上之后的协议一模一样：我们照样发 action、收 echo 回包 / 事件帧，
#     所以 OneBotWS 那一层可以原样复用（见 OneBotWS.attach）。
#   · 区别只有两点：
#       1) 谁发起 TCP 连接（反向是我们 accept，不拨号）；
#       2) **服务端发出的帧不能掩码**（见 WebSocket._is_server）。
#   · 框架会在握手请求头里带 X-Self-ID（QQ 号）与 X-Client-Role，
#     多账号 = 同一个端口上多个 X-Self-ID 各连一条。
# ======================================================================

def _send_http_error(conn, code, why=""):
    """握手失败时回一个最小 HTTP 响应（让对端看到明确原因，而不是干等超时）。"""
    body = ("%d %s" % (code, why or "error")).encode("utf-8")
    try:
        conn.sendall(
            ("HTTP/1.1 %d %s\r\n"
             "Content-Type: text/plain; charset=utf-8\r\n"
             "Content-Length: %d\r\n"
             "Connection: close\r\n\r\n" % (code, why or "Error", len(body))
             ).encode("utf-8") + body)
    except Exception:
        pass


def _read_http_request(conn, timeout=10.0, limit=1 << 20):
    """从已 accept 的 socket 读一个 HTTP 请求（读到 \\r\\n\\r\\n 为止）。

    返回 {"line","method","target","path","query","headers"(小写键),
          "raw_headers","rest"}。
    rest 是「请求头之后多读到的字节」，必须原样塞回 WebSocket._recv_buf ——
    客户端可能把「握手响应 + 第一帧」连着发过来，丢了它就会吃掉第一个数据帧。
    """
    try:
        conn.settimeout(max(0.5, float(timeout)))
    except Exception:
        pass
    data = b""
    while b"\r\n\r\n" not in data:
        try:
            chunk = conn.recv(4096)
        except socket.timeout:
            raise WebSocketException("等待 WebSocket 握手请求超时")
        except OSError as ex:
            raise WebSocketException("读取握手请求失败: %s" % ex)
        if not chunk:
            raise WebSocketException("握手期间对端已关闭")
        data += chunk
        if len(data) > limit:
            raise WebSocketException("握手请求过大")
    head, _, rest = data.partition(b"\r\n\r\n")
    lines = head.decode("utf-8", "replace").split("\r\n")
    req_line = lines[0].strip() if lines else ""
    parts = req_line.split()
    method = parts[0].upper() if parts else ""
    target = parts[1] if len(parts) > 1 else "/"
    q = ""
    if "?" in target:
        target, q = target.split("?", 1)
    headers = {}
    raw_headers = []
    for ln in lines[1:]:
        if ":" not in ln:
            continue
        k, v = ln.split(":", 1)
        k, v = k.strip(), v.strip()
        raw_headers.append((k, v))
        lk = k.lower()
        headers[lk] = (headers[lk] + ", " + v) if lk in headers else v
    return {"line": req_line, "method": method,
            "target": parts[1] if len(parts) > 1 else target,
            "path": target or "/", "query": q,
            "headers": headers, "raw_headers": raw_headers, "rest": rest}


class WSListener(object):
    """极简 TCP 监听器（只给反向 WS 用：accept 完交给 accept_websocket 升级）。"""

    def __init__(self, host="0.0.0.0", port=6700, backlog=16):
        self.host = str(host or "0.0.0.0")
        self.port = int(port)
        self.backlog = int(backlog)
        self.sock = None

    def start(self):
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        s.bind((self.host, self.port))
        s.listen(self.backlog)
        self.sock = s
        return self

    def accept(self, timeout=0.5):
        """返回 (conn, addr)；超时或已被 close 打断时返回 None。"""
        s = self.sock
        if s is None:
            raise WebSocketException("监听未启动")
        try:
            s.settimeout(float(timeout))
        except Exception:
            pass
        try:
            return s.accept()
        except socket.timeout:
            return None
        except OSError as ex:
            if self.sock is None:
                return None          # close() 引起的，正常退出
            raise WebSocketException("accept 失败: %s" % ex)

    def close(self):
        s, self.sock = self.sock, None
        if s is not None:
            try:
                s.close()
            except Exception:
                pass


def accept_websocket(conn, req, token=""):
    """对一个已 accept 的 TCP 连接做**服务端** WebSocket 握手。

    req 用 _read_http_request() 的结果；token 非空时要求
    `Authorization: Bearer <token>` 或 `?access_token=<token>` 任一对上。

    成功返回 WebSocket（server 模式，可直接 send/recv）；
    失败抛 WebSocketException，且已把 HTTP 错误码回给对端。
    """
    if req.get("method") not in ("GET", ""):
        _send_http_error(conn, 405, "Method Not Allowed")
        raise WebSocketException("反向 WS 只接受 GET 升级请求")
    h = req.get("headers") or {}
    if "websocket" not in str(h.get("upgrade") or "").lower():
        _send_http_error(conn, 400, "Not a WebSocket upgrade")
        raise WebSocketException("不是 WebSocket 升级请求")
    key = str(h.get("sec-websocket-key") or "").strip()
    if not key:
        _send_http_error(conn, 400, "Missing Sec-WebSocket-Key")
        raise WebSocketException("缺 Sec-WebSocket-Key")
    if token:
        auth = str(h.get("authorization") or "")
        q = req.get("query") or ""
        if (auth != "Bearer " + token) and ("access_token=" + token not in q):
            _send_http_error(conn, 401, "Unauthorized")
            raise WebSocketException("反向 WS Token 不匹配")
    accept = base64.b64encode(
        __import__("hashlib").sha1(key.encode("ascii") + _GUID).digest()
    ).decode("ascii")
    try:
        conn.sendall((
            "HTTP/1.1 101 Switching Protocols\r\n"
            "Upgrade: websocket\r\n"
            "Connection: Upgrade\r\n"
            "Sec-WebSocket-Accept: %s\r\n\r\n" % accept
        ).encode("ascii"))
    except OSError as ex:
        raise WebSocketException("回 101 失败: %s" % ex)
    ws = WebSocket()
    ws.sock = conn
    ws._is_server = True
    ws.connected = True
    ws._recv_buf = req.get("rest") or b""   # 握手后可能已带上第一帧
    return ws
