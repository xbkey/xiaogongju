# -*- coding: utf-8 -*-
"""小工具 网页版 —— 启动入口。

用法：
    python run_web.py                 # 端口用「上次保存的设置」（默认 8000），自动打开浏览器
    python run_web.py --port 9000     # 本次临时用 9000（不写进设置）
    python run_web.py --host 127.0.0.1  # 只让本机访问（不对外）
    python run_web.py --no-browser    # 不自动开浏览器
    python run_web.py --lan           # 显式对其它电脑开放（本来就是默认，可省）

★ 监听方式**默认就是 0.0.0.0**（对其它电脑开放），放在服务器上开箱即可用。
  要改回「只有本机能开」：网页「设置 → 访问端口」里取消勾选「允许其它电脑访问」，
  或者启动时加 --host 127.0.0.1。勾选状态会记进设置文件，下次启动继续生效。

★ 端口可以在网页「设置 → 访问端口」里改，改完自动热切换 + 跳新地址，不用重启程序。
  运行时改的端口会记进设置文件，下次启动继续用；命令行 --port 只影响本次。

★ 启动时如果端口被别的程序占用，会**自动 +1 顺延**（8000 被占就去 8001，再占再 +1），
  以实际监听的端口为准开浏览器；顺延不会写回设置文件，别的程序让开后下次仍然回 8000。
  在网页里手动改端口时不同：那是明确的指定，占了就直接报错并回滚（不会替你顺延）。

★ 部署到服务器给别人用时：确认监听 0.0.0.0（默认已满足），并且要在服务器上
  **放行端口**（Windows 防火墙 / 云服务器安全组），否则别的电脑连不上
  （表现就是一直转圈 / 连接被拒绝）。

源码目录按以下顺序自动查找：
    1) 环境变量 ZSF_SRC
    2) 本目录下的 SRC_DIR.txt（写一行源码目录路径）
    3) 本目录 / 本目录下的「小工具源码」/ 上一级目录及其子目录
    4) %USERPROFILE%\\Downloads\\小工具源码网络版等2项文件\\小工具源码
"""

import argparse
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
if HERE not in sys.path:
    sys.path.insert(0, HERE)

# --- 免安装单文件版（小工具端.exe）专用 -----------------------------------------
# 单文件版 exe 是一个「自解压启动器」：它把整套程序（runtime + web + 小工具源码）
# 释放到 %LOCALAPPDATA%\XiaoGongJu\app，然后调本文件。
# 但原程序的 config.json / accounts.json / card_config.json / app.lock 等
# **全部写在源码目录里**（zsf_gift_grabber.py:base_dir()），app 目录每次升级会被覆盖，
# 所以这里把「代码」和「数据」分开：
#   代码：%LOCALAPPDATA%\XiaoGongJu\app\      ← 可被覆盖/升级
#   数据：%LOCALAPPDATA%\XiaoGongJu\data\小工具源码\  ← 只补缺、绝不覆盖
# 启动器通过 ZSF_DATA_ROOT 告诉我们根目录；没设就是普通文件夹版，什么都不做。
DATA_ROOT_ENV = "ZSF_DATA_ROOT"


# ★★★ v1.1.27 修「代码永远升不了级」的严重缺陷。
#   数据目录里混着两类文件：
#     · 程序文件：zsf_gift_grabber.py / _card_embed.py / 卡密服务端.py
#                 ← **必须随版本覆盖**
#     · 用户设置：config.json / accounts.json / card_config.json / app.lock
#                 / forum_*.json / records.json        ← 只补缺，绝不覆盖
#   旧实现「一律只补缺」，导致 data\小工具源码\zsf_gift_grabber.py 一旦存在，
#   **之后再怎么升级 exe，跑的都是最初那份旧代码** —— 改了判据/功能全部无效
#   （2026-09-26 踩：红包判据修好、exe 重打了，用户那边「还是不通知」）。
#
# ★★★ 2026-09-26 用户要求「**新版自动覆盖老版本数据，保留用户设置**」：
#   规则倒过来写 —— 只有**明确属于用户设置**的才保住（只补缺），
#   其余一律随新版覆盖。这样 `卡密服务端.py` 之类随版本演进的文件就不会
#   卡在旧版上（跟当初 zsf_gift_grabber.py 是同一个坑）。
USER_SETTINGS = (
    "config.json",          # 程序设置（浏览器 / 端口 / 等待时长…）
    "accounts.json",        # QQ 账号列表
    "card_config.json",     # 卡密配置 + 激活状态
    "web_unlock.json",      # ★ 网页「按访问 IP 解锁」的记账（重启要留住）
    "app.lock",             # 单实例锁
    "records.json",         # 领取记录
    "forum_cfg.json",       # 论坛站点配置 / Cookie
    "notice.json",          # 公告（已读状态）
    "公告.json",
)


def _is_user_setting(name):
    """这个文件属不属于「用户设置」（是就只补缺，绝不覆盖）。

    ★ 判定从严：拿不准的一律**不**算用户设置，让它随新版升级 ——
      卡在旧版上（功能改了没效果）比被覆盖（重配一次）更难查。
    """
    if name in USER_SETTINGS:
        return True
    low = str(name or "").lower()
    if low.startswith("forum_"):            # 论坛站点配置 / Cookie 备份
        return True
    if low.endswith((".txt", ".log", ".bak", ".old")):   # 日志 / 导出 / 备份
        return True
    return False


def _bootstrap_portable():
    root = (os.environ.get(DATA_ROOT_ENV) or "").strip().strip('"')
    if not root:
        return ""
    import shutil

    live = os.path.join(root, "data", "小工具源码")
    bundled = os.path.join(HERE, "小工具源码")

    if os.path.isdir(bundled):
        # ★ 用户要求：控制台不再显示「首次运行：正在准备…」这类内部过程提示。
        #   这里只是把内置源码同步到数据目录（几个小文件，瞬间完成），
        #   没必要打扰用户；真出问题看 %LOCALAPPDATA%\XiaoGongJu\启动日志.txt。
        os.makedirs(live, exist_ok=True)
        for name in sorted(os.listdir(bundled)):
            sp = os.path.join(bundled, name)
            if not os.path.isfile(sp):
                continue
            dp = os.path.join(live, name)
            if _is_user_setting(name):
                # ★ 用户设置 / 用户数据：只补缺，绝不覆盖（保住账号、卡密、Cookie）
                if not os.path.exists(dp):
                    shutil.copy2(sp, dp)
            else:
                # ★ 其余（代码 + 随版本演进的程序文件）：**总是覆盖**
                #   内容相同就不动，免得白白写盘。
                try:
                    if (not os.path.exists(dp)
                            or os.path.getsize(dp) != os.path.getsize(sp)
                            or open(dp, "rb").read() != open(sp, "rb").read()):
                        shutil.copy2(sp, dp)
                except OSError:
                    try:
                        shutil.copy2(sp, dp)
                    except OSError:
                        pass

    os.environ["ZSF_SRC"] = live
    return live


def _hint_src():
    print("   三种指定方式（任选其一）：")
    print("   1) 把 zsf-web 文件夹放到「小工具源码」目录旁边或里面；")
    print("   2) 在本目录新建 SRC_DIR.txt，写入源码目录的完整路径；")
    print("   3) 启动前执行：set ZSF_SRC=D:\\path\\to\\小工具源码")
    print("   （从 .exe 运行的话，本文件不该被单独运行 —— 请重新下载完整 exe。）")


def _qq_group_total(st):
    """★ 2026-10-09 多账号：QQ 群数 = 各条 WS 连接自己的群列表之和。"""
    n = 0
    for c in (st.get("qq", {}).get("conns") or []):
        n += len(c.get("groups") or [])
    return n


def main():
    ap = argparse.ArgumentParser(description="小工具 网页版")
    ap.add_argument("--host", default=None,
                    help="监听地址（不填则用网页里保存的设置，默认 0.0.0.0 = 对其它电脑开放）")
    ap.add_argument("--lan", action="store_true",
                    help="允许局域网/其它电脑访问（等价 --host 0.0.0.0；本来就是默认，可省）")
    ap.add_argument("--port", type=int, default=None,
                    help="监听端口（不填则用上次保存的设置，默认 8000）")
    ap.add_argument("--no-browser", action="store_true", help="不自动打开浏览器")
    ap.add_argument("--check", action="store_true", help="只做环境自检后退出")
    args = ap.parse_args()

    if sys.version_info < (3, 8):
        print("!! 需要 Python 3.8 及以上，当前 %s" % sys.version.split()[0])
        return 2

    # 免安装单文件版：先把内置源码补到固定数据目录，并设好 ZSF_SRC
    _bootstrap_portable()

    # 依赖自检：第三方库缺了也能跑（内置 WebSocket 实现兜底），但要说清楚
    try:
        from web import core
        core._ensure_websocket()
        src = core.find_src_dir()
        if not src:
            print("!! 没找到 zsf_gift_grabber.py。")
            _hint_src()
            return 2
        if args.check:
            C = core.load()
            print("加载成功 ：%s %s" % (C.APP_NAME, C.VERSION))
            from web.service import get_service
            st = get_service().state()
            print("数据自检 ：账号 %d 个 / 论坛 %d 个 / QQ群 %d 个"
                  % (len(st["gift"]["accounts"]), len(st["forum"]["list"]),
                     _qq_group_total(st)))
            print("\n环境自检通过。")
            return 0
    except ImportError as ex:
        print("!! 导入失败：%s" % ex)
        print("   缺少第三方库不影响启动（有内置 WebSocket 实现），请检查上面的报错。")
        return 2

    try:
        from web import server
        from web import settings as wsettings
    except ImportError as ex:
        missing = getattr(ex, "name", "") or ""
        print("!! 启动失败：%s" % ex)
        if missing and missing not in ("web", "websocket"):
            print("   缺少库 %s，可执行：python -m pip install %s" % (missing, missing))
        return 2

    # 监听地址优先级：命令行 --lan / --host（只影响本次） > 网页里保存的设置 > 默认 0.0.0.0
    # ★ 默认绑 0.0.0.0（对其它电脑开放）——放到服务器上开箱即可用，不用再找开关。
    #   要回到「只有本机能开」：网页「设置 → 访问端口」里取消勾选，或 --host 127.0.0.1。
    if args.lan:
        host = "0.0.0.0"
    elif args.host:
        host = args.host
    else:
        host = "0.0.0.0" if wsettings.saved_lan() else "127.0.0.1"

    port = args.port or wsettings.saved_port() or wsettings.DEFAULT_PORT
    # 端口合法性先兜住，后面几条提示都要用到它
    if wsettings.valid_port(port) is None:
        print("!! 端口 %s 不合法（要 %d~%d），改用 %d"
              % (port, wsettings.PORT_MIN, wsettings.PORT_MAX, wsettings.DEFAULT_PORT))
        port = wsettings.DEFAULT_PORT

    # ★ 用户要求：「8000 端口如果占用自动顺延 +1」。
    #   这里在**打印横幅之前**就把端口定下来，免得上面提示一个端口、
    #   下面 serve() 又贴着另一个端口起监听，两边对不上。
    #   顺延结果不写回设置文件 —— 占用往往只是临时的（别的程序开着），
    #   写回去就等于把用户设的端口悄悄改掉了，下次启动就再也回不到 8000。
    _want_port = port
    port = server.pick_port(host, port)
    if port != _want_port:
        print("端口     ：%d 已被占用，已自动顺延到 %d（设置里仍是 %d）"
              % (_want_port, port, _want_port))

    _local_only = host in ("127.0.0.1", "::1", "localhost", "")
    if _local_only:
        print("监听     ：%s（只有本机能开；要放开就取消网页里的勾选限制）" % host)
    else:
        _why = "命令行 --lan" if args.lan else ("命令行 --host" if args.host
                                               else "网页里保存的设置（默认值）")
        print("监听     ：%s（其它电脑可以访问 · %s）" % (host, _why))
        print("提示     ：别的电脑打不开时，记得在服务器上放行 %d 端口（防火墙/安全组）" % port)

    try:
        return server.serve(host=host, port=port,
                            open_browser=not args.no_browser)
    except KeyboardInterrupt:
        return 0


if __name__ == "__main__":
    sys.exit(main() or 0)
