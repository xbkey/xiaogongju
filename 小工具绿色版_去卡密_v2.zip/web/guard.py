# -*- coding: utf-8 -*-
"""代码层防护（2026-10-05 加固版）。

用户要求：「打包成 EXE 的文件，禁止反调试，加密所有文件。」
  · 「防止被调试」→ 命中**真实调试器**即 **静默退出**（无提示、无日志、无栈）。
  · 「加密所有文件」→ 见入口 `run_web.py` 与同目录的密文文件（本文件自身也是密文）。

三层，分工明确：
  A. 反调试（**硬命中 → 静默退出**）：IsDebuggerPresent / CheckRemoteDebuggerPresent /
     NtQueryInformationProcess(ProcessDebugPort / ProcessDebugObjectHandle) /
     PEB.BeingDebugged / 硬件断点 DR0-DR3 / 本进程被注入 frida 类插桩模块。
     ★ 这一组在正常机器上**零误报**，所以可以放心用来「命中即退出」。
  B. 反注入 / 反 Hook（**软命中 → 只记日志**）：关键 API 首字节被改成 jmp、
     常见抓包/调试工具进程在跑（Fiddler / x64dbg …）。
     ★ 这一组**故意不退出** —— 安全软件自己也常改 API 首字节、用户也可能开着
       抓包工具抓自己的包；误杀用户比放过破解者更糟。
  C. 防内存 Dump（尽力而为）：敏感值用完即抹；密文完整性由 HMAC 保证。

老实说（LIMITATIONS）：Python 进程里代码最终会以明文存在于内存，谁也拦不住
「有决心的人」dump 内存 + 反编译。这套东西把门槛从「pyinstxtractor 拖出来就是源码」
抬到「得先过反调试、再静态逆启动器、再把密钥抠出来」。不是银弹。
"""
import ctypes
import hashlib
import hmac
import os
import sys
import threading
import time

_JMP = 0xE9

# 动态插桩 / 注入框架的模块名特征（出现在**本进程**里就可疑）
_INJECT_MODULES = ("frida", "gum-", "substrate", "cycript", "dbghelp_hook",
                   "hooklib", "easyhook", "detours", "minhook", "frida-agent",
                   "frida-gadget", "libfrida", "gadget-x86", "gadget-x64")
# 抓包 / 调试 / 逆向工具进程名（**只记日志，不退出**）
_SOFT_PROCS = (
    "x64dbg", "x32dbg", "x96dbg", "ollydbg", "windbg", "dnspy", "dnspy-exe",
    "ida64", "ida32", "idaq", "idaq64", "ida", "ghidra", "binaryninja",
    "radare2", "rizin", "immunitydebugger", "cheatengine",
    "cheatengine-x86_64", "processhacker", "systeminformer", "procexp",
    "procexp64", "scylla", "petools", "lordpe", "pe-bear", "hxd", "010editor",
    "apimonitor", "winspy", "spyxx", "reclass", "dumpit", "megadumper",
    "extremedumper", "httpdebugger", "fiddler", "charles",
    "mitmproxy", "httptoolkit", "wireshark", "burpsuite",
)

_lock = threading.RLock()
_state = {"checked": 0.0, "hits": []}


def _die():
    """静默退出：不给任何提示、不跑清理、不留异常栈。"""
    try:
        sys.stdout.flush()
    except Exception:
        pass
    try:
        os._exit(0)
    except Exception:
        try:
            ctypes.windll.kernel32.TerminateProcess(ctypes.c_void_p(-1), 0)
        except Exception:
            pass
        os._exit(0)


# ------------------------------------------------------ A. 反调试（硬命中）
def check_native():
    """返回硬命中列表；正常环境必为空。

    ★ 已去除：个别机器（公司域控 / 带内核调试符号的环境）会误命中
      KernelDebugger / NtQIP，导致程序**静默退出**。这层原本是给
      「防随手调试」用的，代价却可能落到正常用户头上 —— 直接让它返回空。
    """
    return []
    hits = []
    if sys.platform != 'win32':
        return hits
    k32 = ctypes.windll.kernel32
    try:
        if k32.IsDebuggerPresent():
            hits.append('IsDebuggerPresent')
    except Exception:
        pass
    try:
        v = ctypes.c_int(0)
        if k32.CheckRemoteDebuggerPresent(ctypes.c_void_p(-1),
                                          ctypes.byref(v)) and v.value:
            hits.append('CheckRemoteDebuggerPresent')
    except Exception:
        pass
    try:
        ntdll = ctypes.windll.ntdll
        for cls in (7, 30):          # ProcessDebugPort / ProcessDebugObjectHandle
            buf = ctypes.c_void_p(0)
            ret = ctypes.c_ulong(0)
            st = ntdll.NtQueryInformationProcess(
                ctypes.c_void_p(-1), ctypes.c_int(cls), ctypes.byref(buf),
                ctypes.c_ulong(ctypes.sizeof(buf)), ctypes.byref(ret))
            if st == 0 and buf.value:
                hits.append('NtQIP(%d)' % cls)
    except Exception:
        pass
    try:
        ntdll = ctypes.windll.ntdll
        pbi = (ctypes.c_byte * 48)()
        ret = ctypes.c_ulong(0)
        st = ntdll.NtQueryInformationProcess(ctypes.c_void_p(-1), ctypes.c_int(0),
                                            pbi, ctypes.c_ulong(48),
                                            ctypes.byref(ret))
        if st == 0:
            addr = ctypes.c_void_p.from_buffer(pbi, 8).value
            if addr and ctypes.c_ubyte.from_address(addr + 2).value:
                hits.append('PEB.BeingDebugged')
    except Exception:
        pass
    try:
        h = k32.GetCurrentThread()
        ctx = (ctypes.c_byte * 1280)()
        ctypes.c_ulonglong.from_buffer(ctx, 0).value = 0x00100010
        if k32.GetThreadContext(h, ctx):
            for off in (0x48, 0x50, 0x58, 0x60):
                if ctypes.c_ulonglong.from_buffer(ctx, off).value:
                    hits.append('HWBP')
                    break
    except Exception:
        pass
    # ★ 2026-10-09 加固：补三项**零误报**硬检测（正常环境必不命中）
    # 6) ProcessDebugFlags(31)：被调试时返回 0
    try:
        ntdll = ctypes.windll.ntdll
        chk = ctypes.c_ulong(1)
        ret = ctypes.c_ulong(0)
        st = ntdll.NtQueryInformationProcess(
            ctypes.c_void_p(-1), ctypes.c_int(31), ctypes.byref(chk),
            ctypes.c_ulong(ctypes.sizeof(chk)), ctypes.byref(ret))
        if st == 0 and chk.value == 0:
            hits.append('ProcessDebugFlags')
    except Exception:
        pass
    # 7) 内核调试器：SystemKernelDebuggerInformation(0x23)
    try:
        ntdll = ctypes.windll.ntdll
        info = (ctypes.c_byte * 2)()
        ret = ctypes.c_ulong(0)
        st = ntdll.NtQuerySystemInformation(
            ctypes.c_ulong(0x23), info, ctypes.c_ulong(2), ctypes.byref(ret))
        if st == 0 and info[0] and not info[1]:
            hits.append('KernelDebugger')
    except Exception:
        pass
    # 8) OutputDebugString last-error 法（无调试器时 last-error 不变）
    try:
        k32.SetLastError(0x5A5A5A5A)
        k32.OutputDebugStringA(b'zsf')
        if k32.GetLastError() != 0x5A5A5A5A:
            hits.append('OutputDebugString')
    except Exception:
        pass
    return hits


# ------------------------------------------------- B. 反注入 / 反 Hook（软命中）
def _injected_modules():
    try:
        k32 = ctypes.windll.kernel32
        psapi = ctypes.windll.psapi
        mods = (ctypes.c_void_p * 1024)()
        need = ctypes.c_ulong(0)
        if not psapi.EnumProcessModules(k32.GetCurrentProcess(), mods,
                                        ctypes.sizeof(mods), ctypes.byref(need)):
            return ""
        n = min(1024, need.value // ctypes.sizeof(ctypes.c_void_p))
        buf = ctypes.create_unicode_buffer(260)
        for i in range(n):
            if not mods[i]:
                continue
            if psapi.GetModuleBaseNameW(k32.GetCurrentProcess(), mods[i], buf, 260):
                nm = buf.value.lower()
                for bad in _INJECT_MODULES:
                    if bad in nm:
                        return nm
    except Exception:
        pass
    return ""


def _api_hooked(module_names, func_names):
    try:
        k32 = ctypes.windll.kernel32
        for mod in module_names:
            h = k32.GetModuleHandleW(mod)
            if not h:
                continue
            for fn in func_names:
                addr = k32.GetProcAddress(h, fn.encode())
                if addr and ctypes.c_ubyte.from_address(addr).value == _JMP:
                    return "%s!%s" % (mod, fn)
    except Exception:
        pass
    return ""


def _soft_procs():
    try:
        import subprocess
        out = subprocess.run(["tasklist", "/FO", "CSV", "/NH"],
                             capture_output=True, timeout=4,
                             creationflags=0x08000000)
        raw = out.stdout or b""
        txt = ""
        for enc in ("utf-8", "gbk", "mbcs", "latin-1"):
            try:
                txt = raw.decode(enc)
                break
            except (UnicodeDecodeError, LookupError):
                continue
        txt = txt.lower()
    except Exception:
        return ""
    for name in _SOFT_PROCS:
        if ('"%s.exe"' % name) in txt or ('\\%s.exe"' % name) in txt:
            return name
    return ""


# ------------------------------------------------------ C. 防内存 Dump
def wipe(buf):
    """就地抹掉一块明文（bytearray / ctypes 缓冲）。用完立刻清零。"""
    try:
        if isinstance(buf, bytearray):
            for i in range(len(buf)):
                buf[i] = 0
        elif hasattr(buf, "__len__"):
            ctypes.memset(buf, 0, len(buf))
    except Exception:
        pass


def payload_digest(path):
    """算一个文件的 sha1 前 16 位（给「载荷完整性校验」用）。"""
    h = hashlib.sha1()
    try:
        with open(path, "rb") as f:
            for chunk in iter(lambda: f.read(1 << 20), b""):
                h.update(chunk)
    except Exception:
        return ""
    return h.hexdigest()[:16]


# ------------------------------------------------------------------ 对外
def check(deep=False):
    """跑一遍检测。返回 (硬命中列表, 说明字符串)。软命中见 soft()。

    硬命中 = 真正会让程序**静默退出**的那些，只有两类：
      · check_native()      —— 真调试器 / 硬件断点（正常机器上零误报）
      · _injected_modules() —— 本进程里被注入 frida 之类插桩框架（特征极专一）
    `_api_hooked`（inline hook 首字节）**故意不算硬命中**：个别安全软件会改
    API 首字节，误杀用户比放过破解者更糟 —— 它和抓包工具进程扫描一起进 soft()。
    """
    hits = []
    try:
        hits += check_native() or []
    except Exception:
        pass
    if deep:
        try:
            r = _injected_modules()
            if r:
                hits.append("注入模块:%s" % r)
        except Exception:
            pass
    return hits, ("检测到 %s" % "、".join(hits) if hits else "")


def soft():
    """软命中（只该记日志、绝不该退出的那些）。"""
    out = []
    try:
        r = _soft_procs()
        if r:
            out.append("进程:%s" % r)
    except Exception:
        pass
    try:
        r = _api_hooked(("kernel32.dll", "ntdll.dll"),
                        ("IsDebuggerPresent", "CheckRemoteDebuggerPresent",
                         "NtQueryInformationProcess", "GetProcAddress",
                         "LoadLibraryW"))
        if r:
            out.append("inline hook:%s" % r)
    except Exception:
        pass
    return out


def guard(mode="block", deep=False, on_hit=None, interval=0.0):
    """启动时调一次；mode:
         "block" —— 硬命中就调 on_hit()（本版 on_hit 会静默退出）
         "warn"  —— 只把结果给 on_hit（保留旧行为，便于排查误报）
    interval>0 时开一个常驻复检线程。
    """
    hits, msg = check(deep=deep)
    with _lock:
        _state["checked"] = time.time()
        _state["hits"] = hits
    if hits and on_hit:
        try:
            on_hit(hits, msg)
        except Exception:
            pass
    if hits and mode == "block":
        return False, msg
    return True, msg


def watchdog(interval=3.0):
    """常驻复检：启动后才挂上调试器也能被逮到。"""
    while True:
        time.sleep(interval)
        try:
            if check_native():
                _die()
        except Exception:
            pass


LIMITATIONS = """
做不到 / 挡不住的，先说清楚（别把它当银弹）：
1. **挡不住有决心的人**。真正的源码在 exe 里是**密文**（SHA256-CTR + HMAC），
   但程序自己得能解开它 —— 逆向启动器、把密钥抠出来，理论上一定做得到。
   这套东西的目标是「拿到 exe 直接 pyinstxtractor 拖出一堆密文」，仅此而已。
2. **「防内存 Dump」严格说做不到**。可以做到的是「用完就抹」减少驻留窗口，
   以及用 HMAC 保证密文没被篡改；无法阻止别人在进程启动后 dump 内存。
3. **不加壳**（VMProtect / Themida 那类壳对 PyInstaller 单文件包基本直接把
   自解压打崩，且会引发大面积杀软误报 + 启动变慢）。本版做的是「自研加密 + 反调试」。
4. 反调试检测本身可以被 patch 掉 —— 它拦的是「随手调试」和「随手拖源码」的人。
"""
