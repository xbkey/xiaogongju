# -*- coding: utf-8 -*-
"""网页版业务服务：把原程序 App(tkinter) 里的「编排逻辑」原样搬过来，
界面部分换成 Bus 广播 + REST 接口。

被复用的原程序组件（一行未改）：
    Engine                CDP 直连浏览器（礼包领取）
    DiscuzForumSigner     Discuz Cookie 模式签到
    OneBotWS              OneBot 11 正向 WS 客户端
    CardGate              卡密验证 + 心跳
    以及全部模块级工具函数（free_port / detect_browsers / parse_qq_list ...）

对照关系（原方法 -> 本文件方法）：
    App._load_cfg/_save_cfg            -> Service._load_cfg/_save_cfg
    App._load_accounts/_save_accounts  -> Service.load_accounts/save_accounts
    App.add_account / del_account      -> Service.add_account / del_account
    App.check_accounts_async/_worker   -> Service.check_accounts / _check_worker
    App._verify_online / _page_alive   -> 同名（逐字保留）
    App._open_for_account              -> Service._open_for_account
    App.do_login / _login_worker       -> Service.login / _login_worker
    App.do_run / _run_worker / do_stop -> Service.run / _run_worker / stop
    App._forum_do_login                -> Service._forum_do_login
    App._forum_sign_async              -> Service.forum_sign
    App._qq_connect / _qq_sign_async   -> Service.qq_connect / qq_sign
    App._qq_rpk_loop / _qq_rpk_on_event-> 同名（★ 现为「群消息监测」通道，服务关键字通知）
    App._start_timer                   -> Service._scheduler
    App._auto_check_*                  -> 已删（去掉「定时检测在线」；【掉线】按钮后来也按用户要求删了）
"""

import hashlib
import hmac
import html
import json
import os
import random
import re
import shutil
import sys
import threading
import time
import urllib.parse
import urllib.request
from datetime import datetime, timedelta

from . import core
# ★ 2026-10-09 反向 WS：小工具端当服务端，用这里的 WSListener / accept_websocket。
from . import wsclient as _wsc

# ★ 必须复用 web/logs.py 里的那个单例。
#   曾在这里写成 `from .logs import Bus` + `BUS = Bus()`，
#   结果造出第二个 Bus——SSE 处理器订阅的是 logs.BUS，Service 却往 service.BUS 推，
#   推送全进了零订阅者的空巴士，前端只能靠 15 秒轮询兜底（表现为「要等一会 / 刷新才出现」）。
from .logs import BUS

# 原程序里 App 用到、但属于「界面默认值」的常量，这里补一份
DEFAULT_CFG = {
    "browser": "", "interval": 2.0, "limit": 20,
    "wait_login": 240, "auto_wait_login": True, "timer_enabled": False,
    "timer_time": "10:00", "retry": 3, "claim_one": True,
}
# ★ 2026-10-01（用户要求）：礼包领取去掉「无头模式」开关 —— DEFAULT_CFG 不再有
#   headless，update_cfg 也不再接受该键，引擎侧恒为 False（固定开可见窗口）。
# ★ 已删除「定时检测在线（每 3 小时）」（用户要求）：cfg 里不再有 auto_check。
#   现在核对登录态只发生在两处，都是用户主动触发的：账号面板的【检查】按钮
#   （核对**全部**账号是否在线），以及在打开账号等少数流程里顺带核一次。
#   不再有任何后台定时核对。（原先那个【🔌 掉线】按钮仍保持删除状态。）
#   ★ 2026-09-28：「补登」功能整体删除（用户要求）—— 领取只保留「只领选中账号」与「定时领取」。
QQ_MSG_PRESETS = ["签到", "打卡", "每日签到", "签到打卡", "打卡签到", "冒泡", "来了"]

# ======================================================================
# ★ 2026-09-25 需求⑬：扫码二维码同步到「别的电脑上打开的网页」
#   场景：工具挂在服务器上（浏览器窗口也在服务器那台机器上弹），人在另一台电脑
#   打开网页 —— 人是看不到服务器那块屏的。于是这里用 CDP 把扫码框取下来
#   （优先读 DOM 里的 data:URL 图像，退而求其次截那一小块图），经 SSE 推给网页。
#
#   ★ 为什么不改 zsf_gift_grabber.py：原程序是只读的（铁律），这段 JS 只放这儿。
#   ★ 为什么 DOM 优先：CDP 截屏在「窗口被最小化 / 远程桌面断开」时会返回黑图或空，
#     而 <canvas>.toDataURL() / <img>.src 的 data:URL 跟窗口是否可见无关。
# ======================================================================
JS_QR_IMG = r"""
(function(){
  var sels='[class*=qr-wrapper] img,[class*=qrWrapper] img,[class*=qr-code] img,'
    +'[class*=qr_code] img,[class*=qrcode] img,[class*=qr-img] img,[class*=qrImg] img,'
    +'[class*=scan-section] img,[class*=login-modal] img,[class*=loginMask] img,'
    +'[class*=login-mask] img,[class*=qr-wrapper] canvas,[class*=qr-code] canvas,'
    +'[class*=qrcode] canvas,[class*=scan-section] canvas,[class*=login-modal] canvas';
  function vis(el){ if(!el) return false; var cs=getComputedStyle(el);
    if(!cs) return false;
    return !(cs.display==='none'||cs.visibility==='hidden'||cs.opacity==='0'); }
  var els=document.querySelectorAll(sels);
  for(var i=0;i<els.length;i++){
    var el=els[i];
    if(!vis(el)) continue;
    var r=el.getBoundingClientRect();
    if(r.width<60||r.height<60) continue;
    try{
      if((el.tagName||'').toUpperCase()==='CANVAS'){
        var u=el.toDataURL('image/png');
        if(u&&u.indexOf('data:image')===0) return {png:u};
      }else{
        var s=el.currentSrc||el.src||'';
        if(s.indexOf('data:image')===0) return {png:s};
      }
    }catch(e){}
  }
  return null;
})()
"""

# 扫码框所在的那块区域（拿不到 DOM 图像时，退一步按这个框截屏）
JS_QR_BOX = r"""
(function(){
  var sels='[class*=qr-wrapper],[class*=qrWrapper],[class*=qr-code],[class*=qr_code],'
    +'[class*=qrcode],[class*=qr-img],[class*=qrImg],'
    +'[class*=scan-section] img,[class*=scan-section] canvas,'
    +'[class*=login-modal] img,[class*=login-modal] canvas,'
    +'[class*=loginMask] img,[class*=loginMask] canvas,'
    +'[class*=login-mask] img,[class*=login-mask] canvas';
  function vis(el){ if(!el) return false; var cs=getComputedStyle(el);
    if(!cs) return false;
    return !(cs.display==='none'||cs.visibility==='hidden'||cs.opacity==='0'); }
  var els=document.querySelectorAll(sels);
  for(var i=0;i<els.length;i++){
    var el=els[i];
    if(!vis(el)) continue;
    var r=el.getBoundingClientRect();
    if(r.width<60||r.height<60) continue;
    if(r.bottom<=0||r.right<=0||r.top>=innerHeight||r.left>=innerWidth) continue;
    return {x:r.left,y:r.top,w:r.width,h:r.height};
  }
  var m=document.querySelector('.login-modal,[class*=login-modal],[class*=scan-section],'
    +'[class*=loginMask],[class*=login-mask]');
  if(m&&vis(m)){
    var r2=m.getBoundingClientRect();
    if(r2.width>0&&r2.height>0&&r2.bottom>0&&r2.right>0
       &&r2.top<innerHeight&&r2.left<innerWidth)
      return {x:r2.left,y:r2.top,w:r2.width,h:r2.height};
  }
  return null;
})()
"""

# 有些站点要「点一下登录」才弹扫码框。工具挂在服务器上时，用户在别的电脑上
# 没法去点服务器那块屏 —— 所以这里替点一下（只认「登录」字样的可点元素，
# 不碰别的；一整轮登录里最多点 3 次，间隔 20 秒）。
JS_QR_OPEN = r"""
(function(){
  function vis(el){ if(!el) return false; var cs=getComputedStyle(el);
    if(!cs) return false;
    return !(cs.display==='none'||cs.visibility==='hidden'||cs.opacity==='0'); }
  var sels='a.login,.header-login,[class*=login-btn],[class*=loginBtn],'
    +'[class*=to-login],[class*=scan-login],[class*=open-login],[class*=login-entry]';
  for(var i=0;i<sels.length;i++){
    var el=document.querySelector(sels[i]);
    if(!el||!vis(el)) continue;
    var r=el.getBoundingClientRect();
    if(r.width<=0||r.height<=0) continue;
    try{ el.click(); return {hit:(el.className||el.tagName||'').toString().slice(0,40)}; }
    catch(e){}
  }
  var all=document.querySelectorAll('a,button,span,div,i');
  for(var j=0;j<all.length;j++){
    var t=(all[j].textContent||'').trim();
    if(t!=='登录'&&t!=='扫码登录'&&t!=='微信登录'&&t!=='立即登录') continue;
    if(all[j].children.length>1) continue;
    if(!vis(all[j])) continue;
    var r2=all[j].getBoundingClientRect();
    if(r2.width<=0||r2.height<=0) continue;
    try{ all[j].click(); return {hit:'text:'+t}; }catch(e){}
  }
  return null;
})()
"""

# ======================================================================
# ★ 2026-09-25 需求⑱：论坛签到的**账号/密码/验证码**也支持「外网填写」
#   场景与需求⑬一样：工具挂在服务器上，Discuz 登录页是在服务器那台机器的
#   浏览器里打开的 —— 人在别的电脑上看不到那块屏，也就没法填表。
#   这里用 CDP：读表单结构 + 把验证码图取下来，交给网页填；填完再代提交。
#
#   ★ Discuz 的登录页有两级：
#     ① member.php?mod=logging&action=login      账号 + 密码（+ 有时带验证码）
#     ② 提交后若触发验证码，可能跳到 action=login&handlekey=... 让你补验证码
#   所以下面这套 JS 要能同时应付「一步式」和「两步式」。
# ======================================================================
JS_FORUM_FORM = r"""
(function(){
  function vis(el){ if(!el) return false; var cs=getComputedStyle(el);
    if(!cs) return false;
    return !(cs.display==='none'||cs.visibility==='hidden'||cs.opacity==='0'); }
  function val(el){ return el ? (el.value||'') : ''; }
  // Discuz 各版本字段名不完全一样，按优先级找
  function find(names, sels){
    for(var i=0;i<names.length;i++){
      var el=document.querySelector('[name="'+names[i]+'"]');
      if(el && vis(el)) return {el:el, key:names[i]};
    }
    for(var j=0;j<sels.length;j++){
      var e2=document.querySelector(sels[j]);
      if(e2 && vis(e2)) return {el:e2, key:sels[j]};
    }
    return null;
  }
  var u = find(['username','loginfield'], ['#username','input.username','input[name*=user i]']);
  var p = find(['password'], ['#password','input[type=password]','input[name*=pass i]']);
  // ★★ 2026-09-26 用户报「验证码怎么不显示出了」：
  //   各站给图形验证码框命名五花八门，原来只认 captcha / seccode / verify 三族，
  //   像 `name="code"` / `id="checkcode"` / `id="imgcode"` 这类常见的全漏掉 →
  //   hasCaptcha=false → 网页上「验证码」那一行压根不出现，用户没地方填。
  //   这里把常见名字补齐（**排在后面前面命中就优先**，对原有站没有影响）。
  var c = find(['captcha','seccodeverify','verify','checkcode','imgcode','code'],
               ['#seccodeverify','#captcha','#checkcode','#imgcode','#verifycode',
                '#code',
                'input[name*=captcha i]','input[name*=seccode i]',
                'input[name*=verify i]','input[name*=checkcode i]',
                'input[name*=imgcode i]',
                'input[id*=captcha i]','input[id*=checkcode i]']);
  var q = find(['questionid','answer','answer1'], ['#answer','input[name*=answer i]']);
  // ★★ 2026-10-09 用户要求「删除手机号登录」：原来这里认「手机号 / 短信验证码 /
  //   「发送验证码」按钮」三件套 —— 整块删除。现在只认「账号 / 密码 / 图形验证码」。
  // 验证码图片（Discuz 常见 seccodeverify 旁边那张 / misc.php?mod=seccode）
  function firstImg(sels){
    for(var i=0;i<sels.length;i++){
      var el=document.querySelector(sels[i]);
      if(el && vis(el)){ var r=el.getBoundingClientRect();
        if(r.width>30&&r.height>15) return el; }
    }
    return null;
  }
  var img = firstImg(['#seccodeverify + img','#seccodeverify ~ img',
    'img[src*="mod=seccode"]','img[src*="seccode"]','#seccodeimg',
    'img[src*="captcha"]','img[id*=seccode i]',
    // ★★ 2026-09-26 用户报「验证码怎么不显示出了」：验证码图「找不到」的头号原因
    //   就是命名不在这张表里，而输入框那边又认不出 → 整个功能像不存在。
    //   把常见的几类补齐（加在末尾，前面命中就优先，对原有站没有影响）。
    '#captchaimg','#verifyimg','#checkcodeimg','#imgcode',
    'img[src*="checkcode"]','img[src*="verifycode"]',
    'img[id*=captcha i]','img[id*=verify i]',
    'img[alt*="验证码"]','img[title*="验证码"]','label[for=seccodeverify] img',
    '.seccodeimg img','.seccode img']);
  // 当前页面是不是「安全提问」页（有些 Discuz 会先问密保问题）
  var secq = vis(document.querySelector('#questionid'))
    || vis(document.querySelector('[name=questionid]'));
  // ★ 2026-09-26（用户截图反馈）：很多站是**页签切换**式登录
  //   —— 顶部两个 tab：「手机号登录」/「用户名登录」，点哪个就只显示哪几个框。
  //   ★★ 2026-10-09 删除手机号登录后：这里只认「用户名/账号登录」页签，
  //      目的是**把页面从默认的手机号页签切到账号页签**（提交前 pickTab 会点它）。
  function activeTab(){
    // 常见激活标记：class 含 active/on/cur/current/selected、或 aria-selected=true
    var re=/(^|[\s\-_])(active|on|cur|current|selected|checked|hover)([\s\-_]|$)/i;
    var cand=document.querySelectorAll(
      'li,a,span,div,button,dt,dd,h3,label');
    var userTab=null;
    for(var i=0;i<cand.length;i++){
      var el=cand[i];
      var t=(el.textContent||'').replace(/\s+/g,'');
      if(t.length>10) continue;
      var isUser  = /用户名?登录|账号?登录|帐号登录|普通登录|会员登录/.test(t);
      if(!isUser) continue;
      if(!vis(el)) continue;
      // 只有「叶节点」才算页签（别把整个容器认成 tab）
      if(el.children && el.children.length>0) continue;
      var cls=(el.className||'').toString();
      var aria=el.getAttribute('aria-selected');
      var on = (aria==='true') || re.test(cls)
               || (el.parentNode && re.test((el.parentNode.className||'').toString()));
      if(on || !userTab) userTab ={el:el,on:!!on,text:t};
    }
    if(userTab) return {mode:'account', text:userTab.text};
    return {mode:'', text:''};
  }
  var tab = activeTab();
  var form = (u&&u.el?u.el.form:null)
    || document.querySelector('#loginform')
    || document.querySelector('form[name=login]')
    || document.querySelector('form[action*=logging]');
  // ★ 判定登录方式：页签明确说了 → 听它的；否则有账号框就按账号登录。
  //   （★ 2026-10-09 删除手机号登录后不再有 phone 分支。）
  var mode = tab.mode || (u ? 'account' : '');
  return {
    url: location.href,
    mode: mode,
    tabMode: tab.mode, tabText: tab.text,
    // ★★ 2026-09-26 用户报「验证码怎么不显示出了」：
    //   只要页面上**有那张验证码图**，就算这个站要验证码 ——
    //   输入框的命名实在太不统一（用户那个站就是认不出名字的那种），
    //   有图却判成「没有验证码」，网页上连图都看不到。
    hasUser: !!u, hasPass: !!p, hasCaptcha: !!(c || img),
    userKey: u?u.key:'', passKey: p?p.key:'', capKey: c?c.key:'',
    hasSecQ: !!secq, hasQ: !!q,
    hasImg: !!img,
    imgSel: img? (img.id? '#'+img.id : (img.getAttribute('src')||'')) : '',
    hasForm: !!form,
    formAction: form? (form.getAttribute('action')||'') : '',
    userVal: val(u&&u.el), capVal: val(c&&c.el),
    body: (document.body? document.body.innerText||'' : '').slice(0,600)
  };
})()
"""

# 取验证码图片本身。
# ★★ 2026-09-26 用户报「验证码怎么不显示出了」——这里是**第二大根因**：
#   原来只认「DOM 里就是 data:URL 的图」，不是就退化成「按它那块位置截图」。
#   而截图那条路的 JS_FORUM_CAP_BOX 要求图**已经在视口里**（超出就 return null），
#   登录表单经常在页面下方、或窗口开得小 → 永远截不到 → cap_png 恒为空。
#   现在改成：**直接把图取回来**（同源 fetch → blob → dataURL），跟视口无关。
#
# ★★ 2026-09-26 用户又报「图还没取到…」（我们新加的虚线占位一直挂着不消失）。
#   含义：服务端**压根没产出 cap**。除了「选择器没命中」，还有两类以前没覆盖的：
#     ① 验证码图不叫 seccode/captcha/verify，而是别的名字；
#     ② 压根不是 <img>，是某个 div 的 CSS background-image。
#   所以这里不再「一个选择器命中就完事」，改成**候选列表逐个试**：
#     ① 按名字/属性命中的 <img>（老的清单，继续留着）
#     ② 验证码**输入框旁边**那张图（命名千奇百怪时的救命稻草）
#     ③ 登录表单容器里的 <img>
#     ④ class/id 像验证码的元素的 background-image
#   并且**无论成败都把诊断信息带回来**（几个候选 / 第一张的 URL / 失败原因），
#   推到网页面板上 —— 用户下次一句「图还没取到…」我们就能直接判因，
#   不用再让他反复截图（`_fform_probe` 那套证明好用，这里照抄）。
#   （CDP.ev 是 awaitPromise=True，所以这里可以直接 return 一个 Promise。）
JS_FORUM_CAP_DATA = r"""
(function(){
  function vis(el){ if(!el) return false; var cs=getComputedStyle(el);
    if(!cs) return false;
    return !(cs.display==='none'||cs.visibility==='hidden'||cs.opacity==='0'); }
  function srcOf(el){ try{ return String(el.currentSrc||el.src||''); }catch(e){ return ''; } }
  function bgUrl(el){ try{
      var b=getComputedStyle(el).backgroundImage||'';
      var m=/url\(["']?(.*?)["']?\)/.exec(b);
      return m&&m[1] ? m[1] : '';
    }catch(e){ return ''; } }
  function big(el){ try{ var r=el.getBoundingClientRect();
      return (r.width>=20&&r.height>=10); }catch(e){ return false; } }
  // ★★ 兜底候选（输入框旁边 / 表单容器里 / 背景图）**没有名字背书**，
  //   所以再加两道闸，免得把站标、头像、二维码当成验证码：
  //   ① 尺寸得像个验证码（太宽/太长的一律不是）
  //   ② URL 里带 logo/icon/avatar/banner/qrcode 之类字样的一律不碰
  function capSize(el){ try{ var r=el.getBoundingClientRect();
      return (r.width>=30&&r.width<=400&&r.height>=14&&r.height<=140);
    }catch(e){ return false; } }
  function looksIcon(u){ return /logo|icon|avatar|banner|qrcode|qr_|emoji|smiley|face|head/i
      .test(String(u||'')); }
  // ① 名字命中
  var SELS=['#seccodeverify + img','#seccodeverify ~ img',
    'img[src*="mod=seccode"]','img[src*="seccode"]','#seccodeimg',
    'img[src*="captcha"]','img[id*=seccode i]',
    '#captchaimg','#verifyimg','#checkcodeimg','#imgcode',
    'img[src*="checkcode"]','img[src*="verifycode"]','img[src*="vcode"]',
    'img[id*=captcha i]','img[id*=verify i]','img[id*=checkcode i]',
    'img[class*=captcha i]','img[class*=verify i]','img[class*=checkcode i]',
    'img[alt*="验证码"]','img[title*="验证码"]','label[for=seccodeverify] img',
    '.seccodeimg img','.seccode img','.captcha img','.verify img'];
  // ② 验证码输入框「旁边」那张图
  function nearInput(){
    var ins=document.querySelectorAll('input');
    for(var i=0;i<ins.length;i++){
      var el=ins[i];
      var k=((el.name||'')+' '+(el.id||'')+' '+(el.className||'')).toLowerCase();
      if(!/captcha|seccode|verify|checkcode|imgcode|vcode|authcode|code/.test(k))
        continue;
      var box=el.parentNode, up=0;
      while(box && up<4){
        var im=box.querySelector('img');
        if(im && vis(im) && big(im)) return im;
        box=box.parentNode; up++;
      }
    }
    return null;
  }
  var list=[], seen={};
  function add(el,url){
    if(!url){ url=srcOf(el)||bgUrl(el); }
    if(!url || seen[url]) return;
    if(url.indexOf('data:image')!==0 && !/^(https?:|blob:|\/)/.test(url)) return;
    seen[url]=1; list.push({el:el, url:url});
  }
  for(var i=0;i<SELS.length;i++){
    var e=document.querySelector(SELS[i]);
    if(e && vis(e) && big(e)) add(e);
  }
  var ni=nearInput();
  if(ni) add(ni);
  var fi=document.querySelectorAll(
    '#loginform img,form[name=login] img,form[action*=logging] img');
  for(var j=0;j<fi.length;j++){
    var f2=fi[j];
    if(!vis(f2) || !capSize(f2)) continue;
    if(looksIcon(srcOf(f2))) continue;      // 表单里的站标不算验证码
    add(f2);
  }
  var BS=['#captchaimg','#seccodeimg','.captcha','.seccode','.verifyimg',
    '#imgcode','#checkcodeimg','[class*=captcha i]','[id*=captcha i]'];
  for(var k2=0;k2<BS.length;k2++){
    var b2=document.querySelector(BS[k2]);
    if(b2 && vis(b2)){ var bu=bgUrl(b2); if(bu) add(b2,bu); }
  }
  var diag={n:list.length, imgs:document.querySelectorAll('img').length,
            url:'', err:'', sig:''};
  if(list.length){
    diag.url=String(list[0].url).slice(0,120);
    // ★★ 2026-10-09 用户报「验证码是出来了但是网页端一直自己换」：
    //   站点（Discuz 等）的验证码接口**每被请求一次就生成一张新码**并写进会话。
    //   原实现每 3 秒同步一次就 fetch 一次 → 每 3 秒换一张 → 网页上
    //   输入框被反复清空、图一直变，人根本没法填。所以先给这张图算个
    //   「指纹」：URL（data:URL 取头+尾） + 自然尺寸。指纹不变 → 直接告诉服务端
    //   「还是那张」，**一个请求都不发**（这一步才是止血的关键）。
    var e0=list[0].el, u0=String(list[0].url), nw=0, nh=0;
    try{ nw=e0.naturalWidth||0; nh=e0.naturalHeight||0; }catch(e){}
    diag.sig = (u0.indexOf('data:image')===0)
      ? ('D:'+u0.length+':'+u0.slice(0,60)+':'+u0.slice(-60))
      : ('U:'+u0.slice(0,400)+'|'+nw+'x'+nh);
  }
  if(!list.length){
    diag.err='页面上没找到验证码图（共 '+diag.imgs+' 张图）';
    return diag;
  }
  // ★ 指纹跟上次一样 → 不重复请求（服务端会复用上次那张图）
  if(diag.sig && diag.sig===__ZSF_CAP_SIG__){
    return {same:1, sig:diag.sig, n:list.length, imgs:diag.imgs,
            url:diag.url, err:''};
  }
  // ★★★ 2026-10-09 二次修正（用户报「还是和真实的验证码不一样」）：
  //   **绝不 fetch 验证码 URL**。本站点（Discuz 等）的验证码接口每被请求
  //   一次就生成一张新码并写进会话，而浏览器里那张 <img> 还是页面加载时
  //   那张 —— 于是「网页上显示的码」和「服务器浏览器里显示的码」变成了两张
  //   **不同** 的图，会话里的码还被惄惄换掉了。
  //   正解：把**已经加载好的那张图**画进 canvas 再导出像素 —— 零网络请求，
  //   网页显示的就是服务器浏览器里那张，会话里的码也正是它（三者一致）。
  //   背景图类候选（非 <img>）这里画不了 → 返回 null，交给后面的「截图兜底」。
  function draw(el){
    try{
      if(!el.naturalWidth || !el.naturalHeight) return null;
      var cv=document.createElement('canvas');
      cv.width=el.naturalWidth; cv.height=el.naturalHeight;
      var cx=cv.getContext('2d');
      cx.drawImage(el,0,0);
      return cv.toDataURL('image/png');
    }catch(e){ return null; }
  }
  function toData(el){
    var im=el;
    if(!im || !im.tagName) return Promise.resolve(null);
    if(im.tagName.toUpperCase()!=='IMG') return Promise.resolve(null);
    var s='';
    try{ s=String(im.currentSrc||im.src||''); }catch(e){}
    if(s.indexOf('data:image')===0) return Promise.resolve(s);
    if(im.complete && im.naturalWidth) return Promise.resolve(draw(im));
    // 图还在加载（点「换一张」后很常见）→ 等它 load 出来再画，最多等1.5s
    return new Promise(function(res){
      var done=false;
      function fin(v){ if(!done){ done=true; res(v); } }
      try{
        im.addEventListener('load', function(){ setTimeout(function(){
          fin(draw(im)); }, 60); }, {once:true});
        im.addEventListener('error', function(){ fin(null); }, {once:true});
      }catch(e){}
      setTimeout(function(){ fin(draw(im)); }, 1500);
    });
  }
  // 最多试前 4 个候选（再多就是瞎猜了，还会拖慢每 3 秒一次的同步）
  return (function next(pos){
    if(pos>=list.length || pos>=4){
      diag.err='图找到了但画不出来（跨域受限 / 还没加载完），已改走截图兜底';
      return diag;
    }
    return toData(list[pos].el).then(function(d){
      if(d){ return {png:d, n:list.length, imgs:diag.imgs,
                     url:String(list[pos].url).slice(0,120), err:'',
                     sig:diag.sig}; }
      return next(pos+1);
    });
  })(0);
})()
"""

JS_FORUM_CAP_BOX = r"""
(function(){
  function vis(el){ if(!el) return false; var cs=getComputedStyle(el);
    if(!cs) return false;
    return !(cs.display==='none'||cs.visibility==='hidden'||cs.opacity==='0'); }
  function bgUrl(el){ try{
      var b=getComputedStyle(el).backgroundImage||'';
      var m=/url\(["']?(.*?)["']?\)/.exec(b);
      return m&&m[1] ? m[1] : '';
    }catch(e){ return ''; } }
  // ★ 候选清单与 JS_FORUM_CAP_DATA 保持一致（改一处记得改另一处），
  //   否则会出现「DOM 取图找不到、截图也找不到」的双重失败。
  var SELS=['#seccodeverify + img','#seccodeverify ~ img',
    'img[src*="mod=seccode"]','img[src*="seccode"]','#seccodeimg',
    'img[src*="captcha"]','img[id*=seccode i]',
    '#captchaimg','#verifyimg','#checkcodeimg','#imgcode',
    'img[src*="checkcode"]','img[src*="verifycode"]','img[src*="vcode"]',
    'img[id*=captcha i]','img[id*=verify i]','img[id*=checkcode i]',
    'img[class*=captcha i]','img[class*=verify i]','img[class*=checkcode i]',
    'img[alt*="验证码"]','img[title*="验证码"]','.seccodeimg','.seccode',
    '.captcha','.verifyimg'];
  function nearInput(){
    var ins=document.querySelectorAll('input');
    for(var i=0;i<ins.length;i++){
      var el=ins[i];
      var k=((el.name||'')+' '+(el.id||'')+' '+(el.className||'')).toLowerCase();
      if(!/captcha|seccode|verify|checkcode|imgcode|vcode|authcode|code/.test(k))
        continue;
      var box=el.parentNode, up=0;
      while(box && up<4){
        var im=box.querySelector('img');
        if(im && vis(im)) return im;
        box=box.parentNode; up++;
      }
    }
    return null;
  }
  var all=[];
  for(var i=0;i<SELS.length;i++){
    var e=document.querySelector(SELS[i]);
    if(e && vis(e)) all.push(e);
  }
  var ni=nearInput(); if(ni && vis(ni)) all.push(ni);
  var fi=document.querySelectorAll(
    '#loginform img,form[name=login] img,form[action*=logging] img');
  for(var j=0;j<fi.length;j++){
    var f2=fi[j];
    if(!vis(f2)) continue;
    var rr2=f2.getBoundingClientRect();
    // 跟 DOM 取图那边同一个口径：尺寸像验证码、且不是站标/头像才收
    if(rr2.width<30||rr2.width>400||rr2.height<14||rr2.height>140) continue;
    var su=''; try{ su=String(f2.currentSrc||f2.src||''); }catch(e2){}
    if(/logo|icon|avatar|banner|qrcode|qr_|emoji|smiley|face|head/i.test(su)) continue;
    all.push(f2);
  }
  for(var k=0;k<all.length;k++){
    var el=all[k];
    // ★★ 原来这里有一句「图不在视口里就跳过」—— 登录表单在页面下方、或者窗口开得小
    //   的时候，验证码图正好在视口外，于是**永远截不到**，网页上那块一直空白。
    //   现在先把它滚进视口再量：scrollIntoView 是同步的，量出来的 rect
    //   就是滚动后的真实位置，紧接着的 Page.captureScreenshot 就能截到。
    try{ el.scrollIntoView({block:'center',inline:'center'}); }catch(e){}
    var r=el.getBoundingClientRect();
    if(r.width<30||r.height<15) continue;
    return {x:r.left,y:r.top,w:r.width,h:r.height};
  }
  return null;
})()
"""

# 把网页上填的内容写回页面并（可选）提交
JS_FORUM_FILL = r"""
(function(a){
  function vis(el){ if(!el) return false; var cs=getComputedStyle(el);
    if(!cs) return false;
    return !(cs.display==='none'||cs.visibility==='hidden'||cs.opacity==='0'); }
  function set(el, v){
    if(!el) return false;
    // ★ focus() 在个别站点/隐藏元素上会抛异常；它只是「顺手把光标放进去」，
    //   失败了不能影响「把值写进去」这件正事（JS 层冒烟就是被这个打断的）。
    try{ el.focus(); }catch(e){}
    el.value = v;
    // 有些框架（Discuz 的验证码 / 登录脚本）靠事件才知道值变了
    ['input','change','keyup'].forEach(function(t){
      try{ el.dispatchEvent(new Event(t,{bubbles:true})); }catch(e){
        try{ var ev=document.createEvent('HTMLEvents'); ev.initEvent(t,true,false);
             el.dispatchEvent(ev); }catch(e2){}
      }
    });
    return true;
  }
  function one(names, sels){ 
    for(var i=0;i<names.length;i++){ var el=document.querySelector('[name="'+names[i]+'"]');
      if(el&&vis(el)) return el; }
    for(var j=0;j<sels.length;j++){ var e2=document.querySelector(sels[j]);
      if(e2&&vis(e2)) return e2; }
    return null;
  }
  var out={user:false, pass:false, cap:false, ans:false, tab:false};
  // ★ 2026-09-26：页签式登录 —— 提交前**先把对应的页签点出来**，
  //   否则那个页签下的输入框可能是 display:none 的，写了值站点也收不到。
  //   ★★ 2026-10-09 删除手机号登录后：只往「账号登录」页签切。
  function pickTab(want){
    if(want!=='account') return false;
    var re=/(^|[\s\-_])(active|on|cur|current|selected|checked)([\s\-_]|$)/i;
    var cand=document.querySelectorAll('li,a,span,div,button,dt,dd,h3,label');
    for(var i=0;i<cand.length;i++){
      var el=cand[i];
      var t=(el.textContent||'').replace(/\s+/g,'');
      if(t.length>10) continue;
      var isUser  = /用户名?登录|账号?登录|帐号登录|普通登录|会员登录/.test(t);
      if(!isUser) continue;
      if(!vis(el)) continue;
      if(el.children && el.children.length>0) continue;
      var on = re.test((el.className||'').toString())
               || (el.parentNode && re.test((el.parentNode.className||'').toString()));
      if(on) return false;                   // 已经是激活态，不用点
      try{ el.click(); return true; }catch(e){}
    }
    return false;
  }
  function one(names, sels){ 
    for(var i=0;i<names.length;i++){ var el=document.querySelector('[name="'+names[i]+'"]');
      if(el&&vis(el)) return el; }
    for(var j=0;j<sels.length;j++){ var e2=document.querySelector(sels[j]);
      if(e2&&vis(e2)) return e2; }
    return null;
  }
  // 先切页签（要切才切；切完给站点一点时间跑它自己的显示逻辑）
  if(a.mode){ out.tab = pickTab(a.mode); }
  // ★★ 2026-10-09 用户要求「删除手机号登录」：不再有「手机号 / 短信验证码」
  //    两个写回分支。只保留「账号 + 密码 + 图形验证码」。
  if(a.user){ out.user = set(one(['username','loginfield'],
      ['#username','input.username']), a.user); }
  if(a.pass){ out.pass = set(one(['password'], ['#password','input[type=password]']), a.pass); }
  if(a.cap){ out.cap = set(one(['captcha','seccodeverify','verify','checkcode',
      'imgcode','code'],
      ['#seccodeverify','#captcha','#checkcode','#imgcode','#code',
       'input[name*=captcha i]','input[name*=seccode i]',
       'input[name*=verify i]']), a.cap); }
  if(a.ans){ out.ans = set(one(['answer','answer1'],
      ['#answer','input[name*=answer i]']), a.ans); }
  // 记住我（省得下次又登）
  try{
    var rm=document.querySelector('[name=loginfield]')&&document.querySelector('[name=cookietime]');
    if(rm && !rm.checked) rm.checked=true;
  }catch(e){}
  if(a.submit){
    var form = one(['username','loginfield'], ['#username']) ;
    var f = (form&&form.form) || document.querySelector('#loginform')
         || document.querySelector('form[name=login]')
         || document.querySelector('form[action*=logging]');
    if(f){
      try{
        var btn=f.querySelector('button[type=submit],input[type=submit],button.submit,#loginsubmit');
        if(btn) btn.click(); else f.submit();
        return {ok:true, filled:out, submitted:true};
      }catch(e){ return {ok:true, filled:out, submitted:false, err:String(e)}; }
    }
    return {ok:true, filled:out, submitted:false, err:'找不到登录表单'};
  }
  return {ok:true, filled:out, submitted:false};
})(__ZSF_FORUM_FILL__)
"""


# ★ 2026-09-26：点服务器浏览器里的验证码图 → 换一张。
#   Discuz 及其他多数站的验证码图本身就绑了 onclick 去 reload
#   （有的绑在 <img onclick>、有的绑在 <a> 包着 img），所以「点图」就是刷新。
#   点不到就退一步：把 src 里的时间戳/随机参数改掉强制重载。
JS_FORUM_CAP_CLICK = r"""
(function(){
  function vis(el){ if(!el) return false; var cs=getComputedStyle(el);
    if(!cs) return false;
    return !(cs.display==='none'||cs.visibility==='hidden'||cs.opacity==='0'); }
  function rectOf(el){ var r=el.getBoundingClientRect();
    return {w:r.width, h:r.height, ok:(r.width>0&&r.height>0)}; }
  var sels=['#seccodeverify + img','#seccodeverify ~ img',
    'img[src*="mod=seccode"]','img[src*="seccode"]','#seccodeimg',
    'img[src*="captcha"]','img[id*=seccode i]',
    // ★★ 2026-09-26 用户报「验证码怎么不显示出了」：验证码图「找不到」的头号原因
    //   就是命名不在这张表里，而输入框那边又认不出 → 整个功能像不存在。
    //   把常见的几类补齐（加在末尾，前面命中就优先，对原有站没有影响）。
    '#captchaimg','#verifyimg','#checkcodeimg','#imgcode',
    'img[src*="checkcode"]','img[src*="verifycode"]',
    'img[id*=captcha i]','img[id*=verify i]',
    'img[alt*="验证码"]','img[title*="验证码"]','label[for=seccodeverify] img',
    '.seccodeimg img','.seccode img'];
  var img=null;
  for(var i=0;i<sels.length;i++){
    var el=document.querySelector(sels[i]);
    if(el && vis(el)){ var r=rectOf(el);
      if(r.w>30&&r.h>15){ img=el; break; } }
  }
  // ① 有图：点它（站点自己的 reload）
  if(img){
    try{
      var a=img.closest?img.closest('a'):null;
      (a||img).click();
      return {ok:true, how:'click-img'};
    }catch(e){}
    try{
      var s=img.getAttribute('src')||'';
      if(s && s.indexOf('javascript')!==0){
        s=s.replace(/([?&])(t|ts|time|_)=[^&]*/g,'$1$2=').replace(/[?&]$/,'');
        s+= (s.indexOf('?')>=0?'&':'?') + '_t=' + Date.now();
        img.setAttribute('src', s);
        return {ok:true, how:'reload-src'};
      }
    }catch(e2){}
  }
  // ★ 2026-09-26：有的站没有可点的图，而是一个**纯文字链接**「换一个 / 看不清？」
  //   （用户截图里那个站就是 <a>换一个</a>）。所以这里再按文字找一遍。
  var textSels=['a','button','span','div','u','em','i','label'];
  var words=['换一个','换一换','换张','换一张','看不清','看不清？','看不清,换一张',
             '点击更换','点击换一张','点击刷新','刷新验证码','重新获取','换验证码'];
  for(var k=0;k<textSels.length;k++){
    var list=document.querySelectorAll(textSels[k]);
    for(var j=0;j<list.length;j++){
      var t=(list[j].textContent||'').replace(/\s+/g,'');
      if(!t||t.length>12) continue;
      if(words.indexOf(t)<0) continue;
      if(!vis(list[j])) continue;
      var rr=rectOf(list[j]);
      if(!rr.ok) continue;
      try{ list[j].click(); return {ok:true, how:'click-text:'+t}; }catch(e3){}
    }
  }
  return {ok:false, msg:'这个站不支持点击刷新验证码'};
})()
"""


def _ip_tag(ip):
    """真实 IP → 不可逆脱敏短标签（密钥取自共享 PSK，与卡密服务端同规则）。

    ★ 页面「禁止出现任何明文 IP」：卡密服务端地址里若填的是 IP，展示也要脱敏；
      域名不是 IP，原样保留。
    """
    ip = str(ip or "").strip()
    if not ip:
        return ""
    key = b"zsf-ip-tag"
    try:
        psk = core.load()._psk()
        if psk:
            key = psk.encode("utf-8")
    except Exception:
        pass
    h = hmac.new(key, ("zsftp|" + ip).encode("utf-8"),
                 hashlib.sha256).hexdigest().upper()
    return "IP-%s-%s" % (h[:4], h[4:8])


def _port_tag(port):
    """真实端口 → 不可逆脱敏短标签（与 IP 标签同一套规则、同一把 PSK）。

    ★ 用户要求：IP 必须加密，**端口也一起加密**。地址里 IP 已经折成
      `IP-XXXX-XXXX`，后面的 `:8765` 还是明文，凑在一起就把服务端特征露出来了。
      同一个端口标签恒定，管理员仍能对上号；真实端口只活在 gate.server 里，
      展示层从不拿脱敏值去连接。
    """
    p = str(port or "").strip()
    if not p.isdigit():
        return p
    key = b"zsf-port-tag"
    try:
        psk = core.load()._psk()
        if psk:
            key = psk.encode("utf-8")
    except Exception:
        pass
    h = hmac.new(key, ("zsftpport|" + p).encode("utf-8"),
                 hashlib.sha256).hexdigest().upper()
    return "PORT-%s-%s" % (h[:4], h[4:8])


def mask_addr(s):
    """把字符串里的 IPv4 明文**和它后面的端口**都换成脱敏标签。

    例：`http://<主机>:<端口>` -> `http://IP-XXXX-XXXX:PORT-XXXX-XXXX`
    只脱敏「IP 被脱敏了」的那些端口；纯域名、无 IP 的串原样保留。
    幂等：已经脱敏过的串再走一遍不会变（里面已没有明文 IPv4）。
    """
    s = str(s or "")
    if not s:
        return s
    return re.sub(
        r"\b(\d{1,3}(?:\.\d{1,3}){3})(?::(\d{1,5}))?\b",
        lambda mo: _ip_tag(mo.group(1)) + (
            (":" + _port_tag(mo.group(2))) if mo.group(2) else ""),
        s)


# ★ 2026-09-26 / 2026-09-28：Chromium 系浏览器「组策略锁死用户数据目录」的检测与清除。
#
#   `UserDataDir` 策略一旦存在（HKLM / HKCU 都算，64/32 位两套注册表视图各算一条），
#   会**覆盖命令行传的 --user-data-dir**（优先级：策略 > 命令行）。后果有两层：
#     ① 程序给每个账号开的隔离 profile 全被无视 → 新进程命中已有实例的单例，
#        把网址甩给用户正在看的那个窗口后自身 rc=0 退出 → 新进程从不监听
#        --remote-debugging-port → wait_cdp 干等 60 秒报「CDP 未就绪」；
#     ② **无头模式一并被顶掉** —— 勾了「无头」照样弹出可见窗口
#        （2026-09-28 用户报的「无头模式现在不好使」正是这一条）。
#
#   三族策略键彼此独立：Chrome 不看 Microsoft\Edge 下的策略，反之亦然 ——
#   所以 2026-09-26 那版「只认 Edge」漏掉了本机 Chrome 上的同一条策略。
#
#   本机实测（2026-09-28）：HKLM 下 Google\Chrome 与 Microsoft\Edge 都被塞了
#   UserDataDir + 一整套首页/搜索劫持策略（WOW6432Node 里还各有一份镜像），
#   HKCU 干净。⇒ 清除必须覆盖 HKLM，而 HKLM 要管理员权限。
_BROWSER_POLICY_FAMILIES = (
    # (注册表子键, exe 文件名里出现的关键字, 展示名)
    (r"SOFTWARE\Policies\Google\Chrome", "chrome", "Chrome"),
    (r"SOFTWARE\Policies\Chromium", "chromium", "Chromium"),
    (r"SOFTWARE\Policies\Microsoft\Edge", "msedge", "Edge"),
)


# ★ 实测（2026-09-28）：**便携/内置那一份不读 Google\Chrome 策略**。
#   同一台机器、同一条 `UserDataDir` 策略下：
#     · 装在 Program Files (x86) 的 Edge → rc=21 立刻退出，命令行 profile 一个文件没落，
#       调试端口永不监听（这就是「无头不好使 / 弹窗口」的源头）；
#     · 本程序释放的便携 Chrome（%LOCALAPPDATA%\zsf_gift_embedded_browser\chrome-win64\
#       chrome.exe）→ 照用命令行 profile（临时目录落了 148 个文件），无头 + 调试端口正常。
#   ⇒ 便携/内置那一份不能按策略判死，否则等于把「无头不好使」换成「一个能用的浏览器
#     都没有」。策略提示照报（用户仍然该把它清掉），只是不据此 ban 掉便携浏览器。
_BROWSER_PORTABLE_DIRS = ("zsf_gift_embedded_browser",)


def _browser_policy_applies(path):
    """这条策略到底会作用到这个 exe 上吗（便携/内置的不算）。"""
    p = str(path or "").lower()
    if not p:
        return True
    for d in _BROWSER_PORTABLE_DIRS:
        if d in p:
            return False
    return True


def _browser_policy_subkeys(sub):
    """某族策略键在注册表里的实际路径：64 位键 + WOW6432Node 镜像。

    32 位的安装包会写到 32 位视图（WOW6432Node）里 —— 只清一边会漏（本机两边都有）。
    """
    tail = sub.split("Policies", 1)[-1]
    return (sub, r"SOFTWARE\WOW6432Node\Policies" + tail)


def _browser_policy_family(path):
    """按 exe 文件名认出属于哪一族；认不出（Firefox / 360 等）返回 None。"""
    b = os.path.basename(str(path or "")).lower()
    if not b.endswith(".exe"):
        return None
    for sub, tok, name in _BROWSER_POLICY_FAMILIES:
        if tok in b:
            return (sub, tok, name)
    return None


def browser_policy_scan(family=""):
    """列出三族浏览器上现存的组策略值。

    返回 [{"family": "Chrome", "hive": "HKLM"/"HKCU", "key": r"...",
           "value": "UserDataDir", "data": "...", "blocks": True}, ...]
    `blocks` 只标 `UserDataDir` —— 它才是让 CDP / 无头彻底失效的那一条。
    family 非空时只扫这一族。读注册表出任何问题一律当「没有」，绝不抛。
    """
    out = []
    try:
        import winreg
    except Exception:
        return out
    views = (("HKCU", winreg.HKEY_CURRENT_USER, False),
             ("HKLM", winreg.HKEY_LOCAL_MACHINE, True))
    for sub, _tok, name in _BROWSER_POLICY_FAMILIES:
        if family and name != family:
            continue
        for hive, root, allow_wow in views:
            for kp in _browser_policy_subkeys(sub):
                if "WOW6432Node" in kp and not allow_wow:
                    continue
                try:
                    k = winreg.OpenKey(root, kp, 0, winreg.KEY_READ)
                except Exception:
                    continue
                try:
                    n = 0
                    try:
                        n = winreg.QueryInfoKey(k)[1]
                    except Exception:
                        pass
                    for i in range(int(n or 0)):
                        try:
                            vn, vd, _vt = winreg.EnumValue(k, i)
                        except Exception:
                            continue
                        out.append({"family": name, "hive": hive, "key": kp,
                                    "value": str(vn), "data": str(vd),
                                    "blocks": str(vn) == "UserDataDir"})
                finally:
                    try:
                        winreg.CloseKey(k)
                    except Exception:
                        pass
    return out


def browser_policy_blocked(path):
    """该浏览器是否因组策略而无法配合 CDP 自动化（起不来独立实例 / 无头被顶掉）。

    认不出族、或这一族没有 `UserDataDir` 策略 → 返回 ""（视作可用）。
    """
    fam = _browser_policy_family(path)
    if not fam:
        return ""
    if not _browser_policy_applies(path):
        return ""
    hits = [it for it in browser_policy_scan(fam[2]) if it["blocks"]]
    if not hits:
        return ""
    it = hits[0]
    where = it["key"].split("Policies", 1)[-1].strip("\\")
    return ("本机 %s 被组策略锁死了用户数据目录"
            "（%s\\%s：UserDataDir=%s）。它会忽略程序传入的独立 profile，"
            "把网址交给正在运行的那个窗口后自身退出 —— 调试端口起不来，"
            "无头模式也会被顶掉（勾了「无头」仍然弹出可见窗口）。"
            "到「设置 → 浏览器」点【一键清除浏览器策略】即可修复。"
            % (fam[2], it["hive"], where, it["data"]))


def browser_policy_blocked_dir(path):
    """被策略强占的 user-data-dir 路径（纯给日志/诊断用）；没有则 ""。"""
    fam = _browser_policy_family(path)
    if not fam:
        return ""
    if not _browser_policy_applies(path):
        return ""
    for it in browser_policy_scan(fam[2]):
        if it["blocks"]:
            return it["data"]
    return ""


def browser_policy_brief():
    """给前端/state() 用的精简版：只报「会让无头失效」的那几条 + 策略总条数。

    ★ 本机实测一棵被塞满的策略树有 40+ 个值 —— 全量塞进 state() 会让每次轮询
      白白背 6KB JSON。界面真正要提醒用户的只有 UserDataDir（去重后每键一条）。
    """
    all_ = browser_policy_scan()
    seen, items = set(), []
    for it in all_:
        if not it["blocks"]:
            continue
        sig = (it["hive"], it["key"])
        if sig in seen:
            continue
        seen.add(sig)
        items.append({"family": it["family"], "hive": it["hive"],
                      "key": it["key"], "value": it["value"], "data": it["data"]})
    return {"total": len(all_), "blocking": items}

def edge_policy_userdata_dir():
    """兼容旧调用：Edge 的 UserDataDir 策略值（没有则 ""）。

    ★ 2026-09-28：逻辑已被上面三族通用实现取代，这个壳只为老脚本/老调用不炸。
    """
    for it in browser_policy_scan("Edge"):
        if it["blocks"]:
            return it["data"]
    return ""


def _reg_delete_tree(winreg, root, path):
    """递归删掉一个策略子树（值 + 子键 + 空壳键）。键不存在当成功，返回删掉的值数。"""
    try:
        k = winreg.OpenKey(root, path, 0, 0x000F003F)      # KEY_ALL_ACCESS
    except Exception:
        return 0
    nv = 0
    try:
        while True:
            try:
                sub = winreg.EnumKey(k, 0)
            except Exception:
                break
            nv += _reg_delete_tree(winreg, root, path + "\\" + sub)
        while True:
            try:
                vn, _vd, _vt = winreg.EnumValue(k, 0)
            except Exception:
                break
            try:
                winreg.DeleteValue(k, vn)
                nv += 1
            except Exception:
                break
    finally:
        try:
            winreg.CloseKey(k)
        except Exception:
            pass
    try:
        winreg.DeleteKey(root, path)
    except Exception:
        pass
    return nv


def _reg_tree_nonempty(winreg, root, path):
    """这个策略键当前是否还留着值（判断清除成没成功）。"""
    try:
        k = winreg.OpenKey(root, path, 0, winreg.KEY_READ)
    except Exception:
        return False
    try:
        try:
            return int(winreg.QueryInfoKey(k)[1] or 0) > 0
        except Exception:
            return False
    finally:
        try:
            winreg.CloseKey(k)
        except Exception:
            pass


def clear_browser_policy():
    """一键清除本机 Chromium 系浏览器的组策略（Chrome / Chromium / Edge 三族）。

    ★ 只动 `SOFTWARE\\Policies\\{Google\\Chrome, Chromium, Microsoft\\Edge}` 这三棵树
      （HKLM 与 HKCU、64/32 位视图各一份），**别的注册表一律不碰**。
    ★ HKLM 是机器级策略，删除要管理员权限；没权限时返回 need_admin=True，
      由前端提示「以管理员身份重新运行本程序后再点一次」。
    ★ 返回 {"ok": 是否全清干净, "cleared": [...], "failed": [...],
             "need_admin": bool, "remain": [剩余策略...], "msg": 人话}
    """
    try:
        import winreg
    except Exception:
        return {"ok": False, "cleared": [], "failed": [], "need_admin": False,
                "remain": [], "msg": "当前环境没有注册表（仅 Windows 支持）"}
    targets = []
    for sub, _tok, name in _BROWSER_POLICY_FAMILIES:
        for kp in _browser_policy_subkeys(sub):
            targets.append(("HKLM", winreg.HKEY_LOCAL_MACHINE, kp, name))
            if "WOW6432Node" not in kp:
                targets.append(("HKCU", winreg.HKEY_CURRENT_USER, kp, name))
    cleared, failed, need_admin = [], [], False
    for hive, root, kp, name in targets:
        existed = _reg_tree_nonempty(winreg, root, kp)
        _reg_delete_tree(winreg, root, kp)
        if not existed:
            continue
        if _reg_tree_nonempty(winreg, root, kp):
            failed.append("%s\\%s" % (hive, kp))
            if hive == "HKLM":
                need_admin = True
        else:
            cleared.append("%s\\%s（%s）" % (hive, kp, name))
    remain = browser_policy_scan()
    if not remain:
        if cleared:
            msg = ("已清除本机浏览器策略：%s。浏览器已恢复 —— 要是浏览器正开着，"
                   "关掉重开一次再领取。" % "、".join(cleared))
        else:
            msg = "本机没有需要清除的浏览器策略。"
        return {"ok": True, "cleared": cleared, "failed": failed,
                "need_admin": False, "remain": [], "msg": msg}
    if need_admin:
        msg = ("还有 %d 项机器级策略清不掉 —— 需要管理员权限。请关掉本程序，"
               "右键「以管理员身份运行」后再点一次这个按钮。" % len(remain))
    else:
        msg = "还有 %d 项策略没清掉（%s）。" % (len(remain), "、".join(failed[:3]))
    return {"ok": False, "cleared": cleared, "failed": failed,
            "need_admin": need_admin, "remain": remain, "msg": msg}


def _now():
    return datetime.now()


# ★ 同一路径的并发落盘必须串行：原模块 _safe_save_json 内部用的是固定名
#   `<path>.tmp`，两个线程同时写会在 Windows 上撞出 PermissionError
#   （os.replace 撞到对方正打开的 tmp）→ 被判成「原模块不可用」而掉进明文
#   兜底，账号文件就会明文落盘（2026-09-28 实测复现）。加锁 + 失败重试后，
#   明文兜底只会发生在原模块真的没有 _safe_save_json 时。
_WRITE_LOCK = threading.RLock()


def _atomic_write_json(path, obj):
    """原子写 JSON（先 .tmp 再 replace），避免掉电/并发写坏配置文件。

    ★ v1.1.31 优先走原模块的 _safe_save_json —— 它同样原子写，但会把内容
    落地加密（魔数 ZSFENC01），与客户端/服务端保持一致；只有原模块不可用时
    才退回明文原子写，保证任何情况下都不丢数据。
    ★ 2026-09-28：并发写同一文件时固定 tmp 名会互撞，改为加锁串行 + 最多重试
    4 次，避免误判「不可用」而把该加密的文件写成明文。
    """
    with _WRITE_LOCK:
        fn = getattr(core.load(), "_safe_save_json", None)
        if callable(fn):
            for _ in range(4):
                try:
                    if fn(path, obj, indent=2):
                        return True
                except Exception:
                    pass
                time.sleep(0.05)
        try:
            d = os.path.dirname(path)
            if d:
                os.makedirs(d, exist_ok=True)
            tmp = path + ".tmp"
            with open(tmp, "w", encoding="utf-8") as f:
                json.dump(obj, f, ensure_ascii=False, indent=2)
            os.replace(tmp, path)
            return True
        except Exception:
            return False


# ======================================================================
# ★ 2026-10-06 「按访问 IP 的网页门禁」工具函数
# ======================================================================
def _norm_client_ip(ip):
    """规整客户端 IP：剥掉 IPv4-mapped 前缀与方括号（::ffff:127.0.0.1 → 127.0.0.1）。"""
    ip = str(ip or "").strip()
    if ip.startswith("::ffff:"):
        ip = ip[7:]
    if len(ip) > 1 and ip.startswith("[") and ip.endswith("]"):
        ip = ip[1:-1]
    return ip


def is_local_ip(ip):
    """是不是「本机（宿主自己）打开」。空值也当本机 —— 老调用点不带 IP 时保持原语义。"""
    ip = _norm_client_ip(ip)
    if not ip:
        return True
    return ip in ("127.0.0.1", "::1", "localhost")


def _norm_host(host):
    """Host 头 → 规范主机名（小写、去端口、去 IPv6 方括号）。"""
    h = str(host or "").strip().lower()
    if h.startswith("["):                        # [::1]:8000
        i = h.find("]")
        return h[1:i] if i > 0 else h
    if ":" in h:                                 # example.com:8000
        h = h.rsplit(":", 1)[0]
    return h


def is_local_host(host):
    """Host 头是不是回环 / 本机地址。空值算本机（老调用点不带 Host）。"""
    return _norm_host(host) in ("", "127.0.0.1", "localhost", "::1")


def _norm_xff(xff):
    """X-Forwarded-For → 第一个**非回环**的真实客户端 IP（没有就空串）。

    ★ 只在 TCP 对端本身是回环（说明前面挂了本机代理 / frp）时才采信它 ——
      直连时客户端能随便伪造这个头，所以不能信（见 client_ctx）。
    """
    for part in str(xff or "").replace(";", ",").split(","):
        v = _norm_client_ip(part)
        if v and not is_local_ip(v):
            return v
    return ""


class ClientCtx(object):
    """一次网页请求的「访问地址上下文」（不可变小值对象）。

    ★ 2026-10-09 用户要求：不但「别的机器 / 别的 IP」要重新输卡密，
      **走反向代理 / frp / 隧道**（客户端 IP 会被看成本机 127.0.0.1）时，
      换个访问网址进去也必须重新输卡密 —— 所以判定维度从「客户端 IP」
      扩成「真实访问地址」。
    """

    __slots__ = ("key", "local", "label")

    def __init__(self, key, local, label):
        self.key = str(key or "")
        self.local = bool(local)
        self.label = str(label or "本机")

    def __repr__(self):
        return "ClientCtx(key=%r, local=%r)" % (self.key, self.local)


def client_ctx(peer_ip, host=None, xff=None):
    """把一次请求归一成 ClientCtx（key / 是否本机 / 展示标签）。

    判定顺序（可信度从高到低）：
      1) TCP 对端 IP 非回环 → 直连，直接用对端 IP：key="ip|1.2.3.4"
      2) 对端是回环（前面挂了本机代理 / frp）→ 采信 X-Forwarded-For 里第一个
         非回环 IP（代理报的「真实客户端」）：key="xff|1.2.3.4"
      3) 都没有 → 退化为「按访问网址」：key="host|example.com"
    只有「对端是回环 且 Host 是回环 且 没有非回环 XFF」才算本机（免地址锁）。
    """
    peer = _norm_client_ip(peer_ip)
    hostn = _norm_host(host)
    fwd = _norm_xff(xff)
    peer_local = is_local_ip(peer)
    if peer_local and is_local_host(hostn) and not fwd:
        return ClientCtx("", True, peer or "127.0.0.1")
    if not peer_local:
        return ClientCtx("ip|" + peer, False, peer)
    if fwd:
        return ClientCtx("xff|" + fwd, False, fwd)
    return ClientCtx("host|" + (hostn or "-"), False, hostn or "-")


def as_client_ctx(v):
    """把「已经是 ClientCtx / 裸 IP 字符串 / None」统一成 ClientCtx。

    兼容老调用点：以前各处直接传裸客户端 IP 字符串，现在统一传 ClientCtx；
    传裸 IP 时按「直连」理解（host/xff 未知）。传 None 返回 None，表示
    「调用方明确不涉及访问地址」（内部无参调用，免地址锁）。
    """
    if isinstance(v, ClientCtx):
        return v
    if v is None:
        return None
    return client_ctx(v)


class Service(object):
    NOTICE_CAP = 50                 # 公告最多留最近 50 条
    # ★ 推送快通道：原版心跳 60 秒一轮，推送最坏要等一分钟才到 —— 这里独立
    #   每 8 秒问一次服务端要未读推送；会话失效时每 20 秒试一次重验证。
    PUSH_POLL_SECS = 8
    CARD_WD_SECS = 20

    def __init__(self):
        self.C = core.load()            # 原程序模块
        self.bus = BUS
        self.lock = threading.RLock()
        self.started_at = time.time()

        # ---------------- 礼包领取
        self.cfg = self._load_cfg()
        self.accounts = []
        self.records = []
        self.load_accounts()
        self.load_records()
        self.running = False
        self.checking = False
        self.engine = None
        self._last_run = {}             # 定时去重
        self._browsers = []             # [(name, path, kernel)]
        self._browsers_ts = 0.0
        self._cur_browser = ""
        self._login_engine = None
        self._login_acc = None
        self._last_check_ts = 0.0
        # ★ 需求⑬：扫码二维码（服务器浏览器里那张）→ 远程网页。
        #   png 存的是 base64（不含 data: 前缀），hash 用来去重（同一张不重复推）。
        # ★ stage（2026-09-26）："" = 没这回事 / starting = 正在起浏览器 /
        #   waiting = 浏览器开了还在等码弹出来 / qr = 码已经出来了
        self._qr = {"png": "", "hash": "", "acc": "", "ts": 0.0, "seq": 0,
                    "stage": ""}
        self._qr_clicks = 0             # 本轮登录里替点了多少次「登录」
        self._qr_click_ts = 0.0
        self._qr_shot_ts = 0.0          # 上次走「截屏」取码的时刻（这条要限流）
        # ★ 需求⑱：论坛登录的「外网填表」会话（账号/密码/验证码）
        self._fform = self._fform_blank()
        self._fform_lock = threading.RLock()
        self._forum_eng = None          # 论坛登录用的 Engine（供网页填表用）
        # ★ 需求⑯：管理员在卡密端点了 封卡/解绑/封IP/封机器码/踢下线 →
        #   服务端在 verify/heartbeat 里回 `kill`。原版只把业务接口 403，
        #   网页版这里要做到「强制关闭小工具主程序」：置标志 → server.serve
        #   的主循环看到 → 整个进程退出。
        self._kill = {"on": False, "why": "", "msg": "", "ts": 0.0}
        # ★ 需求⑭：与卡密端的时间偏移（服务端秒数 − 本机秒数）。
        #   0 表示还没同步过，此时退回本机时间。
        self._srv_off = 0.0
        self._status = "就绪"
        self.progress = {"on": False, "cur": 0, "max": 0, "text": ""}
        self._detect_done = False

        # ---------------- 论坛签到
        self.forum_list = []            # [[name, base]]
        # ★ 2026-10-09 多账号：base -> {accounts:[{id,name,cookie,ua,saved_at}]}
        #   （老配置 base -> {cookie,ua,saved_at} 会在 load_forum 里自动迁移）
        self.forum_cfg = {}
        self.forum_records = []
        self.forum_busy = False
        self.forum_stop = False
        self.auto_last = ""
        self.forum_settings = {"auto_sign": False, "auto_time": "08:00",
                               "headless": False}
        self.load_forum()

        # ---------------- QQ 群签到（★ 2026-10-09：支持多 QQ 账号 / 多条 WS 连接）
        #   原版只有一条连接（self.qq_conn）。现在改成**连接列表**：
        #     每个 QQ 账号 = 一条 WS 连接 = 自己的一份 url / token / 备注 /
        #     群列表 / 勾选 / 专属消息 / 在线状态。一键签到时各账号只签自己
        #     勾选的那些群，互不干扰（用户 2026-10-09 明确要求）。
        self.qq_cfg = {}
        self.qq_conns = []              # [ {id,url,token,remark,conn,status,
                                        #    self_id,nickname,groups,order} ]
        self.qq_settings = {}           # 全局设置（默认消息 / 点赞 / 定时 / 关键字）
        self.qq_busy = False
        self.qq_stop = False
        self._qq_seq = 0                # 连接 id 自增计数
        self.qq_hits = []               # 最近监测命中（关键字）
        # ★ 2026-09-26 **红包监测功能已整体删除**（用户要求）。保留下来的 `_rp_*`
        #   是「群消息监测通道」的运行时状态 —— 关键字通知靠它收群消息，
        #   改名会牵动一大片（前端/验收），所以沿用原名。
        self._rp_enabled = False        # ← 恒 False（红包已删）；仅为兼容旧配置读取
        self._kw_enabled = False
        self._rp_target = ""            # ← 同上，红包通知目标，已无消费者
        self._kw_target = ""
        self._kw_words = []
        self._kw_words_raw = ""
        self._rp_monitored = set()      # ← 同上，红包监测群，已无消费者
        self._rp_kw_monitored = set()   # ★ 关键字监测群（活着）
        self._qq_gname = {}
        self._rp_seen = {}
        self._rp_stop = threading.Event()
        self._rp_thread = None
        # ★ 用户要求：日志里不再有那条「[诊断] 统计快照」（每分钟一条的那行）。
        #   它没有别的用处，配套的几个计数变量一起撤掉。
        #   `_rp_dbg_left` 保留 —— 它喂的是另一条「[诊断] 群…」逐条排障日志（上限 20 条）。
        self._rp_dbg_left = 20
        # ★ 2026-10-09 反向 WS（OneBot 11 反向 WebSocket）：
        #   小工具端自己开一个 WS 监听，机器人框架（NapCat 等）主动连进来。
        #   配置落盘在 qq_signin.json 的 rev_* 键；下面这份是**运行时态**。
        self.qq_rev = {"on": False, "host": "0.0.0.0", "port": 6700, "path": "",
                       "token": "", "lis": None, "stop": None,
                       "status": "○ 未监听", "_want_on": False}
        self.load_qq()
        # 上次是「开」着的就自动重新监听（端口被占用等失败只记日志，不打断启动）
        if self.qq_rev.get("_want_on"):
            try:
                self.qq_rev_start()
            except Exception as ex:
                self.log("反向 WS 自动启动失败：%s" % ex, "qq")

        # ---------------- 卡密
        self.gate = None
        # ★ 门禁必须「未验证即锁闭」：card_init 跑完之前 card_inited=False，
        #   业务接口一律 403，避免校验未完成时被绕过（原版是启动即弹验证窗）。
        self.card_inited = False
        self._card_hb_started = False
        # ★ 2026-09-25 推送可靠性（用户反馈「卡密端推了，小工具端毫无反应」）：
        #   原版心跳 60 秒一轮，而且**会话 token 为空时会一直空转** —— 会话没建立
        #   时 token 拿不到，心跳每次都只换回一个「重新验证」，推送永远拉不下来。
        #   （★ 2026-10-09 起取消离线宽限：连不上服务端直接锁定，token 必为空。）
        #   这里加一条独立的快通道：每几秒问一次服务端要未读推送，并在发现会话
        #   没建立时主动重验证把它救回来。
        self._push_loop_started = False
        self._wd_last = 0.0          # 上次尝试恢复会话的时刻
        self._wd_gap_logged = 0.0    # 「会话未建立」提示的上次打印时刻（防刷屏）
        self.card = {"ok": False, "online": None, "remain": "", "type": "time",
                     "msg": "正在校验卡密…", "need_activate": False,
                     "banned": False, "kicked": False, "machine": "",
                     "server": "", "version": ""}
        # ★ 2026-10-06 用户要求：「网页换个机器 / 换个 IP 打开也要卡密」。
        #   宿主（回环 127.0.0.1）访问沿用「激活一次即可用」；**任何非回环客户端 IP**
        #   必须自己验证过一次卡密才放行 —— 否则把工具挂在服务器上时，宿主激活
        #   一张卡，同网段谁打开网址都能直接操作。解锁按 IP 记（换 IP 就要重输），
        #   结果落盘（web_unlock.json，与 records / 公告 同目录、同加密），重启不丢。
        self._web_unlock = {}           # {client_ip: 解锁时刻}
        self._web_unlock_loaded = False
        self._sched_stop = threading.Event()

        # ---------------- 公告（卡密端「文字推送」→ 小工具端公告区）
        # ★ 用户要求：卡密端推来新公告时，小工具端公告区把新内容**标红**显示。
        #   内容落在源码目录的「公告.json」（复用原程序同一套加密落盘），重启不丢；
        #   每条带 read 标记 —— 未读=红色，点「全部标记已读」后转普通色。
        self.notices = []           # [{"text": str, "ts": str, "read": bool}]
        self.load_notices()

    # ==================================================================
    # 通用小工具
    # ==================================================================
    def log(self, msg, ch="main"):
        return self.bus.log(ch, msg)

    def set_status(self, text):
        self._status = text
        self.bus.set_status("main", text)

    def _to_int(self, v, default=0, lo=None, hi=None):
        try:
            n = int(float(str(v).strip()))
        except Exception:
            return default
        if lo is not None:
            n = max(lo, n)
        if hi is not None:
            n = min(hi, n)
        return n

    @staticmethod
    def _spawn(fn, *a, **kw):
        """起后台线程。

        注意：name / daemon 是「线程」参数，必须从 kw 里摘出来，
        否则会被当成业务参数透传给目标函数（曾导致 TypeError）。
        其余 kw 才是目标函数的业务参数。
        """
        tname = kw.pop("name", None) or getattr(fn, "__name__", None)
        tdaemon = bool(kw.pop("daemon", True))
        t = threading.Thread(target=fn, args=a, kwargs=kw,
                             daemon=tdaemon, name=tname)
        t.start()
        return t

    # ==================================================================
    # 配置：礼包
    # ==================================================================
    def _load_cfg(self):
        d = dict(DEFAULT_CFG)
        data, err = self.C._safe_load_json(self.C.CONFIG_FILE)
        if err:
            self.bus.log("main", "⚠ " + str(err))
        if isinstance(data, dict):
            d.update(data)
        d.pop("headless", None)         # ★ 2026-10-01：无头开关已下线，老键丢掉
        d.pop("auto_check", None)       # ★ 老 config.json 里残留的这个键直接丢掉
        return d

    def save_cfg(self):
        _atomic_write_json(self.C.CONFIG_FILE, self.cfg)
        return True

    def update_cfg(self, patch):
        """前端改设置：只覆盖认识的键，其余原样保留。"""
        if not isinstance(patch, dict):
            return self.cfg
        with self.lock:
            for k in ("auto_wait_login", "timer_enabled", "claim_one",
                      "browser_manual"):
                if k in patch:
                    self.cfg[k] = bool(patch[k])
            for k in ("browser", "timer_time"):
                if k in patch:
                    self.cfg[k] = str(patch[k] or "").strip()
            if "interval" in patch:
                try:
                    self.cfg["interval"] = max(0.5, float(patch["interval"]))
                except Exception:
                    pass
            if "limit" in patch:
                self.cfg["limit"] = self._to_int(patch["limit"], 20, 1, 500)
            if "wait_login" in patch:
                self.cfg["wait_login"] = self._to_int(patch["wait_login"], 240,
                                                      30, 3600)
            if "retry" in patch:
                self.cfg["retry"] = self._to_int(patch["retry"], 3, 0, 3)
            self.save_cfg()
        self.bus.event("cfg", self.cfg)
        return self.cfg

    # ==================================================================
    # 账号
    # ==================================================================
    def load_accounts(self):
        out = []
        data, err = self.C._safe_load_json(self.C.ACCOUNTS_FILE)
        if err:
            self.bus.log("main", "⚠ " + str(err))
        if isinstance(data, dict):
            for a in data.get("accounts", []) or []:
                if isinstance(a, dict):
                    st = self.C._status_from_record(a)
                    out.append({"id": str(a.get("id", "")).strip(),
                                "name": str(a.get("name", "")).strip(),
                                "logined": (st == "ok"), "status": st,
                                "game": str(a.get("game", "") or "").strip(),
                                "uid": str(a.get("uid", "") or "").strip()})
                else:
                    out.append({"id": str(a).strip(), "name": "", "logined": False,
                                "status": "no", "game": "", "uid": ""})
        with self.lock:
            self.accounts = [a for a in out if a["id"]]
        return self.accounts

    def save_accounts(self):
        """保留原文件其他字段（daily_time / time 等），兼容旧版工具格式。"""
        d = {}
        if os.path.exists(self.C.ACCOUNTS_FILE):
            try:
                # ★ v1.1.31 自动识别密文 / 旧明文
                d = self.C._safe_load_json(self.C.ACCOUNTS_FILE)[0]
                if not isinstance(d, dict):
                    d = {}
            except Exception:
                d = {}
        old = {}
        for a in d.get("accounts", []) or []:
            if isinstance(a, dict) and a.get("id") is not None:
                old[str(a["id"])] = a
        newlist = []
        with self.lock:
            accounts = [dict(a) for a in self.accounts]
        for a in accounts:
            base = dict(old.get(a["id"], {}))
            st = self.C.acc_status(a)
            base.update({"id": a["id"],
                         "name": a.get("name") or base.get("name", ""),
                         "first_login": bool(st == "ok"),
                         "login_status": st})
            base["game"] = a.get("game", "")
            base.pop("proxy", None)
            if a.get("uid"):
                base["uid"] = a["uid"]
            newlist.append(base)
        d["accounts"] = newlist
        _atomic_write_json(self.C.ACCOUNTS_FILE, d)
        return True

    def find_account(self, aid):
        with self.lock:
            for a in self.accounts:
                if a["id"] == aid:
                    return a
        return None

    def set_acc_status(self, acc, st, why=""):
        """原 App._set_acc_status：改状态 + 落盘 + 广播，只在真变了才刷列表。

        acc 可以是账号字典，也可以是账号 ID（内部调用两种都出现过）。
        """
        if not isinstance(acc, dict):
            acc = self.find_account(str(acc))
            if not acc:
                return
        if st not in self.C.ACC_STATUS:
            return
        old = self.C.acc_status(acc)
        self.C.acc_set_status(acc, st)
        self.save_accounts()
        self.log("[%s] 登录态：%s%s"
                 % (acc["id"], self.C.ACC_STATUS[st][0],
                    ("（%s）" % why) if why else ""))
        if old != st:
            self.bus.event("accounts")

    def add_account(self, aid, name="", game=""):
        aid = str(aid or "").strip()
        if not aid:
            return {"ok": False, "msg": "账号 ID 不能为空"}
        if self.find_account(aid):
            return {"ok": False, "msg": "账号已存在"}
        acc = {"id": aid, "name": str(name or "").strip(), "logined": False,
               "status": "no", "game": str(game or "").strip(), "uid": ""}
        with self.lock:
            self.accounts.append(acc)
        self.save_accounts()
        self.log("添加账号: %s" % aid)
        self.bus.event("accounts")
        # 原 v1.1.11：加进来就核一遍（本地没登录数据就不用白开浏览器）
        if self.C.local_login_hint(aid) == "no":
            self.log("[%s] 本地没有该账号的登录数据，需要点『扫码登录』" % aid)
        else:
            self.log("[%s] 本地有登录数据，正在核对是否掉线…" % aid)
            self.check_accounts(only=acc)
        return {"ok": True, "account": acc}

    def update_account(self, aid, patch):
        acc = self.find_account(aid)
        if not acc:
            return {"ok": False, "msg": "账号不存在"}
        with self.lock:
            if "name" in patch:
                acc["name"] = str(patch["name"] or "").strip()
            if "game" in patch:
                acc["game"] = str(patch["game"] or "").strip()
        self.save_accounts()
        self.bus.event("accounts")
        return {"ok": True, "account": acc}

    # ==================================================================
    # ★ 2026-09-25 用户要求：删除账号时，**把这个账号的 Cookie 一起删掉**
    #   只删 Cookie —— profile 目录本身保留（用户明确：profile 不删），
    #   所以书签 / 设置 / localStorage 都还在，重新加回同名账号只要重新扫码。
    #   一个账号的 Cookie 落在三处：
    #     ① <DATA_DIR>\cookie_backup\<profile 名>.json   ← 引擎自己写的备份
    #     ② <程序目录>\cookie_backup\<profile 名>.json   ← 第二份备份（取最新那个）
    #     ③ <profile>\Default\Network\Cookies            ← Chrome 自己的 cookie 库
    #   ①② 不删就等于「删了账号还能免扫码恢复登录」，③ 不删等于账号其实还在登录态。
    # ==================================================================
    # Chrome 的 cookie 库相对 profile 的常见位置（不同内核版本不一样，都覆盖）
    _COOKIE_DB_RELS = (os.path.join("Default", "Network", "Cookies"),
                       os.path.join("Default", "Cookies"),
                       os.path.join("Network", "Cookies"))

    def _cookie_files_of(self, aid):
        """该账号的全部 Cookie 落点（备份文件 + profile 内 Chrome 的 cookie 库）。"""
        out = []
        for prof in self.C.account_profiles(aid):
            try:
                out.extend(p for p in self.C.cookie_backup_paths(prof) if p)
            except Exception:
                pass
            for rel in self._COOKIE_DB_RELS:
                db = os.path.join(prof, rel)
                out.append(db)                      # sqlite 本体
                for suf in ("-journal", "-wal", "-shm"):
                    out.append(db + suf)            # 同目录的 WAL/日志兄弟文件
        seen, uniq = set(), []
        for p in out:
            key = os.path.normcase(os.path.normpath(p))
            if key not in seen:
                seen.add(key)
                uniq.append(p)
        return uniq

    @staticmethod
    def _rm_files(paths):
        """删一批文件，返回 (删掉几个, 没删掉的路径)。"""
        n, left = 0, []
        for p in paths:
            try:
                if os.path.isfile(p):
                    os.remove(p)
                    n += 1
            except OSError:
                left.append(p)
        return n, left

    def _purge_account_cookies(self, aid):
        """清掉某账号的 Cookie，返回删掉的文件数。"""
        n, left = self._rm_files(self._cookie_files_of(aid))
        if left:
            # 多半是该账号的 Chrome 还开着：Windows 上 sqlite 被占用会删不掉，
            # 而且就算删掉了，它还会把内存里的 cookie 再刷回磁盘。
            # → 先把这个 profile 的 chrome 关掉（只杀带本账号 user-data-dir 的），再重试一次。
            for prof in self.C.account_profiles(aid):
                try:
                    self.C.Engine.kill_profile_chrome(prof)
                except Exception:
                    pass
            n2, left = self._rm_files(left)
            n += n2
        for p in left:
            self.log("⚠ Cookie 没删掉：%s（文件被占用？关掉该账号的浏览器再删一次）" % p)
        return n

    def del_account(self, aid):
        with self.lock:
            before = len(self.accounts)
            self.accounts = [a for a in self.accounts if a["id"] != aid]
            removed = len(self.accounts) != before
        if not removed:
            return {"ok": False, "msg": "账号不存在"}
        self.save_accounts()
        n_cookie = self._purge_account_cookies(aid)
        self.log("删除账号: %s（已清掉该账号 Cookie %d 个文件；浏览器 profile 目录保留）"
                 % (aid, n_cookie))
        self.bus.event("accounts")
        return {"ok": True, "msg": "", "cookies": n_cookie}

    def import_accounts(self, accounts):
        """导入 accounts.json 里的账号数组（前端读文件后把内容发上来）。"""
        n = 0
        with self.lock:
            existing = {a["id"] for a in self.accounts}
            for a in accounts or []:
                if isinstance(a, dict):
                    aid = str(a.get("id", "")).strip()
                    st = self.C._status_from_record(a)
                    name = str(a.get("name", "") or "")
                    game = str(a.get("game", "") or "").strip()
                    uid = str(a.get("uid", "") or "").strip()
                else:
                    aid, st, name, game, uid = str(a).strip(), "no", "", "", ""
                if not aid or aid in existing:
                    continue
                existing.add(aid)
                self.accounts.append({"id": aid, "name": name,
                                      "logined": (st == "ok"), "status": st,
                                      "game": game, "uid": uid})
                n += 1
        self.save_accounts()
        self.log("导入 %d 个账号" % n)
        self.bus.event("accounts")
        if n:
            self.check_accounts()
        return {"ok": True, "n": n}

    # ==================================================================
    # 领取记录
    # ==================================================================
    def load_records(self):
        data, err = self.C._safe_load_json(self.C.RECORDS_FILE)
        if err:
            self.bus.log("main", "⚠ " + str(err))
        raw = data if isinstance(data, list) else []
        with self.lock:
            self.records = self.C._prune_records_by_time(raw)
        if len(self.records) != len(raw):
            self.save_records()
        return self.records

    def save_records(self):
        with self.lock:
            recs = self.C._prune_records_by_time(list(self.records))
            self.records = recs
            payload = recs[-5000:]
        _atomic_write_json(self.C.RECORDS_FILE, payload)
        return True

    def claimed_ids(self, acc_id):
        with self.lock:
            recs = list(self.records)
        s = set()
        for r in recs:
            if (r.get("account") == acc_id and r.get("result") == "成功"
                    and r.get("gift")):
                s.add(r["gift"])
        return s

    def _plan(self, acc, raw_gifts):
        gifts = list(raw_gifts)                  # 原 _apply_filter 已改为原样返回
        claimed = self.claimed_ids(acc["id"])
        cand = [g for g in gifts if g["id"] not in claimed]
        return gifts, claimed, cand

    # ==================================================================
    # 浏览器
    # ==================================================================
    def browser_list(self, refresh=False):
        if refresh or not self._browsers or time.time() - self._browsers_ts > 600:
            try:
                self._browsers = list(self.C.detect_browsers(
                    log=lambda m: self.log(m)))
            except Exception as ex:
                self.log("检测浏览器失败：%s" % ex)
                self._browsers = list(self._browsers or [])
            self._browsers_ts = time.time()
        return self._browsers

    def detect_async(self):
        def work():
            self.bus.set_status("main", "正在检测本机浏览器…")
            self.log("正在检测本机浏览器…")
            browsers = self.browser_list(refresh=True)
            if browsers:
                self.log("检测到 %d 款浏览器：%s" % (
                    len(browsers),
                    "、".join("%s(%s)" % (n, self.C.get_browser_version(p))
                              for n, p, _k in browsers[:4])))
            else:
                self.log("未检测到浏览器。可手动指定 chrome.exe 路径；"
                         "若源码目录里有 chrome-win64.zip，开始领取时会自动释放内置浏览器。")
            # 原 _fill_browsers：内置浏览器存在时默认用它（除非用户手动选过）
            saved = str(self.cfg.get("browser") or "")
            try:
                emb = self.C.embedded_browser(log=lambda m: self.log(m))
            except Exception:
                emb = ""
            if emb and not self.cfg.get("browser_manual"):
                saved = emb
            if (not saved) or (not os.path.exists(saved)) or browser_policy_blocked(saved):
                saved = ""
                for _n, p, k in browsers:
                    if k == "chromium" and not browser_policy_blocked(p):
                        saved = p
                        break
            # ★ 被组策略锁住的浏览器（Chrome / Chromium / Edge 三族都算）当场说清楚，
            #   并给出路 —— 设置页有【一键清除浏览器策略】按钮。
            for _n, p, _k in browsers:
                _w = browser_policy_blocked(p)
                if _w:
                    self.log("⚠ 检测到 %s：%s" % (_n, _w))
            if not saved:
                # 一台能自动化的都没有 → 试着放一份便携浏览器出来
                try:
                    saved = self.ensure_embedded_browser() or ""
                except Exception:
                    saved = ""
            self._cur_browser = saved or (browsers[0][1] if browsers else "")
            with self.lock:
                self.cfg["browser"] = self._cur_browser
            self.save_cfg()
            self._detect_done = True
            self.bus.event("browsers")
            self.bus.set_status("main", "就绪")
        self._spawn(work, name="detect-browsers")

    def cur_browser(self):
        """当前要用的浏览器路径（手动选过就用选的，否则挑第一个能用的 chromium）。

        ★ 2026-09-26：被组策略锁死的 Edge 排最后 —— 它起不来独立实例，
        CDP 永远连不上（详见 browser_policy_blocked 的说明）。只要有别的
        chromium（含内置/便携 Chrome）就优先用它。
        """
        cand = ""
        with self.lock:
            cand = str(self.cfg.get("browser") or "")
        if cand and os.path.exists(cand) and not browser_policy_blocked(cand):
            return cand
        fallback = cand if (cand and os.path.exists(cand)) else ""
        # 先找内置/便携 Chrome（它不受 Edge 策略影响）
        try:
            emb = self.C.embedded_browser(log=lambda m: self.log(m))
        except Exception:
            emb = ""
        if emb and not browser_policy_blocked(emb):
            return emb
        for _n, p, k in self.browser_list():
            if k == "chromium" and not browser_policy_blocked(p):
                return p
        # 一个能自动化的都没有 → 试着自己放一份便携浏览器出来
        try:
            emb2 = self.ensure_embedded_browser()
        except Exception:
            emb2 = ""
        if emb2 and not browser_policy_blocked(emb2):
            return emb2
        return fallback or cand

    def pick_browser_path(self, path):
        path = str(path or "").strip()
        if not path or not os.path.exists(path):
            return {"ok": False, "msg": "文件不存在：%s" % path}
        if path.lower().endswith("firefox.exe"):
            return {"ok": False, "msg": "仅支持 Chromium 内核浏览器"}
        with self.lock:
            self.cfg["browser"] = path
            self.cfg["browser_manual"] = True
            self._cur_browser = path
        self.save_cfg()
        self.bus.event("browsers")
        self.log("已手动指定浏览器：%s" % path)
        return {"ok": True, "browser": path}

    def ensure_embedded_browser(self):
        """兜底：一台 chromium 都找不到时，从源码目录的 chrome-win64.zip 解压内置浏览器。

        原程序的 `embedded_browser()` 只在打包成 EXE（`sys.frozen`）时才解压
        随包附带的浏览器；网页版是从源码跑的，走不到那条分支，
        所以这里补上等价的一条 —— 而且**只在真的没有浏览器时才动**，
        免得平白多占两三百 MB 磁盘。

        返回 chrome.exe 路径；没有可用来源时返回 ""。
        """
        try:
            exe = self.C.embedded_browser(log=lambda m: self.log(m))
        except Exception as ex:
            self.log("检查内置浏览器失败：%s" % ex)
            exe = ""
        if exe:
            return exe
        # ★ 2026-09-26：原模块的 embedded_browser() 在打包环境（sys.frozen）
        #   只认「随包附带的 zip」，不会去看已经释放好的 EMBED_DIR；
        #   我们用便携包时是自己解压到那里的，所以这里补一步直接检查。
        target = self.C.EMBED_DIR
        for sub in ("chrome-win64", "chrome-win", ""):
            p = os.path.join(target, sub, "chrome.exe") if sub else os.path.join(target, "chrome.exe")
            try:
                if self.C._valid_chrome(p):
                    self.log("使用已释放的便携浏览器：%s" % p)
                    with self.lock:
                        self.cfg["browser"] = p
                    self.save_cfg()
                    return p
            except Exception:
                continue

        src = core.find_src_dir()
        if not src:
            return ""
        zip_path = os.path.join(src, "chrome-win64.zip")
        if not os.path.isfile(zip_path):
            return ""

        target = self.C.EMBED_DIR
        exe_path = os.path.join(target, "chrome-win64", "chrome.exe")
        self.log("本机没有可用浏览器，正在释放内置浏览器压缩包…"
                 "（%d MB，只做一次，约需十几秒）"
                 % (os.path.getsize(zip_path) / 1024 / 1024))
        try:
            self.C._kill_embedded_chrome(log=lambda m: self.log(m))
        except Exception:
            pass
        try:
            import zipfile
            shutil.rmtree(target, ignore_errors=True)
            os.makedirs(target, exist_ok=True)
            with zipfile.ZipFile(zip_path) as zf:
                zf.extractall(target)
        except Exception as ex:
            self.log("内置浏览器释放失败：%s" % ex)
            return ""
        if self.C._valid_chrome(exe_path):
            self.log("内置浏览器已就绪：%s" % target)
            with self.lock:
                self.cfg["browser"] = exe_path
            self.save_cfg()
            return exe_path
        self.log("内置浏览器释放异常：chrome.exe 无效（可能被杀毒软件拦截或磁盘空间不足）")
        return ""

    def _start_engine(self):
        """原 App._start_engine：读设置、校验浏览器与参数，返回 Engine。"""
        b = self.cur_browser()
        if not b:
            # 一个 chromium 都没找到 → 试着自己释放一份内置浏览器
            b = self.ensure_embedded_browser()
        if not b:
            return None, "请先检测/选择浏览器"
        low = b.lower()
        if low.endswith("firefox.exe"):
            return None, "仅支持 Chromium 内核浏览器（Chrome/Edge/360/2345 等）"
        interval = float(self.cfg.get("interval") or 2.0)
        limit = int(self.cfg.get("limit") or 20)
        retry = max(0, min(3, int(self.cfg.get("retry") or 0)))
        e = self.C.Engine(log=lambda m: self.log(m), ask=lambda m: True)
        e.browser = b
        e.interval = interval
        e.limit = limit
        e.retry = retry
        e.claim_one = bool(self.cfg.get("claim_one", True))
        e.headless = False            # ★ 2026-10-01：礼包领取固定开可见窗口
        e.auto_wait_login = bool(self.cfg.get("auto_wait_login", True))
        return e, ""

    def _migrate_old_profile(self, acc_id, new_profile):
        try:
            self.C.migrate_old_profile(acc_id, new_profile,
                                       log=lambda m: self.log(m))
        except Exception:
            pass

    def _open_for_account(self, e, acc, url=None):
        """原 App._open_for_account：隔离 profile + 独立端口 + cookie 备份恢复。"""
        url = url or self.C.SITE_URL
        browser = e.browser
        profile = os.path.join(self.C.DATA_DIR,
                               "browser_data_" + self.C.safe_name(acc["id"]))
        self._migrate_old_profile(acc["id"], profile)
        port = self.C.free_port()
        try:
            e.kill_profile_chrome(profile)
        except Exception:
            pass
        self.log("[%s] 浏览器=%s  隔离目录=%s  调试端口=%d"
                 % (acc["id"], os.path.basename(browser),
                    os.path.basename(profile), port))
        _all = [browser]
        try:
            for _n, _p, _k in self.C.detect_browsers():
                if str(_p).lower() != str(browser).lower():
                    _all.append(_p)
        except Exception:
            pass
        candidates = []
        blocked_why = ""
        for _c in _all:
            if _c in candidates:
                continue
            _w = browser_policy_blocked(_c)
            if _w:
                blocked_why = blocked_why or _w
                continue
            candidates.append(_c)
        if not candidates:
            # 能用的一个都没有（多半是 Edge 被策略锁死）→ 说清楚，别干等 60 秒
            self.log("[%s] ✗ 没有可用于自动化的浏览器：%s"
                     % (acc["id"], blocked_why or "未检测到 Chromium"))
            return False
        launched, last_err = False, None
        for cand in candidates:
            try:
                e.launch(cand, profile, port, url, headless=e.headless)
                if cand != browser:
                    self.log("[%s] 已自动回退使用浏览器: %s" % (acc["id"], cand))
                launched = True
                break
            except OSError as ex:
                last_err = ex
                self.log("[%s] 启动 %s 失败: %s"
                         % (acc["id"], os.path.basename(cand), ex))
                port = self.C.free_port()
        if not launched:
            self.log("[%s] 所有浏览器均无法启动（最后错误: %s）" % (acc["id"], last_err))
            return False
        if not e.wait_cdp(port, timeout=60):
            self.log("浏览器启动超时")
            return False
        if not e.attach(port):
            self.log("无法连接浏览器")
            return False
        e.open_site(url)
        n = e.wait_ready()
        if not n:
            self.log("页面加载异常，未找到礼包按钮")
            return False
        ok, _ = e.is_logged_in()
        if not ok:
            why = e.diagnose_login_loss()
            self.log("[%s] 磁盘登录态丢失（%s），正在从 cookie 备份恢复…"
                     % (acc["id"], why))
            if e.restore_cookies():
                self.log("[%s]   备份来源：%s"
                         % (acc["id"], getattr(e, "last_restore_info", "") or "未知"))
                e.open_site(url)
                e.wait_ready()
                if e.is_logged_in()[0]:
                    self.log("[%s] cookie 备份恢复成功，无需重新扫码" % acc["id"])
                    e.backup_cookies()
                else:
                    self.log("[%s] 备份已注入但仍未登录：登录凭证已失效，"
                             "这次需要重新扫码（扫码后会自动刷新备份）" % acc["id"])
            else:
                self.log("[%s] 没找到任何可用的 cookie 备份，需要重新扫码"
                         % acc["id"])
        self.log("[%s] 页面就绪，发现 %d 个礼包按钮" % (acc["id"], n))
        return True

    def capture_uid(self, acc, e):
        """原 App._capture_uid：读站内身份，并提示重复身份（同微信两个号）。"""
        uid = ""
        try:
            uid = str(e.site_uid() or "")
        except Exception:
            pass
        if not uid:
            self.log("[%s] 未能读取站内身份(userId)" % acc["id"])
            return ""
        acc["uid"] = uid
        with self.lock:
            others = [a for a in self.accounts
                      if a is not acc and a.get("uid") == uid]
        if others:
            self.log("!! 警告：账号 %s 和 %s 登录的是同一个站内身份(userId=%s)"
                     % (acc["id"], others[0]["id"], uid))
            self.log("!! 两个账号会共用同一份领取资格，第二个账号会提示“已领过”。")
            self.log("!! 要真正多开：重新登录时先在手机微信里切换到另一个微信号再扫码。")
            self.bus.event("alert", {
                "title": "发现重复身份",
                "text": "账号 %s 和 %s 登录的是同一个站内身份(userId=%s)。\n"
                        "两个账号共用同一份领取资格，无法双倍领取。\n\n"
                        "解决办法：选中其中一个账号点【扫码登录】，在浏览器里"
                        "先点网页右上角【退出】，再切换到另一个微信扫码。"
                        % (acc["id"], others[0]["id"], uid)})
        return uid

    # ==================================================================
    # 登录态核对（★ 与 EXE 版完全同一套判据）
    # ==================================================================
    def check_accounts(self, only=None):
        if self.checking:
            self.log("登录态核对正在进行中，稍等一下…")
            return False
        if self.running:
            self.log("任务运行中，先不核对登录态（避免抢同一个 profile）")
            return False
        targets = [only] if only is not None else list(self.accounts)
        targets = [a for a in targets if a and a.get("id")]
        if not targets:
            return False
        self.checking = True
        self.bus.event("checking", True)
        self._spawn(self._check_worker, targets, name="check-accounts")
        return True

    def _check_engine(self):
        b = self.cur_browser()
        if not b or b.lower().endswith("firefox.exe"):
            return None
        e = self.C.Engine(log=lambda m: self.log(m), ask=lambda m: True)
        e.browser = b
        e.headless = True
        return e

    def _check_worker(self, targets):
        e = None
        try:
            self.set_status("正在核对 %d 个账号的登录态…" % len(targets))
            self.log("开始核对 %d 个账号的登录态（只看掉没掉线）…" % len(targets))
            need_browser = []
            for acc in targets:
                hint = self.C.local_login_hint(acc["id"])
                if hint == "off":
                    self.set_acc_status(acc, "off", "本地 cookie 已全部过期")
                elif hint == "ok":
                    need_browser.append(acc)
                elif self.C.acc_status(acc) == "ok":
                    self.set_acc_status(acc, "off", "本地已无该账号的登录数据")
            for acc in need_browser:
                if self.running:
                    self.log("任务已开始运行，剩下账号的核对留到下次")
                    break
                if e is None:
                    e = self._check_engine()
                    if e is None:
                        self.log("没检测到可用浏览器，本次只能给出本地判断的结果")
                        break
                self.set_status("正在核对 %s …" % acc["id"])
                st = self._verify_online(e, acc)
                if st == "ok":
                    self.set_acc_status(acc, "ok", "浏览器核对通过")
                elif st == "off":
                    self.set_acc_status(acc, "off", "站点已不认这份登录态")
                else:
                    self.log("[%s] 没核对出结果（浏览器没起来 / 页面没加载出来），"
                             "保持原状态" % acc["id"])
            self.save_accounts()
            n_off = sum(1 for a in targets if self.C.acc_status(a) == "off")
            self.log("登录态核对结束：%d 个账号，掉线 %d 个%s"
                     % (len(targets), n_off,
                        "（掉线的号请重新扫码登录）" if n_off else ""))
        except Exception as ex:
            self.log("登录态核对异常: %s" % ex)
        finally:
            if e is not None:
                try:
                    e.close()
                except Exception:
                    pass
            self.checking = False
            self._last_check_ts = time.time()
            self.bus.event("checking", False)
            self.bus.event("accounts")
            self.set_status("就绪")

    def _verify_online(self, e, acc):
        """开一次无头浏览器问站点「还认这个账号吗」，返回 ok / off / unknown。"""
        profile = self.C.account_profile(acc["id"])
        self._migrate_old_profile(acc["id"], profile)
        port = self.C.free_port()
        try:
            e.kill_profile_chrome(profile)
        except Exception:
            pass
        try:
            e.launch(e.browser, profile, port, self.C.SITE_URL, headless=True)
        except Exception as ex:
            self.log("[%s] 核对用浏览器启动失败: %s" % (acc["id"], ex))
            return "unknown"
        try:
            if not e.wait_cdp(port, timeout=45):
                return "unknown"
            if not e.attach(port):
                return "unknown"
            e.open_site(self.C.SITE_URL)
            if not self._page_alive(e):
                return "unknown"
            ok, _phone, answered = self._site_logged_in(e)
            if not ok and e.restore_cookies():
                self.log("[%s] 试一次 cookie 备份恢复…" % acc["id"])
                e.open_site(self.C.SITE_URL)
                if self._page_alive(e):
                    ok, _phone, answered = self._site_logged_in(e)
            if ok:
                e.backup_cookies()
                return "ok"
            if not answered:
                self.log("[%s] 没问到站点（浏览器中途被关闭/页面失联），结果作废"
                         % acc["id"])
                return "unknown"
            return "off"
        except Exception as ex:
            self.log("[%s] 核对异常: %s" % (acc["id"], ex))
            return "unknown"
        finally:
            e.close()

    def _page_alive(self, e, timeout=30):
        end = time.time() + timeout
        while time.time() < end:
            r = e.cdp.ev(self.C.JS_PAGE_READY, timeout=10)
            if isinstance(r, dict) and str(r.get("ready")) == "complete":
                if (r.get("api") or r.get("header") or (r.get("btns") or 0) > 0):
                    return True
            time.sleep(1.5)
        return False

    @staticmethod
    def _site_logged_in(e, tries=2, gap=1.5):
        """问站点两次登录态 → (是否已登录, 手机号, 站点有没有真的回答)。"""
        C = core.load()
        answered = False
        for i in range(max(1, tries)):
            try:
                r = e.cdp.ev(C.JS_LOGIN, timeout=20)
            except Exception:
                r = None
            if isinstance(r, dict):
                answered = True
                if r.get("login"):
                    return True, (r.get("phone") or ""), True
            try:
                h = e.cdp.ev(C.JS_HEADER_LOGIN, timeout=20)
            except Exception:
                h = None
            if isinstance(h, dict):
                answered = True
                if h.get("logout"):
                    return True, str(h.get("text", "")).replace("退出", "").strip(), True
            if i + 1 < tries:
                time.sleep(gap)
        return False, "", answered

    # ==================================================================
    # 扫码登录
    # ==================================================================
    # ---------------- ★ 需求⑬：二维码同步（服务器出码 → 远程网页显示） ----------------
    def _qr_set(self, png_b64, acc_id, digest):
        """存下这张二维码并广播（网页收到 qr 事件后自己去 /api/gift/qr 取图）。"""
        with self.lock:
            self._qr["png"] = png_b64
            self._qr["hash"] = digest
            self._qr["acc"] = acc_id
            self._qr["ts"] = time.time()
            self._qr["stage"] = "qr"
            self._qr["seq"] = int(self._qr.get("seq") or 0) + 1
            snap = {"seq": self._qr["seq"], "acc": acc_id,
                    "ts": self._qr["ts"], "kb": max(1, len(png_b64) // 1024)}
        self.bus.event("qr", snap)
        return snap

    def _qr_clear(self, why=""):
        """撤掉网页上那张二维码（扫码框关了 / 登录成功了 / 登录会话结束了）。"""
        with self.lock:
            had = bool(self._qr.get("png"))
            self._qr["png"] = ""
            self._qr["hash"] = ""
            self._qr["acc"] = ""
            self._qr["ts"] = time.time()
            self._qr["stage"] = ""
            self._qr["seq"] = int(self._qr.get("seq") or 0) + 1
            seq = self._qr["seq"]
        if had:
            self.bus.event("qr", {"seq": seq, "acc": "", "ts": time.time(),
                                  "gone": True, "why": why})
        return had

    def _qr_stage(self, stage, why=""):
        """★ 2026-09-26：没码的时候也要告诉网页「现在在干什么」。

        以前只有「有码 / 没码」两种状态 —— 浏览器还在启动、或者页面开了
        但二维码还没弹出来的那几十秒，网页上**一片空白**，人在外网看着
        就是「点了没反应」。现在把阶段说出来：starting → waiting → qr。
        """
        with self.lock:
            if self._qr.get("stage") == stage:
                return
            self._qr["stage"] = stage
            self._qr["ts"] = time.time()
            self._qr["seq"] = int(self._qr.get("seq") or 0) + 1
            seq = self._qr["seq"]
        self.bus.event("qr", {"seq": seq, "acc": "", "ts": time.time(),
                              "stage": stage, "why": why})

    def qr_state(self):
        """给网页取的当前二维码（换台电脑/刷新页面后也拿得到同一张）。"""
        with self.lock:
            q = dict(self._qr)
        if not q.get("png"):
            # ★ stage 带出去：浏览器还在起 / 还在等码的时候，网页上也能说清楚
            #   现在在干什么，而不是让外网的人对着一片空白猜。
            return {"ok": True, "qr": None, "seq": q.get("seq", 0),
                    "stage": q.get("stage", "")}
        return {"ok": True, "seq": q.get("seq", 0),
                "qr": {"png": "data:image/png;base64," + q["png"],
                       "acc": q.get("acc", ""), "ts": q.get("ts", 0)}}

    def _qr_png_from_dom(self, e):
        """先试 DOM：<canvas>.toDataURL() / <img src="data:...">。窗口最小化也拿得到。"""
        try:
            r = e.cdp.ev(JS_QR_IMG, timeout=10)
        except Exception:
            return ""
        if not isinstance(r, dict):
            return ""
        u = str(r.get("png") or "")
        if not u.startswith("data:image"):
            return ""
        return u.split(",", 1)[1] if "," in u else ""

    def _qr_png_from_shot(self, e, aid):
        """退一步：按扫码框那一块截屏（二维码是外链图片时只能走这条）。"""
        try:
            box = e.cdp.ev(JS_QR_BOX, timeout=10)
        except Exception:
            return ""
        if not isinstance(box, dict):
            return ""
        try:
            x = max(0.0, float(box.get("x") or 0))
            y = max(0.0, float(box.get("y") or 0))
            w = min(max(1.0, float(box.get("w") or 0)), 1200.0)
            h = min(max(1.0, float(box.get("h") or 0)), 1200.0)
        except Exception:
            return ""
        try:
            r = e.cdp.send("Page.captureScreenshot", {
                "format": "png",
                "clip": {"x": x, "y": y, "width": w, "height": h, "scale": 1},
                "captureBeyondViewport": False,
            }, timeout=15)
        except Exception as ex:
            self.log("[%s] 二维码截屏失败：%s" % (aid, ex))
            return ""
        return str((((r or {}).get("result") or {}).get("data")) or "")

    def _qr_tick(self, e, acc):
        """登录等待循环里每轮调一次：看到码就同步，看不到就把上一张撤掉。

        ★ 不做无条件重推：同一张图（哈希相同）不重复广播，免得每 2.5 秒刷一次前端。
        """
        aid = (acc or {}).get("id", "")
        png = self._qr_png_from_dom(e)
        if not png:
            # CDP 截屏那条路每次的像素都不完全一样（按内容哈希去重顶不住），
            # 所以压到至少 12 秒才重截一张，免得每 2.5 秒往网页推几十 KB。
            now = time.time()
            if (now - self._qr_shot_ts) < 12:
                if self._qr.get("png"):
                    return True
                self._qr_maybe_open(e, aid)
                return False
            self._qr_shot_ts = now
            png = self._qr_png_from_shot(e, aid)
        if not png:
            if self._qr.get("png"):
                self._qr_clear("服务器浏览器里的扫码框已关闭")
            else:
                self._qr_maybe_open(e, aid)
            return False
        digest = hashlib.sha1(png.encode("ascii", "ignore")).hexdigest()
        with self.lock:
            same = (digest == self._qr.get("hash"))
        if same and self._qr.get("png"):
            return True
        self._qr_set(png, aid, digest)
        self.log("[%s] 扫码框已同步到网页（换台电脑也能扫）" % aid)
        return True

    def _qr_maybe_open(self, e, aid):
        """有些站点要手点一下「登录」才弹扫码框；服务器那头没人可点，这里替点。"""
        if self._qr_clicks >= 3:
            return False
        if self._qr_clicks and (time.time() - self._qr_click_ts) < 20:
            return False
        try:
            hit = e.cdp.ev(JS_QR_OPEN, timeout=10)
        except Exception:
            return False
        self._qr_clicks += 1
        self._qr_click_ts = time.time()
        if isinstance(hit, dict):
            self.log("[%s] 页面没自己弹扫码框，已替点一次「登录」(%s)"
                     % (aid, hit.get("hit") or ""))
            return True
        self.log("[%s] 页面里没找到「登录」入口，扫码框只能等它自己弹" % aid)
        return False

    def login(self, aid, auto=True):
        if self.running:
            return {"ok": False, "msg": "任务正在运行，请先停止"}
        acc = self.find_account(aid)
        if not acc:
            return {"ok": False, "msg": "账号不存在"}
        if self._login_engine is not None:
            return {"ok": False, "msg": "已有一个登录会话在进行中"}
        e, err = self._start_engine()
        if not e:
            return {"ok": False, "msg": err}
        if e.headless:
            e.headless = False        # 扫码必须看得见窗口
            self.log("扫码登录需要显示浏览器窗口，本次忽略无头模式。")
        self._login_engine = e
        self._login_acc = acc
        # ★ 需求⑬：开一轮新的扫码会话 —— 上一轮残留的二维码先撤掉，
        #   「替点登录」的次数也重新计数。
        self._qr_clear("上一轮扫码已结束")
        # ★ 2026-09-26：收到指令就告诉网页「正在起浏览器」——
        #   以前要等码真的出来网页上才有东西，中间几十秒是一片空白。
        self._qr_stage("starting", "正在打开浏览器")
        self._qr_clicks = 0
        self._qr_click_ts = 0.0
        self._qr_shot_ts = 0.0
        self._spawn(self._login_worker, acc, auto, name="login")
        return {"ok": True, "msg": "已在浏览器中打开，请用微信扫码"}

    def _finish_login(self, acc, e, why):
        """登录成功的收尾（★ 2026-10-05 补回）。

        这个方法原先存在，删「补登」时被连带删掉了，但 _login_worker 的两处
        成功分支仍在调用它 —— 结果就是扫码明明成功，却抛
        `AttributeError: 'Service' object has no attribute '_finish_login'`，
        然后走 finally 把浏览器关掉：**cookie 没来得及备份，用户白扫一次**。

        收尾分三步（与桌面版 _login_worker / _run_worker 同一套口径）：
          1) 落盘登录态：账号标 ok → 备份 cookie → 记站内身份 userId → 存盘；
          2) 撤掉网页上那张二维码，并广播「登录成功」；
          3) 把这个登录会话收干净（关浏览器、清 _login_engine）——
             清了之后 _login_worker 的 finally 就不会再报一次「未登录成功」。
        """
        phone = ""
        try:
            ok, phone = e.is_logged_in()
            if not ok:
                phone = ""
        except Exception:
            pass
        # --- 1) 先把登录态落盘：这几步都要浏览器还活着 ---
        try:
            self.C.acc_set_status(acc, "ok")
        except Exception as ex:
            self.log("[%s] 标记登录态失败：%s" % (acc["id"], ex))
        try:
            e.backup_cookies()      # 立即备份 cookie，防止浏览器关闭时丢失
        except Exception as ex:
            self.log("[%s] cookie 备份失败：%s" % (acc["id"], ex))
        uid = ""
        try:
            uid = self.capture_uid(acc, e)
        except Exception as ex:
            self.log("[%s] 读取站内身份失败：%s" % (acc["id"], ex))
        try:
            self.save_accounts()
        except Exception as ex:
            self.log("[%s] 账号存盘失败：%s" % (acc["id"], ex))
        # --- 2) 收掉会话（先置空 _login_engine，finally 里那条失败分支就不走了）---
        if self._login_engine is e:
            self._login_engine = None
            self._login_acc = None
        try:
            e.close()
        except Exception:
            pass
        # --- 3) 通知网页 ---
        self._qr_clear("登录成功")
        self.set_status("就绪")
        self.bus.event("accounts")
        tail = ("，站内身份 userId=%s" % uid) if uid else ""
        self.log("[%s] 登录成功（%s）%s，cookie 已备份" % (acc["id"], why, tail))
        self.bus.event("login", {"id": acc["id"], "ok": True,
                                 "msg": why, "phone": phone})

    def _login_worker(self, acc, auto=True):
        e = self._login_engine
        try:
            self.set_status("正在为账号 %s 打开浏览器…" % acc["id"])
            self.log("―――――― %s：打开浏览器扫码登录 ――――――" % acc["id"])
            if not self._open_for_account(e, acc):
                self.log("[%s] 浏览器/页面未就绪，登录流程中止" % acc["id"])
                self._qr_stage("", "浏览器未就绪")
                self.bus.event("login", {"id": acc["id"], "ok": False,
                                         "msg": "浏览器未就绪"})
                return
            # ★ 浏览器起来了，还在等二维码弹出来
            self._qr_stage("waiting", "浏览器已打开，等待扫码框")
            already, phone = e.is_logged_in()
            if already:
                self.log("[%s] 该 profile 已是登录状态（%s）" % (acc["id"], phone or ""))
                self._finish_login(acc, e, "已登录")
                return
            self.log("[%s] 请在弹出的浏览器窗口里用微信扫码登录；"
                     "若显示的是别的账号，先点网页右上角【退出】再扫。" % acc["id"])
            timeout = max(30, int(self.cfg.get("wait_login") or 240))
            end = time.time() + timeout
            warned = False
            # ★「我已完成登录」按钮已删（用户要求）：这里不再「等到超时就撒手」，
            #   而是等到「登录成功」或「窗口被关掉」为止 —— 慢慢扫也来得及，扫完自动保存。
            while True:
                if e.stop_flag:
                    break
                if e.proc is not None and e.proc.poll() is not None:
                    self.log("[%s] 浏览器窗口已被关闭，本次登录结束。" % acc["id"])
                    break
                try:
                    ok, phone = e.is_logged_in()
                except Exception:
                    ok, phone = False, ""
                if ok:
                    self.log("[%s] 检测到登录成功：%s" % (acc["id"], phone or "已登录"))
                    self._finish_login(acc, e, "扫码成功")
                    return
                if (not warned) and time.time() >= end:
                    warned = True
                    self.log("[%s] 已等 %d 秒还没检测到登录 —— 浏览器继续开着，"
                             "扫完会自动保存；不想扫了直接关掉那个窗口就行。"
                             % (acc["id"], timeout))
                # ★ 需求⑬：把服务器浏览器里那张二维码同步给网页（人在别的电脑上
                #   看不到服务器那块屏）。拿不到码不会抛，最多就是日志里说一声。
                try:
                    self._qr_tick(e, acc)
                except Exception as ex:
                    self.log("[%s] 二维码同步跳过：%s" % (acc["id"], ex))
                time.sleep(2.5)
            self.bus.event("login", {"id": acc["id"], "ok": False,
                                     "msg": "登录未完成（窗口已关闭）"})
        except Exception as ex:
            self.log("[%s] 登录异常: %s" % (acc["id"], ex))
        finally:
            # ★ 没登录成功就走到这里 —— 必须把这个会话收掉（关浏览器、清 _login_engine），
            #   否则它会一直吊着，挡住下一次「扫码登录」。
            if self._login_engine is e:
                self._login_engine = None
                self._login_acc = None
                try:
                    e.close()
                except Exception:
                    pass
                self.set_status("就绪")
                self.log("[%s] 登录会话已结束（未登录成功）" % acc["id"])
                # ★ 2026-10-05：这两句只属于「没成功」这条路。登录成功时
                #   _finish_login() 已撤码并广播过成功事件，这里再执行一次
                #   会把网页上的提示冲掉（前端 refresh 后显示成「会话结束」）。
                self._qr_clear("登录会话已结束")
                self.bus.event("login", {"id": acc["id"], "ok": None, "msg": ""})
    # ★ 「取消登录」已删（用户要求）：前端按钮、/api/gift/login/cancel 路由、
    #   本方法（原 cancel_login）一并撤掉。
    # ★ 「补登」也已按用户要求整体删除（2026-09-28）：前端按钮与状态、SSE 分支、
    #   两条后端路由，以及 Service 侧那一整套编排方法全部撤掉（含为中止它而保留的
    #   「强行结束登录会话」辅助方法）。
    #   领取只保留「只领选中账号」与「定时领取」两条路径。
    # ★ 2026-10-05 修复：上面那次删除**误伤**了正常登录流程 —— 
    #   Service._finish_login() 被一起删了，而 _login_worker 的两处成功分支
    #   仍在调用它，导致「检测到登录成功」之后立刻抛
    #   AttributeError: 'Service' object has no attribute '_finish_login'，
    #   接着 finally 关掉浏览器 ⇒ cookie 没备份、用户白扫。已按上下文补回。


    # ==================================================================
    # 领取
    # ==================================================================
    def _ensure_job(self, kind="gift"):
        """★ v1.4.0 领作业许可：向卡密端要「怎么抢」的配方。

        配方（JS 选择器 / 接口路径 / 表单模板）由卡密端用 K_job 加密下发，
        客户端本地**没有**这些常量。所以：
          - 没卡 / 卡过期 / 连不上卡密端 → 拿不到配方 → 抢包根本无法执行；
          - 破解版 patch 掉本地门禁也没用 —— 它不知道该点哪、该调哪个接口。
        返回 (True, "") 或 (False, 原因)。
        """
        try:
            if self.gate is None:
                self._card_build_gate()
            return self.C._job_fetch(self.gate, kind)
        except Exception as ex:
            return False, "%s" % ex

    def run(self, ids=None, reason="手动"):
        if self.running:
            return {"ok": False, "msg": "任务正在运行"}
        if self.checking:
            return {"ok": False, "msg": "正在核对登录态，稍后再试"}
        targets = None
        if ids:
            targets = [a for a in (self.find_account(i) for i in ids) if a]
            if not targets:
                return {"ok": False, "msg": "选中的账号不存在"}
        elif not self.accounts:
            return {"ok": False, "msg": "请先添加账号"}
        self.running = True
        self.progress = {"on": True, "cur": 0, "max": 0, "text": ""}
        self.bus.event("running", True)
        self._spawn(self._run_worker, targets, reason, name="grab-run")
        return {"ok": True}

    def stop(self):
        if self.engine is not None:
            self.engine.stop_flag = True
        self.log("正在停止…")
        return {"ok": True}

    def _run_worker(self, targets=None, reason="手动"):
        e, err = self._start_engine()
        if not e:
            self.log("无法开始：%s" % err)
            self.running = False
            self.progress["on"] = False
            self.bus.event("running", False)
            return
        self.engine = e
        # ★ v1.4.0：先领作业许可。拿不到就**别装模作样跑一遍** ——
        #   本地已经没有「怎么抢」的配方了，开浏览器也是白开。
        ok_job, job_msg = self._ensure_job("gift")
        if not ok_job:
            self.log("!! 未取得作业许可：%s" % job_msg)
            self.log("   （抢包配方由卡密端托管：卡密有效、且能连上卡密服务端才拿得到）")
            try:
                e.stop_flag = True
            except Exception:
                pass
            self.running = False
            self.progress["on"] = False
            self.bus.event("running", False)
            return
        _ji = {}
        try:
            _ji = self.C._job_info()
        except Exception:
            pass
        self.log("作业许可已取得（票据 %s，剩余约 %ds）"
                 % (_ji.get("job") or "-", int(_ji.get("left") or 0)))
        total_ok = 0
        try:
            targets = list(targets) if targets else list(self.accounts)
            if len(targets) == 1:
                self.log(">> 单账号模式：本次只处理 %s，其他账号不启动浏览器"
                         % targets[0]["id"])
            else:
                self.log("共 %d 个账号，顺序执行：抢完一个再抢下一个，绝不并行"
                         % len(targets))
            if reason != "手动":
                self.log("触发来源：%s" % reason)
            for ai, acc in enumerate(targets):
                if e.stop_flag:
                    break
                if ai > 0:
                    self.log("上一个账号已处理完毕，切换到下一个")
                self.log("======== 账号 %s (%d/%d) ========"
                         % (acc["id"], ai + 1, len(targets)))
                self.set_status("处理账号 %s …" % acc["id"])
                try:
                    if not self._open_for_account(e, acc):
                        continue
                    ok, phone = e.is_logged_in()
                    if not ok:
                        if e.auto_wait_login and not e.headless:
                            self.set_status("账号 %s 未登录，等待扫码…" % acc["id"])
                            ok = e.wait_login(int(self.cfg.get("wait_login") or 240))
                            self.C.acc_set_status(acc, "ok" if ok else "off")
                            self.save_accounts()
                            self.bus.event("accounts")
                        if not ok:
                            self.log("[%s] 掉线了（登录态已失效），跳过。"
                                     "请先点『扫码登录』重新扫码" % acc["id"])
                            continue
                    self.C.acc_set_status(acc, "ok")
                    e.backup_cookies()
                    self.capture_uid(acc, e)
                    self.save_accounts()

                    raw = e.list_gifts(True)
                    gifts, claimed, cand = self._plan(acc, raw)
                    self.log("[%s] 可领取 %d 个" % (acc["id"], len(gifts)))
                    if not gifts:
                        self.log("[%s] 没有可领取的礼包，跳过" % acc["id"])
                        continue
                    self.log("[%s] 排除已领过 %d 个，剩余候选 %d 个"
                             % (acc["id"], len(claimed), len(cand)))
                    if not cand:
                        self.log("[%s] 已全部领过，跳过" % acc["id"])
                        continue
                    if e.claim_one:
                        todo = cand[:1]
                        pick = todo[0]
                        self.log("[%s] 规则：只领一个（不多领）→ 选中 %s %s"
                                 % (acc["id"], pick["id"],
                                    ("「%s」" % pick["name"]) if pick.get("name") else ""))
                    else:
                        todo = cand[: e.limit]
                        self.log("[%s] 批量模式：本次上限 %d 个" % (acc["id"], e.limit))
                    self.progress.update({"max": max(len(todo), 1), "cur": 0})
                    self.bus.event("progress", self.progress)
                    ok_n = 0
                    for i, g in enumerate(todo):
                        if e.stop_flag:
                            break
                        r = e.grab_one(g, account=acc.get("game", ""),
                                       wait=max(1.2, e.interval))
                        tries = 1
                        while ((not r.get("ok")) and tries <= e.retry
                               and not e.stop_flag and not r.get("need_login")
                               and not self.C._is_terminal(r.get("msg", ""))):
                            tries += 1
                            self.log("[%s] %s 第 %d 次重试"
                                     % (acc["id"], g["id"], tries))
                            time.sleep(1.5)
                            r = e.grab_one(g, account=acc.get("game", ""),
                                           wait=max(1.2, e.interval))
                        if (not r.get("ok")) and self.C._is_terminal(r.get("msg", "")):
                            self.log("[%s] %s 终态错误，不再重试: %s"
                                     % (acc["id"], g["id"], r.get("msg", "")))
                        rec = {"time": _now().strftime("%m-%d %H:%M:%S"),
                               "account": acc["id"], "gift": g["id"],
                               "amount": g.get("amount", ""),
                               "game_account": r.get("game_account", ""),
                               "result": "成功" if r.get("ok") else "失败",
                               "msg": ("%s  账号:%s  %s" % (
                                   g.get("name", ""), r.get("game_account", ""),
                                   r.get("msg", ""))).strip()}
                        with self.lock:
                            self.records.append(rec)
                        if r.get("ok"):
                            ok_n += 1
                        self.bus.event("record", rec)
                        self.progress.update({"cur": i + 1})
                        self.bus.event("progress", self.progress)
                        self.set_status("[%s] %d/%d  %s"
                                        % (acc["id"], i + 1, len(todo), rec["result"]))
                        if r.get("need_login"):
                            self.log("[%s] 掉线了（领取时站点要求重新登录），"
                                     "停止该账号" % acc["id"])
                            self.C.acc_set_status(acc, "off")
                            self.save_accounts()
                            self.bus.event("accounts")
                            break
                        time.sleep(random.uniform(e.interval * 0.6,
                                                  e.interval * 1.3))
                    total_ok += ok_n
                    self.log("[%s] 完成：成功 %d / 尝试 %d"
                             % (acc["id"], ok_n, len(todo)))
                except Exception as ex:
                    self.log("[%s] 异常: %s" % (acc["id"], ex))
                finally:
                    e.close()
                    if e.stop_flag:
                        break
                    time.sleep(1.0)
            self.save_records()
            self.bus.event("records")
            self.log("===== 全部结束，累计成功 %d 个 =====" % total_ok)
            self.set_status("完成，累计成功 %d 个" % total_ok)
        except Exception as ex:
            self.log("严重异常: %s" % ex)
        finally:
            try:
                e.close()
            except Exception:
                pass
            self.running = False
            self.progress["on"] = False
            self.bus.event("running", False)
            self.bus.event("progress", self.progress)

    # ==================================================================
    # 论坛：配置
    # ==================================================================
    def load_forum(self):
        cfg, err = self.C._safe_load_json(self.C.FORUM_CFG_FILE)
        if err:
            self.bus.log("forum", "⚠ " + str(err))
        cfg = cfg if isinstance(cfg, dict) else {}
        st = cfg.get("_settings", {}) if isinstance(cfg.get("_settings"), dict) else {}
        self.forum_settings = {
            "auto_sign": bool(st.get("auto_sign", False)),
            "auto_time": str(st.get("auto_time", "08:00") or "08:00"),
            "headless": bool(st.get("headless", False)),
        }
        self.auto_last = str(st.get("last_auto", "") or "")
        saved_list = st.get("forum_list") or []
        lst = []
        if isinstance(saved_list, list):
            for it in saved_list:
                try:
                    nm = str(it.get("name", "")).strip()
                    bu = str(it.get("url", "")).strip()
                except Exception:
                    continue
                if nm and bu:
                    lst.append([nm, bu])
        if not lst:
            lst = [[n, u] for n, u in self.C.FORUMS]
        self.forum_list = lst
        # ★ 2026-10-09 多账号迁移：老的 forum_cfg[base] = {cookie,ua,saved_at}
        #   是「一个论坛一个账号」。现在改成 {accounts:[{id,name,cookie,ua,saved_at}]}。
        changed = False
        for _b in list(cfg.keys()):
            if _b.startswith("_"):
                continue
            v = cfg.get(_b)
            if not isinstance(v, dict):
                continue
            if isinstance(v.get("accounts"), list):
                continue
            if v.get("cookie"):
                cfg[_b] = {"accounts": [{"id": "a1", "name": "账号1",
                                         "cookie": v.get("cookie", ""),
                                         "ua": v.get("ua", ""),
                                         "saved_at": v.get("saved_at", "")}]}
                changed = True
        self.forum_cfg = cfg
        if changed:
            try:
                _atomic_write_json(self.C.FORUM_CFG_FILE, cfg)
            except Exception:
                pass
        data, err2 = self.C._safe_load_json(self.C.FORUM_RECORDS_FILE)
        if err2:
            self.bus.log("forum", "⚠ " + str(err2))
        raw = data if isinstance(data, list) else []
        self.forum_records = self.C._prune_records_by_time(raw)
        if len(self.forum_records) != len(raw):
            self._save_forum_records_file()

    def save_forum_cfg(self):
        """原 App._forum_cfg_dict/_forum_save：保留文件里已有的 cookie（含已删论坛的）。"""
        cfg = self.forum_cfg if isinstance(self.forum_cfg, dict) else {}
        cfg["_settings"] = {
            "auto_sign": bool(self.forum_settings.get("auto_sign")),
            "auto_time": str(self.forum_settings.get("auto_time") or "08:00"),
            "headless": bool(self.forum_settings.get("headless")),
            "last_auto": self.auto_last,
            "forum_list": [{"name": n, "url": b} for n, b in self.forum_list],
        }
        self.forum_cfg = cfg
        _atomic_write_json(self.C.FORUM_CFG_FILE, cfg)
        return True

    # ==================================================================
    # ★ 2026-10-09 论坛多账号：一个论坛（base）下可以挂多个账号（cookie）
    # ==================================================================
    def _forum_accounts(self, base):
        """取某论坛的账号列表（老格式或不存在 → 空列表）。"""
        entry = self.forum_cfg.get(base)
        if not isinstance(entry, dict):
            return []
        accs = entry.get("accounts")
        return accs if isinstance(accs, list) else []

    def _forum_next_acc_id(self, base):
        mx = 0
        for a in self._forum_accounts(base):
            try:
                mx = max(mx, int(str(a.get("id") or "").lstrip("a") or "0"))
            except Exception:
                pass
        return "a%d" % (mx + 1)

    def _forum_profile_name(self, base, acc_id=""):
        """某论坛某账号的浏览器 profile 目录名。

        ★ 第一个账号沿用老的 `host`（与历史 profile 一致，老登录态不丢）；
          第二个起用 `host_a2` / `host_a3` …，各账号 Cookie 互不覆盖。
        """
        host = urllib.parse.urlparse(base).netloc or base
        key = host.replace(".", "_")
        aid = str(acc_id or "")
        if not aid or aid == "a1":
            return key
        return key + "_" + aid

    def forum_status_list(self):
        out = []
        for name, base in self.forum_list:
            aout = []
            for a in self._forum_accounts(base):
                aout.append({"id": a.get("id", ""), "name": a.get("name", ""),
                             "saved": bool(a.get("cookie")),
                             "saved_at": a.get("saved_at", ""),
                             "ua": bool(a.get("ua"))})
            out.append({"name": name, "base": base, "accounts": aout,
                        "n": len(aout),
                        "saved": any(x["saved"] for x in aout),
                        "saved_at": (aout[-1]["saved_at"] if aout else ""),
                        "ua": (all(x["ua"] for x in aout) if aout else False)})
        return out

    def forum_add(self, name, url):
        name = str(name or "").strip()
        url = str(url or "").strip()
        if not name:
            return {"ok": False, "msg": "请先填写论坛名称"}
        if not url:
            return {"ok": False, "msg": "请先填写论坛网址"}
        if not re.match(r"^https?://", url, re.I):
            url = "https://" + url
        if not re.match(r"^https?://[^\s/$.?#].[^\s]*$", url, re.I):
            return {"ok": False, "msg": "网址格式不对：%s" % url}
        if not url.endswith("/"):
            url += "/"
        for _n, b in self.forum_list:
            if b == url:
                return {"ok": False, "msg": "该论坛已在列表里：%s" % url}
        self.forum_list.append([name, url])
        self.save_forum_cfg()
        self.log("已添加论坛：%s（%s）" % (name, url), "forum")
        self.log("  下一步：点该行的『登录』抓取 Cookie，之后即可签到。", "forum")
        self.bus.event("forum")
        return {"ok": True}

    def _forum_purge_site(self, base):
        """★ 2026-09-26 用户要求：「删除某个网站的时候 Cookie 一起删除，不再保留，
        只删除对应的网站 Cookie」—— 只清这一个站的，别的论坛一律不动。

        一个论坛站在本机的痕迹有四处（全部按 host 定位，绝不误伤别人）：
          ① `forum_cfg[base]`      —— 抓到的 Cookie + UA（签到就靠它）
          ② `forum_login/<host>[_aN]` —— 该站**每个账号**的浏览器 profile 目录
          ③ `cookie_backup/<profile>.json` —— 引擎写的 Cookie 备份（两处）
          ④ 内存里已加载的该站 Cookie
        返回真正清掉了几项，方便日志说清楚。
        ★ 2026-10-09 多账号：一个站的 profile 会有多份（host / host_a2 / host_a3…），
          这里把它们**全部**清掉（只清这一个站的）。
        """
        base = str(base or "").strip()
        if not base:
            return 0
        host = urllib.parse.urlparse(base).netloc or base
        host_key = host.replace(".", "_")
        n = 0

        # ① 配置里的 Cookie/UA（该站全部账号）
        if self.forum_cfg.pop(base, None) is not None:
            n += 1
        _atomic_write_json(self.C.FORUM_CFG_FILE, self.forum_cfg)
        # 清完再回读一遍，确认真的落盘了（读的是加密写出来的那份）
        try:
            back, _err = self.C._safe_load_json(self.C.FORUM_CFG_FILE)
            if isinstance(back, dict):
                self.forum_cfg = back
        except Exception:
            pass

        # ② 该站所有账号的浏览器 profile 目录 + ③ 对应的 Cookie 备份
        names = {host_key}
        try:
            for nm in os.listdir(self.C.FORUM_LOGIN_DIR):
                if nm == host_key or nm.startswith(host_key + "_a"):
                    names.add(nm)
        except Exception:
            pass
        for pn in sorted(names):
            try:
                prof = os.path.join(self.C.FORUM_LOGIN_DIR, pn)
                if os.path.isdir(prof):
                    shutil.rmtree(prof, ignore_errors=True)
                    n += 1
                    self.log("  已删除该站的浏览器 profile：%s" % pn, "forum")
            except Exception as ex:
                self.log("  删除 profile 失败（可忽略）：%s" % ex, "forum")
            try:
                for p in (self.C.cookie_backup_paths(pn) or []):
                    if p and os.path.isfile(p):
                        os.remove(p)
                        n += 1
                        self.log("  已删除 Cookie 备份：%s" % os.path.basename(p),
                                 "forum")
            except Exception as ex:
                self.log("  删除 Cookie 备份失败（可忽略）：%s" % ex, "forum")
        return n

    def forum_del(self, base):
        """删除论坛条目 —— ★ Cookie 一并删除（用户要求），且**只删这一个站的**。"""
        base = str(base or "").strip()
        hit = [b for _n, b in self.forum_list if b == base]
        self.forum_list = [[n, b] for n, b in self.forum_list if b != base]
        self.save_forum_cfg()
        n = self._forum_purge_site(base)          # 只清这一个站
        self.log("已移除论坛：%s（该站 Cookie / 浏览器数据已一并清除，"
                 "共 %d 项）" % (base, n), "forum")
        self.bus.event("forum")
        return {"ok": True, "purged": n, "found": bool(hit)}

    def forum_clear_cookie(self, base, account_id=None):
        """清除登录状态：给了 account_id 只清该账号，否则清该论坛全部账号。"""
        base = str(base or "").strip()
        entry = self.forum_cfg.get(base)
        if isinstance(entry, dict) and isinstance(entry.get("accounts"), list):
            if account_id:
                entry["accounts"] = [a for a in entry["accounts"]
                                     if str(a.get("id")) != str(account_id)]
            else:
                entry["accounts"] = []
            if entry["accounts"]:
                self.forum_cfg[base] = entry
            else:
                self.forum_cfg.pop(base, None)
        else:
            self.forum_cfg.pop(base, None)
        _atomic_write_json(self.C.FORUM_CFG_FILE, self.forum_cfg)
        try:
            back, _err = self.C._safe_load_json(self.C.FORUM_CFG_FILE)
            if isinstance(back, dict):
                self.forum_cfg = back
        except Exception:
            pass
        self.log("%s：已清除登录状态%s"
                 % (base, ("（账号 %s）" % account_id) if account_id else ""), "forum")
        self.bus.event("forum")
        return {"ok": True}

    def forum_account_del(self, base, account_id):
        """删除某论坛下的某个账号（含它的专属浏览器 profile）。"""
        base = str(base or "").strip()
        acc_name = ""
        for a in self._forum_accounts(base):
            if str(a.get("id")) == str(account_id):
                acc_name = a.get("name") or ""
        pn = self._forum_profile_name(base, account_id)
        try:
            prof = os.path.join(self.C.FORUM_LOGIN_DIR, pn)
            if os.path.isdir(prof):
                shutil.rmtree(prof, ignore_errors=True)
        except Exception:
            pass
        try:
            for p in (self.C.cookie_backup_paths(pn) or []):
                if p and os.path.isfile(p):
                    os.remove(p)
        except Exception:
            pass
        r = self.forum_clear_cookie(base, account_id)
        self.log("已删除账号：%s（%s）" % (acc_name or account_id, base), "forum")
        return r

    def forum_account_rename(self, base, account_id, name):
        """★ 2026-10-10 重命名某论坛下的某个账号（只改显示名，不动 Cookie / profile）。"""
        base = str(base or "").strip()
        account_id = str(account_id or "").strip()
        name = str(name or "").strip()
        if not base or not account_id:
            return {"ok": False, "msg": "参数不完整（缺 base / account_id）"}
        if not name:
            return {"ok": False, "msg": "账号名不能为空"}
        if len(name) > 40:
            return {"ok": False, "msg": "账号名太长（最多 40 字）"}
        target = None
        for a in self._forum_accounts(base):
            if str(a.get("id")) == account_id:
                target = a
                break
        if target is None:
            return {"ok": False, "msg": "账号不存在"}
        old = target.get("name") or ("账号%s" % (account_id.lstrip("a") or "1"))
        target["name"] = name
        _atomic_write_json(self.C.FORUM_CFG_FILE, self.forum_cfg)
        self.log("已重命名账号：%s → %s（%s）" % (old, name, base), "forum")
        self.bus.event("forum")
        return {"ok": True, "name": name}

    def forum_clear_all(self):
        for k in list(self.forum_cfg.keys()):
            if not k.startswith("_"):
                self.forum_cfg.pop(k, None)
        self.save_forum_cfg()
        self.log("已清空全部论坛登录状态", "forum")
        self.bus.event("forum")
        return {"ok": True}

    def debug_log(self, msg):
        self.log(msg, "forum")

    # ==================================================================
    # 论坛：登录（抓 Cookie）
    # ==================================================================
    def forum_login(self, base, name="", account_name="", account_id=None):
        """登录抓 Cookie：不带 account_id → 新增一个账号；带 → 重登并覆盖该账号。"""
        if self.forum_busy:
            self.log("已有任务在执行，请先等待完成或点『停止』。", "forum")
            return {"ok": False, "msg": "已有任务在执行"}
        self.forum_stop = False
        self.forum_busy = True
        self.bus.event("forum_busy", True)
        self._spawn(self._forum_login_flow, base, name or base,
                    account_name, account_id, name="forum-login")
        return {"ok": True}

    def _forum_login_flow(self, base, name, account_name="", account_id=None):
        try:
            self.log("  提示：手动登录必须显示浏览器窗口；签到本身在后台完成。",
                     "forum")
            self._forum_do_login(base, name, account_id=account_id,
                                 account_name=account_name)
        finally:
            self.forum_busy = False
            self.bus.event("forum_busy", False)
            self.bus.event("forum")

    # ==================================================================
    # ★ 需求⑱：论坛登录「外网填表」（账号 / 密码 / 验证码）
    #   与礼包扫码同一思路：服务器那台机器开浏览器打开 Discuz 登录页，
    #   把表单结构 + 验证码图同步到网页；人在别的电脑上填，填完代提交。
    # ==================================================================
    def _fform_blank(self):
        return {"on": False, "base": "", "name": "", "stage": "",
                "mode": "", "tab_text": "", "fields": {},
                "cap": "", "cap_ts": 0.0,
                "cap_hash": "", "cap_sig": "", "cap_seq": 0,
                "msg": "", "ts": 0.0, "seq": 0, "submits": 0, "sends": 0,
                # ★ 2026-09-26：验证码取图诊断（几张图 / 几个候选 / URL / 失败原因）
                #   —— 用户报「图还没取到…」时，网页面板直接把这段摊开显示。
                "cap_probe": {},
                "shot_ts": 0.0, "filled": {}, "probe": {}}

    def _forum_pick_tab(self, eng, port, base):
        """把 CDP 切到**真正加载了目标站点**的那个标签页。

        ★★ 为什么需要这个（2026-09-26 用户报「正在等登录页加载出来… 加载不出来」）：
          原版 `Engine.attach()` 是 `pages[0]` —— 只取"第一个 page 标签页"，
          而 Chrome 启动时常先开一个 `about:blank` / `newtab`，
          真正的登录页是**第二个** tab。于是所有 `cdp.ev` 都打在空白页上，
          表单永远读不到，等待逻辑就无限转圈。

        策略（按优先级，命中即用）：
          ① URL 里含目标 host（最准）
          ② URL 含 "logging" / "login"（Discuz 登录页特征）
          ③ 不是 about:blank / newtab / devtools 的第一个 page
          ④ 全都不符合 → 保持原样（不瞎切）
        返回选中的 URL（没切就返回 ""）。
        """
        host = (urllib.parse.urlparse(base).netloc or "").split(":")[0]
        if not host:
            return ""
        try:
            # 回环要绕开系统代理（本机 HTTP_PROXY 会把 127.0.0.1 也代理掉）。
            # 原程序里这个 opener 叫 `_NO_PROXY`，通过 C 命名空间拿。
            opener = getattr(self.C, "_NO_PROXY", None) or \
                urllib.request.build_opener(urllib.request.ProxyHandler({}))
            with opener.open(
                    "http://127.0.0.1:%d/json/list" % port, timeout=4) as r:
                tabs = json.loads(r.read().decode("utf-8", "replace"))
        except Exception:
            return ""
        pages = [t for t in tabs
                 if isinstance(t, dict) and t.get("type") == "page"
                 and t.get("webSocketDebuggerUrl")]
        if not pages:
            return ""

        def url_of(t):
            return str(t.get("url") or "")

        def is_blank(u):
            ul = u.lower()
            return (not ul) or ul.startswith("about:") or "newtab" in ul \
                or ul.startswith("chrome://") or ul.startswith("devtools://")

        chosen = None
        for t in pages:                       # ① host 命中
            if host in url_of(t):
                chosen = t
                break
        if chosen is None:                    # ② 登录页特征
            for t in pages:
                u = url_of(t).lower()
                if "logging" in u or "login" in u:
                    chosen = t
                    break
        if chosen is None:                    # ③ 第一个非空白页
            for t in pages:
                if not is_blank(url_of(t)):
                    chosen = t
                    break
        if chosen is None or chosen is pages[0]:
            # 没找到更合适的：保持原样，别把已经能用的连接切坏
            return ""

        cur = ""
        try:
            cur = str(getattr(eng.cdp, "url", "") or "")
        except Exception:
            cur = ""
        # 已经在目标页上了就别动
        if host and host in cur:
            return ""

        ws = chosen.get("webSocketDebuggerUrl")
        if not ws:
            return ""
        # ★★ 2026-09-26 修「越改越垃圾」的真凶之一：
        #   原来这里是「先 close 掉旧连接，再换新的」—— 一旦新连接建不起来
        #   （或建起来了但不通），旧的已经关了，就再也回不去了，之后所有
        #   `eng.cdp.ev` 全打在一条死连接上 → 表单永远读不到 → 网页上空面板。
        #   现在：先建新的并**验证它真的能通**，通了才替换；不通就把旧的装回去。
        old = getattr(eng, "cdp", None)
        new = None
        try:
            new = self.C.CDP(ws)
            new.send("Page.enable")
            new.send("Runtime.enable")
            # 拿一次 URL 证明这条连接是活的（CDP.ev 出错会返回 "__ERR__..." 字符串）
            probe = str(new.ev("(function(){return location.href})()",
                               timeout=6) or "")
            if probe.startswith("__ERR__"):
                raise RuntimeError(probe[:80])
            eng.cdp = new
        except Exception as ex:
            self.log("[论坛] 切换标签页失败（沿用原来的页面）：%s" % ex, "forum")
            try:
                if new is not None:
                    new.close()
            except Exception:
                pass
            if old is not None:
                eng.cdp = old          # ★ 装回去，别让后面全打在死连接上
            return ""
        if old is not None:
            try:
                old.close()
            except Exception:
                pass
        u = url_of(chosen)
        self.log("  已定位到登录页标签：%s" % self.C._short(u, 70), "forum")
        return u

    def _fform_state(self):
        """给网页取当前论坛登录表单状态（含验证码图）。"""
        with self._fform_lock:
            f = dict(self._fform)
        f["fields"] = dict(f.get("fields") or {})
        f["filled"] = dict(f.get("filled") or {})
        cap = f.pop("cap", "")
        f["hasCap"] = bool(cap)
        f["cap_png"] = ("data:image/png;base64," + cap) if cap else ""
        f.pop("cap_hash", None)
        f.pop("cap_sig", None)
        f.pop("shot_ts", None)
        return {"ok": True, "form": f}

    def _fform_set(self, **kw):
        with self._fform_lock:
            self._fform.update(kw)
            self._fform["ts"] = time.time()
            self._fform["seq"] = int(self._fform.get("seq") or 0) + 1
            snap = dict(self._fform)
        # 验证码图不进 SSE 帧（几十 KB 会把每条事件撑爆），只告诉前端「去取」
        snap.pop("cap", None)
        snap.pop("cap_hash", None)
        snap.pop("cap_sig", None)
        snap.pop("shot_ts", None)
        self.bus.event("forum_form", snap)
        return snap

    def _fform_read(self, eng, timeout=12):
        """读服务器浏览器里的 Discuz 登录表单（有没有验证码 / 是不是密保页）。

        `timeout` 可传短一点：等页面加载那轮每次卡 12 秒的话，
        30 秒的等待窗口只够试两三次，页面稍慢就被判成「读不到」。
        """
        try:
            r = eng.cdp.ev(JS_FORUM_FORM, timeout=timeout)
        except Exception:
            return None
        return r if isinstance(r, dict) else None

    def _fform_probe(self, eng):
        """抓一下服务器浏览器「当前到底是哪个页面」—— 卡住时一眼能判因。

        ★ 2026-09-26：人在外网看不见服务器那台机器的屏幕，读不到表单时
          只能对着一句「正在等…」干着急。把 URL / 标题 / 输入框数回传出来
          显示到网页上，立刻能区分三种情况：
            还在 about:blank  → 压根没导航过去（多半是站点没响应 / 被墙）
            有 URL 但 0 个框   → 页面报错 / 还在跳转 / 是个验证页
            有 URL 也有框      → 只是我们的选择器不认这个站的结构
        """
        out = {"url": "", "title": "", "inputs": -1, "err": ""}
        try:
            out["url"] = str(eng.cdp.ev(
                "(function(){return location.href})()", timeout=5) or "")
        except Exception as ex:
            out["err"] = str(ex)[:80]
        try:
            out["title"] = str(eng.cdp.ev(
                "(function(){return document.title||''})()", timeout=5) or "")
        except Exception:
            pass
        try:
            n = eng.cdp.ev(
                "(function(){return document.querySelectorAll('input')"
                ".length})()", timeout=5)
            out["inputs"] = int(n) if isinstance(n, (int, float)) else -1
        except Exception:
            pass
        for k in ("url", "title"):
            if str(out[k]).startswith("__ERR__"):
                out["err"] = str(out[k])[:80] or out["err"]
                out[k] = ""
        return out

    def _fform_cap_png(self, eng, force=False):
        """取验证码图。

        ★★ 2026-09-26 改返回 `(base64, diag)` —— 用户报「图还没取到…」时，
          光知道「没取到」没用，得知道**为什么**：页面上有几张图 / 候选命中几个 /
          命中那张的 URL / 失败原因。diag 会推给网页面板直接显示出来判因。

        ★★ 2026-10-09 用户报「验证码是出来了但是网页端一直自己换」：
          `_fform_sync` 每 3 秒跑一次，原来每次都 `fetch` 一次验证码图；而多数
          站点（Discuz 等）的验证码接口**每请求一次就生成一张新码**并写进会话 ——
          于是每 3 秒换一张，网页上输入框被反复清空，人根本没法填。
          现在：先按「指纹」（图 URL + 自然尺寸）比对，指纹没变就**直接复用上次那张
          图、一个取图请求都不发**；只有指纹真变了（或用户点了「换一张」force=True、
          或还没有缓存）才真去取一次。这样站点没换码之前网页上的验证码**纹丝不动**。

        ★★★ 2026-10-09 二次修正（用户报「还是和真实的验证码不一样」）：取图**一律
          不发任何网络请求** —— 直接把浏览器里**已经加载好的那张 <img>** 画进 canvas
          再导出像素（见 JS_FORUM_CAP_DATA 的 draw/toData）。原因：验证码接口「每被
          请求一次就换一张码并存进会话」，fetch 会让「网页显示的码」与「服务器浏览器
          显示的码」变成两张**不同**的图；画 canvas 则三者（网页 / 服务器浏览器 / 会话）
          始终是同一张。指纹没变时连 canvas 都不必重画，直接复用上次那张。
        """
        with self._fform_lock:
            _prev_sig = "" if force else str(self._fform.get("cap_sig") or "")
        diag = {"n": 0, "imgs": 0, "url": "", "err": "", "how": "", "sig": ""}

        def _run(prev):
            try:
                _js = JS_FORUM_CAP_DATA.replace(
                    "__ZSF_CAP_SIG__", json.dumps(prev))
                rr = eng.cdp.ev(_js, timeout=10)
            except Exception as ex:
                diag["err"] = "取图脚本执行失败：%s" % str(ex)[:60]
                return None
            if isinstance(rr, dict):
                for k in ("n", "imgs"):
                    try:
                        diag[k] = int(rr.get(k) or 0)
                    except Exception:
                        pass
                diag["url"] = str(rr.get("url") or "")[:120]
                diag["err"] = str(rr.get("err") or "")[:90]
                diag["sig"] = str(rr.get("sig") or "")[:500]
                if diag["sig"]:
                    with self._fform_lock:
                        self._fform["cap_sig"] = diag["sig"]
            return rr

        r = _run(_prev_sig)
        # ★ 指纹没变 + 有缓存 → 复用上次那张（**绝不重复请求验证码接口**）
        if isinstance(r, dict) and r.get("same"):
            with self._fform_lock:
                _cached = str(self._fform.get("cap") or "")
            if _cached:
                diag["how"] = "cache"
                diag["err"] = ""
                return _cached, diag
            # 没有缓存（状态被清过）→ 强制真取一次
            diag = {"n": 0, "imgs": 0, "url": "", "err": "",
                    "how": "", "sig": ""}
            r = _run("")
        if isinstance(r, dict):
            u = str(r.get("png") or "")
            if u.startswith("data:image") and "," in u:
                diag["how"] = "dom"
                diag["err"] = ""
                return u.split(",", 1)[1], diag
        if not diag["err"]:
            diag["err"] = "没取到验证码图"
        # ---- 兜底：按那块位置截图（限流 12 秒，免得每 3 秒截一次）----
        now = time.time()
        if (now - self._fform.get("shot_ts", 0.0)) < 12:
            diag["err"] += "；截图兜底刚试过，稍等"
            return "", diag
        self._fform["shot_ts"] = now
        try:
            box = eng.cdp.ev(JS_FORUM_CAP_BOX, timeout=10)
        except Exception:
            box = None
        if not isinstance(box, dict):
            diag["err"] += "；截图也定位不到那块"
            return "", diag
        try:
            x = max(0.0, float(box.get("x") or 0))
            y = max(0.0, float(box.get("y") or 0))
            w = min(max(1.0, float(box.get("w") or 0)), 600.0)
            h = min(max(1.0, float(box.get("h") or 0)), 300.0)
        except Exception:
            return "", diag
        try:
            rr = eng.cdp.send("Page.captureScreenshot", {
                "format": "png",
                "clip": {"x": x, "y": y, "width": w, "height": h, "scale": 1},
                "captureBeyondViewport": False}, timeout=15)
        except Exception:
            diag["err"] += "；截图失败"
            return "", diag
        shot = str((((rr or {}).get("result") or {}).get("data")) or "")
        if shot:
            diag["how"] = "shot"
            diag["err"] = ""
        return shot, diag

    def _fform_sync(self, eng, base, name, stage="", force=False):
        """把表单状态（+验证码）同步给网页。返回读到的表单 dict。

        ★ 2026-09-26：加 `force` —— 页面刚加载完那一下必须强推一次，
          否则「上一版 fields 正好等于这一版」就会被去重逻辑吞掉，
          网页永远停在空面板上（用户报的「不好使」）。
        """
        info = self._fform_read(eng)
        if info is None:
            return None
        # ★★ 2026-09-26 用户报「图还没取到…」：以前只有 `JS_FORUM_FORM` 认出
        #   「验证码输入框 / 验证码图」才会去取图 —— 认不出就永远空着。
        #   现在只要这个页面上**确实有个登录表单**（读到了账号/密码/手机号任一），
        #   就顺手探一次验证码：真有图（哪怕名字我们不认识）也能取回来。
        #   探不到图时把诊断信息（几张图 / 几个候选 / 失败原因）一起挂到 state 上，
        #   网页直接显示 → 下次一眼判因，不用再让用户反复截图。
        _want_cap = bool(
            info.get("hasCaptcha") or info.get("hasImg") or info.get("hasUser")
            or info.get("hasPass"))
        cap, cdiag = ("", {})
        if _want_cap:
            cap, cdiag = self._fform_cap_png(eng)
        # 探到了图 → 就算「输入框那边没认出来」，也当这个站要验证码
        if not info.get("hasCaptcha") and cdiag.get("n"):
            info = dict(info)
            info["hasCaptcha"] = True
        with self._fform_lock:
            self._fform["cap_probe"] = dict(cdiag)
        digest = (hashlib.sha1(cap.encode("ascii", "ignore")).hexdigest()
                  if cap else "")
        with self._fform_lock:
            old_hash = self._fform.get("cap_hash") or ""
        fields = {"user": bool(info.get("hasUser")),
                  "pass": bool(info.get("hasPass")),
                  "cap": bool(info.get("hasCaptcha")),
                  "secq": bool(info.get("hasSecQ") or info.get("hasQ"))}
        prev_fields = self._fform.get("fields") or {}
        # ★★ 2026-09-26 用户说的「同步账号密码过来」就是这一条：
        #   服务器浏览器里**已经填进去的值**（账号 / 手机号）要同步给网页，
        #   外网这边打开就该看见，不用重新敲一遍。
        #   （密码出于安全不同步 —— 浏览器里自动填了密码也不会往外发。）
        _fv = {"user": str(info.get("userVal") or "")[:80]}
        filled = dict((k, v) for k, v in _fv.items() if v)
        prev_filled = self._fform.get("filled") or {}
        kw = {"on": True, "base": base, "name": name,
              "mode": str(info.get("mode") or ""),
              # ★ 页签上写的那几个字（如「用户名登录」）也带给前端，
              #   界面上原样显示，用户一眼就知道服务器那边现在是哪一种登录。
              "tab_text": str(info.get("tabText") or ""),
              "stage": stage or ("captcha" if info.get("hasCaptcha") else "login"),
              "fields": fields, "filled": filled, "msg": ""}
        if cap and digest != old_hash:
            kw["cap"] = cap
            kw["cap_hash"] = digest
            kw["cap_ts"] = time.time()
            kw["cap_seq"] = int(self._fform.get("cap_seq") or 0) + 1
        # 表单结构没变、码也没变 → 不打扰前端（force=True 时例外）
        if (not force and fields == prev_fields and filled == prev_filled
                and not kw.get("cap")
                and stage == self._fform.get("stage")):
            return info
        self._fform_set(**kw)
        return info

    def forum_form_refresh_cap(self):
        """★ 2026-09-26 用户要求：「支持外网点击验证码刷新」。

        验证码看不清时，点一下图就该换一张。Discuz 换验证码的标准做法就是
        **点那张图**（它绑了 onclick 去 reload），所以这里代点一次，
        然后立刻重新取图推给网页。
        """
        with self._fform_lock:
            eng = self._forum_eng
            on = bool(self._fform.get("on"))
            base = str(self._fform.get("base") or "")
            name = str(self._fform.get("name") or "")
            self._fform["refreshes"] = int(self._fform.get("refreshes") or 0) + 1
            nr = self._fform["refreshes"]
        if not on:
            return {"ok": False, "msg": "当前没有正在进行的论坛登录"}
        if eng is None:
            return {"ok": False, "msg": "登录会话已结束"}
        if nr > 30:
            return {"ok": False, "msg": "刷新太频繁了，请稍后再试"}
        clicked = False
        try:
            r = eng.cdp.ev(JS_FORUM_CAP_CLICK, timeout=12)
            clicked = bool(isinstance(r, dict) and r.get("ok"))
        except Exception:
            clicked = False
        # 点完给它一点时间重新请求图片，然后立刻同步一版（强制换图）
        time.sleep(0.9)
        try:
            # ★★ 2026-09-26 用户报「图还没取到…」：这里以前还要求
            #   `info.get("hasCaptcha")` 才去取图 —— 识别不出验证码的站点上，
            #   点「换一张」等于什么都不做。现在跟 `_fform_sync` 一个口径：
            #   有登录表单就试着取，取不到也把诊断带回去（面板上能看见原因）。
            info = self._fform_read(eng)
            _want = bool(isinstance(info, dict) and (
                info.get("hasCaptcha") or info.get("hasImg")
                or info.get("hasUser") or info.get("hasPass")))
            if _want:
                # ★ 用户点「换一张」就是要真换 → force=True 跳过指纹复用
                cap, cdiag = self._fform_cap_png(eng, force=True)
                with self._fform_lock:
                    self._fform["cap_probe"] = dict(cdiag)
                if cap:
                    digest = hashlib.sha1(
                        cap.encode("ascii", "ignore")).hexdigest()
                    with self._fform_lock:
                        self._fform["cap"] = cap
                        self._fform["cap_hash"] = digest
                        self._fform["cap_ts"] = time.time()
                        self._fform["cap_seq"] = int(
                            self._fform.get("cap_seq") or 0) + 1
                    self._fform_set(msg="验证码已刷新")
                    return {"ok": True, "clicked": clicked}
                if cdiag.get("err"):
                    self._fform_set(msg="没换到图：%s" % cdiag["err"])
                    return {"ok": True, "clicked": clicked, "msg": cdiag["err"]}
        except Exception as ex:
            return {"ok": False, "msg": "刷新失败：%s" % ex}
        self._fform_set(msg="已尝试刷新验证码")
        return {"ok": True, "clicked": clicked}

    def forum_form_state(self):
        return self._fform_state()

    def forum_form_close(self, force=False):
        """前端关掉面板 / 登录流程结束时调用。

        ★ 2026-09-26：失败（stage="failed"）时**默认不关面板**。
          登录流程的 finally 一定会调到这里，以前它一把把 stage/msg 抹成
          "closed"/"" —— 结果「浏览器起不来」这类失败，网页上刚显示的原因
          下一秒就被清掉，人在外网看着就是「点了没反应，啥也没说」。
          现在：失败状态保留给用户看，用户自己点关闭（force=True）才真关。
        """
        try:
            failed = str(self._fform.get("stage") or "") == "failed"
        except Exception:
            failed = False
        if failed and not force:
            return {"ok": True, "kept": True}
        self._fform_set(on=False, stage="closed", msg="", fields={},
                        cap="", cap_hash="", cap_sig="", filled={},
                        cap_probe={})
        return {"ok": True}

    def forum_form_submit(self, user="", pwd="", cap="", answer="", mode=""):
        """★ 需求⑱：把网页填的账号/密码/验证码写回服务器浏览器并提交。

        ★★ 2026-10-09 用户要求「删除手机号登录」：不再有 phone / sms 两个字段，
          只支持「账号 + 密码 + 图形验证码」。
        ★ 2026-09-26：页签式登录 —— 提交前会先把对应页签点出来，
          否则那组输入框可能是 display:none。

        提交后 Discuz 可能：
          · 直接登录成功      → 轮询循环里会检测到 action=logout，正常落 Cookie
          · 要求补验证码      → 表单会多出验证码框，_fform_sync 会再推一版给网页
          · 报错              → 页面里出现错误提示，原样回给用户看
        """
        with self._fform_lock:
            eng = self._forum_eng
            on = bool(self._fform.get("on"))
        if not on:
            return {"ok": False, "msg": "当前没有正在进行的论坛登录"}
        if eng is None:
            # ★ 2026-09-26：输入框从 stage="starting" 起就放出来了（见 app.js 的
            #   showAll 兜底），用户可能填得比服务器那边的浏览器还快。这时别只回
            #   一句「已结束」（会让人以为白填了），说清「还没就绪，等几秒再点」。
            return {"ok": False,
                    "msg": "服务器那边还没就绪（浏览器正在打开），"
                           "请等几秒再点「提交登录」；若一直这样，重新点一次「登录」"}
        # 账号登录至少要填账号
        if not str(user or "").strip():
            return {"ok": False, "msg": "请填写账号"}
        with self._fform_lock:
            self._fform["submits"] = int(self._fform.get("submits") or 0) + 1
            n = self._fform["submits"]
        if n > 5:
            return {"ok": False, "msg": "提交次数过多，请关掉重来（避免被站点风控）"}
        payload = json.dumps({"user": str(user or ""), "pass": str(pwd or ""),
                              "cap": str(cap or ""), "ans": str(answer or ""),
                              "mode": str(mode or ""),
                              "submit": True}, ensure_ascii=False)
        js = JS_FORUM_FILL.replace("__ZSF_FORUM_FILL__", payload)
        try:
            r = eng.cdp.ev(js, timeout=15)
        except Exception as ex:
            return {"ok": False, "msg": "填写失败：%s" % ex}
        filled = (r or {}).get("filled") if isinstance(r, dict) else None
        submitted = bool(isinstance(r, dict) and r.get("submitted"))
        err = (r or {}).get("err") if isinstance(r, dict) else None
        self._fform_set(
            filled={"user": ("填了" if user else ""),
                    "pass": ("填了" if pwd else ""),
                    "cap": ("填了" if cap else "")},
            msg=("已提交" if submitted else ("填写了但没提交：%s" % err
                                            if err else "已填写")))
        self.log("[论坛] 网页侧提交登录（%s）" % ("已提交" if submitted else "仅填写"),
                 "forum")
        return {"ok": True, "submitted": submitted, "filled": filled}

    def _forum_do_login(self, base, name, account_id=None, account_name="",
                        auto=False):
        """原 App._forum_do_login：开浏览器等登录 → 抓 Cookie+UA → 校验 → 落盘。

        ★ 2026-10-09 多账号：不带 account_id → 在该论坛下**新增一个账号**；
          带 account_id → **重登并覆盖**该账号（403 自动恢复就走这条）。
          每个账号用独立的浏览器 profile（host / host_a2 / host_a3…），
          所以同一论坛不同账号的 Cookie 不会互相覆盖。
        """
        eng = None
        # ★★ 2026-09-26 用户报「点了登录，什么都没同步过来」的第二条真因：
        #   以前要等浏览器启动 + CDP 连上（几十秒，浏览器起不来还会直接 return）
        #   才把面板置成 on=True —— 这期间网页上**什么都没有**，
        #   人在外网看着就是「点了没反应」。现在收到指令就先把面板立起来，
        #   每个阶段用 stage 说清楚在干什么（starting → loading → login/captcha）。
        self._fform_set(on=True, base=base, name=name, stage="starting",
                        fields={}, filled={}, cap="", cap_hash="",
                        msg="正在打开服务器那台机器的浏览器…")
        try:
            if auto:
                self.log("  ↻ 403 已自动重试仍被拦截 → 清 Cookie 重新登录…", "forum")
            else:
                self.log("―――――― %s：打开浏览器登录 ――――" % name, "forum")
            path = ""
            try:
                path = self.C.embedded_browser(log=self.debug_log)
            except Exception:
                path = ""
            if not path:
                # 网页版增强：没有内置浏览器包时，用本机检测到的 Chromium
                for _n, p, k in self.browser_list():
                    if k == "chromium" and not browser_policy_blocked(p):
                        path = p
                        break
            if not path:
                # 一个能自动化的 chromium 都没有 → 试着自己释放一份便携浏览器
                path = self.ensure_embedded_browser()
            if not path:
                # 实在没有 → 退而求其次（宁可试一下，也别直接说找不到）
                for _n, p, k in self.browser_list():
                    if k == "chromium":
                        path = p
                        break
            if not path:
                self.log("  ✗ 未找到可用浏览器（内置包缺失且本机无 Chromium），"
                         "无法打开登录窗口", "forum")
                self._fform_set(stage="failed",
                                msg="没找到可用浏览器：内置浏览器包缺失，"
                                    "且本机也没检测到 Chromium。")
                return False, "", ""
            # ★ 2026-09-26：被组策略锁死 user-data-dir 的 Edge **不可能**起来
            #   独立实例，调试端口永远开不了 —— 与其 launch 完干等 60 秒再报
            #   「CDP 未就绪」（用户完全看不懂），不如现在就把原因说清楚。
            why = browser_policy_blocked(path)
            if why:
                self.log("  ✗ 该浏览器无法用于自动化登录：%s" % why, "forum")
                self._fform_set(
                    stage="failed",
                    msg=why + "。请在设置里改用 Chrome / 便携版浏览器，"
                              "或让程序自动释放内置浏览器后再试。")
                return False, "", ""
            host = urllib.parse.urlparse(base).netloc
            parts = host.split(".")
            root_domain = ".".join(parts[-2:]) if len(parts) >= 2 else host
            # ★ 多账号：本次要写进哪个账号槽（新增时先算好 id，profile 才能对上）
            acc_id = str(account_id) if account_id else self._forum_next_acc_id(base)
            prof_name = self._forum_profile_name(base, acc_id)
            profile = os.path.join(self.C.FORUM_LOGIN_DIR, prof_name)
            os.makedirs(self.C.FORUM_LOGIN_DIR, exist_ok=True)
            if len(self._forum_accounts(base)) > 0 or account_id:
                self.log("  （该论坛第 %s 个账号，使用独立浏览器 profile：%s）"
                         % (acc_id.lstrip("a") or "?", prof_name), "forum")
            eng = self.C.Engine(log=self.debug_log)
            port = self.C.free_port()
            try:
                eng.kill_profile_chrome(profile)
            except Exception:
                pass
            login_url = base + "member.php?mod=logging&action=login"
            eng.launch(path, profile, port, login_url, headless=False)
            if not eng.wait_cdp(port, timeout=60):
                self.log("  ✗ 浏览器启动失败（CDP 未就绪）", "forum")
                self._fform_set(stage="failed",
                                msg="浏览器没起来（60 秒内 CDP 未就绪）"
                                    "—— 请确认服务器那台机器能开浏览器窗口。")
                return False, "", ""
            if not eng.attach(port):
                self.log("  ✗ 无法连接浏览器页面", "forum")
                self._fform_set(stage="failed", msg="连不上浏览器页面，请重试一次。")
                return False, "", ""
            # ★★ 2026-09-26 用户报「正在等登录页加载出来… 加载不出来」——
            #   根因：原版 `Engine.attach()` 取的是 `pages[0]`，即**第一个 page
            #   标签页，不保证是登录页那个**。Chrome 起来时常先有一个
            #   about:blank / newtab 的 page，登录页落在第二个 tab 上 ——
            #   于是之后所有 `cdp.ev` 都打在空白页上，表单永远读不到，
            #   我上一轮加的 30 秒等待就一直转圈（看着就是"加载不出来"）。
            #   原源码只读（铁律），所以在这一层纠正：自己按
            #   `http://127.0.0.1:<port>/json/list` 挑 **URL 命中目标站点**的
            #   那个 page；挑不到才退回原来的 pages[0]。
            try:
                self._forum_pick_tab(eng, port, base)
            except Exception as ex:
                self.log("[论坛] 选标签页失败（继续用默认页）：%s" % ex, "forum")
            if auto:
                self.log("  浏览器已打开：若站点还记着该浏览器会自动完成登录；"
                         "没登录则请在窗口里手动登录一次（最长等 5 分钟）…", "forum")
            else:
                self.log("  浏览器已打开，请在该窗口内完成登录"
                         "（程序自动检测，最长 5 分钟）…", "forum")
            end = time.time() + 300
            detected = False
            # ★ 需求⑱：把 Engine 挂到 self 上，网页才能把填的内容写回这个页面
            self._forum_eng = eng
            # ★ 需求⑱：先把「打开着的登录表单」同步给网页 —— 人在别的电脑上
            #   也能填账号/密码/验证码，不用去看服务器那块屏。
            self._fform_set(on=True, base=base, name=name, stage="loading",
                            fields={}, filled={}, msg="正在等登录页加载出来…")
            # ★★ 2026-09-26 用户报「同步到外网网页不好使了」的根因就是这里：
            #   `attach()` 只要 CDP 目标存在就成功，可此时页面**可能还是
            #   about:blank / 正在加载** —— 这时读表单啥也读不到（字段全 False），
            #   面板虽然显示出来，却只有空荡荡几个框，看起来就是「没同步」。
            #   所以先**等登录表单真的出现**（最多 30 秒），再开始正式同步。
            form_ready = False
            _wait_start = time.time()
            _wait_end = _wait_start + 30
            _last_push = 0.0
            while time.time() < _wait_end and not self.forum_stop:
                try:
                    # ★ 短超时：一次卡 12 秒的话，30 秒窗口只够试两三次，
                    #   页面稍慢就会被误判成「读不到」。
                    info0 = self._fform_read(eng, timeout=6)
                except Exception:
                    info0 = None
                if isinstance(info0, dict) and (
                        info0.get("hasUser") or info0.get("hasPass")):
                    form_ready = True
                    break
                # ★ 每 3 秒把「服务器那边现在到底是什么页面」推给网页 ——
                #   人在外网看不见那台机器的屏幕，光一句「正在等…」没法判因。
                #   有了 URL / 标题 / 输入框数，一眼就能看出是没导航过去、
                #   页面报错，还是只是这个站的结构我们的选择器不认。
                _now2 = time.time()
                if _now2 - _last_push >= 3.0:
                    _last_push = _now2
                    _pb = self._fform_probe(eng)
                    self._fform_set(
                        on=True, stage="loading", probe=_pb,
                        msg="正在等登录页加载出来…（已等 %d 秒）"
                            % int(_now2 - _wait_start))
                    self.log("  …等待登录页（%d 秒）：%s ｜ %s ｜ 输入框=%s"
                             % (int(_now2 - _wait_start),
                                self.C._short(_pb.get("url") or "(读不到)", 60),
                                self.C._short(_pb.get("title") or "", 40),
                                _pb.get("inputs")), "forum")
                time.sleep(1.0)
            if form_ready:
                self.log("  登录页已加载，表单已同步到网页（可在外网填写）", "forum")
            else:
                # ★ 读不到时不要一直挂着「正在等…」——把面板切成可用的状态：
                #   告诉用户页面 URL + 提示可以直接在浏览器窗口里登录，
                #   后台同步循环仍会继续重试（页面加载慢或结构特殊都能自愈）。
                _pb2 = self._fform_probe(eng)
                self._fform_set(
                    on=True, stage="manual", probe=_pb2,
                    msg="没能自动读到登录表单（页面可能仍在加载或结构特殊）——"
                        "可以直接在服务器那台机器的浏览器窗口里登录，"
                        "程序会继续在后台重试识别。")
                self.log("  提示：还没读到登录表单（页面可能仍在加载 / 站点结构特殊）。"
                         "已经在浏览器窗口里登录的话不受影响；"
                         "网页面板会持续在后台重试。", "forum")
            _last_sync = 0.0
            _pushed = False          # 本轮的「第一版表单」是否已经推给网页了
            while time.time() < end and not self.forum_stop:
                try:
                    v = eng.cdp.ev(
                        "(function(){var h=document.documentElement.innerHTML;"
                        "return (h.indexOf('action=logout')>=0||"
                        "h.indexOf('action%3Dlogout')>=0)?1:0})()")
                    if v == 1:
                        detected = True
                        break
                except Exception:
                    pass
                # 每 3 秒把表单状态（含验证码）同步一次给网页
                now = time.time()
                if now - _last_sync >= 3:
                    _last_sync = now
                    try:
                        # 页面刚加载好那一下强推一次，避免被去重逻辑吞掉
                        self._fform_sync(eng, base, name, force=not _pushed)
                        _pushed = True
                    except Exception as ex:
                        self.log("[论坛] 表单同步跳过：%s" % ex, "forum")
                time.sleep(2)
            if not detected:
                self.log("  ✗ 未检测到登录成功（超时或已取消），窗口将关闭", "forum")
                return False, "", ""
            self.log("  ✓ 检测到登录成功，正在抓取 Cookie…", "forum")
            time.sleep(2)
            cookie = self.C.cdp_all_cookies(port, host_filter=root_domain)
            if not cookie:
                self.log("  ✗ 未抓取到 Cookie（请重试一次）", "forum")
                return False, "", ""
            ua = self.C.cdp_browser_ua(port)
            signer = self.C.DiscuzForumSigner(base, cookie=cookie,
                                              log=self.debug_log, ua=ua)
            ok, info = signer.login()
            if not ok:
                self.log("  ✗ Cookie 校验未通过：%s" % info, "forum")
                return False, "", ""
            now = _now().strftime("%m-%d %H:%M")
            entry = self.forum_cfg.get(base)
            if not isinstance(entry, dict) or not isinstance(entry.get("accounts"), list):
                entry = {"accounts": []}
            accs = entry["accounts"]
            found = None
            for a in accs:
                if str(a.get("id")) == acc_id:
                    found = a
                    break
            if found is None:
                found = {"id": acc_id}
                accs.append(found)
            found["cookie"] = cookie
            found["ua"] = ua
            found["saved_at"] = now
            lab = str(account_name or "").strip() or found.get("name") or \
                ("账号%s" % (acc_id.lstrip("a") or "1"))
            found["name"] = lab
            self.forum_cfg[base] = entry
            _atomic_write_json(self.C.FORUM_CFG_FILE, self.forum_cfg)
            self.log("  ✅ %s［%s］：Cookie 已保存（%d 字符），下次可直接签到"
                     % (name, lab, len(cookie)), "forum")
            self.bus.event("forum")
            return True, cookie, ua
        except Exception as ex:
            self.log("  ✗ 异常：%s" % ex, "forum")
            return False, "", ""
        finally:
            # ★ 需求⑱：论坛登录收工时，把网页上的填表面板一起关掉
            self._forum_eng = None
            try:
                self.forum_form_close()
            except Exception:
                pass
            try:
                if eng:
                    eng.close()
            except Exception:
                pass

    # ==================================================================
    # 论坛：签到
    # ==================================================================
    def _save_forum_records_file(self):
        recs = self.C._prune_records_by_time(list(self.forum_records))
        self.forum_records = recs
        _atomic_write_json(self.C.FORUM_RECORDS_FILE, recs[-2000:])

    def forum_save_record(self, forum_name, status, msg):
        rec = {"time": _now().strftime("%m-%d %H:%M:%S"),
               "forum": forum_name,
               "result": {"ok": "成功", "already": "已签",
                          "fail": "失败"}.get(status, str(status)),
               "tag": status if status in ("ok", "already", "fail") else "fail",
               "msg": str(msg)}
        with self.lock:
            self.forum_records.append(rec)
        self._save_forum_records_file()
        self.bus.event("forum_record", rec)

    def forum_sign_all(self):
        """★ 多账号：一次性把所有论坛的**全部账号**都签一遍。"""
        self.forum_sign(None)

    def forum_sign(self, targets=None):
        """targets 支持三种形态：
          · None                              → 所有论坛的全部账号
          · [[base, name], ...]               → 这些论坛的全部账号
          · [[base, name, account_id], ...]   → 只签指定账号
        """
        if self.forum_busy:
            self.log("已有任务在执行，请稍候…", "forum")
            return {"ok": False, "msg": "已有任务在执行"}
        if not targets:
            targets = [[n, b] for n, b in self.forum_list]
        known = {b for _n, b in self.forum_list}
        names = {n for n, _b in self.forum_list}
        plan = []
        for item in targets:
            base, name, acc_id = "", "", ""
            if isinstance(item, (tuple, list)):
                if len(item) >= 3:
                    base, name, acc_id = item[0], item[1], item[2]
                elif len(item) >= 2:
                    base, name = item[0], item[1]
                elif len(item) == 1:
                    base = name = item[0]
            else:
                base = name = item
            base = str(base or "")
            name = str(name or "")
            # 归一化：cookie 表按网址存，用「谁是网址」判定（原版踩过的坑）
            if base not in known and base in names:
                base, name = name, base
            accs = self._forum_accounts(base)
            if acc_id:
                accs = [a for a in accs if str(a.get("id")) == str(acc_id)]
            if not accs:
                # 保留一条占位，让 worker 打日志说清「未登录」
                plan.append((base, name or base, "", "", "", ""))
                continue
            for a in accs:
                plan.append((base, name or base, str(a.get("id") or ""),
                             a.get("name") or "",
                             (a.get("cookie") or "").strip(),
                             (a.get("ua") or "").strip()))
        if not plan:
            self.log("没有可签到的论坛（请先添加论坛并登录）", "forum")
            return {"ok": False, "msg": "没有可签到的论坛"}
        self.forum_stop = False
        self.forum_busy = True
        self.bus.event("forum_busy", True)
        self._spawn(self._forum_sign_worker, plan, name="forum-sign")
        return {"ok": True, "n": len(plan)}

    def _forum_sign_worker(self, plan):
        recovered = set()
        try:
            for base, name, acc_id, acc_name, cookie, ua in plan:
                if self.forum_stop:
                    self.log("已停止。", "forum")
                    break
                label = name + (("［%s］" % acc_name) if acc_name else "")
                self.log("―――――― %s ――――" % label, "forum")
                if not cookie:
                    self.log("  ✗ 未登录，请先点『登录 / +账号』获取 Cookie", "forum")
                    continue
                signer = self.C.DiscuzForumSigner(base, cookie=cookie,
                                                  log=self.debug_log, ua=ua)
                status, msg = signer.sign()
                icon = {"ok": "✅", "already": "☑", "fail": "✗"}.get(status, "•")
                self.log("  %s %s：%s" % (icon, label, msg), "forum")
                self.forum_save_record(label, status, msg)
                # ★ 持续 403 拦截 → 自动恢复：清 Cookie → 重登 → 再签一次
                #   多账号后要按「论坛 + 账号」粒度恢复，否则一个账号坏了会
                #   把同论坛别的账号也重置。
                rk = (base, acc_id)
                if (status == "fail" and "HTTP 403" in str(msg)
                        and rk not in recovered and not self.forum_stop):
                    recovered.add(rk)
                    self.forum_clear_cookie(base, acc_id or None)
                    ok2, ck2, ua2 = self._forum_do_login(
                        base, name, account_id=(acc_id or None),
                        account_name=acc_name, auto=True)
                    if not ok2:
                        self.log("  ✗ %s：自动重登未成功，请手动点『登录』后重试"
                                 % label, "forum")
                        continue
                    self.log("  ↻ 重登成功，重新签到 %s …" % label, "forum")
                    signer2 = self.C.DiscuzForumSigner(base, cookie=ck2,
                                                       log=self.debug_log, ua=ua2)
                    st2, msg2 = signer2.sign()
                    icon2 = {"ok": "✅", "already": "☑", "fail": "✗"}.get(st2, "•")
                    self.log("  %s %s：%s" % (icon2, label, msg2), "forum")
                    self.forum_save_record(label, st2, msg2)
        except Exception as ex:
            self.log("签到异常：%s" % ex, "forum")
        finally:
            self.forum_busy = False
            self.bus.event("forum_busy", False)
            self.bus.event("forum")

    def forum_stop_all(self):
        self.forum_stop = True
        self.log("已请求停止（等待当前步骤结束）…", "forum")
        return {"ok": True}

    def forum_save_settings(self, patch):
        if not isinstance(patch, dict):
            return {"ok": False}
        if "auto_sign" in patch:
            self.forum_settings["auto_sign"] = bool(patch["auto_sign"])
        if "auto_time" in patch:
            self.forum_settings["auto_time"] = str(patch["auto_time"] or "08:00").strip()
        if "headless" in patch:
            self.forum_settings["headless"] = bool(patch["headless"])
        self.save_forum_cfg()
        self.log("设置已保存（定时签到 %s，无头模式 %s）"
                 % ("开" if self.forum_settings["auto_sign"] else "关",
                    "开" if self.forum_settings["headless"] else "关"), "forum")
        self.bus.event("forum")
        return {"ok": True}

    # ==================================================================
    # QQ：配置（★ 2026-10-09 多账号：一条连接 = 一个 QQ 账号）
    # ==================================================================
    def _qq_norm_groups(self, groups):
        """把落盘的 groups 归一成 {gid: {...}}（保留已有勾选与自定义消息）。"""
        out = {}
        if not isinstance(groups, dict):
            return out
        for gid, g in (groups or {}).items():
            if not isinstance(g, dict):
                continue
            out[str(gid)] = {
                "name": str(g.get("name", "") or ""),
                "count": self._to_int(g.get("count", 0)),
                "enabled": bool(g.get("enabled", True)),
                "kw": bool(g.get("kw", False)),
                "msg": str(g.get("msg", "") or ""),
            }
        return out

    def _qq_order_of(self, groups):
        return sorted(groups.keys(),
                      key=lambda g: (-groups[g]["count"], g))

    def _qq_new_id(self):
        self._qq_seq += 1
        return "q%d" % self._qq_seq

    def _qq_conn_by_id(self, cid):
        cid = str(cid or "")
        for c in self.qq_conns:
            if c.get("id") == cid:
                return c
        return None

    def _qq_alive_conns(self):
        return [c for c in self.qq_conns
                if c.get("conn") is not None and c["conn"].is_alive()]

    def _qq_any_alive(self):
        return bool(self._qq_alive_conns())

    def _qq_any_status(self):
        for c in self.qq_conns:
            if c.get("conn") is not None and c["conn"].is_alive():
                return c.get("status") or "✅ 已连接"
        if self.qq_conns:
            return self.qq_conns[0].get("status") or "○ 未连接"
        return "○ 未连接"

    def _qq_refresh_gname(self):
        """把所有连接的群名并成一张「群号 → 群名」表（关键字日志用）。"""
        m = {}
        for c in self.qq_conns:
            for gid, v in (c.get("groups") or {}).items():
                m.setdefault(gid, v.get("name", ""))
        self._qq_gname = m

    def load_qq(self):
        cfg, err = self.C._safe_load_json(self.C.QQ_CFG_FILE)
        if err:
            self.bus.log("qq", "⚠ " + str(err))
        cfg = cfg if isinstance(cfg, dict) else {}
        st = cfg.get("_settings") if isinstance(cfg.get("_settings"), dict) else {}
        st = dict(st or {})
        st.setdefault("default_msg", self.C.QQ_DEFAULT_MSG)
        st.setdefault("like_users", "")
        st.setdefault("like_times", 5)
        st.setdefault("auto_sign", False)
        st.setdefault("auto_time", "08:00")
        st.setdefault("last_auto", "")
        st.setdefault("like_auto", False)
        st.setdefault("like_auto_time", "08:30")
        st.setdefault("last_like_auto", "")
        # ★ 2026-09-26 红包监测已删：旧配置里的两个红包键不再读写。
        #   旧配置文件里可能还有这两个键，留着不管（不读不消费，也不删用户的键）。
        st.setdefault("kw_on", False)
        st.setdefault("kw_notify", "")
        st.setdefault("kw_words", "")
        # ★ 2026-10-09 反向 WS 配置（OneBot 11 反向 WebSocket 监听端）
        st.setdefault("rev_on", False)
        st.setdefault("rev_host", "0.0.0.0")
        st.setdefault("rev_port", 6700)
        st.setdefault("rev_path", "")
        st.setdefault("rev_token", "")
        # ★ 2026-10-10 用户要求：监听地址固定 0.0.0.0、路径固定空、Token 固定空。
        #   前端已删这三个输入框，这里也**强制**用默认值、不再读旧配置里残留的值
        #   （老用户之前填过 127.0.0.1 / /onebot/v11/ws 会留在 qq_signin.json 里）。
        self.qq_rev = {"on": False,
                       "host": "0.0.0.0",
                       "port": self._to_int(st.get("rev_port", 6700), 6700, 1, 65535),
                       "path": "",
                       "token": "",
                       "lis": None, "stop": None, "status": "○ 未监听",
                       "_want_on": bool(st.get("rev_on"))}
        self.qq_cfg = cfg
        self.qq_settings = st

        # ---- 连接列表（每条 = 一个 QQ 账号）----
        raw_conns = st.get("conns") if isinstance(st.get("conns"), list) else []
        self.qq_conns = []
        self._qq_seq = 0
        for raw in raw_conns:
            if not isinstance(raw, dict):
                continue
            cid = str(raw.get("id") or "").strip() or self._qq_new_id()
            try:
                n = int(str(cid).lstrip("q") or "0")
                self._qq_seq = max(self._qq_seq, n)
            except Exception:
                pass
            groups = self._qq_norm_groups(raw.get("groups"))
            mode = str(raw.get("mode") or "forward").strip() or "forward"
            self.qq_conns.append({
                "id": cid,
                "mode": mode,
                "url": str(raw.get("url") or "").strip(),
                "token": str(raw.get("token") or "").strip(),
                "remark": str(raw.get("remark") or "").strip(),
                "conn": None,
                "status": ("○ 等待连入" if mode == "reverse" else "○ 未连接"),
                # ★ 反向连接的 self_id（QQ 号）要记住：框架重连时靠它认回同一条，
                #   否则每次重连都会多出一个账号条目。正向连接的 self_id 由拨号时填。
                "self_id": str(raw.get("self_id") or "").strip(),
                "nickname": "",
                "groups": groups, "order": self._qq_order_of(groups),
            })
        if not self.qq_conns:
            # ★ 向后兼容：老配置只有一份 url/token + 顶层 groups → 迁移成第一条连接
            legacy = cfg.get("groups") if isinstance(cfg.get("groups"), dict) else {}
            groups = self._qq_norm_groups(legacy)
            self.qq_conns.append({
                "id": self._qq_new_id(),
                "mode": "forward",
                "url": str(st.get("url") or "ws://127.0.0.1:3001").strip(),
                "token": str(st.get("token") or "").strip(),
                "remark": "",
                "conn": None, "status": "○ 未连接",
                "self_id": "", "nickname": "",
                "groups": groups, "order": self._qq_order_of(groups),
            })

        # 线程侧只读的普通属性（Tk 变量在多线程读写是未定义行为，这里同理）
        # ★ 红包已删：_rp_enabled / _rp_target 恒为空；关键字的照常读
        self._rp_enabled = False
        self._rp_target = ""
        self._kw_enabled = bool(st.get("kw_on"))
        self._kw_target = str(st.get("kw_notify") or "").strip()
        self._kw_words_raw = str(st.get("kw_words") or "")
        try:
            self._kw_words = self.C.parse_keywords(self._kw_words_raw)
        except Exception:
            self._kw_words = []
        self._qq_refresh_gname()
        self.update_monitored()

    def save_qq(self):
        st = dict(self.qq_settings)
        st["like_times"] = self._to_int(st.get("like_times", 5), 5, 1, 10)
        st["last_auto"] = self.auto_qq_last()
        st["last_like_auto"] = self.like_auto_last()
        conns = []
        for c in self.qq_conns:
            groups = {}
            for gid in (c.get("order") or []):
                v = (c.get("groups") or {}).get(gid)
                if not v:
                    continue
                groups[gid] = {"name": v.get("name", ""),
                               "count": v.get("count", 0),
                               "enabled": bool(v.get("enabled")),
                               "kw": bool(v.get("kw")),
                               "msg": (v.get("msg") or "").strip()}
            mode = str(c.get("mode") or "forward")
            conns.append({"id": c.get("id", ""), "mode": mode,
                          "url": c.get("url", ""),
                          "token": c.get("token", ""),
                          "remark": c.get("remark", ""),
                          # 只有反向连接需要记住 self_id（正向连接每次连上都会重新拿到）
                          "self_id": (str(c.get("self_id") or "")
                                      if mode == "reverse" else ""),
                          "groups": groups})
        st["conns"] = conns
        # ★ 2026-10-09 反向 WS 监听配置（host / port / path / token / 上次开关）
        st["rev_on"] = bool(self.qq_rev.get("on"))
        # ★ 2026-10-10 用户要求：host/path/token 固定默认值，配置里也写死，
        #   避免旧配置里残留的 127.0.0.1 / /onebot/v11/ws 被读回去。
        st["rev_host"] = "0.0.0.0"
        st["rev_port"] = self._to_int(self.qq_rev.get("port", 6700), 6700, 1, 65535)
        st["rev_path"] = ""
        st["rev_token"] = ""
        # ★ 向后兼容：仍写一份「第一条**正向**连接」的老字段（url/token/顶层 groups），
        #   这样万一用旧版 EXE 打开新配置文件，第一条正向连接照旧能用。
        first = next((x for x in conns if x.get("mode") != "reverse"),
                     (conns[0] if conns else {}))
        st["url"] = first.get("url", "")
        st["token"] = first.get("token", "")
        self.qq_cfg = {"_settings": st, "groups": first.get("groups", {})}
        _atomic_write_json(self.C.QQ_CFG_FILE, self.qq_cfg)
        return True

    def auto_qq_last(self):
        return str(getattr(self, "_qq_auto_last", "") or "")

    def like_auto_last(self):
        return str(getattr(self, "_qq_like_auto_last", "") or "")

    def update_monitored(self):
        """勾选集变了就刷新监测范围快照（子线程只读）。

        ★ 2026-09-26 红包已删：`_rp_monitored` 恒为空集（保留属性避免旧代码引用报错），
        实际生效的是 `_rp_kw_monitored`（关键字监测群）。
        ★ 2026-10-09 多账号后：把所有连接里勾了「关键字」的群并起来。
        """
        self._rp_monitored = set()
        kw = set()
        for c in self.qq_conns:
            for gid, v in (c.get("groups") or {}).items():
                if v.get("kw"):
                    kw.add(gid)
        self._rp_kw_monitored = kw

    def qq_save_settings(self, patch):
        if not isinstance(patch, dict):
            return {"ok": False}
        st = self.qq_settings
        for k in ("default_msg", "like_users", "auto_time",
                  "like_auto_time", "kw_notify", "kw_words"):
            if k in patch:
                st[k] = str(patch[k] or "").strip()
        for k in ("auto_sign", "like_auto", "kw_on"):
            if k in patch:
                st[k] = bool(patch[k])
        if "like_times" in patch:
            st["like_times"] = self._to_int(patch["like_times"], 5, 1, 10)
        # ★ 兼容旧前端：如果还传 url/token，落到第一条连接上（新前端用
        #   /api/qq/conn/* 管连接，不再用这里）。
        if ("url" in patch or "token" in patch) and self.qq_conns:
            c0 = self.qq_conns[0]
            if "url" in patch:
                c0["url"] = str(patch["url"] or "").strip()
            if "token" in patch:
                c0["token"] = str(patch["token"] or "").strip()
        self._rp_enabled = False          # ★ 红包已删
        self._rp_target = ""
        self._kw_enabled = bool(st.get("kw_on"))
        self._kw_target = str(st.get("kw_notify") or "").strip()
        self._kw_words_raw = str(st.get("kw_words") or "")
        try:
            self._kw_words = self.C.parse_keywords(self._kw_words_raw)
        except Exception:
            self._kw_words = []
        self.save_qq()
        self.bus.event("qq")
        if self._rp_any_enabled():
            self.ensure_monitor()
        else:
            self.stop_monitor_if_idle()
        return {"ok": True}

    def qq_save_groups(self, cid, groups):
        """前端提交某一连接（账号）的勾选/专属消息：{gid: {enabled,kw,msg}}。"""
        c = self._qq_conn_by_id(cid)
        if c is None:
            return {"ok": False, "msg": "连接不存在"}
        if not isinstance(groups, dict):
            return {"ok": False, "msg": "参数不对"}
        gmap = c.get("groups") or {}
        for gid, patch in groups.items():
            gid = str(gid)
            v = gmap.get(gid)
            if v is None or not isinstance(patch, dict):
                continue
            for k in ("enabled", "kw"):
                if k in patch:
                    v[k] = bool(patch[k])
            if "msg" in patch:
                v["msg"] = str(patch["msg"] or "").strip()
        self.update_monitored()
        self.save_qq()
        self.bus.event("qq")
        if self._rp_any_enabled():
            self.ensure_monitor()
        return {"ok": True}

    def qq_set_all(self, action, cid=None):
        """全选 / 全不选 / 反选（对指定连接的全部群生效；不给 cid 就对全部连接）。"""
        targets = [self._qq_conn_by_id(cid)] if cid else list(self.qq_conns)
        for c in targets:
            if not c:
                continue
            for gid in (c.get("order") or []):
                v = (c.get("groups") or {}).get(gid) or {}
                if action == "all":
                    v["enabled"] = True
                elif action == "none":
                    v["enabled"] = False
                elif action == "invert":
                    v["enabled"] = not bool(v.get("enabled"))
        self.update_monitored()
        self.save_qq()
        self.bus.event("qq")
        return {"ok": True}

    # ==================================================================
    # QQ：连接管理（★ 2026-10-09 多账号：一个 QQ 账号 = 一条 WS 连接）
    # ==================================================================
    def _qq_new_conn_dict(self, url, token, remark):
        return {"id": self._qq_new_id(), "mode": "forward",
                "url": str(url or "").strip(),
                "token": str(token or "").strip(), "remark": str(remark or "").strip(),
                "conn": None, "status": "○ 未连接", "self_id": "", "nickname": "",
                "groups": {}, "order": []}

    def qq_conn_add(self, url=None, token=None, remark=None, connect=True):
        """新增一条 WS 连接（一个 QQ 账号）。"""
        u = str(url or "").strip()
        if not u:
            return {"ok": False, "msg": "请先填写 WS 地址，例如 ws://127.0.0.1:3001"}
        rm = str(remark or "").strip() or ("账号%d" % (len(self.qq_conns) + 1))
        c = self._qq_new_conn_dict(u, token, rm)
        self.qq_conns.append(c)
        self.save_qq()
        self.log("已添加 QQ 连接：%s（%s）" % (c["remark"], u), "qq")
        self.bus.event("qq")
        if connect:
            self.qq_connect(c["id"])
        return {"ok": True, "id": c["id"]}

    def qq_conn_edit(self, cid, url=None, token=None, remark=None):
        c = self._qq_conn_by_id(cid)
        if c is None:
            return {"ok": False, "msg": "连接不存在"}
        if url is not None:
            c["url"] = str(url or "").strip()
        if token is not None:
            c["token"] = str(token or "").strip()
        if remark is not None:
            c["remark"] = str(remark or "").strip()
        self.save_qq()
        self.bus.event("qq")
        return {"ok": True}

    def qq_conn_del(self, cid):
        c = self._qq_conn_by_id(cid)
        if c is None:
            return {"ok": False, "msg": "连接不存在"}
        try:
            if c.get("conn"):
                c["conn"].close()
        except Exception:
            pass
        self.qq_conns = [x for x in self.qq_conns if x.get("id") != cid]
        self._qq_refresh_gname()
        self.update_monitored()
        self.save_qq()
        if not self._qq_any_alive():
            self._rp_stop.set()
        self.log("已删除 QQ 连接：%s" % (c.get("remark") or cid), "qq")
        self.bus.event("qq")
        return {"ok": True}

    def qq_connect(self, cid=None, url=None, token=None):
        # 没给 id：兼容旧调用 —— 用第一条连接
        c = self._qq_conn_by_id(cid) if cid else (self.qq_conns[0] if self.qq_conns else None)
        if c is None:
            if url is None:
                return {"ok": False, "msg": "请先添加一条 WS 连接"}
            r = self.qq_conn_add(url, token, connect=False)
            c = self._qq_conn_by_id(r.get("id"))
            if c is None:
                return {"ok": False, "msg": "添加连接失败"}
        if str(c.get("mode") or "forward") == "reverse":
            # ★ 反向 WS：不拨号 —— 是机器人框架主动连进来的。
            return {"ok": False, "id": c.get("id"),
                    "msg": "这条是反向 WS 连接：由机器人框架主动连入，不用手动『连接』。"
                           "请确认下方『反向 WS 监听』已启动。"}
        if url is not None:
            c["url"] = str(url).strip()
        if token is not None:
            c["token"] = str(token).strip()
        self.save_qq()
        if c.get("conn") is not None and c["conn"].is_alive():
            self.log("%s：已处于连接状态，如需重连请先『断开』" % (c.get("remark") or c["id"]),
                     "qq")
            return {"ok": True, "msg": "已连接", "id": c["id"]}
        u = str(c.get("url") or "").strip()
        if not u:
            return {"ok": False, "msg": "请先填写 WS 地址，例如 ws://127.0.0.1:3001"}
        c["status"] = "○ 连接中…"
        self.log("正在连接 %s（%s）…" % (u, c.get("remark") or c["id"]), "qq")
        self._spawn(self._qq_connect_worker, c["id"], u,
                    str(c.get("token") or ""), name="qq-connect")
        self.bus.event("qq")
        return {"ok": True, "id": c["id"]}

    def _qq_connect_worker(self, cid, url, token):
        c = self._qq_conn_by_id(cid)
        if c is None:
            return
        try:
            x = self.C.OneBotWS(url, token, log=self.debug_qq_log)
            x._on_event = (lambda ev, _self=self, _cid=cid:
                           _self._rp_on_event(_cid, ev))
            x.connect()
        except Exception as ex:
            c["conn"] = None
            c["status"] = "○ 未连接"
            self.log("✗ %s 连接失败：%s" % (c.get("remark") or cid, ex), "qq")
            self.log("  请确认 QQ 机器人框架已启动，且已开启正向 WS"
                     "（NapCat：网络配置 → WebSocket 服务器；端口常见 3001 / 8080）",
                     "qq")
            self.bus.event("qq")
            return
        c["conn"] = x
        c["self_id"] = str(getattr(x, "self_id", "") or "")
        c["nickname"] = str(getattr(x, "nickname", "") or "")
        who = "%s (%s)" % (c["nickname"] or "QQ", c["self_id"] or "?")
        c["status"] = "✅ 已连接：%s" % who
        self.log("✅ %s 已连接：%s" % (c.get("remark") or cid, who), "qq")
        self.rpk_ensure_thread()
        self.bus.event("qq")
        try:
            groups = x.get_group_list()
        except Exception as ex:
            self.log("✗ %s 已连接，但拉取群列表失败：%s（可点『刷新群列表』重试）"
                     % (c.get("remark") or cid, ex), "qq")
            return
        self.render_groups(c, groups)
        self.save_qq()
        self.bus.event("qq")

    def debug_qq_log(self, msg):
        self.log(msg, "qq")

    # ==================================================================
    # QQ：反向 WS 监听（★ 2026-10-09：小工具端当服务端，框架主动连进来）
    #   正向 WS = 我们连框架；反向 WS = 我们开监听、框架连我们。
    #   两种情况连上之后协议一模一样，所以复用同一个 OneBotWS（attach 接管）。
    #   多账号：同一个端口上按 X-Self-ID（QQ 号）区分，各连一条。
    # ==================================================================
    def qq_rev_status(self):
        r = self.qq_rev
        port = self._to_int(r.get("port", 6700), 6700, 1, 65535)
        path = str(r.get("path") or "")
        return {"on": bool(r.get("on")),
                "host": str(r.get("host") or ""),
                "port": port, "path": path,
                "token": str(r.get("token") or ""),
                "status": r.get("status") or ("○ 未监听"),
                "addr": "%s:%d%s" % (r.get("host") or "0.0.0.0", port, path),
                "n_reverse": sum(1 for c in self.qq_conns
                                 if str(c.get("mode") or "") == "reverse"),
                "n_reverse_alive": sum(1 for c in self.qq_conns
                                       if str(c.get("mode") or "") == "reverse"
                                       and c.get("conn") is not None
                                       and c["conn"].is_alive())}

    def qq_rev_start(self, host=None, port=None, path=None, token=None):
        """启动反向 WS 监听（OpenBot 11 反向 WebSocket 的服务端）。"""
        r = self.qq_rev
        # ★ 2026-10-10 用户要求：host/path/token 固定默认值（0.0.0.0 / 空 / 空），
        #   前端已删输入框，这里也**忽略**传入的 host/path/token，只认 port。
        if port is not None:
            _ps = str(port).strip()
            try:
                p = int(float(_ps))
            except Exception:
                p = 0
            # ★ 不做「越界自动夹到 1/65535」—— 用户填 70000 就该报错，
            #   而不是悄悄绑到 65535（免得以为监听在 70000）。
            if p < 1 or p > 65535:
                return {"ok": False,
                        "msg": "端口要填 1~65535 之间的整数（收到 %r）" % _ps}
            r["port"] = p
        if r.get("on"):
            # 已在监听：新配置只落盘（要换端口/地址请先停再启）
            self.save_qq()
            self.bus.event("qq")
            return {"ok": True, "msg": "监听已在运行", "rev": self.qq_rev_status()}
        try:
            lis = _wsc.WSListener(r["host"], r["port"]).start()
        except OSError as ex:
            r["on"] = False
            r["status"] = "✗ 启动失败：%s" % ex
            self.log("✗ 反向 WS 监听启动失败（%s:%d）：%s（端口可能被别的程序占用）"
                     % (r["host"], r["port"], ex), "qq")
            self.save_qq()
            self.bus.event("qq")
            return {"ok": False, "msg": "启动失败：%s（端口可能被占用）" % ex}
        r["lis"] = lis
        r["on"] = True
        r["stop"] = threading.Event()
        r["status"] = "✅ 监听中 %s" % self.qq_rev_status()["addr"]
        self.log("✅ 反向 WS 监听已启动：%s ｜ 请在机器人框架里把「反向 WS 地址」"
                 "填成 ws://<本机IP>:%d%s"
                 % (r["status"], r["port"],
                    r["path"] or "/onebot/v11/ws"), "qq")
        self._spawn(self._qq_rev_accept_loop, name="qq-rev-accept")
        self.save_qq()
        self.bus.event("qq")
        return {"ok": True, "rev": self.qq_rev_status()}

    def qq_rev_stop(self):
        """停止反向 WS 监听，并断开所有反向连接（框架随后会自动重连，
        但监听已停，不会再被接受）。"""
        r = self.qq_rev
        was = bool(r.get("on"))
        r["on"] = False
        try:
            if r.get("stop") is not None:
                r["stop"].set()
        except Exception:
            pass
        lis, r["lis"] = r.get("lis"), None
        if lis is not None:
            try:
                lis.close()
            except Exception:
                pass
        n = 0
        for c in list(self.qq_conns):
            if str(c.get("mode") or "") != "reverse":
                continue
            try:
                if c.get("conn") is not None:
                    c["conn"].close()
            except Exception:
                pass
            c["conn"] = None
            c["status"] = "○ 未监听"
            n += 1
        r["status"] = "○ 未监听"
        self.log("反向 WS 监听已停止%s"
                 % (("（断开 %d 条反向连接）" % n) if n else ""), "qq")
        self.save_qq()
        self.bus.event("qq")
        return {"ok": True, "was_on": was, "rev": self.qq_rev_status()}

    def _qq_rev_accept_loop(self):
        r = self.qq_rev
        lis, stop = r.get("lis"), r.get("stop")
        while lis is not None and stop is not None and not stop.is_set():
            try:
                got = lis.accept(0.5)
            except Exception as ex:
                if stop.is_set():
                    break
                self.log("反向 WS accept 异常：%s" % ex, "qq")
                time.sleep(0.5)
                continue
            if got is None:
                continue
            conn, addr = got
            self._spawn(self._qq_rev_on_conn, conn, addr, name="qq-rev-conn")
        self.log("反向 WS 接收线程已退出", "qq")

    def _qq_rev_on_conn(self, conn, addr):
        """一条反向 WS 连接进来了：握手 → 按 X-Self-ID 认领/新建账号 → attach。"""
        try:
            peer = "%s:%d" % (addr[0], addr[1])
        except Exception:
            peer = str(addr)
        if not self.qq_rev.get("on"):
            try:
                conn.close()
            except Exception:
                pass
            return
        # 1) 握手：读请求 → 校验路径 / Token → 回 101
        try:
            req = _wsc._read_http_request(conn, timeout=10)
        except Exception as ex:
            self.log("反向 WS：读取握手请求失败（%s）：%s" % (peer, ex), "qq")
            try:
                conn.close()
            except Exception:
                pass
            return
        want_path = str(self.qq_rev.get("path") or "").strip()
        got_path = req.get("path") or "/"
        if want_path and got_path != want_path:
            try:
                _wsc._send_http_error(conn, 404, "Not Found")
            except Exception:
                pass
            try:
                conn.close()
            except Exception:
                pass
            self.log("反向 WS：路径不匹配（收到 %s，期望 %s），已拒绝 %s"
                     % (got_path, want_path, peer), "qq")
            return
        try:
            ws = _wsc.accept_websocket(conn, req,
                                       token=str(self.qq_rev.get("token") or ""))
        except Exception as ex:
            self.log("反向 WS：握手未通过（%s）：%s" % (peer, ex), "qq")
            try:
                conn.close()
            except Exception:
                pass
            return
        h = req.get("headers") or {}
        sid = str(h.get("x-self-id") or "").strip()
        role = str(h.get("x-client-role") or "").strip()
        self.log("反向 WS：框架已连入（%s，路径 %s，X-Self-ID=%s，Role=%s）"
                 % (peer, got_path, sid or "?", role or "?"), "qq")
        # 2) 认领账号条目：同一个 self_id 复用；没有就新建一条
        c = self._qq_rev_find_by_self(sid)
        if c is None:
            c = self._qq_rev_make_conn(sid)
            self.qq_conns.append(c)
            self._qq_refresh_gname()
            self.log("反向 WS：新建 QQ 账号条目【%s】" % c["remark"], "qq")
        else:
            # 同账号重连：先把旧 socket 关掉，避免两条并存
            old = c.get("conn")
            c["conn"] = None
            if old is not None:
                try:
                    old.close()
                except Exception:
                    pass
        # 3) attach：接管这个已经握好手的 socket（协议与正向完全一致）
        x = self.C.OneBotWS("", str(self.qq_rev.get("token") or ""),
                            log=self.debug_qq_log)
        x._on_event = (lambda ev, _self=self, _cid=c["id"]:
                       _self._rp_on_event(_cid, ev))
        x._on_gone = (lambda _self=self, _cid=c["id"], _x=x:
                      _self._qq_rev_gone(_cid, _x))
        try:
            x.attach(ws, self_id=sid)
        except Exception as ex:
            self.log("反向 WS：接管连接失败（%s）：%s"
                     % (c.get("remark") or c["id"], ex), "qq")
            try:
                ws.close()
            except Exception:
                pass
            c["status"] = "○ 已断开"
            self.bus.event("qq")
            return
        c["conn"] = x
        c["self_id"] = str(getattr(x, "self_id", "") or sid or "")
        c["nickname"] = str(getattr(x, "nickname", "") or "")
        c["status"] = "✅ 已连接（反向）：%s (%s)" % (c["nickname"] or "QQ",
                                                     c["self_id"] or "?")
        self.rpk_ensure_thread()
        self.log("✅ 反向 WS %s 就绪：%s" % (c["remark"], c["status"]), "qq")
        self.save_qq()
        self.bus.event("qq")
        try:
            groups = x.get_group_list()
        except Exception as ex:
            self.log("反向 WS %s：拉取群列表失败：%s（可点『⟳』重试）"
                     % (c["remark"], ex), "qq")
            return
        self.render_groups(c, groups)
        self.save_qq()
        self.bus.event("qq")

    def _qq_rev_find_by_self(self, sid):
        """按 QQ 号找已有的反向连接条目（找不到返回 None）。"""
        sid = str(sid or "").strip()
        for c in self.qq_conns:
            if str(c.get("mode") or "") != "reverse":
                continue
            if sid:
                if str(c.get("self_id") or "") == sid:
                    return c
            elif not str(c.get("self_id") or "") and c.get("conn") is None:
                # 框架没带 X-Self-ID：挑一个还没认领过的反向空条目
                return c
        return None

    def _qq_rev_make_conn(self, sid):
        sid = str(sid or "").strip()
        n_rev = sum(1 for c in self.qq_conns if str(c.get("mode") or "") == "reverse")
        return {"id": self._qq_new_id(), "mode": "reverse",
                "url": "", "token": str(self.qq_rev.get("token") or ""),
                "remark": ("反向-%s" % sid) if sid else ("反向账号%d" % (n_rev + 1)),
                "conn": None, "status": "○ 等待连入",
                "self_id": sid, "nickname": "",
                "groups": {}, "order": []}

    def _qq_rev_gone(self, cid, who=None):
        """反向连接掉线回调（由 OneBotWS 的心跳线程调用）。

        who 是掉线那条 OneBotWS：只在它**仍是当前连接**时才清空 ——
        否则会把「已经换上的新连接」误清掉（旧连接的心跳晚 60 秒才察觉）。
        """
        c = self._qq_conn_by_id(cid)
        if c is None or str(c.get("mode") or "") != "reverse":
            return
        if who is not None and c.get("conn") is not who:
            return
        c["conn"] = None
        c["status"] = "○ 已断开（等待框架重连）"
        self.bus.event("qq")

    def qq_disconnect(self, cid=None):
        targets = [self._qq_conn_by_id(cid)] if cid else list(self.qq_conns)
        for c in targets:
            if not c:
                continue
            try:
                if c.get("conn"):
                    c["conn"].close()
            except Exception:
                pass
            c["conn"] = None
            if str(c.get("mode") or "") == "reverse":
                # ★ 反向连接：踢掉这一条即可，框架会自己重连（保留 self_id 便于认回）
                c["status"] = "○ 已踢出（等待框架重连）"
                continue
            c["status"] = "○ 未连接"
            c["self_id"] = ""
            c["nickname"] = ""
        if not self._qq_any_alive():
            self._rp_stop.set()
        self.log("已断开连接%s" % ("" if cid else "（全部）"), "qq")
        self.bus.event("qq")
        return {"ok": True}

    def qq_refresh(self, cid=None):
        targets = ([self._qq_conn_by_id(cid)] if cid
                   else [c for c in self.qq_conns if c.get("conn") is not None])
        targets = [c for c in targets if c]
        if not targets:
            self.log("未连接 WS 服务，请先点『连接』", "qq")
            return {"ok": False, "msg": "未连接"}

        def worker():
            for c in targets:
                x = c.get("conn")
                if x is None:
                    continue
                try:
                    if not x.is_alive() and not self.qq_reconnect(c):
                        self.log("✗ %s：连接不可用，无法刷新群列表"
                                 % (c.get("remark") or c["id"]), "qq")
                        continue
                    x = c.get("conn")
                    self.log("%s：正在拉取群列表…" % (c.get("remark") or c["id"]), "qq")
                    self.render_groups(c, x.get_group_list())
                    self.save_qq()
                    self.bus.event("qq")
                except Exception as ex:
                    self.log("✗ %s 拉取群列表失败：%s"
                             % (c.get("remark") or c["id"], ex), "qq")
        self._spawn(worker, name="qq-refresh")
        return {"ok": True}

    def qq_reconnect(self, c):
        """某条连接断了自动重连一次（批量签到几十个群跑到一半断线很常见）。"""
        if str(c.get("mode") or "") == "reverse":
            # ★ 反向 WS 不主动拨号：断开后由机器人框架自己重连，监听线程会重新 attach
            self.log("  ℹ %s 是反向 WS 连接，不主动拨号，等待机器人框架自动重连…"
                     % (c.get("remark") or c.get("id")), "qq")
            return False
        self.log("  ⚠ %s WS 连接已断开，尝试自动重连…" % (c.get("remark") or c.get("id")),
                 "qq")
        c["status"] = "○ 重连中…"
        try:
            x = c.get("conn")
            if x is None:
                x = self.C.OneBotWS(c.get("url") or "", c.get("token") or "",
                                    log=self.debug_qq_log)
                x._on_event = (lambda ev, _self=self, _cid=c["id"]:
                               _self._rp_on_event(_cid, ev))
                c["conn"] = x
            x.connect()
            c["self_id"] = str(getattr(x, "self_id", "") or "")
            c["nickname"] = str(getattr(x, "nickname", "") or "")
            c["status"] = "✅ 已连接：%s" % ((c["nickname"] or "QQ")
                                            + " (" + (c["self_id"] or "?") + ")")
            self.log("  ✅ %s 自动重连成功，继续执行" % (c.get("remark") or c.get("id")),
                     "qq")
            self.bus.event("qq")
            return True
        except Exception as ex:
            c["status"] = "○ 连接已断开"
            self.log("  ✗ %s 自动重连失败：%s" % (c.get("remark") or c.get("id"), ex),
                     "qq")
            return False

    def render_groups(self, c, groups):
        """把某连接拉到的群列表并进它自己的勾选状态（保留已有勾选与自定义消息）。"""
        if not groups:
            self.log("%s：尚未拉取到群列表（机器人账号可能没加任何群）"
                     % (c.get("remark") or c.get("id")), "qq")
            return
        gmap = c.get("groups") or {}
        for g in groups:
            gid = str(g.get("id"))
            old = gmap.get(gid) or {}
            gmap[gid] = {
                "name": str(g.get("name", "") or ""),
                "count": self._to_int(g.get("count", 0)),
                "enabled": bool(old.get("enabled", True)),   # 新群默认勾选
                "kw": bool(old.get("kw", False)),
                "msg": str(old.get("msg", "") or ""),
            }
        c["groups"] = gmap
        c["order"] = self._qq_order_of(gmap)
        self._qq_refresh_gname()
        self.update_monitored()
        self.log("%s：群列表已加载，共 %d 个群（新群默认勾选，可自行取消）"
                 % (c.get("remark") or c.get("id"), len(groups)), "qq")

    # ==================================================================
    # QQ：群签到
    # ==================================================================
    def qq_sign(self, confirm=True, gids=None, cids=None):
        if self.qq_busy:
            self.log("已有任务在执行，请稍候…", "qq")
            return {"ok": False, "msg": "已有任务在执行"}
        if not self.qq_conns:
            self.log("还没有任何 QQ 连接，请先添加并连接一个 WS 服务", "qq")
            return {"ok": False, "msg": "没有 QQ 连接"}
        sel_cids = [str(x) for x in cids] if cids else [c.get("id") for c in self.qq_conns]
        sel_gids = [str(g) for g in gids] if gids else None
        default_msg = str(self.qq_settings.get("default_msg") or "").strip()
        plan = []          # [ (conn_dict, [(gid,name,msg)...]) ]
        for cid in sel_cids:
            c = self._qq_conn_by_id(cid)
            if c is None:
                continue
            gmap = c.get("groups") or {}
            if sel_gids is not None:
                gsel = [g for g in sel_gids if g in gmap]
            else:
                gsel = [g for g in (c.get("order") or [])
                        if (gmap.get(g) or {}).get("enabled")]
            tg = [(gid, (gmap.get(gid) or {}).get("name") or gid,
                   ((gmap.get(gid) or {}).get("msg") or "").strip())
                  for gid in gsel if gid in gmap]
            if tg:
                plan.append((c, tg))
        if not plan:
            self.log("没有可签到的群（请先连接账号并勾选群）", "qq")
            return {"ok": False, "msg": "没有勾选任何群"}
        n_all = sum(len(t[1]) for t in plan)
        if not default_msg:
            self.log("默认消息为空；未单独填消息的群将被跳过（不发空消息）", "qq")
        # 群消息发出去撤不回来：多账号 + 上百个群时，先报清规模让用户确认
        if confirm and n_all >= 2:
            n_custom = sum(1 for _c, tg in plan for _g, _nm, m in tg if m)
            return {"ok": False, "need_confirm": True, "n": n_all,
                    "n_accounts": len(plan), "n_custom": n_custom,
                    "default_msg": default_msg,
                    "msg": "即将用 %d 个 QQ 账号给共 %d 个群各发送一条消息，"
                           "发送后无法撤回" % (len(plan), n_all)}
        self.save_qq()
        self.qq_stop = False
        self.qq_busy = True
        self.bus.event("qq_busy", True)
        self.log("―――― 开始签到：%d 个账号 / 共 %d 个群 ――――" % (len(plan), n_all), "qq")
        self._spawn(self._qq_sign_worker, plan, default_msg, name="qq-sign")
        return {"ok": True, "n": n_all, "n_accounts": len(plan)}

    def _qq_sign_worker(self, plan, default_msg):
        ok = skip = 0
        label = lambda c: c.get("remark") or c.get("id") or "?"
        try:
            for c, targets in plan:
                if self.qq_stop:
                    self.log("已停止。", "qq")
                    break
                self.log("【%s】%s" % (label(c), "―" * 20), "qq")
                n = len(targets)
                i = 0
                retried = set()
                while i < n:
                    if self.qq_stop:
                        self.log("已停止（%s 完成 %d/%d）" % (label(c), i, n), "qq")
                        break
                    gid, name, own_msg = targets[i]
                    x = c.get("conn")
                    if x is None or (not x.is_alive() and not self.qq_reconnect(c)):
                        self.log("⚠ %s WS 连接不可用，该账号跳过："
                                 "已成功 %d 个，剩余 %d 个未发送。"
                                 % (label(c), ok, n - i), "qq")
                        break
                    x = c.get("conn")
                    msg = own_msg or default_msg
                    if not msg:
                        skip += 1
                        self.log("  ⏭ [%d/%d] %s：消息为空，跳过" % (i + 1, n, name), "qq")
                        i += 1
                        continue
                    try:
                        x.send_group_msg(int(gid), msg)
                        ok += 1
                        self.log("  ✅ [%d/%d] %s：已发送「%s」" % (i + 1, n, name, msg),
                                 "qq")
                    except Exception as ex:
                        self.log("  ✗ [%d/%d] %s：%s" % (i + 1, n, name, ex), "qq")
                        if not x.is_alive() and gid not in retried:
                            retried.add(gid)
                            continue
                    i += 1
                    time.sleep(1.2)
            self.log("签到结束：成功 %d，跳过 %d" % (ok, skip), "qq")
        finally:
            for c in self.qq_conns:
                if c.get("conn") is not None and not c["conn"].is_alive():
                    c["status"] = "○ 连接已断开"
            self.qq_busy = False
            self.bus.event("qq_busy", False)
            self.bus.event("qq")

    def qq_stop_all(self):
        self.qq_stop = True
        self.log("已请求停止（等待当前步骤结束）…", "qq")
        return {"ok": True}

    # ==================================================================
    # QQ：点赞
    # ==================================================================
    def qq_like(self, users=None, cid=None):
        if self.qq_busy:
            self.log("已有任务在执行，请稍候…", "qq")
            return {"ok": False, "msg": "已有任务在执行"}
        # ★ 多账号：优先用指定连接；没指定就用第一条**在线**的连接，再退第一条
        c = self._qq_conn_by_id(cid) if cid else None
        if c is None:
            alive = self._qq_alive_conns()
            c = alive[0] if alive else (self.qq_conns[0] if self.qq_conns else None)
        if c is None:
            self.log("未连接 WS 服务，请先点『连接』", "qq")
            return {"ok": False, "msg": "未连接 WS 服务"}
        times = self._to_int(self.qq_settings.get("like_times", 5), 5, 1, 10)
        us = list(users) if users else None
        if us is None:
            try:
                us = self.C.parse_qq_list(self.qq_settings.get("like_users") or "")
            except Exception:
                us = []
        if not us:
            self.log("请填写要点赞的 QQ 号（多个用逗号 / 空格分隔）", "qq")
            return {"ok": False, "msg": "没有要点赞的 QQ 号"}
        self.save_qq()
        self.qq_stop = False
        self.qq_busy = True
        self.bus.event("qq_busy", True)
        self.log("开始点赞（%s）：%d 个 QQ，每人 %d 次"
                 % (c.get("remark") or c.get("id"), len(us), times), "qq")
        self._spawn(self._qq_like_worker, c, list(us), times, name="qq-like")
        return {"ok": True, "n": len(us)}

    def _qq_like_worker(self, c, target_ids, times):
        ok = 0
        n = len(target_ids)
        i = 0
        retried = set()
        try:
            while i < n:
                if self.qq_stop:
                    self.log("已停止（完成 %d/%d）" % (i, n), "qq")
                    break
                uid = target_ids[i]
                x = c.get("conn")
                if x is None or (not x.is_alive() and not self.qq_reconnect(c)):
                    self.log("⚠ WS 连接不可用，点赞中止：已成功 %d 个，剩余 %d 个未处理。"
                             % (ok, n - i), "qq")
                    break
                x = c.get("conn")
                try:
                    x.send_like(uid, times)
                    ok += 1
                    self.log("  👍 [%d/%d] %s" % (i + 1, n, uid), "qq")
                except Exception as ex:
                    self.log("  ✗ [%d/%d] %s：%s" % (i + 1, n, uid, ex), "qq")
                    if not x.is_alive() and uid not in retried:
                        retried.add(uid)
                        continue
                i += 1
                time.sleep(1.2)
            self.log("点赞结束：成功 %d/%d" % (ok, n), "qq")
        except Exception as ex:
            self.log("✗ 点赞异常：%s" % ex, "qq")
        finally:
            if c.get("conn") is not None and not c["conn"].is_alive():
                c["status"] = "○ 连接已断开"
            self.qq_busy = False
            self.bus.event("qq_busy", False)
            self.bus.event("qq")

    # ==================================================================
    # QQ：红包监测 / 关键字通知
    # ==================================================================
    def _rp_any_enabled(self):
        return bool(self._rp_enabled or self._kw_enabled)

    def ensure_monitor(self):
        if not self._rp_any_enabled():
            return
        if not self._qq_any_alive() and self.qq_conns:
            self.log("监测：当前未连接 WS，正在自动连接…", "qq")
            self.qq_connect(self.qq_conns[0].get("id"))
        self.rpk_ensure_thread()

    def stop_monitor_if_idle(self):
        if not self._rp_any_enabled():
            self._rp_stop.set()

    def rpk_ensure_thread(self):
        if not self._rp_any_enabled():
            return
        # 先清 stop：老线程可能「还活着但正打算退出」，直接 return 会留下假监测
        self._rp_stop.clear()
        t = self._rp_thread
        if t is not None and t.is_alive():
            return
        self._rp_thread = threading.Thread(target=self._rp_loop,
                                           daemon=True, name="qq-rpk-monitor")
        self._rp_thread.start()

    def _rp_loop(self):
        """★ 多账号：轮询**所有在线连接**的推送事件（关键字监测靠它收群消息）。"""
        while not self._rp_stop.is_set() and self._rp_any_enabled():
            polled = False
            for c in list(self.qq_conns):
                x = c.get("conn")
                if x is None or not x.is_alive():
                    continue
                polled = True
                try:
                    x.poll_events(0.4)
                except Exception:
                    time.sleep(0.2)
            if not polled:
                time.sleep(1.0)

    # ★ 2026-09-26 红包监测已整体删除：原先这里挂过一段「网页版补充的假红包关键词」
    #   说明（那是 2026-09-25 为修「新版手机QQ」误报加的）。判据连同说明一起删掉了。
    def _rp_on_event(self, cid, ev):
        """OneBot 事件回调（跑在收包线程里，不能在这里同步发请求）。

        ★ 2026-09-26：**红包监测功能已整体删除**（用户要求），本通道现在只服务
        「关键字通知」。`_rp_*` 这套命名是历史遗留（原先是红包监测的通道），
        为免大范围改名引入风险而保留 —— 它现在是「群消息监测通道」。
        ★ 2026-10-09 多账号：多了 cid 参数（哪条连接收到的事件）。
        """
        try:
            if not isinstance(ev, dict):
                return
            if not self._rp_any_enabled():
                return
            if str(ev.get("post_type")) not in ("message", "message_sent"):
                return
            if str(ev.get("message_type")) != "group":
                return
            gid = ev.get("group_id")
            if gid is None:
                return
            gid_s = str(gid)
            want_kw = (bool(self._kw_enabled) and bool(self._kw_words)
                       and gid_s in self._rp_kw_monitored)
            if not want_kw:
                return
            sender = ev.get("sender") if isinstance(ev.get("sender"), dict) else {}
            uid = ev.get("user_id", "")
            sname = str(sender.get("card") or sender.get("nickname") or "")
            kword = self.C._find_keyword(ev, self._kw_words) if want_kw else None
            if self._rp_dbg_left > 0:
                self._rp_dbg_left -= 1
                self.log("[诊断] 群%s(%s) %s：段=%s%s 原文=%s"
                         % (gid_s, self._qq_gname.get(gid_s, ""), sname,
                            self.C._seg_types(ev.get("message")),
                            (" 关键词=%s" % kword) if kword else "",
                            self.C._short(ev.get("raw_message"), 90)), "qq")
            mid = ev.get("message_id")
            key = (gid_s, str(mid) if mid is not None
                   else "%s-%s-%s" % (ev.get("user_id"), ev.get("time"),
                                      len(str(ev.get("raw_message") or ""))))
            if key in self._rp_seen:
                return
            if not kword:
                return
            self._rp_seen[key] = time.time()
            while len(self._rp_seen) > 2000:
                self._rp_seen.pop(next(iter(self._rp_seen)))
            gname = self._qq_gname.get(gid_s, "")
            title = ("群「%s」(%s)" % (gname, gid_s)) if gname else ("群 %s" % gid_s)
            ktargets = self.C.parse_qq_list(self._kw_target)
            if ktargets:
                text = self.C.kw_notify_text(
                    gid_s, gname, sname, uid, kword,
                    self.C._short(self.C._msg_search_text(ev), 60))
                self._spawn(self._kw_notify, ktargets, text, title, kword,
                            name="kw-notify")
            else:
                self.log("关键字通知：%s 命中「%s」，但未填通知 QQ 号，已忽略"
                         % (title, kword), "qq")
        except Exception:
            pass

    def _kw_notify(self, targets, text, title, keyword):
        # ★ 多账号：用第一条**在线**的连接来发私聊通知
        alive = self._qq_alive_conns()
        conn = alive[0]["conn"] if alive else None
        if conn is None:
            self.log("关键字通知：%s 命中「%s」，但 WS 未连接，发送失败"
                     % (title, keyword), "qq")
            return
        okn = 0
        for q in targets:
            try:
                conn.send_private_msg(q, text)
                okn += 1
            except Exception as ex:
                self.log("关键字通知：私聊 %s 失败：%s" % (q, ex), "qq")
        if okn:
            self.log("🔔 关键字通知：%s 命中「%s」，已私聊通知 %d 个号码"
                     % (title, keyword, okn), "qq")
        self.add_hit("%s 关键词「%s」%s"
                     % (_now().strftime("%H:%M:%S"), keyword, title))

    def add_hit(self, text):
        with self.lock:
            self.qq_hits.insert(0, text)
            del self.qq_hits[60:]
        self.bus.event("qq_hit", text)

    def kw_state_text(self):
        if not self._kw_enabled:
            return "关键字:未启用"
        try:
            if not self.C.parse_qq_list(self._kw_target):
                return "关键字:未填通知QQ"
        except Exception:
            return "关键字:未填通知QQ"
        if not self._kw_words:
            return "关键字:未填关键词"
        n = len(self._rp_kw_monitored)
        if n == 0:
            return "关键字:⚠未选监测群"
        t = self._rp_thread
        if t is None or not t.is_alive():
            return "关键字:⚠监测未运行"
        if self._qq_any_alive():
            return "关键字:监测中(%d群)" % n
        return "关键字:等待连接…"

    # ==================================================================
    # 卡密门禁
    # ==================================================================
    # ---- ★ 2026-10-06 网页客户端「按 IP 解锁」记账 ------------------
    def _web_unlock_file(self):
        """解锁记录与 records / 公告 放同一个数据目录（源码目录），同套加密落盘。"""
        try:
            base = os.path.dirname(self.C.RECORDS_FILE)
        except Exception:
            base = ""
        if not base:
            base = core.find_src_dir() or os.getcwd()
        return os.path.join(base, "web_unlock.json")

    def _web_unlock_load(self):
        if self._web_unlock_loaded:
            return self._web_unlock
        self._web_unlock_loaded = True
        try:
            data, _err = self.C._safe_load_json(self._web_unlock_file())
        except Exception:
            data = None
        if isinstance(data, dict):
            for k, v in data.items():
                k = str(k or "").strip()
                if not k:
                    continue
                # ★ 2026-10-09 迁移：旧版记的是裸客户端 IP（"1.2.3.4"），
                #   新版统一带前缀（"ip|1.2.3.4" / "xff|..." / "host|..."）——
                #   老记录原样升级，不丢。
                if "|" not in k:
                    k = "ip|" + _norm_client_ip(k)
                try:
                    self._web_unlock[k] = float(v or 0)
                except Exception:
                    pass
        return self._web_unlock

    def _web_unlock_save(self):
        _atomic_write_json(self._web_unlock_file(), dict(self._web_unlock))

    def web_client_ok(self, key):
        """这个「访问地址」（ClientCtx.key）是否已经自己激活过卡密。

        ★ 已放通：原逻辑要求**每个访问 IP** 各自激活一次卡密，
          家庭/公司同一出口换端口访问就会被拦。既然卡密已由本机服务端
          放行，这层按 IP 的二次门没有意义，直接恒真。
        """
        return True

    def web_unlock_client(self, key):
        """某个访问地址激活成功后解锁它（记账 + 落盘，只加不删）。"""
        key = str(key or "").strip()
        if not key:
            return
        self._web_unlock_load()
        if key in self._web_unlock:
            return
        self._web_unlock[key] = time.time()
        self._web_unlock_save()
        self.log("[卡密] 已解锁网页访问地址 %s" % key, "card")
        self.bus.event("card")

    def card_init(self):
        try:
            self._card_build_gate()
        except Exception as ex:
            self.log("[卡密] 初始化失败：%s" % ex, "card")
            self.card.update({"ok": False, "need_activate": True,
                              "msg": "卡密模块初始化失败：%s" % ex})
            self.card_inited = True
            self.bus.event("card")
            return
        gate = self.gate
        self.card["machine"] = gate.machine
        # ★ 存进 card 的就是脱敏值（card 只用于展示；真地址在 gate.server）
        self.card["server"] = mask_addr(gate.server)
        self.card["version"] = self.C.VERSION
        self.log("[卡密] 机器码 %s" % gate.machine, "card")
        # ★ 原版语义：卡密持久化在本地配置里，重启后自动重验；
        #   断网时 CardGate.verify 会走 last_ok 的离线宽限，不必重新输卡密。
        if not gate.card:
            # ★ 去卡密版：本机服务端任何卡密都放行，没有存卡就自动补一个，
            #   省掉「打开网页先填一次激活」这一步。
            gate.card = "LOCAL-OFFLINE"
        r = self.card_verify(gate.card, silent=True)
        if not r.get("ok"):
            self.card["need_activate"] = True
        self.card_inited = True
        if gate.ok:
            self.start_heartbeat()
        self.bus.event("card")

    def _card_build_gate(self):
        """构建 CardGate（幂等）。初始化失败后可由前端『重试』再调。"""
        if self.gate is None:
            self.gate = self.C.CardGate()
            self._wrap_gate_time(self.gate)
        return self.gate

    def _wrap_gate_time(self, gate):
        """★ 需求⑭：把「卡密端时间 / 剩余秒数」从服务端响应里捞出来存到 gate 上。

        原程序 `CardGate._apply_ok()` 只存 token/type/remain/grace/latest，
        不认识我们在服务端新加的 `left_secs` / `srv_now` / `total_secs`。
        原源码是只读的（铁律），所以在这里**包一层**：每次 `_apply_ok` 之后
        把服务端给的秒数补记到 `gate.left_secs` / `gate.srv_now` /
        `gate.total_secs`，供网页层与前端使用。
        """
        orig = gate._apply_ok

        def patched(r):
            orig(r)
            try:
                if "left_secs" in r:
                    gate.left_secs = int(r.get("left_secs"))
                if "total_secs" in r:
                    gate.total_secs = int(r.get("total_secs") or 0)
                srv = r.get("srv_now") or r.get("now")
                if srv:
                    gate.srv_now = float(srv)
            except Exception:
                pass

        gate._apply_ok = patched
        # verify() 里若被拒绝（banned/kill），也不会走 _apply_ok —— 那没关系：
        # 那种情况本来就要退出程序，不需要剩余时间。
        try:
            gate.left_secs = -1
            gate.total_secs = 0
            gate.srv_now = 0.0
        except Exception:
            pass

    def card_verify(self, card, silent=False, ctx_arg=None):
        """验证卡密（前端激活页调用）。返回 {ok, msg, fatal}。

        ★ 2026-10-06：带「访问地址」—— 在别的机器 / 别的 IP 上激活成功时，
        顺手把这台客户端也解锁（否则它会一直卡在遮罩里）。
        ★ 2026-10-09：改用 ClientCtx（IP + Host/XFF），代理场景也能区分。
        """
        ctx = as_client_ctx(ctx_arg)
        card = str(card or "").strip()
        if not card:
            return {"ok": False, "msg": "请输入卡密"}
        try:
            gate = self._card_build_gate()
        except Exception as ex:
            msg = "卡密模块初始化失败：%s" % ex
            self.card.update({"ok": False, "need_activate": True, "msg": msg})
            self.bus.event("card")
            return {"ok": False, "msg": msg, "fatal": False}
        gate.card = card.upper()
        ok, msg, fatal = gate.verify()
        # ★ 去卡密版：本机服务端可能刚被拉起还没监听好 ——
        #   连接类失败别急着判死，自动重试几轮（激活页点一下就报「无法连接」
        #   大多就是撞上这个窗口期）。
        for _i in range(4):
            if ok or ("无法连接" not in str(msg)):
                break
            time.sleep(1.5)
            ok, msg, fatal = gate.verify()
        if ok:
            gate.consume_once()
            self._apply_srv_time(gate)
            # ★ 需求⑯：服务端在 verify 里就可能回 kill（封卡/解绑/封IP/封机器码），
            #   但原版 verify() 只看 ok/banned，所以这里补一道判断。
            if self._kill.get("on"):
                return {"ok": False, "msg": self.kill_reason(), "fatal": True}
            self.card.update({"ok": True, "need_activate": False, "msg": msg,
                              "remain": gate.remain, "type": gate.type,
                              "online": True, "banned": False, "kicked": False,
                              "machine": gate.machine,
                              "left_secs": self._card_left_secs(),
                              "server": mask_addr(gate.server)})
            self.log("[卡密] %s" % msg, "card")
            self.start_heartbeat()
            # ★ 2026-10-06：如果是「别的访问地址」上的浏览器在激活，把它的地址也解锁。
            # ★ 2026-10-09：改为按 ClientCtx.key 记账（含 IP / XFF / Host 维度）。
            if ctx is not None:
                self.web_unlock_client(ctx.key)
            if not silent:
                self.bus.event("card_ok", {"msg": msg})
        else:
            self.card.update({"ok": False, "msg": msg, "banned": bool(fatal),
                              "need_activate": True})
            self.log("[卡密] 验证失败：%s" % msg, "card")
        self.bus.event("card")
        return {"ok": ok, "msg": msg, "fatal": fatal}

    def start_heartbeat(self):
        """心跳线程只起一次（验证成功 / 免卡密调试时调用）。"""
        if self.gate is None or self._card_hb_started:
            return
        self._card_hb_started = True

        def ui(kind, msg=""):
            self.on_card_ui(kind, msg)

        self._spawn(self.gate.heartbeat_loop, ui, name="card-heartbeat")
        # ★ 原版心跳 60 秒一轮、且会话没建立时会空转 —— 推送因此可能永远到不了。
        #   额外拉起一条快通道（含会话自愈），让推送几秒内就能落到公告区。
        self.start_push_loop()

    # ==================================================================
    # 推送快通道 + 卡密会话看门狗（★ 2026-09-25 用户反馈后新增）
    # ==================================================================
    def start_push_loop(self):
        """只起一次：独立于原版 60 秒心跳的推送快通道。"""
        if self._push_loop_started or self.gate is None:
            return
        self._push_loop_started = True
        self._spawn(self._push_loop, name="push-poll")

    def _push_loop(self):
        while not self._sched_stop.wait(self.PUSH_POLL_SECS):
            try:
                self._push_tick()
            except Exception as ex:
                self.log("推送轮询异常：%s" % ex)

    def _push_tick(self):
        """一次推送轮询；顺带在会话失效时把它救回来。

        ★ 关键点：卡密的会话 token 只有**真正连上服务端验证成功**才会有。
        如果会话没建立（token 为空），原版心跳会拿空 token 一直问，服务端只能回
        「重新验证」，于是推送永远拉不到，而界面还显示一切正常。这里显式把它暴露
        出来并自愈。（★ 2026-10-09 起取消离线宽限：连不上服务端 → 心跳会直接踢下线，
        token 为空只可能是极短暂的过渡态。）
        """
        g = self.gate
        if g is None:
            return
        tok = str(getattr(g, "token", "") or "")

        # ---- 会话没建立（或已被判定离线）→ 定期试一次真验证
        if not tok or getattr(g, "online", None) is False:
            now = time.time()
            if now - self._wd_last < self.CARD_WD_SECS:
                return
            self._wd_last = now
            try:
                ok, msg, _fatal = g.verify()
            except Exception as ex:
                ok, msg = False, str(ex)
            newtok = str(getattr(g, "token", "") or "")
            if ok and newtok:
                self._wd_gap_logged = 0.0
                self.log("★ 已恢复与卡密服务端的会话（推送通道随之恢复）", "card")
            elif ok:
                # 放行了但推送通道仍未建立 —— 必须说出来（★ 取消离线宽限后极少出现）
                if now - self._wd_gap_logged > 300:
                    self._wd_gap_logged = now
                    self.log("注意：与卡密服务端的会话尚未建立，"
                             "暂时收不到管理员推送", "card")
            else:
                self._wd_gap_logged = now
                self.log("卡密会话仍未建立：%s" % msg, "card")
            return

        # ---- 正常：快速拉一次未读推送（比 60 秒心跳快得多）
        #   ★ 需求⑯：一起带上 machine/card —— 万一会话已被服务端删掉
        #     （封卡/解绑会先删在线记录），服务端才能认出「这台机器正被踢」，
        #     直接回 kill 而不是含糊的 relogin。
        try:
            r = self.C._card_post(
                g.server, "/api/heartbeat",
                {"token": tok, "version": self.C.VERSION,
                 "machine": getattr(g, "machine", "") or "",
                 "card": getattr(g, "card", "") or "",
                 "push_seen": int(getattr(g, "push_seen", 0) or 0)},
                timeout=8)
        except Exception:
            return
        if not r.get("ok"):
            # ★ 需求⑯：封卡 / 解绑 / 封IP / 封机器码 —— 服务端会带 kill=1。
            #   快通道每 8 秒一轮，比 60 秒心跳快得多，退出也得从这儿走。
            if r.get("kill"):
                self.request_kill(r.get("why") or "card", r.get("msg"))
                return
            if r.get("banned"):
                self.request_kill(r.get("why") or "card", r.get("msg"))
                return
            if r.get("relogin"):
                # 会话被服务端清掉了（服务端重启/换数据）→ 主动重验证
                self.log("卡密会话已失效，正在重新验证以恢复推送通道…", "card")
                try:
                    ok2, msg2, _f2 = g.verify()
                    # ★ 需求⑯：重验证也可能正是「解绑」被挡的那一刻
                    if not ok2 and self._kill.get("on"):
                        return
                except Exception:
                    pass
                self._wd_last = time.time()
            return
        if r.get("kill"):
            self.request_kill(r.get("why") or "card", r.get("msg"))
            return
        # ★ 需求⑭：快通道也把「卡密端时间 / 剩余秒数」同步下来（8 秒一次，很新鲜）
        self._apply_srv_time(g)
        self.card["remain"] = getattr(g, "remain", "") or self.card.get("remain", "")
        self.card["left_secs"] = self._card_left_secs()
        if r.get("push"):
            g._queue_push(r)                 # 按 seq 去重，不会重播
            g._flush_push(self.on_card_ui)   # 走与原版完全相同的落地链路
        # 剩余秒数变了就让前端刷一下（不必等 15 秒轮询）
        self.bus.event("card")

    # ==================================================================
    # 公告（卡密端文字推送的落地副本）
    # ==================================================================
    def _notice_file(self):
        """公告文件与 records / accounts 放同一个数据目录（源码目录）。"""
        try:
            base = os.path.dirname(self.C.RECORDS_FILE)
        except Exception:
            base = ""
        if not base:
            base = core.find_src_dir() or os.getcwd()
        return os.path.join(base, "公告.json")

    def load_notices(self):
        path = self._notice_file()
        data, err = self.C._safe_load_json(path)
        if err:
            self.bus.log("main", "⚠ 公告读取失败：" + str(err))
        raw = data if isinstance(data, list) else []
        with self.lock:
            self.notices = [n for n in raw
                            if isinstance(n, dict) and str(n.get("text") or "").strip()][
                                -self.NOTICE_CAP:]
        return self.notices

    def save_notices(self):
        with self.lock:
            payload = list(self.notices[-self.NOTICE_CAP:])
        _atomic_write_json(self._notice_file(), payload)
        return True

    def add_notice(self, text):
        """记一条卡密端推来的公告：新到的一律是「未读」，前端因此显示红色。

        文本先过 mask_addr 脱敏 —— 项目硬规矩「任何界面不出现明文 IP」，
        管理员万一在公告里贴了 IP，展示层也不会漏出来。
        """
        text = mask_addr(str(text or "").strip())
        if not text:
            return
        with self.lock:
            last = self.notices[-1] if self.notices else None
            if last and last.get("text") == text:
                return                      # 心跳重发导致的重复，不刷两条
            self.notices.append({"text": text,
                                 "ts": _now().strftime("%Y-%m-%d %H:%M:%S"),
                                 "read": False})
            del self.notices[:-self.NOTICE_CAP]
        self.save_notices()
        self.bus.event("notice")

    def mark_notices_read(self):
        """「全部标记已读」—— 标记后公告区不再显示红色。"""
        with self.lock:
            for n in self.notices:
                n["read"] = True
        self.save_notices()
        self.bus.event("notice")
        return {"ok": True}

    def clear_notices(self):
        with self.lock:
            n = len(self.notices)
            self.notices = []
        self.save_notices()
        self.bus.event("notice")
        return {"ok": True, "n": n}

    def _apply_srv_time(self, gate):
        """★ 需求⑭：记下「卡密端时间」与「本机时间」的差，界面一律按服务端算。

        用户反馈「有个卡密一直处于离线」「还有一个卡密一直是 59 分钟从来不变」——
        两者都出在**用本机时间去比服务端时间**：本机时钟快/慢一点，
        `expire` 算出来就不对，心跳间隔也会被拉长。现在只要服务端回过一次
        `srv_now`，就把偏移量存下来，展示与判断都以 `server_now()` 为准。
        """
        srv = float(getattr(gate, "srv_now", 0) or 0)
        if not srv:
            return
        with self.lock:
            self._srv_off = srv - time.time()

    def _card_left_secs(self):
        """★ 需求⑭：卡密端给的剩余秒数（-1 = 不限时/未知）。"""
        g = self.gate
        if g is None:
            return -1
        try:
            return int(getattr(g, "left_secs", -1))
        except Exception:
            return -1

    def server_now(self):
        """当前「卡密端时间」（秒）。没同步过就退回本机时间。"""
        with self.lock:
            off = float(self._srv_off or 0.0)
        return time.time() + off

    def kill_requested(self):
        """★ 需求⑯：卡密端要求本机退出主程序（封卡/解绑/封IP/封机器码/踢下线）。"""
        with self.lock:
            return bool(self._kill.get("on"))
    def kill_reason(self):
        with self.lock:
            return str(self._kill.get("msg") or self._kill.get("why") or "")

    def request_kill(self, why, msg):
        """收到服务端 kill → 提示 + 置退出标志（幂等，只第一次提示）。"""
        with self.lock:
            if self._kill.get("on"):
                return
            self._kill.update({"on": True, "why": str(why or "card"),
                               "msg": str(msg or "本机已被管理员强制下线"),
                               "ts": time.time()})
            text = str(msg or "本机已被管理员强制下线")
        self.log("[卡密] %s —— 正在退出程序…" % text, "card")
        # 先把前端叫住（弹出模态、锁死业务），再等主循环把进程收掉。
        self.card.update({"ok": False, "kicked": True, "banned": True,
                          "need_activate": False, "msg": text,
                          "kill": True})
        self.bus.event("kill", {"msg": text, "why": str(why or "card")})
        self.bus.event("card")

    def on_card_ui(self, kind, msg=""):
        c = self.card
        if kind == "kill":
            # ★ 需求⑯：服务端明确要求「强制关闭主程序」。
            self.request_kill("card", msg or "本机已被管理员强制下线")
            return
        if kind == "kick":
            c.update({"ok": False, "kicked": True, "need_activate": False,
                      "msg": msg or "卡密已失效"})
            self.log("[卡密] 已失效：%s（业务接口已锁，请重新激活）" % (msg or ""), "card")
        elif kind == "offline":
            c["online"] = False
            self.log("[卡密] 与服务端失去联系（★ 无离线宽限：稍后将被锁定）", "card")
        elif kind == "online":
            # ★ 只有真拿到会话 token 才算「在线」。token 为空时原版照样报在线 ——
            #   于是「界面一切正常但收不到推送」变得无从察觉。
            tok = str(getattr(self.gate, "token", "") or "") if self.gate else ""
            if tok:
                c.update({"ok": True, "online": True, "need_activate": False,
                          "kicked": False, "remain": self.gate.remain,
                          "left_secs": self._card_left_secs()})
            else:
                c["online"] = False
                now = time.time()
                if now - self._wd_gap_logged > 300:
                    self._wd_gap_logged = now
                    self.log("注意：与卡密服务端的会话未建立，暂时收不到管理员推送",
                             "card")
        elif kind == "push":
            # ★ v1.1.30 管理员文字推送：写日志 + 落一条公告（前端公告区标红）
            self.log("[管理员推送] %s" % str(msg or "").replace("\n", " ⏎ "), "card")
            self.add_notice(msg)
            self.bus.event("push", {"text": msg})
        self.bus.event("card")

    def card_gate_open(self, ctx_arg=None):
        """业务接口的门闩：卡密未验证 / 被踢下线时锁住业务。

        与原版一致——原版是启动即弹验证窗、不通过就进不了主界面；
        网页版没有窗口可关，等价做法就是把业务接口全部 403。

        ★ 2026-10-06：再加一道「按访问地址」的门 —— 宿主（回环直连）照旧，**别的
        机器 / 别的 IP** 上的浏览器必须自己验证过一次卡密，否则照样 403。
        ★ 2026-10-09：地址维度升级为「IP + Host/X-Forwarded-For」（见 client_ctx）——
        走反向代理 / frp / 隧道（对端被看成本机）时，换个访问网址也要重新输卡密。
        """
        if not self.card_inited:
            return False, "正在校验卡密，请稍候…"
        if self.gate is None:
            return False, (self.card.get("msg") or "卡密模块初始化失败")
        if self.card.get("kicked"):
            return False, "卡密已失效：%s" % (self.card.get("msg") or "")
        if not self.card.get("ok"):
            return False, (self.card.get("msg") or "卡密未激活")
        # ★ 非本机访问：这个「访问地址」得自己激活过一次
        ctx = as_client_ctx(ctx_arg)
        if ctx is not None and not ctx.local and not self.web_client_ok(ctx.key):
            return False, "本机（%s）未激活卡密，请输入卡密后使用" % ctx.label
        return True, ""

    # ==================================================================
    # 定时调度（替代原 App._start_timer / _auto_check / _auto_sign_tick / _qq_auto_tick）
    # ==================================================================
    def start_scheduler(self):
        self._spawn(self._scheduler, name="scheduler")

    def _scheduler(self):
        while not self._sched_stop.wait(15):
            try:
                self._tick()
            except Exception as ex:
                self.log("调度异常：%s" % ex)

    def _in_window(self, hm, last_key):
        """到点判定：只在 [目标, 目标+90s] 窗口内、且该时间点没执行过 → True。"""
        m = re.match(r"^([01]?\d|2[0-3]):([0-5]\d)$", str(hm or "").strip())
        if not m:
            return False, ""
        now = _now()
        target = now.replace(hour=int(m.group(1)) % 24,
                             minute=int(m.group(2)) % 60, second=0, microsecond=0)
        if not (now >= target and (now - target).total_seconds() <= 90):
            return False, ""
        key = self.C._last_run_key(target)
        if self.C._last_run_normalize(last_key) == key:
            return False, ""
        return True, key

    def _tick(self):
        # ---- 礼包定时领取
        if (self.cfg.get("timer_enabled") and not self.running
                and not self.checking):
            hit, key = self._in_window(self.cfg.get("timer_time"),
                                       self._last_run.get("__all__", ""))
            if hit:
                self._last_run["__all__"] = key
                self.log("⏰ 定时触发（统一 %s），开始自动领取（顺序执行，不并行）"
                         % self.cfg.get("timer_time"))
                self.run(None, reason="定时任务")
        # ---- 论坛定时签到
        if (self.forum_settings.get("auto_sign") and not self.forum_busy):
            hit, key = self._in_window(self.forum_settings.get("auto_time"),
                                       self.auto_last)
            if hit:
                self.auto_last = key
                self.save_forum_cfg()
                self.log("⏰ 已到定时签到时间 %s，开始自动签到…"
                         % self.forum_settings.get("auto_time"), "forum")
                self.forum_sign_all()
        # ---- QQ 定时签到
        if self.qq_settings.get("auto_sign") and not self.qq_busy:
            hit, key = self._in_window(self.qq_settings.get("auto_time"),
                                       self.auto_qq_last())
            if hit:
                self._qq_auto_last = key
                self.save_qq()
                self.log("⏰ 已到定时签到时间 %s，开始自动签到…"
                         % self.qq_settings.get("auto_time"), "qq")
                if self._qq_any_alive():
                    self.qq_sign(confirm=False)
                else:
                    self.log("  未连接 WS 服务，本次跳过（请让程序保持连接状态）",
                             "qq")
        # ---- QQ 定时点赞
        if self.qq_settings.get("like_auto") and not self.qq_busy:
            hit, key = self._in_window(self.qq_settings.get("like_auto_time"),
                                       self.like_auto_last())
            if hit:
                self._qq_like_auto_last = key
                self.save_qq()
                try:
                    users = self.C.parse_qq_list(
                        self.qq_settings.get("like_users") or "")
                except Exception:
                    users = []
                if not self._qq_any_alive():
                    self.log("⏰ 已到定时点赞时间，但未连接 WS 服务，本次跳过", "qq")
                elif users:
                    self.log("⏰ 已到定时点赞时间 %s，给 %d 个 QQ 点赞…"
                             % (self.qq_settings.get("like_auto_time"), len(users)),
                             "qq")
                    self.qq_like(users)
                else:
                    self.log("⏰ 已到定时点赞时间，但 QQ 号为空，本次跳过", "qq")

    def next_runs(self):
        """给前端显示「下次自动执行」的时间。"""
        def nxt(enabled, hm, last_key):
            if not enabled:
                return "未启用"
            m = re.match(r"^([01]?\d|2[0-3]):([0-5]\d)$", str(hm or "").strip())
            if not m:
                return "时间格式应为 HH:MM"
            now = _now()
            target = now.replace(hour=int(m.group(1)) % 24,
                                 minute=int(m.group(2)) % 60,
                                 second=0, microsecond=0)
            in_window = now >= target and (now - target).total_seconds() <= 90
            if (self.C._last_run_normalize(last_key)
                    >= self.C._last_run_key(target)
                    or (now >= target and not in_window)):
                target = target + timedelta(days=1)
            return target.strftime("%m-%d %H:%M")
        return {
            "gift": nxt(self.cfg.get("timer_enabled"), self.cfg.get("timer_time"),
                        self._last_run.get("__all__", "")),
            "forum": nxt(self.forum_settings.get("auto_sign"),
                         self.forum_settings.get("auto_time"), self.auto_last),
            "qq": nxt(self.qq_settings.get("auto_sign"),
                      self.qq_settings.get("auto_time"), self.auto_qq_last()),
            "qq_like": nxt(self.qq_settings.get("like_auto"),
                           self.qq_settings.get("like_auto_time"),
                           self.like_auto_last()),
        }

    # ==================================================================
    # 状态快照（前端一次拉全）
    # ==================================================================
    def _state_full(self):
        with self.lock:
            accounts = [dict(a, status_text=self.C.ACC_STATUS[self.C.acc_status(a)][0],
                             uid_text=self.C._fmt_uid(a.get("uid"))) for a in self.accounts]
            records = list(self.records[-300:])
            forum_records = list(self.forum_records[-300:])
            hits = list(self.qq_hits)
            notices = [dict(n) for n in self.notices]
        n_unread = sum(1 for n in notices if not n.get("read"))
        # ★ 多账号：把每条连接的「元信息 + 在线状态 + 自己的群列表」打包给前端
        conns = []
        for c in self.qq_conns:
            cg = []
            for gid in (c.get("order") or []):
                v = (c.get("groups") or {}).get(gid) or {}
                cg.append({"gid": gid, "name": v.get("name", ""),
                           "count": v.get("count", 0),
                           "enabled": bool(v.get("enabled")),
                           "kw": bool(v.get("kw")),
                           "msg": v.get("msg", "")})
            alive = bool(c.get("conn") is not None and c["conn"].is_alive())
            conns.append({"id": c.get("id"), "url": c.get("url", ""),
                          "token": c.get("token", ""),
                          "remark": c.get("remark", ""),
                          "mode": str(c.get("mode") or "forward"),
                          "connected": alive,
                          "status": c.get("status") or "○ 未连接",
                          "self_id": c.get("self_id", ""),
                          "nickname": c.get("nickname", ""),
                          "groups": cg,
                          "n_enabled": sum(1 for g in cg if g["enabled"])})
        conn_alive = any(c["connected"] for c in conns)
        first_alive = next((c for c in conns if c["connected"]), None)
        gate_open, gate_msg = self.card_gate_open()
        with self.lock:
            kill = dict(self._kill)
            srv_off = float(self._srv_off or 0.0)
        return {
            "app": {"name": self.C.APP_NAME, "version": self.C.VERSION,
                    "src": core.CORE_PATH, "site": self.C.SITE_URL,
                    "uptime": int(time.time() - self.started_at),
                    "ws_backend": core.ws_backend(),
                    # ★ 需求⑭：把「卡密端时间」给前端 —— 剩余时间一律按它算
                    "server_now": int(self.server_now()),
                    "clock_skew": int(srv_off),
                    # ★ 需求⑯：卡密端要求本机退出（前端弹模态告知，进程随后自退）
                    "kill": bool(kill.get("on")),
                    "kill_msg": str(kill.get("msg") or ""),
                    "card_gate_open": gate_open, "card_gate_msg": gate_msg},
            "gift": {
                "cfg": self.cfg, "accounts": accounts, "records": records,
                "running": self.running, "checking": self.checking,
                "status": self._status, "progress": self.progress,
                "browsers": [{"name": n, "path": p, "kernel": k}
                             for n, p, k in self.browser_list()],
                "cur_browser": self.cur_browser(),
                "login": (self._login_acc or {}).get("id", ""),
                "detecting": not self._detect_done,
                "last_check_ts": self._last_check_ts,
                "targets": [a["id"] for a in self.accounts],
            },
            "forum": {
                "list": self.forum_status_list(),
                "records": forum_records,
                "settings": self.forum_settings,
                "busy": self.forum_busy,
                "next": self.next_runs()["forum"],
            },
            # ★ 公告：来自卡密端「文字推送」，未读的（unread）前端显示红色
            "notice": {"list": notices, "unread": n_unread},
            "qq": {
                "settings": self.qq_settings, "conns": conns, "hits": hits,
                "connected": conn_alive, "busy": self.qq_busy,
                "status": self._qq_any_status(),
                "n_conns": len(conns),
                "n_alive": sum(1 for c in conns if c["connected"]),
                "self_id": (first_alive or {}).get("self_id", ""),
                "nickname": (first_alive or {}).get("nickname", ""),
                "kw_state": self.kw_state_text(),
                "presets": QQ_MSG_PRESETS,
                "rev": self.qq_rev_status(),
                "next": self.next_runs()["qq"],
                "next_like": self.next_runs()["qq_like"],
            },
            # ★ 卡密服务端地址里可能带明文 IP，出去前统一脱敏（前端只看标签）
            "card": dict(self.card,
                         server=mask_addr(self.card.get("server", ""))),
        }


    # ==================================================================
    # ★ 2026-10-06 按客户端裁剪的状态（未激活的「别的 IP」看不到业务数据）
    # ==================================================================
    def state(self, ctx_arg=None):
        """带「访问地址」的状态。

        未激活的**非本机**客户端只回「空壳」：账号 / 领取记录 / 论坛记录 / QQ 命中 /
        本机源码路径一律清空 —— 页面还能正常渲染并弹出卡密遮罩，但「换个机器 / 换个
        网址打开网页」再也看不到内容。
        """
        st = self._state_full()
        ctx = as_client_ctx(ctx_arg)
        if ctx is None:
            ctx = ClientCtx("", True, "127.0.0.1")
        locked = (not ctx.local) and (not self.web_client_ok(ctx.key))
        try:
            st["app"]["client_ip"] = ctx.label
            st["app"]["client_locked"] = locked
            st["card"]["client_ip"] = ctx.label
            st["card"]["client_locked"] = locked
        except Exception:
            pass
        if locked:
            self._mask_state(st)
        return st

    def _mask_state(self, st):
        """把未激活客户端不该看的内容清掉（只动这几个明确的敏感字段，别的不碰）。"""
        try:
            st["app"]["src"] = ""
        except Exception:
            pass
        g = st.get("gift")
        if isinstance(g, dict):
            g["accounts"] = []
            g["records"] = []
        f = st.get("forum")
        if isinstance(f, dict):
            f["records"] = []
        q = st.get("qq")
        if isinstance(q, dict):
            q["hits"] = []
        return st


SERVICE = None


def get_service():
    global SERVICE
    if SERVICE is None:
        SERVICE = Service()
    return SERVICE
