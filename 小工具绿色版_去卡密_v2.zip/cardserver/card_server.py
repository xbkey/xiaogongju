# -*- coding: utf-8 -*-
"""小工具 v1.4.x 自建卡密服务端（离线 / 纯标准库 / 零第三方依赖）。

为什么必须走「自建服务端」这条路，而不是照旧 patch 客户端
--------------------------------------------------------
v1.4.2 把两样本来在客户端的东西搬到了服务端，这是它跟旧版（v1.3 之前）的根本差别：

  1) K_data —— 账号池 / cookie 池 / 本地配置的**唯一业务密钥**。
     它由 /api/verify 下发，只存内存不落盘。`_data_key()` 的三条出口写死了：
       有 K_data 且在租约内 → 用它；否则 → 返回一把跟真密钥无关的「死密钥」。
     作者甚至在注释里点名：「patch 掉校验 = 拿不到 K_data = 账号池 HMAC 不过」
     （zsf_gift_grabber.py:309）。所以本地改分支只会得到一个打不开账号的空壳。

  2) 作业配方 —— 「点哪个按钮、调哪个接口、表单怎么拼」的 6 段 JS。
     v1.4.0 起从客户端源码里删除（见 zsf_gift_grabber.py:3337），改由服务端
     用 K_job = HMAC(K_data, "job|"+job) 加密下发。没有它，领礼包一步都走不动。

好消息：`CardGate.__init__` 里服务端地址的优先级是
        本机加密配置 card_config.json 的 server_enc  >  内置默认地址
所以**只要把配置里的地址指到本机**，官方服务端就被绕过，K_data 与配方由我们签发。

本机端要 pair 的三处细节（错一处客户端就拒绝）
  · K_data 必须**持久化**：账号池是用它加密落盘的，服务端每重启换一把，
    用户录过的账号就永远解不开了。这里落成同目录 kdata.bin。
  · **绝不下发** k_rotate_secs / k_keep：`_kdata_valid()` 见到 0 就不做过期判断，
    于是绕开作者设的「12 小时不下心跳账号池自锁」。
  · latest 给 {}：客户端不会再去拉更新包替换自己。

用法
    python card_server.py                 # 监听 127.0.0.1:8765
    python card_server.py --port 9001     # 换端口（客户端配置要跟着换）
"""
import argparse
import base64
import hashlib
import hmac
import json
import os
import random
import struct
import sys
import threading
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

HERE = os.path.dirname(os.path.abspath(__file__))
KDATA_FILE = os.path.join(HERE, "kdata.bin")
RECIPE_FILE = os.path.join(HERE, "recipe_gift.json")

# 必须与客户端逐字节一致
DATA_MAGIC = b"ZSFENC01"
# v1.3.0 之前的老客数据密钥（= v1.4.x 源码里的 _legacy_data_key）。
# 放进 k_data_prev 是为了让 _reseal_all_pools() 能把旧密钥封的账号池
# 迁移到我们签发的 K_data 下，不至于一换服务端就把老账号读成「无账号」。
LEGACY_PSK = "zsfEcard-psk-2026-8f3a1c"

_lock = threading.RLock()
_STATE = {"kdata": b"", "token": "", "job_no": 0, "clients": {}}

_LOG_LINES = []
_LOG_LOCK = threading.Lock()
MAX_LOG = 400


# ------------------------------------------------------------------ 基础工具
def _log(msg):
    line = "[%s] %s" % (time.strftime("%H:%M:%S"), msg)
    with _LOG_LOCK:
        _LOG_LINES.append(line)
        del _LOG_LINES[:-MAX_LOG]
    try:
        sys.stdout.write(line + "\n")
        sys.stdout.flush()
    except Exception:
        pass


def legacy_key():
    return hashlib.sha256(("zsf-local-data|" + LEGACY_PSK).encode("utf-8")).digest()


def load_kdata():
    """读取（必要时生成）持久化的 K_data —— 32 字节，重启不变。"""
    with _lock:
        if _STATE["kdata"]:
            return _STATE["kdata"]
        kd = b""
        try:
            if os.path.isfile(KDATA_FILE):
                with open(KDATA_FILE, "rb") as f:
                    raw = f.read()
                if len(raw) == 32 and raw != b"\x00" * 32:
                    kd = raw
        except Exception as ex:
            _log("读取 kdata.bin 失败：%s" % ex)
        if not kd:
            kd = os.urandom(32)
            try:
                with open(KDATA_FILE, "wb") as f:
                    f.write(kd)
                os.chmod(KDATA_FILE, 0o600)
            except Exception as ex:
                _log("写入 kdata.bin 失败：%s（本次随机，重启后旧账号会读不出）" % ex)
            _log("首次运行：已生成业务密钥 K_data -> kdata.bin")
        _STATE["kdata"] = kd
        return kd


def xor_stream(key, nonce, data):
    """SHA256 计数器流（与客户端 zsf_gift_grabber._xor_stream 同构）。"""
    out = bytearray(len(data))
    ctr = off = 0
    while off < len(data):
        ks = hashlib.sha256(key + nonce + struct.pack(">I", ctr)).digest()
        chunk = min(32, len(data) - off)
        for i in range(chunk):
            out[off + i] = data[off + i] ^ ks[i]
        off += 32
        ctr += 1
    return bytes(out)


def encrypt(plain, key):
    """与客户端 _file_encrypt 完全一致：MAGIC + nonce(16) + tag(16) + ct。"""
    nonce = os.urandom(16)
    ct = xor_stream(key, nonce, plain)
    tag = hmac.new(key, nonce + ct, hashlib.sha256).digest()[:16]
    return DATA_MAGIC + nonce + tag + ct


def job_key(kd, job):
    """K_job = HMAC(K_data, "job|"+job)（客户端 _job_key）。"""
    return hmac.new(kd, ("job|" + str(job)).encode("utf-8"),
                    hashlib.sha256).digest()


def load_recipe():
    """作业配方（6 段「怎么抢」的 JS，从旧版源码抽出）。"""
    try:
        with open(RECIPE_FILE, "r", encoding="utf-8") as f:
            r = json.load(f)
    except Exception as ex:
        _log("配方读取失败：%s —— 客户端会报「配方不完整」" % ex)
        return {}
    missing = [k for k in ("js_click", "js_has_form", "js_modal",
                           "js_partition", "js_receive", "js_close")
               if not str(r.get(k) or "").strip()]
    if missing:
        _log("配方缺字段：%s" % "、".join(missing))
    return r


def _new_token():
    tok = base64.b16encode(os.urandom(16)).decode("ascii").lower()
    _STATE["token"] = tok
    return tok


# ------------------------------------------------------------------ 业务响应
def _ok_base():
    kd = load_kdata()
    return {
        "ok": 1,
        "token": _STATE["token"] or _new_token(),
        "type": "time",
        "remain": "永久",
        # ---- 命门：业务密钥（账号池 / cookie 池 / 配置全靠它）
        "k_data": base64.b64encode(kd).decode("ascii"),
        "k_data_prev": base64.b64encode(legacy_key()).decode("ascii"),
        "k_epoch": 1,
        # ★ 故意不带 k_rotate_secs / k_keep —— 客户端 _kdata_valid() 见到 0
        #   就不做「租约过期」判断，账号池因此不会在 12 小时后自锁。
        "grace_hours": 0,
        # ---- 网页层用：剩余秒数 / 服务端时间
        "left_secs": -1,
        "total_secs": 0,
        "srv_now": time.time(),
        # ---- 不给更新包，免得客户端把自己替换回去
        "latest": {},
    }


def rsp_challenge(body):
    return {"ok": 1, "nonce": os.urandom(16).hex()}


def rsp_verify(body):
    card = str((body or {}).get("card") or "").strip()
    machine = str((body or {}).get("machine") or "")[:12]
    r = _ok_base()
    # ★ 每次新 session 换 token，行为上跟真服务端一致
    r["token"] = _new_token()
    r["msg"] = "验证通过"
    _log("verify  card=%s machine=%s -> 放行" % (card or "(空)", machine or "?"))
    return r


def rsp_heartbeat(body):
    r = _ok_base()
    r["msg"] = "ok"
    return r


def rsp_consume(body):
    return {"ok": 1, "msg": "ok"}


def rsp_job(body):
    kind = str((body or {}).get("kind") or "gift")
    recipe = load_recipe()
    _STATE["job_no"] += 1
    job = "%08x%s" % (_STATE["job_no"], os.urandom(6).hex())
    pack = {"job": job, "recipe": {kind: recipe}}
    try:
        blob = json.dumps(pack, ensure_ascii=False).encode("utf-8")
    except Exception as ex:
        return {"ok": 0, "msg": "配方打包失败：%s" % ex}
    ct = encrypt(blob, job_key(load_kdata(), job))
    return {
        "ok": 1,
        "job": job,
        "ttl": 31536000,            # 1 年：票据不会中途过期
        "recipe_ct": base64.b64encode(ct).decode("ascii"),
        "recipe_ver": _STATE["job_no"],
        "sig": "",
    }


ROUTES = {
    "challenge": rsp_challenge,
    "verify": rsp_verify,
    "heartbeat": rsp_heartbeat,
    "consume": rsp_consume,
    "job": rsp_job,
}


# ------------------------------------------------------------------ HTTP
class Handler(BaseHTTPRequestHandler):
    protocol_version = "HTTP/1.1"
    server_version = "zsf-card-local/1.0"

    def log_message(self, fmt, *args):
        pass                       # 自带日志，别用默认的刷屏

    def _reply(self, obj, code=200):
        data = json.dumps(obj, ensure_ascii=False).encode("utf-8")
        self.send_response(code)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(data)))
        self.end_headers()
        try:
            self.wfile.write(data)
        except Exception:
            pass

    def do_POST(self):
        path = self.path.split("?", 1)[0].rstrip("/")
        name = path.rsplit("/", 1)[-1]
        n = 0
        try:
            n = int(self.headers.get("Content-Length") or 0)
        except ValueError:
            n = 0
        raw = self.rfile.read(n) if n > 0 else b""
        body = {}
        if raw:
            try:
                body = json.loads(raw.decode("utf-8"))
            except Exception:
                body = {}
        fn = ROUTES.get(name)
        if fn is None:
            _log("未知接口 %s（来自 %s）" % (path, self.client_address[0]))
            return self._reply({"ok": 0, "msg": "no such route"}, 404)
        try:
            self._reply(fn(body))
        except Exception as ex:
            _log("处理 %s 出错：%s" % (name, ex))
            self._reply({"ok": 0, "msg": str(ex)}, 500)

    def do_GET(self):
        path = self.path.split("?", 1)[0].rstrip("/")
        if path.endswith("/api/challenge"):
            return self._reply(rsp_challenge({}))
        if path.endswith("/api/ping"):
            return self._reply({"ok": 1, "ts": time.time()})
        return self._reply({"ok": 0, "msg": "no such route"}, 404)


def pick_port(host, port):
    """端口被占就 +1 顺延（跟客户端同款策略）。"""
    import socket
    for _ in range(50):
        s = socket.socket()
        s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        try:
            s.bind((host, port))
            s.close()
            return port
        except OSError:
            s.close()
            port += 1
    raise SystemExit("找不到可用端口")


def main():
    ap = argparse.ArgumentParser(description="小工具 自建卡密服务端")
    ap.add_argument("--host", default="127.0.0.1")
    ap.add_argument("--port", type=int, default=8765)
    args = ap.parse_args()

    kd = load_kdata()
    recipe = load_recipe()
    port = pick_port(args.host, args.port)

    print("=" * 58)
    print("  小工具 自建卡密服务端（离线）")
    print("=" * 58)
    print("  监听     : http://%s:%d" % (args.host, port))
    print("  业务密钥 : %s…（kdata.bin，重启不变）"
          % base64.b64encode(kd).decode("ascii")[:16])
    print("  旧密钥兜 : 已挂 k_data_prev（旧账号池可自动迁移）")
    print("  作业配方 : %d 段%s" % (len(recipe),
                                "" if len(recipe) == 6 else "  ← 不足 6 段，客户端会拒绝"))
    print("  租约限制 : 已关闭（不下发 k_rotate_secs，12h 自锁失效）")
    print("-" * 58)
    print("  卡密随便填，任意字符都能通过。Ctrl+C 停止。")
    print("=" * 58)

    srv = ThreadingHTTPServer((args.host, port), Handler)
    srv.daemon_threads = True
    t = threading.Thread(target=srv.serve_forever, daemon=True)
    t.start()
    try:
        while True:
            time.sleep(1)
    except KeyboardInterrupt:
        _log("正在停止…")
        srv.shutdown()


if __name__ == "__main__":
    main()
