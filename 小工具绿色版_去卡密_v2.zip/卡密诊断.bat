@echo off
chcp 65001 >nul
cd /d "%~dp0"
where python >nul 2>nul
if errorlevel 1 (
    echo [!] 没检测到 Python，请先安装 Python 3.8 以上
    pause & exit /b 1
)
python "%~dp0diag_card.py"
echo.
pause
